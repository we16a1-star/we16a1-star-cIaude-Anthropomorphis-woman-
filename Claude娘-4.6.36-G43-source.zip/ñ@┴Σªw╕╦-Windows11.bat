@echo off
setlocal
call "%~dp0app\BUILD-WINDOWS11-AUTO.bat"
exit /b %errorlevel%
