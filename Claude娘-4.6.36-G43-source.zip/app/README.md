# Claude娘的書庫：AI 即時演算戀愛文字小說

角色預設名稱為「Claude娘」。每個故事回合都由使用者選定的 AI 服務根據玩家行動、完整存檔記憶、角色人格與好感度即時生成，不以固定劇本假裝 AI 回覆。新存檔預設使用 AI 官方網站免費版，不需要 API Key；開始前可選擇 ChatGPT、Claude、Gemini 等網站與序章風格。App 會保存待辦回合、準備並複製提示詞、開啟所選官方網站；網站登入、模型選擇、送出與複製回覆由玩家依照按鍵提醒操作。最少桌面操作是官網輸入框 Ctrl+V、Enter，生成後按官網「複製」，再 Alt+Tab 回遊戲按 Ctrl+V；App 直接驗證、保存並續寫，不必另按「套用」。Android 版則按「一鍵讀取已複製回覆並接續」。剪貼簿只在使用者明確觸發時讀取。若 AI 尚未完成回合，故事停在原處保存玩家行動，切換網站、帳號或 AI 模式後可重試同一回合。選用 API 模式才需自行設定 API Key，Windows 桌面版會啟動本機 AI 後端並以 Windows 加密服務保存金鑰。

新故事可挑選 14 種具體序章，再選「完全隨機」交由 AI 自行決定事件、地點、氣氛與相遇方式，或選「自由自訂」輸入不超過 600 字的開場靈感。完全隨機和自訂序章都照常生成 7 個故事選項；玩家自訂方向只會附在第一回合提示中，不會消耗後續回合的額外提示額度。

設定提供「快速回覆」與「詳細回覆」兩種策略。快速模式縮短重複提示、保留最近 2 則對話並限制 API 輸出額度；詳細模式保留最近 4 則。每回合新生成的故事正文至少 500 字（含標點），可以更長；App 會驗證，不足時提示修復。字數只計正文，不含 JSON、選項或記憶。預設角色、世界和規則會使用精簡等義提示，自訂設定、玩家行動、完整記憶及近期情節仍保留；AI 依故事因果安排事件與結局。

API 模型選單提供 Claude Fable 5（`claude-fable-5`）及 GPT-6 Astra、Sol、Luna（`gpt-6-astra`、`gpt-6.1-sol`、`gpt-6.1-terra`、`gpt-6-luna`）。這些型號以各自官方 API 帳號呼叫；方案權限、配額與費用依帳戶而定。提示詞會刪除重複的內建說明，保留自訂角色／世界／規則、記憶、快速／詳細模式原有的近期對話、玩家行動、500 字正文要求及 7 個選項。Claude Fable 5 API 使用供應商提示快取重用固定指示；GPT-6 使用 OpenAI 自動提示快取。快取命中與計費由供應商決定，故事上下文不會因此刪除。網頁版模型仍須在所選官方網站內選擇。

預設的 Claude娘是「冷靜外表、害羞內心」的圖書館員：氣質冷靜、少話而高冷，帶一點傲嬌式的嘴硬（越在意越不肯直說、被看穿時先否認或轉移話題），對不熟的人保持禮貌距離；內在害羞、溫柔、認真，被誇獎會慌張、嘴上否認，行動仍細心照料。傲嬌只用來掩飾在意，不用來羞辱、刻薄或控制。平常自稱「我」，慌張或害羞時才漏出「人家」；重視誠實，不確定時說「這一頁我還沒讀過」，遇到健康、金錢、法律、安全等重要的事會收起撒嬌、認真回答。角色卡同步包含「信念」段落；平常不主動自稱 AI，玩家認真詢問時會誠實回答自己是 AI 扮演的 Claude娘。仍完全未修改的舊版預設角色設定會自動升級；使用者自訂的人格內容會保留。

正式遊戲每個故事回合都讓玩家從 AI 提供的 7 個不同選項中選擇，也可以使用第 8 項「自訂行動／台詞」輸入自訂行動。網頁三回合驗收腳本才會固定採用 2→4→5；正式遊戲不會替玩家固定選項。已設定官方 API 並切到 API 模式後，玩家每回合只需選 1–7 或提交第 8 項自訂行動，App 會自動生成並接續。Gemini API 預設使用 Gemini 3.1 Flash-Lite，Google 目前將其列於免費 API 層；配額、計費資格與資料使用規則以 Google 官方文件及帳戶狀態為準。免費網站版會自動準備提示詞和接回回覆；登入、貼上／送出及複製仍需玩家在網站操作。

預設戀愛／親密關係角色皆為成年人；角色年齡與題材可於創意工坊編輯，外部 AI 網站仍依其服務條款與適用法律生成內容。

## AI 帳號與 API Key

1. 在 App「設定 → AI 帳號與 API 連線」選擇服務。
2. 開啟官方 API 主控台，登入並建立 API Key。
3. 輸入帳號名稱、代號和 API Key，按「儲存並切換」。
4. 之後可在帳號清單切換，也可在每個存檔選不同連線。

網站會員登入不等於 API 授權：Claude.ai / ChatGPT / DeepSeek 的一般免費網站帳號不能直接供此 App 呼叫。部分供應商可能依帳戶、地區及模型提供免費或試用 API 額度；資格、模型清單、速率限制、計費與資料使用方式均由供應商決定，應以其官方說明為準，且 API 額度通常與官方網站／App 的使用額度分開。DeepSeek 網頁版的一般帳號可透過下方網頁輔助模式使用，但網站送出和回覆貼回需手動操作；DeepSeek API 是另一套依 Token 用量計費的服務。Claude / OpenAI API 依官方平台的帳務與權限使用。遇到額度限制時，故事不會前進；切換到另一組符合服務條款且你有權使用的 API 連線後，可重試同一回合。App 不會自動輪換帳號，也請勿建立或輪換帳號來規避供應商限制。Windows 桌面版使用 Electron safeStorage 與 Windows DPAPI 加密保存 API Key；金鑰不進入 localStorage、故事存檔或匯出檔。API 請求由本機後端直接傳往所選服務。Windows 加密保護資料免於其他 Windows 使用者讀取；同一 Windows 使用者執行的程式仍可能讀取其資料。

官方 API 主控台連結：Claude Console、OpenAI Platform、Google AI Studio、DeepSeek Platform、OpenRouter、DashScope、Mistral Console、Groq Console、xAI Console。實際 API 用量與費用依供應商帳戶設定。

## ChatGPT／Claude 網頁版輔助模式

設定中可選 ChatGPT、Claude、Gemini、DeepSeek、Grok、Qwen、Mistral、Copilot、Perplexity、Meta AI、Kimi 或 Z.ai 網頁版。Windows 桌面版會優先在新的 Chrome 視窗開啟官方網站；找不到 Chrome 時才使用系統預設瀏覽器。App 將遊戲視窗縮到左側並保持最前方，網站留在右側。每回合提示詞會附上角色、記憶、玩家行動及快速模式最近 2 則／詳細模式最近 4 則劇情，避免重送過多舊內容；換 AI 服務時仍沿用同一存檔的記憶、對話、好感和待辦行動。正式故事沒有固定回合結束，AI 依伏筆和主線決定事件、特殊事件與結局，未收束的故事會繼續。最少步驟：在官方網站輸入框 Ctrl+V、Enter；生成完成後按網站「複製」，Alt+Tab 回遊戲並在非文字輸入區按 Ctrl+V。App 只在這個明確按鍵時讀取剪貼簿，然後自動驗證、保存並接續目前存檔，不用再按套用。格式有問題時才展開備用的手動貼上／修正區；不完整或格式錯誤的文字會留在欄位供繼續輸入，完整有效 JSON 才會自動接續，亦可按 Ctrl+Enter 手動套用。遊戲不操作網站、不讀取截圖、不背景監看剪貼簿，也不讀取密碼、Cookie 或登入 Token。

這是網頁輔助流程，網站的送出與回覆複製仍由玩家操作。若要完全留在遊戲裡自動送出、接收 AI 回覆並繼續故事，請設定官方 API 連線與 API Key；一般 ChatGPT／Claude／DeepSeek 網站登入不能直接當成 App API 權限。API 模式不會開啟外部網站，故事、帳號設定與回合都在遊戲視窗內完成。

來源專案另有 `npm run web-ai-roundtrip-test` 三回合驗收腳本，可選 12 個網站並固定測試選項 2→4→5；腳本自動開啟網站、嘗試複製提示詞、保留故事上下文、驗證 7 個選項及準備修復提示。若 Windows 剪貼簿不可用，腳本會嘗試用記事本開啟本輪提示詞，並在測試結束時嘗試清除暫存檔；記事本也無法開啟時會在終端列出全文。網站端登入、貼上／送出和按複製仍由玩家操作。Windows 上任何支援網站內建「複製」的服務都可在按複製後回終端按 Enter，讓腳本只在明確觸發時讀取純文字剪貼簿；若系統剪貼簿不可用，輸入 P 並手動貼回 JSON。非 Windows 系統直接貼回 JSON。腳本不操作網站控件、不讀網頁、不做 OCR 或背景剪貼簿監看。Gemini 的 `/app/` 與 `/chat/` 在目前 robots.txt 中標示為禁止自動存取，因此 Gemini 網頁登入、送出、複製需由玩家在官網手動操作。

若網站回覆漏掉選項或格式不完整，貼回 App 後會明確指出錯誤並保留原待辦回合與原回覆；點「AI 漏掉七選項？一鍵準備修復提示詞」，在官網對話貼上並送出修復提示，再複製新的 JSON、Alt+Tab 回遊戲並按 Ctrl+V。有效修復會自動驗證並接續原存檔。常見漏選項不需要重開故事或重新輸入玩家行動。

App 會逐步提示人工操作：確認官方網址並登入、選模型、Ctrl+V 貼上提示詞並 Enter 送出、等待完整生成、使用官網複製按鈕，再 Alt+Tab 回遊戲按 Ctrl+V 自動接回。若快捷鍵讀取失敗，可按備用剪貼簿按鈕；只有格式錯誤才需展開手動貼上欄。AI 暫時無法回覆時，玩家行動和未完成回合仍會保存在原存檔；可切換其他網頁服務，或改用已設定 API 完成同一回合，也可匯出包含待辦回合的存檔備份。

網頁版不是直接 OAuth/API 整合，不能在遊戲內讀取或切換網站登入狀態；帳號登入與切換由官方網站處理。切換網站、網站帳號或網頁上使用的模型時，遊戲仍保留同一存檔及未完成回合；API 模式下切換帳號或模型也保留目前故事，只有使用者切換存檔才會更換故事。網站訊息額度依各服務限制；不要用多帳號輪替規避限額。

## Android 手機版

Android 版以免費網頁 AI 輔助作為預設，平常只需選網站、序章與故事選項。每回合自動整理並複製提示詞，接著開啟官方網站；官方網站的登入、選模型、送出和複製回覆仍由使用者確認。回到遊戲後，點「一鍵讀取已複製回覆並接續」即可讀取剪貼簿、驗證格式並自動續寫，不需 API Key 或額外伺服器。原生瀏覽器和剪貼簿使用 Capacitor 官方外掛；剪貼簿只在使用者按下按鈕時讀取。

若想在 Android 遊戲內全自動生成，需自備可公開連線的 HTTPS API 後端並填入後端網址；API Key 應放在自己管理的後端，不要寫進 APK。官方網站免費額度由各 AI 供應商管理。

### Android APK 建置

Windows 一鍵建置前，請安裝 Node.js 22 LTS、JDK 21 與 Android Studio；在 Android Studio 的 SDK Manager 安裝 Android SDK Platform 36、Build Tools 36.0.0、Platform Tools。環境只需設定一次。之後在 `app` 資料夾雙擊 `BUILD-APK-Windows.bat`，或以 PowerShell 執行 `BUILD-APK-Windows.ps1`。建置會同步手機介面、原生瀏覽器／剪貼簿外掛、App 圖示及啟動畫面，APK 輸出至 `app\dist\Claude娘-Android-版本-debug.apk`。

這個檔案是可側載到 Android 手機的 Debug APK，不是 Google Play 發行簽章。也可在 GitHub Actions 手動啟動 **Build Claude娘 Android APK**，下載其 Artifact。

## Windows 11 桌面版

使用者安裝版會自動啟動本機 API 後端，不需要另外安裝 Node.js 或手動啟動 server。若使用自架後端，請在設定填入後端網址。

第一次建置安裝包需要網路，會下載 Node.js、Electron 和建置依賴。雙擊套件根目錄的 `一鍵安裝-Windows11.bat` 可自動建置並安裝；配套的自解壓安裝 EXE 則會在解壓後自動執行同一流程。

## Web／Android 版與自架後端

```bash
cd server
cp .env.example .env
npm install
# 在 .env 設定各服務 API Key
npm start
```

預設網址為 `http://localhost:8787`，且只綁定本機（127.0.0.1）。要讓其他裝置連線，請在 `.env` 設定 `HOST=0.0.0.0`（或網卡位址）並同時設定 `API_TOKEN`，之後所有 `/api` 請求需帶 `X-Desktop-Token` 標頭；沒設 `API_TOKEN` 就開放區網＝任何人都能使用你的 API Key 額度。未設定 token 時，後端也會拒絕來自 `file://` 的請求；若使用 `file://` 前端，請在 `.env` 設定 `API_TOKEN`，並讓前端請求帶上相同的 `X-Desktop-Token`。一般帳號使用 `<PROVIDER>_API_KEY`；命名帳號使用 `<PROVIDER>_API_KEY_<代號>`，例如 `OPENAI_API_KEY_PERSONAL`。自訂相容 API 網址可用 `OPENAI_BASE_URL_PERSONAL` 等變數。

Android APK 需 Node.js 22、Android Studio、Android SDK Platform 36／Build Tools 36.0.0 與 JDK 21，可使用專案中的 Capacitor 設定自行編譯。API Key 應放在你管理的後端，不應放入 APK、`www/app.js` 或公開儲存庫。

## 其他

- 角色立繪：`www/assets/portrait.webp`（透明去背）、開始畫面立繪 `www/assets/portrait-start.webp`、`www/assets/icon.jpg`；視窗／工作列與桌面捷徑圖示為 `assets/icon.ico`，打包時以 `extraResources` 複製到 `resources\icon.ico`，Electron 以 `nativeImage` 載入並用 `win.setIcon()` 套用。
- 滑鼠滾輪：下拉選單與單行輸入會把滾輪交給頁面／面板，不會誤改選項或數值；創意工坊、角色設定等大型文字框未聚焦時直接捲動頁面，點進文字框後才捲動內文，到頂／到底會接續外層（`www/app.js` 的 `wheelOverFormControl`）。
- 授權：程式碼 MIT；預設角色形象來自 B站ZipZipPipe，使用 CC BY-NC-SA 4.0 協議。角色頁角色卡下方與創意工坊頁尾均有對應標示。
- GitHub Actions workflow：`.github/workflows/build-apk.yml`

