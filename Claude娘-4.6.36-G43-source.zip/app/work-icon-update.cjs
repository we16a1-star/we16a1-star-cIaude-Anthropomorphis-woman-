const sharp=require('sharp');const fs=require('fs');
(async()=>{
 const crop={left:154,top:126,width:720,height:720};
 const base=await sharp('assets/icon.png').extract(crop).png().toBuffer();
 const png1024=await sharp(base).resize(1024,1024,{fit:'cover',kernel:'lanczos3'}).png().toBuffer();
 const png512=await sharp(base).resize(512,512,{fit:'cover',kernel:'lanczos3'}).png().toBuffer();
 const png256=await sharp(base).resize(256,256,{fit:'cover',kernel:'lanczos3'}).png().toBuffer();const png128=await sharp(base).resize(128,128,{fit:'cover',kernel:'lanczos3'}).png().toBuffer();
 fs.writeFileSync('assets/icon.png',png1024);fs.writeFileSync('assets/icon-only.png',png1024);fs.writeFileSync('assets/desktop-avatar.png',png512);
 function ico(images){let offset=6+16*images.length;const header=Buffer.alloc(6);header.writeUInt16LE(0,0);header.writeUInt16LE(1,2);header.writeUInt16LE(images.length,4);const dirs=Buffer.alloc(images.length*16);images.forEach((im,i)=>{const o=i*16;dirs.writeUInt8(im.size===256?0:im.size,o);dirs.writeUInt8(im.size===256?0:im.size,o+1);dirs.writeUInt8(0,o+2);dirs.writeUInt8(0,o+3);dirs.writeUInt16LE(1,o+4);dirs.writeUInt16LE(32,o+6);dirs.writeUInt32LE(im.data.length,o+8);dirs.writeUInt32LE(offset,o+12);offset+=im.data.length;});return Buffer.concat([header,dirs,...images.map(x=>x.data)]);}
 fs.writeFileSync('assets/icon.ico',ico([{size:256,data:png256},{size:128,data:png128}]));
 console.log('Updated icon.png, icon-only.png, desktop-avatar.png and multi-size icon.ico');
})();


