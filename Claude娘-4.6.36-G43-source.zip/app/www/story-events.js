// Fixed event proposals from the model are suggestions only. The game validates
// relationship/time gates and persists one-shot milestones per save slot.
export const STORY_EVENT_FLAGS = ['letter', 'moon_bird', 'outing_memory', 'magic_touch', 'vow'];
export const STORY_EVENT_ONE_SHOTS = ['moon_bird', 'outing_memory', 'magic_touch', 'vow'];

export function normalizeStoryEventFlag(value) {
  return STORY_EVENT_FLAGS.includes(value) ? value : '';
}

export function normalizeSeenStoryEventFlags(value) {
  return [...new Set((Array.isArray(value) ? value : [])
    .map(normalizeStoryEventFlag)
    .filter(flag => STORY_EVENT_ONE_SHOTS.includes(flag)))];
}

export function approveStoryEvent(value, { affection = 0, isNight = false, seen = [] } = {}) {
  const flag = normalizeStoryEventFlag(value);
  if (!flag) return '';
  const safeSeen = normalizeSeenStoryEventFlags(seen);
  if (STORY_EVENT_ONE_SHOTS.includes(flag) && safeSeen.includes(flag)) return '';
  if (flag === 'moon_bird' && (Number(affection) < 25 || !isNight)) return '';
  if (flag === 'outing_memory' && Number(affection) < 25) return '';
  if (flag === 'magic_touch' && (Number(affection) < 50 || !isNight)) return '';
  if (flag === 'vow' && Number(affection) < 75) return '';
  return flag;
}
