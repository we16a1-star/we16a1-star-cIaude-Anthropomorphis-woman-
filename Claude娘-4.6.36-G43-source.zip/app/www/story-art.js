// G43：整張帶背景的插畫採單圖淡出／淡入；劇情 CG 只接受遊戲核准的結構化事件旗標。
const tab = document.getElementById('tab-story');
const stage = document.querySelector('.vn-stage');
const defaultArt = document.getElementById('storyDefaultArt');
const cgArt = document.getElementById('bundledStoryCg');
const grade = document.getElementById('storyArtGrade');
const transition = document.getElementById('storySceneTransition');
const dialogue = document.getElementById('dialogueText');
if (tab && stage && defaultArt && cgArt && grade && transition && dialogue) {
  const image = name => `assets/${name}`;
  const cgEvents = [
    { flag: 'moon_bird', id: 'moon-bird', file: 'g43-cg-moon-bird.jpg', alt: '月夜中發光信鳥送來書信的劇情 CG', once: true, tone: 'night' },
    { flag: 'outing_memory', id: 'outing-memory', file: 'g43-cg-outing-memory.jpg', alt: '克勞德在向日葵田閱讀的外出回憶 CG', once: true, tone: 'none' },
    { flag: 'magic_touch', id: 'magic-touch', file: 'g43-cg-magic-touch.jpg', alt: '克勞德觸碰發光面板的劇情 CG', once: true, tone: 'warm' },
    { flag: 'vow', id: 'vow', file: 'g43-cg-vow.jpg', alt: '克勞德感動祈願的劇情 CG', once: true, tone: 'none' },
    { flag: 'letter', id: 'letter', file: 'g43-cg-letter.jpg', alt: '克勞德燭光下閱讀信件的插入 CG', once: false, tone: 'none' },
  ];

  let timeGroup = 'day';
  let currentScene = '';
  let activeCg = '';
  let lastDialogue = '';
  let lastEmotionToken = '';
  let neutralTurns = 0;
  let cgTimer = 0;
  let transitionTimer = 0;
  let cgTransitionTimer = 0;
  let openingFlashTimer = 0;
  let artGeneration = 0;
  let cgGeneration = 0;
  let cgStartedAt = 0;
  let pendingCg = null;
  let lastStoryEventToken = stage.dataset.storyEventToken || '';

  const hasUserOverride = () => tab.classList.contains('has-custom-portrait') ||
    tab.classList.contains('has-scene-image') || tab.classList.contains('text-only');

  function setTone(tone) {
    grade.dataset.tone = tone || 'none';
    tab.dataset.artTone = tone || 'none';
  }

  function setStoryArt(file, alt, scene = '', tone = 'none') {
    if (hasUserOverride() || tab.classList.contains('has-bundled-cg')) return;
    const src = image(file);
    currentScene = scene;
    if (defaultArt.getAttribute('src') === src) {
      defaultArt.alt = alt;
      defaultArt.dataset.art = scene || 'default';
      setTone(tone);
      return;
    }
    const generation = ++artGeneration;
    clearTimeout(transitionTimer);
    defaultArt.style.opacity = '0';
    defaultArt.onload = () => {
      if (generation !== artGeneration) return;
      requestAnimationFrame(() => {
        if (generation !== artGeneration) return;
        defaultArt.style.opacity = '1';
        defaultArt.alt = alt;
        defaultArt.dataset.art = scene || 'default';
        setTone(tone);
      });
    };
    defaultArt.src = src;
    if (defaultArt.complete && defaultArt.naturalWidth) defaultArt.onload();
  }

  function returnToTimeDefault() {
    if (timeGroup === 'night') setStoryArt('g43-cg-magic-light.jpg', '夜色中克勞德手托微光，作為夜間獨處場景', 'night', 'night');
    else setStoryArt('g43-story-default.jpg', '克勞德站在窗前，日間故事預設立繪', 'default', 'warm');
  }

  function applyEmotionArt() {
    if (hasUserOverride() || tab.classList.contains('has-bundled-cg') || tab.classList.contains('g43-story-opening')) return;
    if (timeGroup === 'night') {
      setStoryArt('g43-cg-magic-light.jpg', '夜色中克勞德手托微光，夜間立繪', 'night', 'night');
      return;
    }
    const emotion = stage.dataset.storyEmotion || 'neutral';
    if (emotion === 'shy' || emotion === 'curious') {
      setStoryArt('g43-story-soft-morning.jpg', '克勞德在日光中溫柔傾聽', 'soft-morning', 'warm');
    } else {
      setStoryArt('g43-story-default.jpg', '克勞德站在窗前，日間故事預設立繪', 'default', 'warm');
    }
  }

  function finishCg() {
    clearTimeout(cgTimer);
    clearTimeout(cgTransitionTimer);
    cgTimer = 0;
    const generation = ++cgGeneration;
    tab.classList.remove('has-bundled-cg');
    transition.classList.remove('is-active');
    transition.removeAttribute('data-mode');
    cgArt.style.opacity = '0';
    transitionTimer = setTimeout(() => {
      if (generation !== cgGeneration) return;
      cgArt.hidden = true;
      cgArt.removeAttribute('src');
      cgArt.removeAttribute('data-cg');
      cgArt.style.removeProperty('opacity');
      activeCg = '';
      applyEmotionArt();
      if (pendingCg) { const next = pendingCg; pendingCg = null; showCg(next); }
    }, 500);
  }

  function openingFlash() {
    clearTimeout(openingFlashTimer);
    transition.dataset.mode = 'opening-flash';
    transition.classList.add('is-active');
    openingFlashTimer = setTimeout(() => {
      transition.classList.remove('is-active');
      transition.removeAttribute('data-mode');
    }, 250);
  }

  function showCg(event) {
    if (!event) return;
    if (hasUserOverride()) return;
    if (activeCg) { pendingCg = event; return; }
    clearTimeout(cgTimer);
    clearTimeout(transitionTimer);
    clearTimeout(cgTransitionTimer);
    const generation = ++cgGeneration;
    activeCg = event.id;
    cgStartedAt = Date.now();
    transition.dataset.mode = 'cg-dark';
    transition.classList.add('is-active');
    setTone(event.tone);
    cgArt.style.opacity = '0';
    cgArt.hidden = false;
    cgArt.alt = event.alt;
    cgArt.dataset.cg = event.id;
    cgArt.onload = () => {
      if (generation !== cgGeneration) return;
      cgTransitionTimer = setTimeout(() => {
        if (generation !== cgGeneration) return;
        tab.classList.add('has-bundled-cg');
        cgArt.style.opacity = '1';
        transition.classList.remove('is-active');
        transition.removeAttribute('data-mode');
        cgTimer = setTimeout(finishCg, 5000);
      }, 700);
    };
    cgArt.src = image(event.file);
    if (cgArt.complete && cgArt.naturalWidth) cgArt.onload();
  }

  function receiveStoryEvent() {
    const token = stage.dataset.storyEventToken || '';
    if (!token || token === lastStoryEventToken) return;
    lastStoryEventToken = token;
    const flag = stage.dataset.storyEvent || '';
    const event = cgEvents.find(item => item.flag === flag);
    if (event) showCg(event);
  }

  function updateTimeGroup(text) {
    const before = timeGroup;
    if (/夜晚|深夜|入夜|月夜|月色|月光|星空|燭光/.test(text)) {
      if (timeGroup !== 'night') { timeGroup = 'night'; currentScene = ''; }
    } else if (/清晨|早晨|日出|晨光|白天|日間|午後|太陽升起/.test(text)) {
      if (timeGroup !== 'day') { timeGroup = 'day'; currentScene = ''; }
    }
    return before !== timeGroup;
  }

  function inspectDialogue() {
    if (tab.classList.contains('story-empty') || tab.classList.contains('g43-story-opening')) return;
    const text = String(dialogue.textContent || '').trim();
    if (!text || text === lastDialogue || /AI 正在構思故事/.test(text)) return;
    lastDialogue = text;
    const timeChanged = updateTimeGroup(text);
    if (timeChanged) returnToTimeDefault();

    // 36370（只保留 36370_1）：傍晚讀書、白鴿停窗台的鋪梗場景；非情緒切換。
    if (/傍晚|暮色|夕陽|日落/.test(text) && /白鴿|鴿子|鳥停在窗台|窗台.{0,8}白鳥/.test(text)) {
      setStoryArt('g43-story-reading.jpg', '傍晚的克勞德與窗台白鴿，為夜間信鳥故事鋪梗', 'evening-reading', 'warm');
    } else if (timeGroup === 'night' && currentScene !== 'night') {
      returnToTimeDefault();
    }

    const emotionToken = stage.dataset.storyEmotionToken || '';
    if (emotionToken && emotionToken !== lastEmotionToken) {
      lastEmotionToken = emotionToken;
      const emotion = stage.dataset.storyEmotion || 'neutral';
      if (emotion === 'neutral') {
        neutralTurns++;
        if (neutralTurns >= 3) { currentScene = ''; applyEmotionArt(); }
      } else {
        neutralTurns = 0;
        if (!currentScene || currentScene === 'default' || currentScene === 'soft-morning' || currentScene === 'night') applyEmotionArt();
      }
    }

    // 劇情 CG 不依旁白猜測，改由 JSON eventFlag 經遊戲端核准後觸發。
    if (activeCg) {
      if (Date.now() - cgStartedAt < 5700) return;
      finishCg();
    }
  }

  new MutationObserver(() => { if (!hasUserOverride()) applyEmotionArt(); }).observe(stage, { attributes: true, attributeFilter: ['data-story-emotion','data-story-emotion-token'] });
  new MutationObserver(receiveStoryEvent).observe(stage, { attributes: true, attributeFilter: ['data-story-event','data-story-event-token'] });
  new MutationObserver(inspectDialogue).observe(dialogue, { childList: true, subtree: true, characterData: true });
  new MutationObserver(records => {
    for (const record of records) {
      const wasOpening = String(record.oldValue || '').split(/\s+/).includes('g43-story-opening');
      const isOpening = tab.classList.contains('g43-story-opening');
      if (wasOpening && !isOpening) openingFlash();
    }
    if (!hasUserOverride()) applyEmotionArt();
    inspectDialogue();
  }).observe(tab, { attributes: true, attributeOldValue: true, attributeFilter: ['class'] });
  applyEmotionArt();
  inspectDialogue();
}
