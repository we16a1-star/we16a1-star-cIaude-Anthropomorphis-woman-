// G21 立繪觸碰動畫：釘住「點立繪會有反應」的結構與不能退步的規則。
// 真正的 WebGL 畫面與滑鼠／觸控流程需要瀏覽器，這裡只檢查原始碼結構與純邏輯（可在任何電腦跑 npm test）。
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { Script } from 'node:vm';

const read = rel => readFileSync(new URL('../../' + rel, import.meta.url), 'utf8');
const js = read('www/portrait-anim.js');
const css = read('www/style.css');
const html = read('www/index.html');

const g21Start = css.indexOf('/* ==== G21');
const g21BaseEnd = css.indexOf('/* G21.3', g21Start);
const g21End = css.indexOf('/* G22', g21Start);
const g21StarStart = css.indexOf('/* G21.5', g21Start);
const g21 = css.slice(g21Start);
const g21Base = css.slice(g21Start, g21BaseEnd);
const g21Effects = css.slice(g21Start, g21End);
const g21Stars = css.slice(g21StarStart, g21End);

test('G21 shader：兩個觸碰槽（A 最新、B 前一下）都宣告、都被 warp 使用', () => {
  for (const name of ['uTA', 'uKA', 'uTB', 'uKB']) {
    assert.match(js, new RegExp(`uniform vec4\\s+${name};`), `${name} 有宣告`);
    assert.match(js, new RegExp(`'${name}'`), `${name} 有取得 location`);
  }
  assert.match(js, /vec2 touchDisp\(vec2 p, float hair, vec4 tc, vec4 kw, vec4 mo\)/, '有 touchDisp 函式');
  assert.match(js, /d \+= touchDisp\(p, hair, uTA, uKA, uMA\) \+ touchDisp\(p, hair, uTB, uKB, uMB\);/, 'warp 疊加兩個觸碰');
  assert.ok(js.indexOf('vec2 touchDisp') < js.indexOf('vec2 warp(vec2 p, float hair)'), 'touchDisp 要定義在 warp 之前（GLSL 不能前向引用）');
});

test('G22 故事畫面新動畫：待機點頭／髮飾微光，書本／髮尾／裙擺觸碰反應', () => {
  assert.match(js, /uniform float uStory;/, '故事畫面旗標');
  assert.match(js, /this\.img\.id === 'storyPortrait' \? 1 : 0/, '待機點頭與觸碰特效只用於故事立繪');
  assert.match(js, /float idleNod = .*uStory;/, '週期性輕點頭');
  assert.match(js, /float readDip = .*uStory;/, '新增閱讀時低頭再抬頭的待機動作');
  assert.match(js, /function spawnBookPageGlint\(animator\)/, '閱讀時顯示書頁掠光');
  assert.match(css, /@keyframes g28-book-page-glint/, '書頁掠光有獨立動畫');
  assert.match(js, /book: \[0\.23, 0\.19, 0\.40, 0\.34\]/, '書本觸碰區域');
  assert.match(js, /entry\.effect = 1/, '書本微傾');
  assert.match(js, /entry\.effect = 2/, '髮尾甩動');
  assert.match(js, /entry\.effect = 3/, '裙擺旋擺');
  assert.match(js, /touch\.m\[3\] = touch\.effect \|\| 0;/, '新反應與既有表情動作共存');
  assert.match(js, /function spawnHairpinGlint\(animator\)/, '定位髮飾微光');
  assert.match(js, /className = 'pa-hairpin-glint'/, '髮飾微光 DOM');
  assert.match(g21, /@keyframes g21-hairpin-glint/, '髮飾微光動畫');
  assert.match(css, /@media \(prefers-reduced-motion:reduce\)\{\.pa-touch-fx,\.pa-hearts,\.pa-face,\.pa-sparkles,\.pa-orbit,\.pa-hairpin-glint,\.pa-book-page-glint,\.pa-story-petals\{display:none\}\}/, '減少動態時隱藏微光、書頁掠光與花瓣');
});

test('G23 故事觸碰花瓣：SVG 素材存在、點故事立繪才播放，並尊重減少動態', () => {
  const petal = readFileSync(new URL('../../www/assets/story-petal.svg', import.meta.url), 'utf8');
  assert.match(petal, /<svg[\s\S]*viewBox="0 0 40 56"/, '有獨立花瓣 SVG 素材');
  assert.match(js, /function spawnStoryPetals\(stage, x, y\)/, '故事花瓣生成函式');
  assert.match(js, /petal\.src = 'assets\/story-petal\.svg'/, '動畫載入新增圖檔');
  assert.match(js, /if \(target\.animator\.img\.id === 'storyPortrait'\) spawnStoryPetals/, '只在故事立繪觸碰時播放');
  assert.match(css, /@keyframes g23-story-petal\{[\s\S]*?translate:var\(--px\) var\(--py\)[\s\S]*?rotate:var\(--pr\)/, '花瓣向外旋落並淡出');
  assert.match(css, /\.pa-story-petals\{[^}]*pointer-events:none\}/, '特效不攔截觸碰');
  assert.match(css, /\.pa-story-petals\{display:none\}/, '減少動態時隱藏花瓣');
  assert.match(js, /\.pa-story-petals'\)\.forEach\(node => node\.remove\(\)\)/, '停止動畫會清除花瓣');
});

test('G21 shader：無觸碰時零成本、剛觸碰時不會跳、播完後完全回到待機', () => {
  assert.match(js, /if \(T < 0\.0 \|\| T > 2\.6\) return vec2\(0\.0\);/, '沒有觸碰（T<0）或超過 2.6 秒直接回傳 0');
  assert.match(js, /const TOUCH_DURATION = 2\.6;/, 'JS 端的長度與 shader 的 2.6 一致');
  assert.match(js, /float att = 1\.0 - exp\(-T \* 14\.0\);/, '髮絲／裙擺的波有淡入，T=0 時位移為 0');
  assert.match(js, /\* e \* att;/, '淡入確實乘在波上');
  assert.match(js, /live \? T : -1/, '沒有觸碰或已播完時，JS 傳 T=-1');
});

test('G21 觸碰判定：只有點在角色身上才算；按鈕、覆蓋層、減少動態都不觸發', () => {
  assert.match(js, /const TOUCH_INTERACTIVE = 'button,a,input,select,textarea,label,summary,\[role="button"\]';/, '控制項不觸發');
  assert.match(js, /el\.closest\('\.vn-stage'\)/, '只處理舞臺內的點擊');
  assert.match(js, /animator\.shouldRender\(\)/, '選單／對話框蓋住時（shouldRender=false）不觸發');
  assert.match(js, /map\.alpha\[y \* map\.aw \+ x\] > 48/, '透明背景不算（以透明度圖判斷）');
  assert.match(js, /if \(event\.button !== 0\) return;/, '只處理主要按鍵（滑鼠左鍵／手指）');
  assert.match(js, /window\.addEventListener\('pointerdown', onDown, \{ passive: true \}\);/, '用 pointerdown，滑鼠與觸控一視同仁');
  assert.match(js, /state\.handlers\.push\(\['pointerdown', onDown\], \['pointermove', onHover\], \['pointerup', onUp\], \['pointercancel', onUp\]\);/, '觸碰與長按事件都登記進 handlers，stop() 會一併移除');
  assert.match(js, /}, 650\);/, '故事立繪按住 0.65 秒觸發新增表情動作');
  assert.match(js, /held\.m = \[0, 0, 0, 4\];/, '長按使用獨立的低頭與髮尾揚起 shader 動作');
  assert.match(js, /showFace\(heldTarget\.stage, heldTarget\.animator, 'curious'/, '長按觸發好奇思考表情');
  const handlers = js.slice(js.indexOf('const onDown = event'), js.indexOf("state.handlers.push(['pointerdown'"));
  assert.ok(handlers.length > 100, '找得到觸碰事件處理段落');
  assert.doesNotMatch(handlers, /preventDefault|stopPropagation/, '觸碰處理不攔截事件，不影響原本的點擊行為');
});

test('G21 座標：考慮 object-fit:contain、object-position、PAD 與介面縮放', () => {
  assert.match(js, /Math\.min\(rect\.width \/ canvas\.width, rect\.height \/ canvas\.height\)/, 'contain 縮放');
  assert.match(js, /getComputedStyle\(canvas\)\.objectPosition/, '讀 object-position');
  assert.match(js, /cu \* \(1 \+ 2 \* PAD_X\) - PAD_X/, '扣掉左右留白');
  assert.match(js, /cv \* \(1 \+ PAD_Y\) - PAD_Y/, '扣掉上方留白');
  assert.match(js, /const k = \(fx\.getBoundingClientRect\(\)\.left - origin\.left\) \/ 100 \|\| 1;/, '漣漪位置換算介面縮放（CSS zoom）');
});

test('G21 純邏輯：object-position 解析與平滑步進', () => {
  const grab = name => {
    const start = js.indexOf(`function ${name}(`);
    assert.ok(start > 0, name + ' 存在');
    let depth = 0, i = js.indexOf('{', start);
    for (; i < js.length; i++) { if (js[i] === '{') depth++; else if (js[i] === '}' && --depth === 0) break; }
    return js.slice(start, i + 1);
  };
  const ctx = {};
  new Script(grab('parsePosition') + grab('smooth') + '\nthis.parsePosition = parsePosition; this.smooth = smooth;').runInNewContext(ctx);
  assert.equal(ctx.parsePosition('50%', 0), 0.5);
  assert.equal(ctx.parsePosition('100%', 0), 1);
  assert.equal(ctx.parsePosition('0%', 1), 0);
  assert.equal(ctx.parsePosition('right', 0), 1);
  assert.equal(ctx.parsePosition('bottom', 0), 1);
  assert.equal(ctx.parsePosition('center', 0), 0.5);
  assert.equal(ctx.parsePosition('12px', 0.5), 0.5, 'px 看不懂就用預設');
  assert.equal(ctx.parsePosition(undefined, 0.25), 0.25);
  assert.equal(ctx.smooth(0, 1, -1), 0);
  assert.equal(ctx.smooth(0, 1, 2), 1);
  assert.equal(ctx.smooth(0, 1, 0.5), 0.5);
});

test('G21 對外測試介面與既有介面都在', () => {
  for (const name of ['hitTest', 'touchAt', 'renderAt']) assert.match(js, new RegExp(`\\b${name}\\(`), `window.__portraitAnim.${name}`);
  assert.match(js, /touchWeights\(u, v\)/, '各部位反應強度');
  assert.match(js, /if \(!this\.asset\) return \[0, 1, 0, 0\];/, '自訂角色圖只做整體戳一下（不亂套頭／髮／裙）');
  assert.match(js, /const TOUCH_MAX = 2;/, '連點最多疊兩下');
});

test('G21 CSS：只追加、零重要旗標、零字級、有減少動態保險、游標變手指', () => {
  assert.ok(g21.startsWith('/* ==== G21'), 'G21 區段存在且在檔尾');
  assert.doesNotMatch(g21Base, /!important/, 'G21 不使用 !important');
  assert.doesNotMatch(g21Base, /font-size/, 'G21 沒有文字，不新增字級（font-scale-coverage 測試）');
  assert.match(g21Base, /#tab-story \.vn-stage\.pa-touchable\{cursor:pointer\}/, '游標');
  assert.match(g21Base, /\.pa-touch-fx\{position:absolute;z-index:4;[^}]*pointer-events:none\}/, '漣漪不擋滑鼠');
  assert.match(g21Base, /clip-path:polygon\(/, '四芒星');
  assert.match(g21Base, /@keyframes g21-ripple-grow/, '漣漪縮放');
  assert.match(g21Base, /@keyframes g21-ripple-fade/, '漣漪淡出');
  assert.match(g21, /@keyframes g21-star/, '四芒星');
  assert.match(g21, /@media \(prefers-reduced-motion:reduce\)\{\.pa-touch-fx,\.pa-hearts,\.pa-face,\.pa-sparkles,\.pa-orbit,\.pa-hairpin-glint,\.pa-book-page-glint,\.pa-story-petals\{display:none\}\}/, '減少動態時隱藏漣漪、愛心、花飾微光、書頁掠光與花瓣');
});

test('G21 壓扁彈回：五個關鍵格、以腳下為支點、剎那與播完後都是 1（不跳）', () => {
  assert.match(js, /float squishKeys\(float T, float v1, float v2, float v3, float v4\)/, '關鍵格函式');
  for (const edge of ['0.0, 0.14', '0.14, 0.32', '0.32, 0.48', '0.48, 0.62']) assert.ok(js.includes(`smoothstep(${edge}, T)`), `時間格 ${edge}`);
  assert.match(js, /squishKeys\(T, 1\.04, 0\.98, 1\.01, 1\.0\)/, '橫向 1.04／0.98／1.01／1');
  assert.match(js, /squishKeys\(T, 0\.94, 1\.03, 0\.99, 1\.0\)/, '縱向 0.94／1.03／0.99／1');
  assert.match(js, /d \+= vec2\(\(p\.x - 0\.50\) \* \(sx - 1\.0\), \(p\.y - 0\.97\) \* \(sy - 1\.0\)\);/, '以腳下（y≈0.97）為支點');
  assert.match(js, /\) \* 0\.5;/, '幅度取一半（立繪比桌面小人高很多）');
});

test('G21 摸頭愛心：只在摸頭出現、位置換算縮放、連點限流、用 CSS 畫（無文字）', () => {
  assert.match(js, /if \(touch\.k\[0\] > 0\.6\) spawnHearts\(/, '只有摸頭（頭權重 >0.6）才有愛心');
  assert.match(js, /if \(now - state\.heartAt < 700\) return;/, '0.7 秒內不重複生成');
  assert.match(js, /for \(let i = 0; i < all\.length - 2; i\+\+\) all\[i\]\.remove\(\);/, '同時最多 2 組');
  assert.match(js, /function placeFx\(stage, fx, x, y\)/, '漣漪與愛心共用「換算介面縮放」的定位函式');
  assert.match(js, /querySelectorAll\('\.pa-touch-fx,\.pa-hearts[^']*'\)\.forEach/, 'stop() 會清掉殘留的愛心');
  assert.equal((js.match(/\[-?\d+, -?\d+, \d+, [\d.]+, '#ff[0-9a-f]{4}'\]/g) || []).length, 3, '三顆愛心');
  assert.match(g21, /@keyframes g21-heart/, '愛心動畫');
  assert.match(g21, /\.pa-heart::before,\.pa-heart::after\{content:""/, '愛心由兩個圓頂方塊拼成');
  assert.doesNotMatch(g21, /content:"[^"]/, 'G21 沒有任何文字內容');
});

test('G21 表情窗：點的位置決定表情、連點變暈、缺圖整個停用', () => {
  assert.match(js, /const FACES = \['pat', 'happy', 'surprised', 'dizzy', 'story-daily', 'story-proud', 'story-shy', 'story-focused'\];/, '觸碰表情與四種故事差分');
  assert.match(js, /if \(burst\) return 'dizzy';/, '連點 → 暈');
  assert.match(js, /if \(touch\.k\[0\] > 0\.6\) return 'pat';/, '摸頭 → 害羞');
  assert.match(js, /if \(touch\.k\[2\] > 0\.55\) return 'happy';/, '碰髮絲 → 開心');
  assert.match(js, /return 'surprised';/, '其餘 → 驚訝');
  assert.match(js, /const FACE_BURST = \[5, 2200\];/, '2.2 秒內連點 5 下');
  assert.match(js, /img\.onerror = \(\) => \{ state\.faceOk = false; left = Infinity; \};/, '任何一張載入失敗 → 永久停用');
  assert.match(js, /if \(state\.faceOk !== true\) return;/, '沒載入完成／已停用時不顯示');
  assert.match(js, /placeFx\(stage, el, anchor\.x, anchor\.y\);/, '表情窗位置同樣換算介面縮放');
  assert.match(js, /querySelectorAll\('\.pa-touch-fx,\.pa-hearts,\.pa-face[^']*'\)/, 'stop() 會清掉表情窗');
  assert.match(js, /imageToScreen\(u, v, g = this\.screenGeometry\(\)\)/, '圖面座標 → 螢幕座標');
  assert.match(g21, /\.pa-face\{position:absolute;z-index:4;/, 'CSS：表情窗');
  assert.match(g21, /@keyframes g21-face\{/, 'CSS：彈出動畫');
  assert.match(g21, /\.pa-face\{[^}]*pointer-events:none/, '表情窗不擋滑鼠');
});

test('G21 表情動作：跳／抖／頭晃在 shader、星光與繞星在 CSS，T=0 與播完後都是 0', () => {
  for (const name of ['uMA', 'uMB']) {
    assert.match(js, new RegExp(`uniform vec4\\s+${name};`), `${name} 有宣告`);
    assert.match(js, new RegExp(`'${name}'`), `${name} 有取得 location`);
  }
  assert.match(js, /float hopCurve\(float T\)/, '跳的曲線');
  assert.match(js, /float shakeCurve\(float T\)/, '抖的曲線');
  for (const edge of ['0.0, 0.22', '0.22, 0.45', '0.45, 0.65', '0.65, 0.90']) assert.ok(js.includes(`smoothstep(${edge}, T)`), `跳的時間格 ${edge}`);
  for (const edge of ['0.0, 0.10', '0.10, 0.20', '0.20, 0.30', '0.30, 0.40', '0.40, 0.50']) assert.ok(js.includes(`smoothstep(${edge}, T)`), `抖的時間格 ${edge}`);
  assert.match(js, /d\.y \+= mo\.x \* 0\.013 \* hopCurve\(T\);/, '跳套用在整個人');
  assert.match(js, /d\.x \+= mo\.y \* 0\.009 \* shakeCurve\(T\);/, '抖套用在整個人');
  assert.match(js, /float angW = 0\.0; \/\/ 故事立繪取消頭部左右抖動/, '故事立繪取消頭部抖動');
  assert.match(js, /touchDisp\(p, hair, uTA, uKA, uMA\) \+ touchDisp\(p, hair, uTB, uKB, uMB\)/, '兩個觸碰槽都帶動作');
  assert.match(js, /const MOTIONS = \{ pat: \[0\.28, 0, 0\.6, 0\], happy: \[0\.6, 0, 0, 0\], surprised: \[1, 0, 0, 0\], dizzy: \[0, 1, 1, 0\] \};/, '摸頭有輕彈與頭部回擺，其他表情維持原動作強度');
  assert.match(js, /touch\.m = \[\.\.\.MOTIONS\[expression\]\];/, '複製表情動作，避免污染共用設定');
  assert.match(js, /if \(expression === 'happy'\) spawnSparkles\(/, '開心 → 星光');
  assert.match(js, /if \(expression === 'dizzy'\) spawnOrbit\(/, '暈 → 繞星');
  assert.equal(SPARKLE_COUNT(), 6, '六顆星光');
  assert.match(js, /for \(let i = 0; i < 3; i\+\+\) group\.appendChild\(document\.createElement\('i'\)\);/, '三顆繞星');
  assert.match(g21Stars, /@keyframes g21-twinkle/, 'CSS：星光閃爍');
  assert.match(g21Stars, /@keyframes g21-orbit\{[\s\S]*?rotate:720deg/, 'CSS：繞星轉兩圈');
  assert.match(g21Stars, /\.pa-sparkles,\.pa-orbit\{position:absolute;z-index:4;[^}]*pointer-events:none\}/, '不擋滑鼠');
  assert.doesNotMatch(g21Base+g21Stars, /font-size/, '沒有文字');
});

function SPARKLE_COUNT() {
  const block = js.slice(js.indexOf('const SPARKLES = ['), js.indexOf('function spawnSparkles'));
  return (block.match(/\[-?\d+, -?\d+, \d+, [\d.]+\]/g) || []).length;
}

test('表情素材：觸碰原圖與四種故事差分都在、README 記錄來源與授權；程式清單與檔案一致', () => {
  const dir = new URL('../../www/assets/expressions/', import.meta.url);
  const sizes = { pat: 57052, happy: 56298, surprised: 56392, dizzy: 55866, 'story-daily': 18916, 'story-proud': 18210, 'story-shy': 19312, 'story-focused': 19450 };
  const listed = [...js.match(/const FACES = \[([^\]]+)\]/)[1].matchAll(/'([\w-]+)'/g)].map(m => m[1]).sort();
  assert.deepEqual(listed, Object.keys(sizes).sort(), '程式的 FACES 與素材清單一致');
  for (const [name, size] of Object.entries(sizes)) {
    const buf = readFileSync(new URL(`${name}.webp`, dir));
    assert.equal(buf.length, size, `${name}.webp 大小`);
    assert.equal(buf.subarray(0, 4).toString('latin1'), 'RIFF', `${name}.webp 是 WebP（RIFF）`);
    assert.equal(buf.subarray(8, 12).toString('latin1'), 'WEBP');
  }
  const readme = readFileSync(new URL('README.txt', dir), 'utf8');
  assert.match(readme, /claude-xiaoke/);
  assert.match(readme, /ZipZipPipe/);
  assert.match(readme, /不在範圍內/, '寫明圖片不在 MIT 範圍');
  assert.match(readme, /無法驗證/, '寫明授權條款未驗證');
  assert.match(readme, /Claude娘圖3\.jpg/);
  assert.match(readme, /story-focused 改由 portrait-start\.webp 裁切/);
  assert.match(readme, /去除眼鏡/);
  for (const name of ['story-daily', 'story-proud', 'story-shy', 'story-focused']) assert.ok(listed.includes(name), `${name} 故事差分已接線`);
  assert.match(readme, /刪掉整個 assets\/expressions 資料夾/, '寫明如何移除');
});

test('第三方授權聲明：出處、MIT 全文、圖片的授權狀態與移除方式都在', () => {
  const notice = read('../第三方授權聲明-claude-xiaoke.txt');
  assert.match(notice, /github\.com\/blackshoretuner\/claude-xiaoke/);
  assert.match(notice, /MIT License[\s\S]*Copyright \(c\) 2026 blackshoretuner/);
  assert.match(notice, /Permission is hereby granted, free of charge/);
  assert.match(notice, /沒有使用該專案的程式碼檔案/);
  assert.match(notice, /二、圖片（不在 MIT 範圍內）/);
  assert.match(notice, /ZipZipPipe/);
  assert.match(notice, /無法驗證該 CC 授權的實際條款/);
  assert.match(notice, /刪除 app\/www\/assets\/expressions\//);
  assert.match(js, /第三方授權聲明-claude-xiaoke\.txt/, '程式碼檔頭指向授權聲明');
});

test('G21 沒有動到不該動的：index.html 的 script 順序、既有 G19／G20 區段與立繪素材', () => {
  assert.match(html, /<script type="module" src="app\.bundle\.js"><\/script>\s*<script src="portrait-anim-assets\.js"><\/script>\s*<script type="module" src="portrait-anim\.js"><\/script>/, 'script 順序不變');
  assert.match(css, /G19｜立繪動畫化/, 'G19 還在');
  assert.match(css, /G20｜開始面板 UI 美術優化/, 'G20 還在');
  assert.ok(css.indexOf('G19｜') < css.indexOf('G20｜') && css.indexOf('G20｜') < css.indexOf('G21｜'), '級聯順序 G19 → G20 → G21');
  assert.match(js, /const ENABLE_BLINK = false;/, '眨眼仍維持預設關閉');
});
