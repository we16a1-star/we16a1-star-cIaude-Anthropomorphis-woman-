import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');
const html = readFileSync(new URL('../../www/index.html', import.meta.url), 'utf8');
const css = readFileSync(new URL('../../www/style.css', import.meta.url), 'utf8');

test('角色卡可新增多張：資料模型與存檔往返', () => {
  assert.match(source, /function normalizeCharacterCards\(raw\)\{/, '多角色卡陣列正規化');
  assert.match(source, /characterCards: normalizeCharacterCards\(source\.characterCards\)/, 'serializeState 保存角色卡陣列');
  assert.match(source, /characterCardIds: \(Array\.isArray\(rawState\.characterCardIds\)\?rawState\.characterCardIds:\[\]\)\.map\(String\)\.slice\(0,12\)/, '讀檔還原勾選的角色卡');
  assert.match(source, /\.slice\(0,12\)/, '角色卡上限 12 張');
});

test('角色卡可多選「參與故事」，並併入 AI 提示詞', () => {
  assert.match(source, /function toggleCharacterCardUse\(id,use\)\{[\s\S]{0,220}state\.characterCardIds=\[\.\.\.set\];/, '勾選盒切換使用狀態並保存');
  assert.match(source, /function renderCharacterCardsBar\(\)\{[\s\S]{0,1100}box\.onchange=\(\)=>toggleCharacterCardUse\(card\.id,box\.checked\);/, '每張卡的晶片都是勾選盒（可多選）');
  assert.match(source, /function characterCardsUseText\(\)\{[\s\S]{0,1400}其他角色（與主角同台，互動時保持各自的個性與設定）/, '勾選的卡轉成提示詞文字');
  assert.match(source, /const profile=\(rawProfile===DEFAULT_CHARACTER_PROFILE\?compactProfile:String\(rawProfile\)\.trim\(\)\+modeNote\)\+characterCardsUseText\(\);/, '網頁模式依角色模式選擇精簡提示詞，並併入勾選的角色卡');
  assert.match(source, /characterProfile:apiProfile\+characterCardsUseText\(\)/, 'API 模式提示詞併入勾選的角色卡');
  assert.match(source, /參與故事的角色[\s\S]{0,420}used\.map\(card=>/, '角色頁列出參與故事的角色摘要');
});

test('角色卡可新增、編輯（下拉選目標）、刪除', () => {
  assert.match(html, /id="sheetAddCardBtn"[^>]*>＋ 新增角色卡/, '新增角色卡按鈕');
  assert.match(html, /id="sheetDeleteCardBtn"/, '刪除角色卡按鈕');
  assert.match(html, /id="sheetEditCardSelect"/, '編輯對話框有目標下拉');
  assert.match(html, /id="sheetEditCardName"/, '編輯對話框可改角色名稱');
  assert.match(source, /\$\('sheetAddCardBtn'\)\.onclick=addCharacterCard;/, '新增按鈕接線');
  assert.match(source, /\$\('sheetDeleteCardBtn'\)\.onclick=deleteCharacterCard;/, '刪除按鈕接線');
  assert.match(source, /function addCharacterCard\(\)\{[\s\S]{0,560}openSheetEditDialog\(\);/, '新增後直接打開編輯對話框');
  assert.match(source, /function deleteCharacterCard\(\)\{[\s\S]{0,300}filter\(item=>item\.id!==card\.id\)/, '刪除只移除該張卡並同步移除勾選');
  assert.match(source, /if\(del\)del\.hidden=!cards\.length;/, '刪除按鈕只要有額外卡就顯示');
  assert.match(source, /mainOption\.textContent=uiText\('主要角色卡'\);/, '目標下拉含主要角色卡');
  assert.match(source, /const card=sheetEditTargetCard\(\);\s*const previous=state\.characterSheet,previousCards=state\.characterCards;/, '編輯保存依目標寫入（主要卡或該張卡）');
  assert.match(source, /state\.characterCards=characterCardsList\(\)\.map\(item=>item\.id===card\.id\?\{\.\.\.item,name:[\s\S]{0,140}normalizeCharacterSheet\(fields\)\}:item\);/, '保存寫入該張卡（含名稱）');
  assert.match(css, /\.character-cards-bar\{display:flex;flex-wrap:wrap/, '切換列樣式');
  assert.match(css, /\.character-cards-bar \.card-chip\.active/, '勾選中的卡片高亮');
  const uiEn = source.slice(source.indexOf('const UI_EN = {'), source.indexOf('\n};', source.indexOf('const UI_EN = {')));
  for (const key of ['＋ 新增角色卡', '刪除角色卡', '角色名稱', '刪除這張角色卡？', '新角色', '參與故事（可多選）', '參與故事的角色', '主要角色卡', '角色卡最多 12 張，請先刪除不需要的。']) {
    assert.ok(uiEn.includes(`'${key}':`), `UI_EN covers ${key}`);
  }
});
