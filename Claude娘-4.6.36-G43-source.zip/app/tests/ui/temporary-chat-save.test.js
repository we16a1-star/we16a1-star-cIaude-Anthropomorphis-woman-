import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');
const storage = readFileSync(new URL('../../www/save-storage.js', import.meta.url), 'utf8');
const main = readFileSync(new URL('../../electron-main.cjs', import.meta.url), 'utf8');
const flow = readFileSync(new URL('../../ai-web-flow.cjs', import.meta.url), 'utf8');

test('臨時對話存檔會落地本機：沒有任何「不寫入／刪除」的例外路徑', () => {
  assert.doesNotMatch(source, /kind === 'incognito'\) continue/, 'persistSlots writes the temporary slot like any other save');
  assert.doesNotMatch(source, /slotsIndexPayload\(slots\.filter\(/, 'the slot index includes the temporary slot');
  assert.doesNotMatch(source, /if \(active\.kind === 'incognito'\) \{[\s\S]{0,220}renderSaveStatus\(\);[\s\S]{0,60}return true;\s*\}/, 'save() persists the temporary slot instead of memory-only updates');
  assert.doesNotMatch(source, /無痕對話不會建立存檔/, 'no alert ever blocks quick save / checkpoints');
  assert.doesNotMatch(source, /無痕對話不會保存/, 'leaving no longer deletes the temporary slot');
  assert.match(source, /function confirmLeaveIncognito\(\)\{\s*return true;\s*\}/, 'leave/switch flows keep the temporary save');
  assert.doesNotMatch(source, /exportSlots=slots\.filter\(/, 'export includes the temporary slot');
  assert.match(source, /localStorage\.setItem\('claude_novel_active_slot_v1',INCOGNITO_SLOT_ID\)/, 'starting a temporary story records the active slot so it resumes after relaunch');
  assert.match(source, /temporaryChat: \!\!slot\.temporaryChat/, 'normalizeSlot round-trips the temporaryChat flag');
  assert.match(storage, /temporaryChat: \!\!slot\?\.temporaryChat/, 'slot index carries the temporaryChat flag');
  assert.match(storage, /temporaryChat: \!\!entry\?\.temporaryChat/, 'slot index parsing restores the temporaryChat flag');
});

test('臨時對話格的存檔控制：可刪除、自動落地、不佔用自動存檔格', () => {
  assert.match(source, /if \(target\.kind === 'auto' \|\| target\.kind === 'quick'\)/, 'only auto/quick system slots refuse deletion; the temporary slot can be deleted by the player');
  assert.match(source, /activeSlot\.kind==='manual'\|\|activeSlot\.kind==='incognito'/, 'the in-story delete button is enabled for the temporary slot');
  assert.match(source, /if\(!autoSaveEnabled&&!force&&active\.kind!=='incognito'\)\{manualSaveDirty=true;/, 'temporary stories auto-persist regardless of the manual-save switch');
  assert.match(source, /if \(slots\.some\(x => x\.kind === 'incognito'\)\) return; \/\/ 臨時對話：該格自己隨回合落地/, 'the temporary story does not overwrite the auto-save slot');
});

test('介面全面改稱「臨時」，不再出現「無痕」字樣', () => {
  assert.ok(!source.includes('無痕'), 'app.js has no 無痕 text left');
  assert.match(source, /uiText\('保存記錄（預設）'\)/, 'opening option defaults to 保存記錄（預設）');
  assert.match(source, /uiText\('臨時對話'\)/, '臨時對話 remains available as an option');
  assert.match(source, /name:'臨時對話'/, 'the temporary slot is named 臨時對話');
  assert.match(source, /uiText\('臨時'\)/, 'slot badge shows 臨時');
  assert.match(source, /網頁模式可使用清單中的 12 家 AI 官網；臨時對話目前限 ChatGPT 與 Gemini/, 'the opening hint explains all listed web providers and the temporary-chat limitation');
  const uiEn = source.slice(source.indexOf('const UI_EN = {'), source.indexOf('\n};', source.indexOf('const UI_EN = {')));
  assert.ok(!uiEn.includes('無痕'), 'UI_EN has no Incognito entries left');
  for (const key of ['臨時對話', '保存記錄（預設）', '臨時', '臨時對話：本機自動存檔', '官網使用臨時對話（本機照常存檔）', '已經有一個臨時對話存檔；開始新的臨時對話會取代它。要繼續嗎？']) {
    assert.ok(uiEn.includes(`'${key}':`), `UI_EN covers ${key}`);
  }
});

test('保存記錄模式也能使用官網臨時對話，且照常存檔', () => {
  assert.match(source, /id="openingTempChat"/, 'the opening panel offers a website temporary-chat checkbox');
  assert.match(source, /function slotWantsTemporaryChat\(id\)\{[\s\S]{0,160}slot\.kind==='incognito'\|\|slot\.temporaryChat===true/, 'temporary-chat gating covers incognito and flagged save slots');
  assert.match(source, /const requiresTemporaryChat=slotWantsTemporaryChat\(activeSlotId\)/, 'every turn re-checks the temporary-chat requirement');
  assert.match(source, /if\(slotWantsTemporaryChat\(activeSlotId\)\)throw new Error\(uiText\('臨時對話故事只能透過已確認的 ChatGPT 或 Gemini 官網進行/, 'API mode is refused for temporary-chat stories');
  assert.match(source, /newSlot\.temporaryChat=openingSaveTempChatSelected\(\)/, 'the checkbox state is stored on the new save slot');
  assert.match(main, /requireTemporaryChat/, 'main keeps the provider-side temporary-chat verification');
  assert.match(flow, /TEMPORARY_CHAT_PROVIDERS\s*=\s*Object\.freeze\(\['openai',\s*'gemini'\]\)/, 'provider-side temporary chat support is unchanged');
});

test('Esc 像 galgame 一樣逐層退後；故事中直接叫出退出／存檔選單', () => {
  assert.match(source, /if \(storyLogOpen\) \{ setBacklogOpen\(false\); return; \}/, 'Escape first closes the backlog');
  assert.match(source, /const openDialog = document\.querySelector\('dialog\[open\]'\);[\s\S]{0,80}openDialog\.close\(\); return;/, 'Escape closes the topmost dialog');
  assert.match(source, /if \(gameMenuOpen\) \{ setGameMenu\(false\); return; \}/, 'Escape then closes the game menu');
  assert.match(source, /if \(storyExited\) \{ resumeStory\(\); return; \}/, 'Escape resumes from the exit overlay');
  assert.match(source, /storyTab\?\.classList\.contains\('active'\) && \(state\.history\.length \|\| state\.pendingAction\)\) leaveStory\(\)/, 'with nothing open, Escape opens the exit/save overlay');
});
