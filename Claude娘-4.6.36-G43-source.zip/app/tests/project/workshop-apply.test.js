import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {mkdtempSync, mkdirSync, writeFileSync, readFileSync, existsSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';

const require = createRequire(import.meta.url);
const W = require('../../workshop-apply.cjs');
const allowed = new Set(['www/app.js', 'server/server.js', 'electron-main.cjs', 'package.json', 'www/style.css']);
const read = rel => readFileSync(new URL('../../' + rel, import.meta.url), 'utf8');

function makeProject() {
  const root = mkdtempSync(path.join(tmpdir(), 'ws-proj-'));
  const appDir = path.join(root, 'app');
  mkdirSync(path.join(appDir, 'www'), {recursive: true});
  writeFileSync(path.join(appDir, 'package.json'), JSON.stringify({name: W.PROJECT_NAME, main: 'electron-main.cjs', scripts: {dist: 'x'}, build: {}}));
  writeFileSync(path.join(appDir, 'electron-main.cjs'), '// main\n');
  writeFileSync(path.join(appDir, 'www', 'app.js'), 'export const v = 1;\n');
  return {root, appDir};
}

test('validateFiles still accepts an allowlist, but the allowlist is optional (v4.4.0 整個專案都能改)', () => {
  assert.deepEqual(W.validateFiles({'www/app.js': 'a'}, allowed), [{path: 'www/app.js', content: 'a'}]);
  assert.throws(() => W.validateFiles({'../evil.js': 'a'}, allowed), /不支援/);
  assert.throws(() => W.validateFiles({'www/app.js': 5}, allowed), /不支援/);
  assert.throws(() => W.validateFiles({}, allowed), /沒有可套用/);
  assert.throws(() => W.validateFiles([], allowed), /格式無效/);
  assert.throws(() => W.validateFiles({'www/app.js': 'x'.repeat(W.MAX_FILE_BYTES + 1)}, allowed), /超過/);
  const many = new Set(['a.js', 'b.js', 'c.js', 'd.js', 'e.js', 'f.js']);
  const big = Object.fromEntries([...many].map(name => [name, 'x'.repeat(399000)]));
  assert.throws(() => W.validateFiles(big, many), /總量/);
  // 沒有白名單時：專案內任何地方（含新檔案、文件、腳本）都能寫入。
  assert.deepEqual(W.validateFiles({'docs/新說明.md': 'hi', 'app/tools/new.cjs': 'x'}).map(e => e.path), ['docs/新說明.md', 'app/tools/new.cjs']);
});

test('v4.4.0 blocks only the unsafe paths: traversal, dependencies, build output, backups and secrets', () => {
  for (const bad of ['../outside.js', 'www/../../outside.js', '/etc/passwd', 'C:/Windows/system32/x.dll', 'www\\..\\..\\x.js', '', '   ']) {
    assert.throws(() => W.validateFiles({[bad]: 'a'}), /不支援/, bad);
  }
  for (const bad of ['node_modules/express/index.js', 'www/node_modules/x.js', '.git/config', 'dist/win-unpacked/app.js', 'release/x.txt', 'app/_build-tools/node/node.exe', '.workshop-backup/20260101-000000/www/app.js', '.cache/x.json', 'server/.env', '.env', '.env.local', 'source-root.json', 'www/app.js.workshop-tmp']) {
    assert.throws(() => W.validateFiles({[bad]: 'a'}), /不支援/, bad);
  }
  assert.deepEqual(W.validateFiles({'www/new-feature.js': 'export const a = 1;\n'}).map(e => e.path), ['www/new-feature.js']);
  assert.equal(W.normalizeRelativePath('www\\app.js'), 'www/app.js');
  assert.equal(W.normalizeRelativePath('./www//app.js'), 'www/app.js');
});

test('Windows 路徑陷阱一併擋掉：NTFS 資料流、結尾句點與空白、保留裝置名稱', () => {
  // 這些寫法在 Windows 上會被重新解讀，可能繞過上方封鎖清單（例如 .env:stream 其實是 .env 的資料流）
  for (const bad of ['.env:stream', 'www/app.js:evil', '.env:hidden', 'foo./bar.js', 'foo /bar.js', 'nul', 'CON.txt', 'com1.log', 'www/LPT9.js']) {
    assert.throws(() => W.validateFiles({[bad]: 'a'}), /不支援/, bad);
  }
  assert.throws(() => W.normalizeRelativePath('a:b'), /不支援/);
  assert.throws(() => W.normalizeRelativePath('nul'), /不支援/);
  assert.throws(() => W.normalizeRelativePath('docs/v1.'), /不支援/);
  assert.equal(W.normalizeRelativePath('www/app.js'), 'www/app.js', '正常路徑不受影響');
  assert.equal(W.normalizeRelativePath('docs/新說明.md'), 'docs/新說明.md');
  assert.equal(W.normalizeRelativePath('www/nul-file.js'), 'www/nul-file.js', '名字以 nul 開頭但不是裝置名稱的檔案可用');
  assert.equal(W.normalizeRelativePath('www/com10.js'), 'www/com10.js', 'com10 不是保留名稱');
});

test('safeTarget refuses to leave the project folder', () => {
  const {appDir} = makeProject();
  assert.equal(W.safeTarget(appDir, 'www/app.js'), path.join(appDir, 'www', 'app.js'));
  assert.throws(() => W.safeTarget(appDir, '../outside.js'), /拒絕/);
  assert.throws(() => W.safeTarget(appDir, '../../etc/passwd'), /拒絕/);
});

test('listEditableFiles walks the whole project but skips dependencies, build output, backups and secrets', () => {
  const {appDir} = makeProject();
  mkdirSync(path.join(appDir, 'docs'), {recursive: true});
  mkdirSync(path.join(appDir, 'node_modules', 'express'), {recursive: true});
  mkdirSync(path.join(appDir, '.git'), {recursive: true});
  mkdirSync(path.join(appDir, 'dist'), {recursive: true});
  mkdirSync(path.join(appDir, '.workshop-backup', '20260101'), {recursive: true});
  writeFileSync(path.join(appDir, 'docs', '說明.md'), '# hi\n');
  writeFileSync(path.join(appDir, 'node_modules', 'express', 'index.js'), 'x');
  writeFileSync(path.join(appDir, '.git', 'config'), 'x');
  writeFileSync(path.join(appDir, 'dist', 'app.exe'), 'x');
  writeFileSync(path.join(appDir, '.env'), 'SECRET=1');
  writeFileSync(path.join(appDir, '.workshop-backup', '20260101', 'www.js'), 'x');
  const files = W.listEditableFiles(appDir).map(item => item.path);
  for (const expected of ['package.json', 'electron-main.cjs', 'www/app.js', 'docs/說明.md']) assert.ok(files.includes(expected), expected);
  for (const skipped of ['node_modules/express/index.js', '.git/config', 'dist/app.exe', '.env', '.workshop-backup/20260101/www.js', 'source-root.json']) assert.ok(!files.includes(skipped), skipped);
  assert.ok(W.listEditableFiles(appDir).every(item => typeof item.bytes === 'number'));
});

test('readEditableFile reads inside the project and refuses outside, missing, oversized and blocked files', () => {
  const {appDir} = makeProject();
  assert.equal(W.readEditableFile(appDir, 'www/app.js'), 'export const v = 1;\n');
  assert.throws(() => W.readEditableFile(appDir, '../outside.js'), /不支援/);
  assert.throws(() => W.readEditableFile(appDir, 'node_modules/x.js'), /不支援/);
  assert.throws(() => W.readEditableFile(appDir, 'www/missing.js'), /找不到這個程式檔/);
  writeFileSync(path.join(appDir, 'www', 'big.js'), 'x'.repeat(W.MAX_FILE_BYTES + 1));
  assert.throws(() => W.readEditableFile(appDir, 'www/big.js'), /超過/);
});

test('resolveSourceRoot validates the marker, the folder and the project identity', () => {
  const {root, appDir} = makeProject();
  const installed = mkdtempSync(path.join(tmpdir(), 'ws-installed-'));
  assert.throws(() => W.resolveSourceRoot(installed), /找不到原始專案位置/);
  writeFileSync(path.join(installed, W.SOURCE_ROOT_FILE), JSON.stringify({appDir: path.join(root, 'gone')}));
  assert.throws(() => W.resolveSourceRoot(installed), /已移動或刪除/);
  writeFileSync(path.join(installed, W.SOURCE_ROOT_FILE), JSON.stringify({appDir}));
  assert.equal(W.resolveSourceRoot(installed), path.resolve(appDir));
  writeFileSync(path.join(appDir, 'package.json'), JSON.stringify({name: 'something-else'}));
  assert.throws(() => W.resolveSourceRoot(installed), /不是本專案/);
});

test('resolveWorkshopRoot prefers the whole delivery folder, falls back to app, then to the installed content', () => {
  const {root, appDir} = makeProject();
  const installed = mkdtempSync(path.join(tmpdir(), 'ws-installed-'));
  const noMarker = W.resolveWorkshopRoot(installed);
  assert.equal(noMarker.scope, 'installed');
  assert.equal(noMarker.original, false);
  assert.equal(noMarker.dir, path.resolve(installed));
  assert.match(noMarker.reason, /找不到原始專案位置/);
  writeFileSync(path.join(installed, W.SOURCE_ROOT_FILE), JSON.stringify({appDir}));
  const appOnly = W.resolveWorkshopRoot(installed);
  assert.equal(appOnly.scope, 'app');
  assert.equal(appOnly.dir, path.resolve(appDir));
  writeFileSync(path.join(installed, W.SOURCE_ROOT_FILE), JSON.stringify({appDir, rootDir: root}));
  const whole = W.resolveWorkshopRoot(installed);
  assert.equal(whole.scope, 'project', 'rootDir wins so docs and build scripts are editable too');
  assert.equal(whole.dir, path.resolve(root));
  assert.equal(whole.original, true);
  writeFileSync(path.join(installed, W.SOURCE_ROOT_FILE), JSON.stringify({appDir, rootDir: path.join(root, 'gone')}));
  assert.equal(W.resolveWorkshopRoot(installed).scope, 'app', 'a stale rootDir falls back to the app folder');
  writeFileSync(path.join(installed, W.SOURCE_ROOT_FILE), JSON.stringify({rootDir: root}));
  assert.equal(W.resolveSourceRoot(installed), path.resolve(appDir), 'rootDir alone still finds app/');
});

test('checkSyntax accepts valid ESM/CJS, reports real file names, and guards package.json and other JSON', () => {
  const ok = W.checkSyntax([
    {path: 'www/app.js', content: "import fs from 'node:fs';\nexport const a = () => fs;\n"},
    {path: 'electron-main.cjs', content: "const x = require('node:fs');\nmodule.exports = x;\n"},
    {path: 'www/style.css', content: 'body{color:red}'},
    {path: 'www/manifest.json', content: '{"name":"ok"}'}
  ]);
  assert.deepEqual(ok, {problems: [], unchecked: []});
  const {problems: bad} = W.checkSyntax([
    {path: 'www/app.js', content: 'export const = ;\n'},
    {path: 'package.json', content: '{oops'},
  ]);
  assert.equal(bad.length, 2);
  assert.equal(bad[0].file, 'www/app.js');
  assert.ok(!bad[0].message.includes('workshop-check-'), 'temp paths are replaced by the real file name');
  assert.match(bad[1].message, /JSON/);
  const changedPkg = W.checkSyntax([{path: 'package.json', content: JSON.stringify({name: 'x'})}]).problems;
  assert.match(changedPkg[0].message, /name、main/);
  const brokenJson = W.checkSyntax([{path: 'www/settings.json', content: '{oops'}]).problems;
  assert.equal(brokenJson[0].file, 'www/settings.json');
});

test('checkSyntax never blocks on a checker that cannot run, but reports the file as unchecked', () => {
  const fake = () => ({status: 9, stderr: 'node: bad option: --check', error: undefined});
  const result = W.checkSyntax([{path: 'www/app.js', content: 'export const a = 1;\n'}], {spawn: fake});
  assert.deepEqual(result, {problems: [], unchecked: ['www/app.js']});
  const crashed = W.checkSyntax([{path: 'www/app.js', content: 'x'}], {spawn: () => ({error: new Error('ENOENT')})});
  assert.deepEqual(crashed.unchecked, ['www/app.js']);
});

test('applyFiles backs up originals, writes new content (including brand-new files) and leaves no temp files', () => {
  const {appDir} = makeProject();
  const result = W.applyFiles(appDir, [
    {path: 'www/app.js', content: 'export const v = 2;\n'},
    {path: 'www/style.css', content: 'body{}\n'},
    {path: 'docs/新檔案.md', content: '# new\n'}
  ], {now: new Date(2026, 9, 14, 8, 30, 15)});
  assert.deepEqual(result.written, ['www/app.js', 'www/style.css', 'docs/新檔案.md']);
  assert.equal(readFileSync(path.join(appDir, 'www', 'app.js'), 'utf8'), 'export const v = 2;\n');
  assert.equal(readFileSync(path.join(appDir, 'docs', '新檔案.md'), 'utf8'), '# new\n');
  assert.equal(readFileSync(path.join(result.backupDir, 'www', 'app.js'), 'utf8'), 'export const v = 1;\n');
  assert.ok(result.backupDir.endsWith('20261014-083015'));
  assert.ok(!existsSync(path.join(result.backupDir, 'www', 'style.css')), 'new files have nothing to back up');
  assert.ok(!existsSync(path.join(appDir, 'www', 'app.js.workshop-tmp')));
});

test('applyFiles restores already written files when a later write fails', () => {
  const {appDir} = makeProject();
  mkdirSync(path.join(appDir, 'blocked', 'inner'), {recursive: true});   // 目標是非空資料夾，改名覆寫會失敗
  assert.throws(() => W.applyFiles(appDir, [
    {path: 'www/app.js', content: 'export const v = 99;\n'},
    {path: 'blocked', content: 'cannot replace a folder'}
  ]), /已還原/);
  assert.equal(readFileSync(path.join(appDir, 'www', 'app.js'), 'utf8'), 'export const v = 1;\n');
  assert.ok(!existsSync(path.join(appDir, 'blocked.workshop-tmp')));
});

test('the workshop is wired into Electron, the preload bridge, the editor and the installer without an allowlist', () => {
  const main = read('electron-main.cjs');
  const preload = read('electron-preload.cjs');
  const app = read('www/app.js');
  const html = read('www/index.html');
  const pkg = JSON.parse(read('package.json'));
  const bat = read('BUILD-WINDOWS11-AUTO.bat');
  assert.match(main, /ipcMain\.handle\('workshop-code:list'/, 'main can list every editable file');
  assert.match(main, /ipcMain\.handle\('workshop-code:info'/);
  assert.match(main, /ipcMain\.handle\('workshop-code:apply',[\s\S]{0,520}?workshopApply\.validateFiles\(requestedFiles\)/, 'apply no longer needs an allowlist argument');
  assert.ok(!main.includes('WORKSHOP_SOURCE_PATHS'), 'the editor allowlist is gone in v4.4.0');
  assert.ok(!app.includes('WORKSHOP_CODE_FILES'), 'the renderer allowlist is gone in v4.4.0');
  assert.match(main, /function workshopSourceRoot\(/, 'the workshop prefers the original source folder');
  assert.ok(main.includes('assertTrustedRenderer(event)'));
  assert.match(preload, /listWorkshopSources/, 'the preload bridge exposes the file list');
  assert.match(app, /let workshopListRequest=0/, 'overlapping refreshes are tracked so stale results cannot replace the latest list');
  assert.match(app, /if\(request!==workshopListRequest\)return/, 'stale list responses are ignored');
  assert.match(app, /沒有可編輯的程式檔/, 'an empty source list is shown explicitly');
  assert.match(app, /清單載入失敗/, 'a failed refresh replaces stale options with an error state');
  assert.match(main, /truncated: files\.length >= workshopApply\.MAX_LISTED_FILES/, 'the renderer can warn when the file list reaches its cap');
  assert.ok(preload.includes('applyWorkshopCode') && preload.includes('rebuildFromWorkshop'));
  for (const id of ['applyWorkshopCodeBtn', 'rebuildWorkshopCodeBtn', 'openWorkshopCodePathBtn', 'refreshWorkshopCodeListBtn']) assert.ok(html.includes(`id="${id}"`) && app.includes(`$('${id}')`), id);
  for (const file of ['workshop-apply.cjs', 'source-root.json']) assert.ok(pkg.build.files.includes(file), `${file} is packaged`);
  assert.match(bat, /source-root\.json/, 'the one-click build records where the source folder is');
  assert.match(bat, /AUTO_INSTALL_SFX.*source-root|source-root[^\r\n]*AUTO_INSTALL_SFX|if \/I not "%AUTO_INSTALL_SFX%"=="1" "%NODE%\\node\.exe" -e/, 'the marker is skipped for the self-extracting installer');
});
