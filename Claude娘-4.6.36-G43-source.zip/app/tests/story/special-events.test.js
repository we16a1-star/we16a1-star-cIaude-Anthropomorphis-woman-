// 約會型特殊事件：每回合成功後 8% 抽一次，下一回合提示詞才帶入。
// 釘住：機率邊界、70% 約會／30% 由 AI 安排、存檔欄位與 app/server 提示詞接線、
// 以及「不要向玩家說明這是系統安排」的沉浸規則。
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import {
  SPECIAL_EVENT_CHANCE, SPECIAL_EVENT_KEYS,
  normalizeSpecialEventKey, rollSpecialEvent, specialEventPromptLines
} from '../../www/special-events.js';

const appSource = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');
const serverSource = readFileSync(new URL('../../server/server.js', import.meta.url), 'utf8');

test('特殊事件機率固定 8%，且三種來源都存在', () => {
  assert.equal(SPECIAL_EVENT_CHANCE, 0.08);
  assert.deepEqual(SPECIAL_EVENT_KEYS, ['date', 'free', 'milestone']);
});

test('每回合只抽一次：0.0799 觸發、0.08 不觸發', () => {
  assert.equal(rollSpecialEvent(() => 0.0799), 'date');
  assert.equal(rollSpecialEvent(() => 0.08), '');
  assert.equal(rollSpecialEvent(() => 0.999), '');
});

test('觸發後 70% 約會、30% 交給 AI 自行安排', () => {
  const seq = (...values) => { let index = 0; return () => values[Math.min(index++, values.length - 1)]; };
  assert.equal(rollSpecialEvent(seq(0.079, 0)), 'date', '第二抽 < 0.7＝約會');
  assert.equal(rollSpecialEvent(seq(0.079, 0.6999)), 'date', '第二抽 0.6999＝約會');
  assert.equal(rollSpecialEvent(seq(0.079, 0.7)), 'free', '第二抽 0.7＝AI 安排');
  assert.equal(rollSpecialEvent(seq(0.079, 0.999)), 'free');
  assert.equal(rollSpecialEvent(() => 0.999), '', '第一抽未中＝沒有事件');
});

test('壞掉或舊存檔的事件鍵一律安全回空', () => {
  assert.equal(normalizeSpecialEventKey('date'), 'date');
  assert.equal(normalizeSpecialEventKey('free'), 'free');
  assert.equal(normalizeSpecialEventKey('milestone'), 'milestone');
  assert.equal(normalizeSpecialEventKey('__proto__'), '');
  assert.equal(normalizeSpecialEventKey(null), '');
  assert.deepEqual(specialEventPromptLines(''), []);
});

test('提示詞是約會／出遊型，且不揭露系統安排', () => {
  const date = specialEventPromptLines('date', 'zh').join('\n');
  assert.match(date, /約會|出遊/);
  assert.match(date, /不要.*系統安排|不要向玩家說明/);
  assert.match(date, /七個選項/);
  assert.match(date, /婉拒.*不扣好感/);
  const free = specialEventPromptLines('free', 'zh').join('\n');
  assert.match(free, /由你安排/);
  assert.match(free, /約會/);
  const milestone = specialEventPromptLines('milestone', 'zh').join('\n');
  assert.match(milestone, /里程碑/);
  assert.match(milestone, /約會|外出|獨處/);
  const en = specialEventPromptLines('date', 'en').join('\n');
  assert.match(en, /date or outing/i);
  assert.match(en, /Do not tell the player/i);
  assert.match(en, /must not reduce affection/i);
});

test('app.js 接線：存檔、提示詞、API 請求與成功後重抽都在', () => {
  assert.match(appSource, /import \{[^}]*normalizeSpecialEventKey[^}]*rollSpecialEvent[^}]*specialEventPromptLines[^}]*\} from '\.\/special-events\.js'/);
  assert.match(appSource, /pendingSpecialEvent: ''/);
  assert.match(appSource, /pendingSpecialEvent:normalizeSpecialEventKey\(value\.pendingSpecialEvent\)/);
  assert.match(appSource, /pendingSpecialEvent: normalizeSpecialEventKey\(rawState\.pendingSpecialEvent\)/);
  assert.match(appSource, /pendingSpecialEvent: normalizeSpecialEventKey\(source\.pendingSpecialEvent\)/);
  assert.match(appSource, /specialEventPromptLines\(state\.pendingSpecialEvent,uiLanguage\)/);
  assert.match(appSource, /specialEvent:isOpening\?'':normalizeSpecialEventKey\(state\.pendingSpecialEvent\)/);
  assert.match(appSource, /state\.pendingSpecialEvent=\(undoBefore\.action==='__OPENING__'\|\|state\.ending\|\|state\.pendingMilestone\)\?'':rollSpecialEvent\(\)/);
  assert.match(appSource, /state\.pendingSpecialEvent=safe\.pendingSpecialEvent/);
  assert.match(appSource, /pendingSpecialEvent:undoBefore\.pendingSpecialEvent/);
});

test('server.js 接線：API 提示詞也支援特殊事件與里程碑', () => {
  assert.match(serverSource, /specialEventPromptLines\(normalizeSpecialEventKey\(body\.specialEvent\),body\.language\)/);
  assert.match(serverSource, /const milestoneLines=milestone\?specialEventPromptLines\('milestone',body\.language\)/);
  assert.match(serverSource, /\.\.\.specialEventLines/);
});
