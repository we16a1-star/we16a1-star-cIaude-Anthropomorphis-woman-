import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { parse, requestSystemInstruction } from '../../server/server.js';
import { evaluateModelCheck } from '../../www/model-check.js';

const choices = ['陪她喝茶', '問起窗外的雨', '一起整理書架', '看她手上的書', '點亮桌燈', '談談今晚的音樂', '安靜坐在一旁'];
const base = { narration: '她接過熱茶，露出笑容。', affectionDelta: 1, choices, ending: false, endingText: null, memory: '雨夜喝茶。' };
const app = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');
const anim = readFileSync(new URL('../../www/portrait-anim.js', import.meta.url), 'utf8');
const css = readFileSync(new URL('../../www/style.css', import.meta.url), 'utf8');

test('故事回覆情緒契約：提示詞列出情緒值，API parser 保留有效值並相容舊回覆', () => {
  const prompt = requestSystemInstruction({ language: 'zh' });
  assert.match(prompt, /欄位：narration、affectionDelta、choices、ending、endingText、memory、emotion、intensity/);
  assert.match(prompt, /neutral、happy、proud、shy、surprised、dizzy、curious、focused/);
  assert.match(prompt, /暗自滿意.*用 proud/);
  assert.match(prompt, /閱讀、思考、解題或認真聆聽時用 focused/);
  assert.match(prompt, /不能只按好感變化推測/);
  assert.equal(parse(JSON.stringify({ ...base, emotion: 'shy' })).emotion, 'shy');
  assert.equal(parse(JSON.stringify({ ...base, emotion: 'curious' })).emotion, 'curious');
  assert.equal(parse(JSON.stringify({ ...base, emotion: 'focused', intensity: 3 })).emotion, 'focused');
  assert.equal(parse(JSON.stringify({ ...base, emotion: 'focused', intensity: 3 })).intensity, 3);
  assert.equal(parse(JSON.stringify({ ...base, emotion: 'proud' })).emotion, 'proud');
  assert.equal(parse(JSON.stringify(base)).emotion, 'neutral', '舊版 API 回覆缺欄位時預設 neutral');
  assert.equal(parse(JSON.stringify(base)).intensity, 1, '舊版 API 回覆缺強度時相容為 1');
  assert.equal(parse(JSON.stringify({ ...base, intensity: 9 })).intensity, 3, '強度會限制在 1～3');
  assert.equal(parse(JSON.stringify({ ...base, emotion: 'angry' })).emotion, 'neutral', '未知情緒值安全回退 neutral');
});

test('模型相容性檢查：emotion 與 intensity 欄位都符合契約', () => {
  const reply = { ...base, emotion: 'happy', intensity: 2 };
  assert.equal(evaluateModelCheck(reply).ok, true);
  const missing = evaluateModelCheck(base);
  assert.equal(missing.ok, false);
  assert.equal(missing.checks.find(item => item.key === 'emotion').ok, false);
  assert.equal(missing.checks.find(item => item.key === 'intensity').ok, false);
});

test('故事情緒存入存檔並驅動立繪表情窗；舊存檔仍回退 neutral', () => {
  assert.match(app, /storyEmotion: normalizeStoryEmotion\(rawState\.storyEmotion\)/);
  assert.match(app, /storyEmotionIntensity: normalizeStoryEmotionIntensity\(rawState\.storyEmotionIntensity\)/);
  assert.match(app, /state\.storyEmotion=normalizeStoryEmotion\(r\.emotion\)/);
  assert.match(app, /setStoryEmotion\?\.\(window\.__storyEmotion,window\.__storyEmotionIntensity,window\.__storyEmotionToken\)/);
  assert.match(anim, /function setStoryEmotion\(value, intensity = 1, token = null\)/);
  assert.match(anim, /focused: 9000/);
  assert.match(anim, /now - state\.lastEmotionAt < 6000/);
  assert.match(anim, /emotion === 'neutral' \? 'story-daily'/);
  assert.match(anim, /emotion === 'proud' \? 'story-proud'/);
  assert.match(anim, /emotion === 'shy' \? 'story-shy'/);
  assert.match(anim, /emotion === 'focused' \? 'story-focused'/);
  assert.match(anim, /neutral: 1800/);
  assert.match(anim, /emotion === 'curious' \? 'curious'/);
  assert.match(css, /\.pa-face\.pa-curious::after/);
  assert.match(css, /\.vn-stage\.pa-emotion-neutral \.pa-daily-tea/);
  assert.match(css, /\.vn-stage\.pa-emotion-proud \.story-portrait\.pa-canvas/);
  assert.match(css, /\.vn-stage\.pa-emotion-shy \.story-portrait\.pa-canvas/);
  assert.match(css, /\.vn-stage\.pa-emotion-curious \.story-portrait\.pa-canvas/);
  assert.match(css, /\.vn-stage\.pa-emotion-focused \.story-portrait\.pa-canvas/);
  assert.match(anim, /classList\.add\('pa-story-emotion'\)/);
  assert.match(css, /\.pa-face\.pa-story-emotion\{opacity:1;scale:1;animation:none\}/);
});
