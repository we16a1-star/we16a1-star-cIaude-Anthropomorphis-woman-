import test from 'node:test';
import assert from 'node:assert/strict';
import { Script, runInNewContext } from 'node:vm';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const flow = require('../../ai-web-flow.cjs');
const main = readFileSync(new URL('../../electron-main.cjs', import.meta.url), 'utf8');
const preload = readFileSync(new URL('../../electron-preload.cjs', import.meta.url), 'utf8');
const webApp = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');

function runSequence(probes, { baseline, minLength = 5, requiredStable = 2 } = {}) {
  let lastText = '';
  let stableCount = 0;
  let emitted = null;
  for (const probe of probes) {
    const step = flow.replyProgress({ probe, baseline, lastText, stableCount, minLength, requiredStable });
    lastText = step.lastText;
    stableCount = step.stableCount;
    if (step.emit) emitted = step.reply;
  }
  return { emitted, lastText, stableCount };
}

test('自動化頁面腳本全部可在官網頁面解析，且填入腳本保持安全', () => {
  const tricky = '引號\'、"雙引號"、\\反斜線、${樣板}、換行\n結束';
  const scripts = [
    ['填入', flow.buildFillScript(tricky)],
    ['送出', flow.buildSubmitScript()],
    ['探測', flow.buildReplyProbeScript()],
    ['複製', flow.buildCopyClickScript()],
    ['ChatGPT 臨時對話', flow.buildTemporaryChatScript('openai', {startNew: true})],
    ['Gemini 臨時對話', flow.buildTemporaryChatScript('gemini', {startNew: false})]
  ];
  for (const [name, script] of scripts) {
    assert.equal(typeof script, 'string', `${name}腳本必須是字串`);
    assert.doesNotThrow(() => new Script(script), `${name}腳本必須是有效 JavaScript`);
  }
  const fill = flow.buildFillScript(tricky);
  assert.match(fill, /tagName\.toLowerCase\(\)!=='input'/, '填入時不會把登入用的 input 當成訊息輸入框');
  assert.match(fill, /alreadyFilled/, '輸入框已有同一段文字時回報已填入，不重複覆蓋');
  assert.match(fill, /const verified=landed\(\);\s*return \{ok:verified,alreadyFilled:false,verified,error:verified\?'':'官網未確認完整提示詞已填入。'\}/, '內容未完整落入輸入框時絕不送出');
  assert.match(fill, /未送出的文字/, '輸入框有別的文字時拒絕覆蓋，避免弄丟玩家內容');
  assert.match(fill, /const norm=s=>String\(s\|\|''\)\.replace\(\/\\s\+\/g,' '\)\.trim\(\);/, '比對輸入框內容時忽略空白差異（換行摺疊、空行分段不會誤判成殘留舊文字）');
  assert.match(fill, /InputEvent/, '填入後會通知官網輸入事件，網站才會啟用送出鈕');
});

test('清單上的 12 家 AI 官網都接入共用網頁故事流程；Claude 使用一般保存記錄模式', () => {
  const ids = flow.SITE_MATRIX.map(site => site.id);
  assert.equal(ids.length, 12);
  assert.deepEqual(ids, ['openai','anthropic','gemini','deepseek','grok','qwen','mistral','copilot','perplexity','meta','kimi','glm']);
  const providerBlock = webApp.slice(webApp.indexOf('const WEB_AI_PROVIDERS=['), webApp.indexOf('];', webApp.indexOf('const WEB_AI_PROVIDERS=[')));
  for (const id of ids) {
    assert.match(providerBlock, new RegExp(`id:'${id}'`), `${id} appears in the selectable web provider list`);
    assert.match(main, new RegExp(`${id}:'https://`), `${id} has an official website route`);
  }
  assert.match(webApp, /state\.aiMode==='web'&&openingRecordModeDraft==='incognito'&&!TEMPORARY_CHAT_WEB_PROVIDERS\.has\(normalizeWebAIProvider\(state\.webProvider\)\)\)openingRecordModeDraft='save'/, 'switching to Claude or another listed site falls back to the working saved-story flow');
  assert.match(webApp, /const requiresTemporaryChat=slotWantsTemporaryChat\(activeSlotId\)/, 'only saves explicitly marked as temporary require provider temporary-chat verification');
  assert.deepEqual(flow.TEMPORARY_CHAT_PROVIDERS, ['openai','gemini'], 'temporary mode is limited to providers whose official UI can be verified');
});

test('自動化回合會驗證提示詞落入輸入框，再精確送出一次', async () => {
  let sendCount=0;
  const button={disabled:false,innerText:'Send',getAttribute:()=>null,getClientRects:()=>[{}],getBoundingClientRect:()=>({x:10,y:20,width:30,height:30}),click(){sendCount++;}};
  const container={parentElement:null,querySelectorAll:selector=>selector.includes('button')?[button]:[]};
  class MockTextarea {}
  Object.defineProperty(MockTextarea.prototype,'value',{get(){return this._value||'';},set(value){this._value=value;},configurable:true});
  const editor=Object.assign(new MockTextarea(),{tagName:'TEXTAREA',disabled:false,readOnly:false,_value:'',parentElement:container,getAttribute:()=>'',getClientRects:()=>[{}],focus(){},dispatchEvent(){},querySelectorAll:()=>[]});
  const context={
    document:{querySelectorAll:selector=>selector.includes('textarea')?[editor]:[],createRange:()=>({})},
    getComputedStyle:()=>({display:'block',visibility:'visible'}),
    HTMLTextAreaElement:MockTextarea,HTMLInputElement:class {},
    InputEvent:class {},Event:class {},
  };
  const prompt='請依本回合玩家選擇，產生完整故事回覆。';
  const filled=await runInNewContext(flow.buildFillScript(prompt),context);
  assert.equal(filled.ok,true);
  assert.equal(filled.verified,true);
  assert.equal(editor.value,prompt);
  const submitted=runInNewContext(flow.buildSubmitScript(),context);
  assert.equal(submitted.ok,true);
  assert.equal(sendCount,1,'one confirmed prompt causes one send click');
});

test('Gemini 的 Google 登入一律在外部真 Chrome／Edge 完成，App 內不承接 Google OAuth', () => {
  assert.doesNotMatch(main, /handoffGoogleSignInToBrowser/, '不再有 Google OAuth→外部瀏覽器的轉接函式');
  assert.doesNotMatch(main, /ai-web:google-sign-in-handoff/, '主程序不再送外部登入事件');
  assert.match(main, /Google OAuth 不允許嵌入式 user-agent[\s\S]{0,150}Gemini[\s\S]{0,100}Claude[\s\S]{0,100}外部 Chrome／Edge/, 'Claude 與 Gemini 的 Google OAuth 使用外部真瀏覽器');
  assert.match(main, /prefillWebLoginCredential[\s\S]{0,280}?gemini[\s\S]{0,120}?return;/, 'Gemini 不在內建視窗預填任何 Google 帳密');
  assert.match(webApp, /\['gemini','anthropic'\]\.includes\(normalizeWebAIProvider\(provider\)\)[^\n]*return 'external'/, 'Claude and Gemini always use the external browser on desktop');
  assert.match(webApp, /pendingExternalOnly\?'disabled':''/, 'Claude and Gemini disable the embedded-browser option in pending turns');
  assert.match(webApp, /const externalOnly=\['gemini','anthropic'\]\.includes\(webLoginProvider\);[\s\S]*?browserModeSelect\.options\[0\]\.disabled=externalOnly/, 'Claude and Gemini disable embedded sign-in in settings');
  assert.match(webApp, /Gemini 請在外部 Chrome／Edge 視窗完成 Google 登入[^\n]*不需要 Windows PIN/, '提示使用者在外部視窗登入且不需要 PIN');
  const start = webApp.indexOf("window.claudeDesktop?.onGoogleSignInHandoff?.(");
  const end = webApp.indexOf('// 網頁模式自動化狀態事件', start);
  assert.ok(start >= 0 && end > start, 'old handoff listener is only kept for compatibility');
  const handler = webApp.slice(start, end);
  assert.doesNotMatch(handler, /webBrowserMode='external'/, '收到舊事件也絕不切到外部模式');
  assert.doesNotMatch(handler, /localStorage\.setItem\(WEB_BROWSER_MODE_KEY,'external'\)/, '不再把 external 永久寫進設定');
  assert.match(handler, /保留這個事件只是相容舊主程序/, '舊事件只更新提示，不改變登入方式');
  assert.match(webApp, /WEB_BROWSER_MODE_CHOSEN_KEY/, '一次性遷移把舊的自動 external 值重置回內建模式');
  assert.match(main, /'youtube\.com'/, 'Google 登入必要的 accounts.youtube.com 也在白名單');
});

test('Google 登入頁與 Gemini 登出頁會被辨識，且登入鈕回報可點座標', () => {
  const script = flow.buildLoginGateScript('gemini');
  assert.doesNotThrow(() => new Script(script), '登入探測腳本語法正確');
  const googleLogin = runInNewContext(script, {
    location: {hostname: 'accounts.google.com'},
    document: {querySelectorAll: () => []},
    getComputedStyle: () => ({visibility: 'visible', display: 'block'})
  });
  assert.equal(googleLogin.loggedOut, true);
  assert.equal(googleLogin.loginPage, true);
  assert.equal(googleLogin.loginButton, false);

  const loginButton = {
    disabled: false,
    innerText: '登入',
    getClientRects: () => [{}],
    getAttribute: () => '',
    getBoundingClientRect: () => ({left: 100, top: 200, width: 60, height: 30})
  };
  const geminiLoggedOut = runInNewContext(script, {
    location: {hostname: 'gemini.google.com'},
    document: {querySelectorAll: selector => /button/.test(selector) ? [loginButton] : []},
    getComputedStyle: () => ({visibility: 'visible', display: 'block'})
  });
  assert.equal(geminiLoggedOut.loggedOut, true);
  assert.equal(geminiLoggedOut.loginButton, true);
  assert.equal(geminiLoggedOut.x, 130);
  assert.equal(geminiLoggedOut.y, 215);
});

test('外部 Gemini 會沿用登入分頁、自動點登入，並在登入後才確認臨時對話', () => {
  assert.match(main, /function isGoogleLoginTabFor\(tab, base\)[\s\S]*?accounts\\\.google\\\.com[\s\S]*?continuation\.startsWith\(base\)/, '登入分頁用 continue 參數確認是 Gemini 的 Google 登入');
  assert.match(main, /tabs\.find\(tab => isGoogleLoginTabFor\(tab, base\)\)/, '啟用時沿用既有的 Google 登入分頁，不另開新分頁');
  assert.match(main, /if \(watcher\.provider === 'gemini'\)[\s\S]*?buildLoginGateScript\(watcher\.provider\)[\s\S]*?runner\.click\(gate\.x, gate\.y\)/, '監看時會自動點官網的登入鈕');
  assert.match(main, /if \(watcher\.requireTemporaryChat && !watcher\.temporaryReady[\s\S]*?buildTemporaryChatScript\(watcher\.provider/, '登入後才建立／確認臨時對話，未確認前不填入');
  assert.match(webApp, /browserMode==='external'&&provider==='gemini'&&webAutoFlow[\s\S]{0,300}?登入後會自動確認臨時對話/, '第一次登入時不會因臨時對話尚未出現而中止');
  assert.match(webApp, /temporaryReady:temporaryConfirmed,startNewTemporary:autoOpen/, '把臨時對話是否已確認與是否需新建傳給主程序');
});

test('登入後仍待辦的提示詞會重試填入、送出一次並開始接回監看', () => {
  assert.match(main, /pendingPrompt:submit&&!submitted\?prompt:''/, '未送出的使用者回合留給 watcher 在登入後重試');
  assert.match(main, /if\(watcher\.pendingPrompt&&!watcher\.submissionAttempted&&Date\.now\(\)-watcher\.lastFillAttemptAt>=5000\)/, '登入頁期間會定時重試尋找輸入框');
  assert.match(main, /fillViaRunner\(runner,\s*watcher\.pendingPrompt\)/, '登入後用原生輸入管線重填同一個待辦提示詞');
  assert.match(main, /watcher\.submissionAttempted=true;[\s\S]*?sent=await submitViaRunner\(runner,\s*watcher\.pendingPrompt\)/, '確認提示詞進入輸入框後只呼叫一次送出');
  assert.match(main, /pushWebAutoStatus\('submitted'\);[\s\S]*?pushWebAutoStatus\('watching',\{submitted:true\}\)/, '送出後切換成回覆監看狀態');
  assert.match(webApp, /const watchOnly=webAutoFlowWatchOnly\|\|webAutoFlowSubmitted/, 'already-sent turns resume monitoring only');
  assert.match(webApp, /const syncPrompt=watchOnly\?'':makeWebPrompt\(state\.pendingAction==='__OPENING__'\?null:state\.pendingAction\)/, '登入後重啟時也帶回待辦提示詞');
  assert.ok(webApp.indexOf('const watchOnly=webAutoFlowWatchOnly||webAutoFlowSubmitted')<webApp.indexOf("const syncPrompt=watchOnly?'':makeWebPrompt",webApp.indexOf('function syncWebAutoFlow()')), 'watchOnly is initialized before the sync path reads it');
  assert.match(webApp, /stage==='submitted'\)webAutoFlowSubmitted=true/, '登入後送出會標記已送出，後續只重接監看而不重複送');
});

test('臨時對話只支援可確認的官網模式，並在確認失敗時阻止送出', () => {
  assert.deepEqual(flow.TEMPORARY_CHAT_PROVIDERS, ['openai', 'gemini']);
  assert.match(flow.buildTemporaryChatScript('openai', {startNew: true}), /newChat\.click\(\)/, 'ChatGPT 開始新臨時對話前先建立新對話');
  assert.match(flow.buildTemporaryChatScript('gemini', {startNew: true}), /newChatControl\(\)/, 'Gemini 先按新對話，讓官網顯示臨時對話控制項');
  assert.match(flow.buildTemporaryChatScript('gemini', {startNew: true}), /control\.click\(\)/, 'Gemini 使用官網臨時聊天控制項');
  assert.match(flow.buildTemporaryChatScript('gemini'), /is-temporary-chat/, 'Gemini 目前版面的臨時對話類別可直接確認');
  assert.match(flow.buildTemporaryChatScript('gemini', {startNew: true}), /menuControl/, 'Gemini 側欄收起時會先開主選單');
  assert.match(flow.buildTemporaryChatScript('claude'), /temporary-chat-not-supported/, '沒有確認支援的網站不會假稱臨時聊天');
  assert.match(main, /ai-web:temporary-chat/, '主程序提供官網臨時對話切換與驗證');
  assert.ok(main.includes('result.rect'), '臨時對話未確認時會取回按鈕座標');
  assert.ok(main.includes('runner.click(x, y)'), '外部模式用可信滑鼠點擊重試臨時對話');
  assert.match(preload, /ensureTemporaryChat: payload => ipcRenderer\.invoke\('ai-web:temporary-chat'/, 'preload 對 renderer 只暴露受限的臨時對話方法');
  assert.match(main, /buildTemporaryChatScript\(provider, \{startNew: temporaryReady \? false : startNewTemporary\}\)/, '送出前再次驗證官網仍處於臨時對話；登入前未確認時會在登入後建立');
  assert.match(main, /loginGate && loginGate\.ok && loginGate\.loggedOut[\s\S]{0,900}?startWebAutoWatch\(runner, \{[\s\S]{0,300}?pendingPrompt: submit \? prompt : ''/, '登入頁先保留待辦提示詞，登入完成後再繼續');
  assert.match(main, /readGeminiLoginGate\(runner\)/, '主程序會重試辨識 Google 登入頁，避免 SPA 載入時誤判');
  assert.match(main, /if \(provider === 'gemini' && submit && prompt\)[\s\S]{0,500}?temporary-chat-required/, '登入或載入中的 Gemini 會保留回合交給 watcher，不直接放棄');
  assert.match(webApp, /temporary-chat-required/, 'UI 會說明正在等待臨時對話');
  assert.match(main, /官網未確認為臨時對話[^\n]*本回合未送出/, '未確認臨時模式時絕不送出提示詞');
  assert.match(webApp, /const requiresTemporaryChat=slotWantsTemporaryChat\(activeSlotId\)/, '臨時對話（含保存記錄勾選官網臨時）每回合都要求官網臨時對話');
  assert.match(webApp, /臨時對話故事只能透過已確認的 ChatGPT 或 Gemini 官網進行/, '無痕故事不會轉送到 API');
});

test('開場無痕選項保持可選，預設切到 AI 網頁版並接上官網臨時對話驗證', () => {
  const style = readFileSync(new URL('../../www/style.css', import.meta.url), 'utf8');
  assert.match(webApp, /let openingRecordModeDraft='save'/, '新故事預設選擇保存記錄（臨時對話為選配）');
  assert.match(webApp, /id="openingRecordIncognito" value="incognito" \$\{openingRecordModeDraft==='incognito'\?'checked':''\}/, '無痕選項會在重繪開場面板時保留');
  assert.match(webApp, /incognitoInput\.disabled=state\.aiMode==='web'&&!TEMPORARY_CHAT_WEB_PROVIDERS\.has\(normalizeWebAIProvider\(state\.webProvider\)\)/, 'unsupported websites disable temporary mode while saved web stories remain selectable');
  assert.match(webApp, /if\(openingRecordModeDraft==='incognito'&&state\.aiMode!=='web'\)state\.aiMode='web';/, '選擇無痕時切換至官方網站模式');
  assert.match(webApp, /ensureTemporaryChat\(\{provider,mode:browserMode,startNew:autoOpen\}\)/, '開始回合前會建立並確認官網臨時對話');
  assert.match(style, /#tab-story \.opening-clock-row:has\(input\[name="openingRecordMode"\]\)/, '開場無痕／保存選擇有清楚的 Galgame 選項卡');
  assert.match(style, /\.game-back-btn\{\s*position:fixed;\s*top:calc\(14px \+ env\(safe-area-inset-top,0px\)\);\s*left:calc\(14px \+ env\(safe-area-inset-left,0px\)\);/, '返回鍵固定於左上角');
});

test('Gemini 臨時對話用官網隱私提示確認，不把一般工具按鈕誤認成啟用狀態', async () => {
  const control = {
    className: '',
    getAttribute: name => name === 'aria-label' ? '臨時對話' : null,
    getClientRects: () => [{}],
    matches: () => false
  };
  const context = {
    document: {
      body: {innerText: '臨時對話不會顯示在近期對話，也不會用於改良 Google AI。為安全起見，相關資料將留存 72 小時。'},
      querySelector: () => null,
      querySelectorAll: selector => selector.includes('button') ? [control] : []
    },
    getComputedStyle: () => ({visibility: 'visible', display: 'block'}),
    location: {pathname: '/app', search: ''},
    setTimeout
  };
  const verified = await runInNewContext(flow.buildTemporaryChatScript('gemini'), context);
  assert.equal(verified.ok, true);

  context.document.body.innerText = '最近使用臨時對話';
  const unverified = await runInNewContext(flow.buildTemporaryChatScript('gemini'), context);
  assert.equal(unverified.ok, false);
  assert.equal(unverified.error, 'temporary-chat-not-active');
});

test('啟用臨時對話後等待官網非同步顯示確認提示', async () => {
  const body = {innerText: '最近使用的對話'};
  const newChat = {
    className: '',
    getAttribute: name => name === 'aria-label' ? '新對話' : null,
    getClientRects: () => [{}],
    matches: () => false,
    click: () => {}
  };
  const control = {
    className: '',
    getAttribute: name => name === 'aria-label' ? '臨時對話' : null,
    getClientRects: () => [{}],
    matches: () => false,
    click: () => setTimeout(() => {
      body.innerText = '臨時對話不會顯示在近期對話，相關資料將留存 72 小時。';
    }, 900)
  };
  const context = {
    document: {
      body,
      querySelector: () => null,
      querySelectorAll: selector => selector.includes('button') ? [newChat, control] : []
    },
    getComputedStyle: () => ({visibility: 'visible', display: 'block'}),
    location: {pathname: '/app', search: ''},
    setTimeout
  };
  const result = await runInNewContext(flow.buildTemporaryChatScript('gemini', {startNew: true}), context);
  assert.equal(result.ok, true, '等待 Gemini 非同步顯示官方臨時對話提示後才確認');
});

test('Gemini 以 is-temporary-chat 類別確認目前臨時對話', async () => {
  const control = {
    className: '',
    getAttribute: name => name === 'aria-label' ? '臨時對話' : null,
    getClientRects: () => [{}],
    matches: () => false
  };
  const context = {
    document: {
      body: {innerText: '一般對話'},
      querySelector: selector => /is-temporary-chat/.test(selector) ? {} : null,
      querySelectorAll: selector => selector.includes('button') ? [control] : []
    },
    getComputedStyle: () => ({visibility: 'visible', display: 'block'}),
    location: {pathname: '/app', search: ''},
    setTimeout
  };
  const result = await runInNewContext(flow.buildTemporaryChatScript('gemini'), context);
  assert.equal(result.ok, true, 'Gemini 目前版面的 is-temporary-chat 類別可直接確認');
});

test('Gemini 側欄收起時會先開主選單再按新對話與臨時對話', async () => {
  const body = {innerText: 'Gemini Flash'};
  let opened = false;
  const menu = {
    className: '',
    getAttribute: name => name === 'aria-label' ? '主選單' : null,
    getClientRects: () => [{}],
    matches: () => false,
    click: () => { opened = true; }
  };
  const newChat = {
    className: '',
    getAttribute: name => name === 'aria-label' ? '新對話' : null,
    getClientRects: () => opened ? [{}] : [],
    matches: () => false,
    click: () => {}
  };
  const control = {
    className: '',
    getAttribute: name => name === 'aria-label' ? '臨時對話' : null,
    getClientRects: () => [{}],
    matches: () => false,
    click: () => setTimeout(() => {
      body.innerText = '臨時對話不會顯示在近期對話，相關資料將留存 72 小時。';
    }, 900)
  };
  const context = {
    document: {
      body,
      querySelector: () => null,
      querySelectorAll: selector => selector.includes('button') ? [menu, newChat, control] : []
    },
    getComputedStyle: () => ({visibility: 'visible', display: 'block'}),
    location: {pathname: '/app', search: ''},
    setTimeout
  };
  const result = await runInNewContext(flow.buildTemporaryChatScript('gemini', {startNew: true}), context);
  assert.equal(result.ok, true, '主選單展開後可完成新對話與臨時對話');
  assert.equal(opened, true, '側欄收起時有先按主選單');
});

test('Gemini 未確認時回傳臨時對話按鈕座標，讓主程序可信點擊重試', async () => {
  const control = {
    className: '',
    getAttribute: name => name === 'aria-label' ? '臨時對話' : null,
    getClientRects: () => [{}],
    matches: () => false,
    getBoundingClientRect: () => ({x: 100, y: 200, width: 40, height: 30})
  };
  const context = {
    document: {
      body: {innerText: '一般對話'},
      querySelector: () => null,
      querySelectorAll: selector => selector.includes('button') ? [control] : []
    },
    getComputedStyle: () => ({visibility: 'visible', display: 'block'}),
    location: {pathname: '/app', search: ''},
    setTimeout
  };
  const result = await runInNewContext(flow.buildTemporaryChatScript('gemini'), context);
  assert.equal(result.ok, false);
  assert.equal(result.rect.x, 100);
  assert.equal(result.rect.y, 200);
  assert.equal(result.rect.width, 40);
  assert.equal(result.rect.height, 30);
});

test('送出腳本只會按真正的送出鈕，空輸入框一律不送出', () => {
  const submit = flow.buildSubmitScript();
  assert.match(submit, /send\|submit\|送出\|傳送\|发送\|發送\|提交\|送信/, '以送出字樣辨識送出鈕');
  assert.match(submit, /blockWords/, '排除停止、語音、麥克風、附件、模型、新對話等非送出鈕');
  assert.match(submit, /editor-empty/, '輸入框是空的時候回報 editor-empty，不做任何點擊');
  assert.match(submit, /no-send-button/, '找不到送出鈕時回報，交由 Enter 後備處理');
  assert.match(submit, /editor\.focus\(\)/, '送出前先聚焦輸入框，Enter 後備才會打在對的地方');
  assert.match(submit, /target\.click\(\)/, '找到送出鈕就真的按下去');
});

test('回覆探測腳本支援三個官網的訊息結構與停止鈕判定', () => {
  const probe = flow.buildReplyProbeScript();
  assert.match(probe, /data-message-author-role="assistant"/, 'ChatGPT 的助理訊息容器');
  assert.match(probe, /font-claude-message/, 'Claude 的訊息容器');
  assert.match(probe, /model-response/, 'Gemini 的訊息容器');
  assert.match(probe, /data-is-streaming="true"/, 'Claude 串流中的標記');
  assert.match(probe, /stop/i, '以停止鈕判斷是否還在生成中');
  assert.match(probe, /count:nodes\.length/, '回報助理訊息數量，用來判斷是否出現新回覆');
  assert.match(probe, /generating[,:]/, '回報目前是否還在生成');
  assert.match(probe, /const present=/, '畫面外的舊回覆仍算進基準，避免誤接上一則');
  assert.match(probe, /filter\(present\)/, '回覆節點用實際存在判斷，而不是只看目前視窗可見');
});

test('複製腳本只按回覆的複製鈕，排除程式碼與連結複製', () => {
  const copy = flow.buildCopyClickScript();
  assert.match(copy, /copy\|copy reply\|copy response/, '支援英文複製鈕');
  assert.match(copy, /複製\|複製回覆\|コピー/, '支援中日文複製鈕');
  assert.match(copy, /code\|程式碼\|代码\|link\|連結\|链接/, '排除「複製程式碼」「複製連結」');
  assert.match(copy, /buttons\[buttons\.length-1\]/, '取畫面上最後一個（最新）回覆的複製鈕');
});

test('回覆完成判斷：串流中不接、沒變不接、穩定後才接', () => {
  const baseline = { count: 2, text: '舊回覆' };
  // 還在生成：即使文字變了也不接，並重設穩定計數。
  let step = flow.replyProgress({ probe: { ok: true, generating: true, count: 2, text: '新回覆上半' }, baseline, lastText: '', stableCount: 3, minLength: 5 });
  assert.equal(step.emit, false, '還在生成時不接回');
  assert.equal(step.stableCount, 0, '生成中重設穩定計數');
  assert.equal(step.lastText, '新回覆上半', '生成中的文字仍要記住，完成後才能算穩定');
  // 完成後只有一次探測：不算完成。
  step = flow.replyProgress({ probe: { ok: true, generating: false, count: 3, text: '新回覆完成' }, baseline, lastText: '', stableCount: 0, minLength: 5 });
  assert.equal(step.emit, false, '只有一次探測不算完成');
  // 內容沒變（與基準相同）：不接。
  step = runSequence(
    [{ ok: true, generating: false, count: 2, text: '舊回覆' }, { ok: true, generating: false, count: 2, text: '舊回覆' }, { ok: true, generating: false, count: 2, text: '舊回覆' }],
    { baseline, minLength: 5 }
  );
  assert.equal(step.emitted, null, '啟用前就存在的舊回覆不能被當成新回覆接回');
  // 完整流程：串流數次 → 完成 → 穩定兩次 → 接回。
  const done = runSequence(
    [
      { ok: true, generating: true, count: 3, text: '新' },
      { ok: true, generating: true, count: 3, text: '新回覆' },
      { ok: true, generating: false, count: 3, text: '新回覆完成' },
      { ok: true, generating: false, count: 3, text: '新回覆完成' },
      { ok: true, generating: false, count: 3, text: '新回覆完成' }
    ],
    { baseline, minLength: 5 }
  );
  assert.equal(done.emitted, '新回覆完成', '完成且穩定後才接回');
  // 太短的內容（例如官網顯示「Copied」之類的提示）不接。
  const short = runSequence(
    [{ ok: true, generating: false, count: 3, text: '已複製' }, { ok: true, generating: false, count: 3, text: '已複製' }, { ok: true, generating: false, count: 3, text: '已複製' }],
    { baseline, minLength: 20 }
  );
  assert.equal(short.emitted, null, '太短的內容不當成回覆');
  // 探測失敗（頁面導航中）不接，且不會誤觸發。
  step = flow.replyProgress({ probe: { ok: false, error: 'navigating' }, baseline, lastText: '新回覆完成', stableCount: 5, minLength: 5 });
  assert.equal(step.emit, false, '探測失敗時不接回');
  assert.equal(step.stableCount, 0, '探測失敗重設穩定計數');
});

test('畫面外的上一則回覆已納入基準時，不會被當成本回合新回覆', () => {
  const baseline = { count: 2, text: '上一則舊回覆' };
  let step = flow.replyProgress({
    probe: { ok: true, generating: false, count: 2, text: '上一則舊回覆', copyReady: true },
    baseline,
    lastText: '',
    stableCount: 0,
    minLength: 5
  });
  assert.equal(step.emit, false, '基準已含上一則時，即使它現在可見也不接回');
  step = flow.replyProgress({
    probe: { ok: true, generating: false, count: 3, text: '本回合新回覆', copyReady: true },
    baseline,
    lastText: '本回合新回覆',
    stableCount: 0,
    minLength: 5
  });
  assert.equal(step.emit, true, '真正的新回覆出現後才接回');
});

test('官網結構設定集中在 SITE_HINTS（改版時只改這一塊）', () => {
  assert.equal(typeof flow.SITE_HINTS, 'object', 'SITE_HINTS 要匯出，讓工具與文件能指向同一個地方');
  const flowSource = readFileSync(new URL('../../ai-web-flow.cjs', import.meta.url), 'utf8');
  assert.match(flowSource, /官網改版時要改哪裡/, '原始碼開頭要有「官網改版時要改哪裡」的說明');
  assert.match(flowSource, /const SITE_HINTS = \{/, '設定集中在單一 SITE_HINTS 物件');
  for (const key of ['editorSelectors', 'sendWords', 'sendBlockWords', 'replySelectors', 'stopWords', 'copyWords', 'copyBlockWords']) {
    assert.ok(flow.SITE_HINTS[key], `SITE_HINTS.${key} 必須存在`);
  }
  assert.ok(Array.isArray(flow.SITE_HINTS.replySelectors) && flow.SITE_HINTS.replySelectors.length >= 3, '三個官網的回覆容器都要列在 replySelectors');
  // 設定改了要真的反映到注入官網的腳本上（不是放好看的）。
  const submit = flow.buildSubmitScript();
  assert.ok(submit.includes(flow.SITE_HINTS.sendWords), '送出腳本要使用 SITE_HINTS.sendWords');
  const probe = flow.buildReplyProbeScript();
  assert.ok(probe.includes(quoteForPage(flow.SITE_HINTS.replySelectors[0])), '探測腳本要使用 SITE_HINTS.replySelectors');
});

function quoteForPage(value) {
  return `'${String(value).replace(/\\/g, '\\\\').replace(/'/g, "\\'")}'`;
}

test('主程序提供自動化 IPC、監看與外部瀏覽器管理', () => {
  assert.match(main, /aiWebFlow = require\('\.\/ai-web-flow\.cjs'\)/, '主程序共用 ai-web-flow 腳本');
  assert.match(main, /ipcMain\.handle\('ai-web:auto-flow'/, 'renderer 可開啟／關閉自動化');
  assert.match(main, /webContents\.send\('ai-web:auto-reply'/, '抓到的回覆推回 renderer 接續');
  assert.match(main, /--remote-debugging-port=\$\{automationPort\}/, '外部瀏覽器以除錯埠啟動，才能自動控制');
  assert.match(main, /web-automation-browser-r24/, '沿用舊版已登入的專用設定檔，升級後不必重新登入');
  assert.match(main, /DevToolsActivePort/, '同一個設定檔已有 Chrome 時，改接它實際的除錯埠，避免卡在 about:blank');
  assert.match(main, /automationDebugPortFromProfile/, '啟動前會驗證設定檔內的除錯埠');
  assert.match(main, /automationPortFromRunningChrome/, 'Chrome 沒留下 DevToolsActivePort 時，仍會從程序命令列找出實際除錯埠');
  assert.match(main, /Get-CimInstance Win32_Process/, '程序掃描只讀取 Chrome／Edge 的命令列');
  assert.match(main, /const runningPort = automationPortFromRunningChrome\(profileDir\);[\s\S]{0,220}automationBrowserAliveAt\(runningPort\)/, '找到的埠會先驗證可用才接手');
  assert.match(main, /Page\.navigate/, '新分頁若停在 about:blank，會用 CDP 明確導航到官網');
  assert.match(main, /const stopWords=new RegExp\(\$\{JSON\.stringify\(aiWebFlow\.SITE_HINTS\.stopWords\)\}/, '模型切換會辨識官網的停止生成按鈕');
  assert.match(main, /if\(\$\{JSON\.stringify\(action\)\}!=='list'&&!\(await waitForIdle\(60000\)\)\)/, '官網正在產生回覆時會先等它完成，再切換模型');
  assert.match(main, /waitForIdle\(60000,8000\)/, '若切換發生在自動送出前，會等這一輪開始並結束後再重試');
  assert.match(main, /官網沒有套用這個模型/, '模型切換會驗證官網是否真的套用，不再假報成功');
  assert.match(main, /json\/activate\/\$\{encodeURIComponent\(tab\.id\)\}/, '切換模型前會把自動化分頁帶到前景，讓官網彈出選單可以操作');
  assert.match(main, /--disable-sync/, '自動化設定檔不啟用 Chrome 同步');
  assert.match(main, /--disable-extensions/, '自動化設定檔不載入擴充功能');
  assert.match(main, /--disable-features=WebAuthentication,WebAuthenticationCable,WebAuthenticationPasskey,WebAuthenticationConditionalUI/, '關閉 WebAuthn／Passkey，避免登入被導向 Windows Hello／PIN');
  assert.match(main, /--disable-blink-features=AutomationControlled/, '真 Chrome 不應被官網當成自動化瀏覽器');
  assert.doesNotMatch(main, /'--test-type'/, '移除 --test-type（Google 可偵測的自動化標記）');
  assert.match(main, /Emulation\.setFocusEmulationEnabled/, '背景視窗仍以可見頁面處理輸入');
  assert.match(main, /Page\.setWebLifecycleState', params: \{state: 'active'\}/, '強制頁面保持 active，避免隱藏頁吞掉送出事件');
  assert.match(main, /type: 'keyDown'[\s\S]{0,220}?text: '\\r'[\s\S]{0,120}?unmodifiedText: '\\r'/, 'Enter 用帶 text 的 keyDown，Gemini 才會真的送出');
  assert.match(main, /async function ensureAutomationBrowser\(\)/, '外部模式會自動啟動（或重用）瀏覽器');
  assert.match(main, /function startWebAutoWatch\(runner, \{submitted/, '主程序負責監看官網回覆');
  assert.match(main, /buildCopyClickScript\(\)/, '抓回覆優先用官網自己的複製鈕（最忠實）');
  assert.match(main, /no-editor' \|\| failure === 'editor-empty'/, '沒有輸入框或輸入框是空的時不送出');
  assert.match(main, /runner\.pressEnter\(\)/, '找不到送出鈕時退回 Enter 送出');
  assert.match(main, /async function submitViaRunner\(runner, prompt = ''\)[\s\S]*?probe\.generating[\s\S]*?return false;/, '送出後須等官網生成或新回覆作證；未確認時交由待辦回合重試');
  assert.match(main, /existing && existing\.id/, '外部模式重複啟用時沿用同一個官網分頁（不每次開新分頁）');
  assert.match(main, /else \{\s*preferredTabId = rememberAutomationTab\(provider, await openAutomationTab\(url\)\);\s*\}/, '沒有既有分頁才開新的官網分頁');
  assert.match(main, /function createWebAutoRunner\(mode, provider, url, preferredTabId = ''\)/, '自動化 runner 可指定固定分頁，避免多個同網址分頁時換錯');
  assert.match(main, /findAutomationProviderTab\(tabs, url, pinnedId\)/, 'runner 每次解析分頁都優先沿用 pinned target id');
  assert.match(main, /createWebAutoRunner\('external',provider,url,tab\.id\)/, '模型切換會把選定的分頁傳給 runner，切換與驗證讀同一個分頁');
  assert.match(main, /existing = tabs\.find\(tab => isDebuggableAutomationTab\(tab\) && base && tab\.url\.startsWith\(base\)\)/, '沿用分頁只挑真正的頁面（排除 service worker 等非 page 目標）');
  assert.match(main, /const canSubmit = Boolean\(filled && filled\.ok\);/, '兩種模式都先確認輸入框內容就是本回合提示詞才送出（不送殘留的舊文字）');
  assert.match(main, /info && typeof info\.Browser === 'string' && \/chrome\|chromium\|edge\/i\.test\(info\.Browser\)/, '確認除錯埠真的是 Chromium 系瀏覽器，避免誤認別的服務');
  assert.doesNotMatch(main, /['"`]--remote-allow-origins/, '不得把 --remote-allow-origins 當參數傳給外部瀏覽器：開放來源等於讓造訪中的網站接管已登入多家官網的瀏覽器');
  assert.match(main, /function hardenAiWebSession\(\)/, '官網視窗的工作階段要有權限收斂');
  assert.match(main, /const allowed = new Set\(\['clipboard-sanitized-write', 'clipboard-read', 'fullscreen', 'identity-credentials-get', 'fedcm'\]\);/, '權限只留複製回覆、全螢幕與 FedCM／Google One Tap');
  assert.match(main, /setPermissionRequestHandler/, '未列出的權限請求一律拒絕（不靠 Electron 預設全允許）');
  assert.match(main, /setPermissionCheckHandler/, '權限檢查也走同一份允許清單');
});

test('外部模式登入與自動化共用專用瀏覽器，啟動或導航失敗不會停在 about:blank', () => {
  assert.match(main, /return openAutomationWebsite\(String\(provider\|\|''\),url\)/, '外部模式的登入與自動化走同一個專用瀏覽器');
  assert.match(main, /async function openAutomationWebsite\(provider, url\)/, '外部開啟官網有單一入口');
  assert.match(main, /await ensureAutomationBrowserFor\(url\)/, '開啟官網會把目標網址帶進專用瀏覽器啟動');
  assert.match(main, /'--new-window', automationInitialUrl \|\| AI_WEBSITE_URLS\.gemini/, '啟動時直接載入官網，不先開空白視窗');
  assert.doesNotMatch(main, /'--new-window',\s*'about:blank'/, '不再以 about:blank 啟動自動化瀏覽器');
  assert.match(main, /async function navigateAutomationTab\(target, url\)/, '既有空白分頁會用 CDP 導航到官網');
  assert.match(main, /分頁停在 about:blank，沒有完成載入/, '導航失敗會明確報錯，不把空白頁當成功');
  assert.match(main, /async function closeBlankAutomationTabs\(keepId = ''\)/, '成功後會清掉殘留空白分頁');
  assert.match(main, /function automationProcessesForProfile\(profileDir\)/, '重新啟動只找使用專用設定檔的程序');
  assert.match(main, /taskkill\.exe/, '重新啟動會終止專用瀏覽器程序');
  assert.match(main, /ipcMain\.handle\('ai-web:automation-restart'/, 'renderer 可要求重新啟動自動化瀏覽器');
  assert.match(main, /ipcMain\.handle\('ai-web:automation-reconnect'/, 'renderer 可要求重新接入並檢查登入');
  assert.match(preload, /restartAutomationBrowser: payload => ipcRenderer\.invoke\('ai-web:automation-restart', payload\)/, 'preload 曝露重新啟動');
  assert.match(preload, /reconnectAutomationBrowser: payload => ipcRenderer\.invoke\('ai-web:automation-reconnect', payload\)/, 'preload 曝露重新接入');
  assert.match(webApp, /async function openWebLoginFromSettings\(\)/, '設定頁有開啟官網並登入');
  assert.match(webApp, /async function checkWebConnection\(\)/, '設定頁有登入與接入檢查');
  assert.match(webApp, /async function restartAutomationBrowserFromSettings\(\)/, '設定頁有重新啟動按鈕');
});

test('preload 與 renderer 都有自動化開關、預設開啟且會記住', () => {
  assert.match(preload, /setWebAutoFlow: payload => ipcRenderer\.invoke\('ai-web:auto-flow', payload\)/, 'preload 曝露自動化開關');
  assert.match(preload, /onWebAutoReply: callback =>/, 'preload 曝露自動接回回呼');
  assert.match(webApp, /WEB_AUTO_FLOW_KEY='claude_novel_web_auto_flow_v1'/, '自動化開關有獨立的儲存鍵');
  assert.match(webApp, /localStorage\.getItem\(WEB_AUTO_FLOW_KEY\)!=='off'/, '預設開啟，只有使用者關掉才關閉');
  assert.match(webApp, /localStorage\.setItem\(WEB_AUTO_FLOW_KEY,webAutoFlow\?'on':'off'\)/, '開關選擇會被記住');
  assert.match(webApp, /id="pendingWebAutoFlow"/, '待辦面板有自動化開關');
  assert.match(webApp, /select\.id='webAutoFlowSelect'/, '設定頁也有自動化開關');
  assert.match(webApp, /pendingWebAutoFlow\.onchange=\(\)=>applyWebAutoFlow/, '待辦面板開關立即生效');
  assert.match(webApp, /autoFlowSelect\.onchange=\(\)=>applyWebAutoFlow/, '設定頁開關立即生效');
  assert.match(webApp, /function queueWebAutoReply\(value\)[\s\S]*?applyWebReply\(reply\)/, '自動接回走既有回覆驗證與接續管線');
  assert.match(webApp, /setWebAutoFlow\(\{enabled:true,submit:true,prompt,provider,mode:browserMode,requireTemporaryChat:requiresTemporaryChat,temporaryReady:temporaryConfirmed,startNewTemporary:autoOpen\}\)/, '兩種模式都帶提示詞，由主程序端補驗證或補填；登入前未確認的臨時對話會在登入後建立');
  assert.match(webApp, /api\(\{enabled:false\}\)/, '回合結束或關閉開關時停止監看');
  assert.match(webApp, /webAutoFlowBaseKey=baseKey;\s*\r?\n?\s*webAutoFlowRetryAt=Date\.now\(\)\+20000;/, '啟動前先佔位＋節流，避免同一個畫面週期重複啟動');
  assert.match(webApp, /webAutoFlowBaseKey=automationBaseKey;\s*\r?\n?\s*webAutoFlowRetryAt=Date\.now\(\)\+20000;/, 'prepare 啟動前也先佔位，避免啟動期間被 syncWebAutoFlow 重複啟動');
  assert.match(webApp, /else\{webAutoFlowBaseKey=previousBaseKey;scheduleWebAutoRetry\(\);\}/, '啟動失敗時還原佔位並排程自動重試');
  assert.match(webApp, /const syncPrompt=watchOnly\?'':makeWebPrompt\(state\.pendingAction==='__OPENING__'\?null:state\.pendingAction\)/, 'sync 路徑對兩種瀏覽器都帶本回合提示詞，只有純監看重試例外');
  assert.match(webApp, /if\(!\(browserMode==='external'&&webAutoFlow\)\)/, '外部模式＋自動化開啟時，回合開始不再彈出日常瀏覽器');
  assert.match(webApp, /await window\.claudeDesktop\.openAiWebsite\(provider,browserMode\)/, '自動化開啟時「開啟官網」開的是同一個自動化專用瀏覽器');
  assert.doesNotMatch(webApp, /setWebAutoFlow\(\{enabled:true,submit:false,prompt:''/, '開啟官網不再經過空白提示詞的自動化啟動');
});

test('自動接回事件遇到 renderer 忙碌時會保留並重試，不會丟掉已抓到的回覆', () => {
  assert.match(webApp, /function queueWebAutoReply\(value\)/, '主程序回覆先進入可重試佇列');
  assert.match(webApp, /if\(busy\)[\s\S]*?setTimeout\(attempt,200\)/, '忙碌期間每 200ms 等待 renderer 空閒');
  assert.match(webApp, /state\.pendingAction!==expectedAction\|\|activeSlotId!==expectedSlot/, '只在原本待辦回合與存檔仍有效時接回');
  assert.match(webApp, /onWebAutoReply\?\.\(text=>queueWebAutoReply\(text\)\)/, '自動化回覆事件接入重試佇列');
  assert.match(webApp, /state\.webReply=reply[\s\S]*?畫面忙碌中/, '等待逾時會先保留回覆到手動欄位');
});

test('自動化狀態訊息說明兩種模式的行為與首次登入', () => {
  assert.match(webApp, /提示詞已自動填入並送出；官網回覆完成會自動接回。/, '內建模式的成功訊息');
  assert.match(webApp, /已用自動化瀏覽器開啟官網並自動送出；回覆完成會自動接回。首次使用請在該視窗登入一次。/, '外部模式提醒只需登入一次');
  assert.match(webApp, /自動化未啟動：/, '失敗時說明明確、不誤導');
  assert.match(webApp, /關閉中：App 只準備並複製提示詞/, '關閉時說明維持手動流程');
});

// ── 追加十（網頁全面自動化檢查優化）─────────────────────────────────────────
test('追加十 A：自動化失敗階梯與狀態事件在主程序與 App 兩邊都有接線', () => {
  assert.match(main, /function pushWebAutoStatus\(stage, extra\)/, '主程序有自動化狀態事件');
  assert.match(main, /ai-web:auto-status/, '狀態事件頻道存在');
  for (const stage of ['watching', 'retrying', 'gave-up', 'timeout', 'needs-login', 'harvesting', 'harvested']) {
    assert.ok(main.includes(`'${stage}'`), `有 ${stage} 階段`);
  }
  assert.match(main, /watcher\.failures === 4 \|\| watcher\.failures === 6/, '重試中段會重新確認官網視窗／分頁還在');
  assert.match(main, /if \(watcher\.failures >= \(watcher\.provider === 'gemini' \? 20 : 8\)\)/, '連續失敗到達上限才停手（Gemini 登入後分頁重建需要較久）');
  assert.match(main, /1\.2 秒重找一次/, '填入失敗會等待後重找一次（失敗階梯第一階）');
  assert.match(preload, /onWebAutoStatus: callback =>/, 'preload 曝露狀態事件');
  assert.match(preload, /webAutoHealth: payload => ipcRenderer\.invoke\('ai-web:auto-health'/, 'preload 曝露健康檢查');
  assert.match(webApp, /onWebAutoStatus\?\.\(payload=>\{/, 'App 接收狀態事件');
  assert.match(webApp, /webAutoFlowWatchOnly/, '已送出的回合重試只准重新監看（不重填再送）');
  assert.match(webApp, /function scheduleWebAutoRetry/, '啟動失敗會排程自動重試');
  assert.match(webApp, /webAutoWatchRetryCount<webAutoRetryLimit/, '重試次數受使用者設定上限約束');
  assert.match(webApp, /api\(\{enabled:true,submit:!watchOnly,prompt:watchOnly\?'':syncPrompt,provider,mode\}\)/, '重新監看不帶提示詞、不送出');
});

test('追加十 A：回合佔位避免 sync 與 prepare 搶先各啟動一次（同一回合只送一次）', () => {
  assert.match(webApp, /function claimWebAutoTurn\(\)\{[\s\S]{0,40}webAutoFlowBaseKey=/, '有回合佔位函式');
  assert.match(webApp, /claimWebAutoTurn\(\);[\s\S]{0,40}busy=true; render\(\);/, 'beginWebTurn 先佔位再 render：本回合由 prepareWebPrompt 獨家啟動');
  assert.match(webApp, /claimWebAutoTurn\(\);[\s\S]{0,60}busy=true;settings\(\);render\(\);/, '切換官網同樣先佔位再 render');
  assert.match(webApp, /webAutoFlowBaseKey='';webAutoFlowRetryAt=0;[\s\S]{0,40}syncWebAutoFlow\(\);/, '手動切換開關會清掉佔位並立即重新同步');
});

test('追加十 B：探測回報多訊號，回復判斷支援複製鈕與「看過生成中」加速', () => {
  const probe = flow.buildReplyProbeScript();
  assert.ok(probe.includes('editor:!!editor'), '探測腳本要回報輸入框還在不在');
  assert.ok(probe.includes('stopVisible:!!stopButton'), '探測腳本要分開回報停止鈕');
  assert.ok(probe.includes('streaming:!!streaming'), '探測腳本要分開回報串流標記');
  assert.ok(probe.includes('copyReady'), '探測腳本要回報複製鈕是否出現（完成強訊號）');
  assert.match(probe, /const generating=!!\(stopButton\|\|streaming\|\|dsGenerating\)/, 'generating 以停止鈕、串流標記或 DeepSeek 主按鈕狀態為準');
  const baseline = {count: 1, text: '舊'};
  // 複製鈕出現（強訊號）：一次穩定就能接回。
  let step = flow.replyProgress({probe: {ok: true, generating: false, count: 2, text: '新回覆完成', copyReady: true}, baseline, lastText: '新回覆完成', stableCount: 0, minLength: 5});
  assert.equal(step.emit, true, '複製鈕出現＋一次穩定即可接回');
  // 沒看過生成中、也沒有複製鈕：照舊要兩次穩定。
  step = flow.replyProgress({probe: {ok: true, generating: false, count: 2, text: '新回覆完成', copyReady: false}, baseline, lastText: '新回覆完成', stableCount: 0, minLength: 5});
  assert.equal(step.emit, false, '沒有強訊號時仍然要等兩次穩定');
  // 看過生成中（sawGenerating）＋一次穩定：可以早一步接回。
  step = flow.replyProgress({probe: {ok: true, generating: false, count: 2, text: '新回覆完成'}, baseline, lastText: '新回覆完成', stableCount: 0, sawGenerating: true, minLength: 5});
  assert.equal(step.emit, true, '看過生成中、停了且一次穩定即可接回');
  // 生成中一律不接，即使有複製鈕。
  step = flow.replyProgress({probe: {ok: true, generating: true, count: 2, text: '新回覆完成', copyReady: true}, baseline, lastText: '', stableCount: 3, minLength: 5});
  assert.equal(step.emit, false, '生成中不接回');
  // 主程序監看迴圈有把 sawGenerating 餵進判斷。
  assert.match(main, /watcher\.sawGenerating = true/, '監看迴圈會記住「看過生成中」');
  assert.match(main, /sawGenerating: watcher\.sawGenerating/, '判斷時帶入「看過生成中」');
});

test('追加十 D：健康檢查腳本可解析且回報四項線索', () => {
  const health = flow.buildHealthScript();
  assert.doesNotThrow(() => new Script(health), '健康檢查腳本必須是有效 JavaScript');
  for (const field of ['editor:!!editor', 'sendButton', 'replyNodes', 'loginForm']) {
    assert.ok(health.includes(field), `健康檢查要回報 ${field}`);
  }
  assert.match(health, /input\[type="password"\]/, '登入頁線索＝畫面上有密碼欄位');
  assert.match(main, /ipcMain\.handle\('ai-web:auto-health'/, '主程序有健康檢查 IPC');
  assert.match(main, /async function webAutoHealth\(payload\)/, '主程序有健康檢查實作（不呼叫 ready，避免卡 30 秒）');
  assert.match(webApp, /runWebAutoHealthCheck/, 'App 有自檢流程');
  assert.match(webApp, /if\(autoOpen\)void runWebAutoHealthCheck\(\);/, '序章回合自動做一次自檢');
  assert.match(webApp, /id="webAutoHealthBtn"/, '待辦面板有自檢按鈕');
});

test('追加十 E：站點覆蓋矩陣與官網清單一致（12 家）', () => {
  assert.ok(Array.isArray(flow.SITE_MATRIX), 'SITE_MATRIX 要匯出');
  assert.equal(flow.SITE_MATRIX.length, 12, '矩陣涵蓋 12 家官網');
  const urlsMatch = main.match(/AI_WEBSITE_URLS = \{([\s\S]*?)\};/);
  assert.ok(urlsMatch, '主程序有官網清單');
  const urlsBlock = urlsMatch[1];
  for (const site of flow.SITE_MATRIX) {
    assert.ok(urlsBlock.includes(`${site.id}:'`), `官網清單要有 ${site.id}`);
    assert.ok(site.name && site.login && site.notes, `${site.id} 要有名稱、登入方式與已知限制`);
  }
  const ids = flow.SITE_MATRIX.map(site => site.id).sort().join(',');
  const urlIds = [...urlsBlock.matchAll(/(\w+):'https/g)].map(match => match[1]).sort().join(',');
  assert.equal(ids, urlIds, '矩陣與官網清單必須是同一組網站');
});

test('追加十 F：自動重試次數與狀態顯示詳細度是使用者自選項且會記住', () => {
  assert.match(webApp, /WEB_AUTO_RETRY_KEY='claude_novel_web_auto_retry_v1'/, '重試次數有獨立儲存鍵');
  assert.match(webApp, /WEB_AUTO_DETAIL_KEY='claude_novel_web_auto_detail_v1'/, '顯示詳細度有獨立儲存鍵');
  assert.match(webApp, /function normalizeWebAutoRetry\(value\)\{if\(value===null\|\|value===''\|\|typeof value==='undefined'\)return 3;const n=Number\(value\);return \[0,2,3,5\]\.includes\(n\)\?n:3;\}/, '重試次數只接受 0／2／3／5，預設 3（未設定時不可被 Number(null)=0 誤收）');
  assert.match(webApp, /select\.id='webAutoRetrySelect'/, '設定頁有重試次數選單');
  assert.match(webApp, /select\.id='webAutoDetailSelect'/, '設定頁有顯示詳細度選單');
  assert.match(webApp, /localStorage\.setItem\(WEB_AUTO_RETRY_KEY,String\(webAutoRetryLimit\)\)/, '重試次數選擇會被記住');
  assert.match(webApp, /localStorage\.setItem\(WEB_AUTO_DETAIL_KEY,webAutoStatusDetail\)/, '顯示詳細度會被記住');
  assert.match(webApp, /webAutoStatusDetail==='brief'/, '簡潔模式會少講細節、只留重要狀態');
});

test('Gemini 回覆容器改版：gemini.google.com 會加用新選擇器，其他官網不受影響', () => {
  const probe = flow.buildReplyProbeScript();
  assert.match(probe, /gemini\\\.google/, '探測腳本會判斷是否為 Gemini 網域');
  for (const selector of ['model-response', 'message-content', '.model-response-text', 'response-container']) {
    assert.ok(probe.includes(quoteForPage(selector)), `Gemini 探測要包含 ${selector}`);
  }
  const geminiBranch = probe.slice(probe.indexOf('/gemini\\.google'));
  assert.ok(geminiBranch.indexOf(quoteForPage('model-response')) < geminiBranch.indexOf(quoteForPage(flow.SITE_HINTS.replySelectors[0])), 'Gemini 選擇器排在通用清單之前（先命中才接得到回覆）');
  const health = flow.buildHealthScript();
  assert.match(health, /replySelectors=dsHost[\s\S]{0,1200}geminiHost/, '自檢也使用同一組 Gemini 選擇器');
});

test('送出鈕回報座標：真的點不動時可用可信滑鼠點擊重試', () => {
  const submit = flow.buildSubmitScript();
  assert.match(submit, /getBoundingClientRect\(\)/, '送出腳本會量送出鈕座標');
  assert.match(submit, /rect:Number\.isFinite\(rect\.x\)/, '回傳 rect 讓主程序改用真實滑鼠點擊');
  assert.match(main, /sendRect\s*=\s*result\.rect/, '主程序會保存送出鈕座標');
  assert.match(main, /await runner\.click\(cx, cy\)/, '送出失敗時改用真實滑鼠點擊');
});

test('殘留提示詞自救：只清本 App 產生的長提示詞，不動玩家草稿', () => {
  const clear = flow.buildAppPromptClearScript();
  assert.match(clear, /looksLikeAppPrompt/, '先判斷是不是本 App 的提示詞');
  assert.match(clear, /current\.length>=300&&\/JSON\/i\.test\(current\)/, '長度與 JSON 字樣是辨識條件');
  assert.match(clear, /not-app-prompt/, '不是本 App 的提示詞就拒絕清除');
  assert.match(main, /buildAppPromptClearScript\(\)/, '填字遇到殘留時會嘗試自救');
  assert.match(main, /recovered: true/, '自救成功會標記，方便除錯');
});

test('反偵測腳本只注入一次，且不再偽造 navigator.plugins', () => {
  assert.match(main, /automationStealthPrepared\.has\(wsUrl\)/, '同一分頁只注入一次，避免腳本累積');
  assert.match(main, /automationStealthPrepared\.add\(wsUrl\)/, '注入後會記住');
  assert.doesNotMatch(main, /navigator, 'plugins', \{get: \(\) => \[1,2,3,4,5\]\}/, '不再用假陣列覆寫 plugins（會讓官網腳本丟錯）');
  assert.doesNotMatch(main, /window\.chrome = window\.chrome \|\|/, '不再覆寫 window.chrome，交給瀏覽器原生值');
});

function deepseekButton(right, {disabled = false, onClick} = {}) {
  return {
    className: `ds-button ds-button--icon${disabled ? ' ds-button--disabled' : ''}`,
    innerText: '',
    textContent: '',
    disabled: false,
    getAttribute: () => null,
    getClientRects: () => [{}],
    getBoundingClientRect: () => ({x: right - 34, y: 710, width: 34, height: 34, top: 710, left: right - 34, right}),
    click: onClick || (() => {})
  };
}

function deepseekToolbar(buttons, parent = null) {
  return {
    parentElement: parent,
    children: buttons,
    querySelectorAll: selector => selector.includes('role="button"') ? buttons : [],
    getClientRects: () => [{}]
  };
}

function deepseekEditor(value, parent) {
  return {
    tagName: 'TEXTAREA',
    value,
    disabled: false,
    readOnly: false,
    getAttribute: () => '',
    getClientRects: () => [{}],
    getBoundingClientRect: () => ({x: 0, y: 700, width: 500, height: 40, top: 700, left: 0, right: 500}),
    focus: () => {},
    querySelectorAll: () => [],
    contains: () => false,
    parentElement: parent
  };
}

function deepseekContext(editor, roots) {
  return {
    location: {hostname: 'chat.deepseek.com', href: 'https://chat.deepseek.com/'},
    document: {
      querySelectorAll: selector => {
        if (/textarea|contenteditable|textbox/.test(selector)) return [editor];
        if (/div\.ds-markdown/.test(selector)) return roots;
        return [];
      },
      querySelector: () => null
    },
    getComputedStyle: () => ({display: 'block', visibility: 'visible'})
  };
}

test('DeepSeek 送出鈕以輸入框右側最右邊的圖示 ds-button 結構辨識，不誤按附件鈕', () => {
  let mainClicks = 0;
  let attachClicks = 0;
  const main = deepseekButton(350, {onClick: () => { mainClicks += 1; }});
  const attach = deepseekButton(260, {onClick: () => { attachClicks += 1; }});
  const toolbar = deepseekToolbar([attach, main]);
  const editor = deepseekEditor('請產生本回合故事', toolbar);
  toolbar.parentElement = deepseekToolbar([], null);
  const context = deepseekContext(editor, []);

  const result = runInNewContext(flow.buildSubmitScript(), context);
  assert.equal(result.ok, true, '找到 DeepSeek 主按鈕');
  assert.equal(result.structural, true, '以結構而非字樣判定');
  assert.equal(mainClicks, 1, '只按最右側主按鈕');
  assert.equal(attachClicks, 0, '附件鈕不被誤按');

  const verified = runInNewContext(flow.buildVerifyFillScript('請產生本回合故事'), context);
  assert.equal(verified.sendReady, true, 'React 更新後主按鈕已啟用');

  main.className = 'ds-button ds-button--icon ds-button--disabled';
  const blocked = runInNewContext(flow.buildSubmitScript(), context);
  assert.equal(blocked.ok, false, '主按鈕停用時不送出');
  assert.equal(blocked.error, 'no-send-button');
  const blockedVerify = runInNewContext(flow.buildVerifyFillScript('請產生本回合故事'), context);
  assert.equal(blockedVerify.sendReady, false, '停用狀態回報 sendReady=false');
  assert.equal(mainClicks, 1, '停用時不會再點擊');
});

test('DeepSeek 回覆只取最外層 ds-markdown，並以助理動作列判斷完成', () => {
  let copyClicks = 0;
  let otherClicks = 0;
  const copy = deepseekButton(340, {onClick: () => { copyClicks += 1; }});
  const actionButtons = [
    copy,
    deepseekButton(320, {onClick: () => { otherClicks += 1; }}),
    deepseekButton(300, {onClick: () => { otherClicks += 1; }}),
    deepseekButton(280, {onClick: () => { otherClicks += 1; }})
  ];
  const actionToolbar = {
    className: 'assistant-actions',
    parentElement: null,
    children: actionButtons,
    querySelectorAll: selector => selector.includes('role="button"') ? actionButtons : [],
    getClientRects: () => [{}]
  };
  const message = {
    className: 'ds-message',
    parentElement: null,
    children: [],
    innerText: '',
    querySelectorAll: () => [],
    getClientRects: () => [{}],
    getAttribute: () => null
  };
  const outer = {
    className: 'assistant-message',
    parentElement: null,
    children: [message, actionToolbar],
    querySelectorAll: selector => selector === 'div' ? [message, actionToolbar] : [],
    getClientRects: () => [{}]
  };
  message.parentElement = outer;
  actionToolbar.parentElement = outer;
  const messageBody = {parentElement: message, closest: () => null};
  const root = {
    className: 'ds-markdown ds-assistant-message-main-content',
    innerText: '完整的 DeepSeek 回覆內容，長度足夠。',
    textContent: '',
    parentElement: messageBody,
    getAttribute: () => null,
    getClientRects: () => [{}],
    getBoundingClientRect: () => ({x: 0, y: 100, width: 500, height: 200, top: 100, left: 0, right: 500}),
    closest(selector) {
      if (/ds-message/.test(selector)) return message;
      if (/ds-markdown/.test(selector)) return root;
      return null;
    },
    querySelectorAll: () => [],
    contains: () => false
  };
  const nested = {
    className: 'ds-markdown-cite-brand-inner',
    innerText: '引用卡片文字',
    textContent: '',
    parentElement: root,
    getAttribute: () => null,
    getClientRects: () => [{}],
    getBoundingClientRect: () => ({x: 0, y: 120, width: 300, height: 40, top: 120, left: 0, right: 300}),
    querySelectorAll: () => [],
    contains: () => false
  };

  const composerMain = deepseekButton(350);
  const composer = deepseekToolbar([deepseekButton(260), composerMain]);
  const editor = deepseekEditor('', composer);
  composer.parentElement = deepseekToolbar([], null);
  const context = deepseekContext(editor, [root, nested]);

  let probe = runInNewContext(flow.buildReplyProbeScript(), context);
  assert.equal(probe.generating, true, '輸入框清空且主按鈕仍可按＝生成中');
  assert.equal(probe.editorEmpty, true);
  assert.equal(probe.count, 1, '引用卡片等子節點不算獨立回覆');
  assert.equal(probe.text, '完整的 DeepSeek 回覆內容，長度足夠。', '只取最外層 ds-markdown 的文字');
  assert.equal(probe.copyReady, true, '助理動作列出現＝回覆完成');

  const copied = runInNewContext(flow.buildCopyClickScript(), context);
  assert.equal(copied.clicked, true, '完成後可按下官網複製鈕');
  assert.equal(copied.structural, true, '複製鈕以結構定位');
  assert.equal(copyClicks, 1, '點的是動作列第一顆（複製）');
  assert.equal(otherClicks, 0, '不會誤按重新生成／讚／倒讚');

  composerMain.className = 'ds-button ds-button--icon ds-button--disabled';
  probe = runInNewContext(flow.buildReplyProbeScript(), context);
  assert.equal(probe.generating, false, '主按鈕停用＝已結束生成');
  assert.equal(probe.copyReady, true, '已完成回覆的動作列仍在');
});

test('DeepSeek 防護寫進共用腳本與站點矩陣，官網改版時有線索可查', () => {
  const probe = flow.buildReplyProbeScript();
  assert.ok(probe.includes(quoteForPage('div.ds-markdown')), 'DeepSeek 使用精確的回覆根選擇器');
  assert.ok(probe.indexOf(quoteForPage('div.ds-markdown')) < probe.indexOf(quoteForPage(flow.SITE_HINTS.replySelectors[0])), 'DeepSeek 選擇器排在通用清單之前');
  assert.match(probe, /dsMainButton/, '探測腳本以結構尋找主按鈕');
  assert.match(probe, /ds-button--disabled/, '以官方停用類名判斷送出／停止狀態');
  assert.match(probe, /dsActionToolbar/, '以助理動作列判斷回覆完成');
  const submit = flow.buildSubmitScript();
  assert.match(submit, /dsHost/, '送出腳本只在 DeepSeek 網域啟用結構判定');
  assert.match(submit, /structural:dsHost/, '回報是否走結構判定');
  assert.match(flow.buildCopyClickScript(), /deepseek-copy/, '複製腳本有 DeepSeek 結構分支');
  const deepseek = flow.SITE_MATRIX.find(site => site.id === 'deepseek');
  assert.match(deepseek.notes, /ds-markdown/, '站點矩陣記錄回覆根選擇器');
  assert.match(deepseek.notes, /主按鈕/, '站點矩陣記錄無標籤主按鈕');
});

test('自動化卡住會明確回報（送出沒反應／輸入框被佔用），不再無聲重試', () => {
  assert.match(main, /pushWebAutoStatus\('stalled',\{reason:'send'/, '送出沒有證據時回報 stalled/send');
  assert.match(main, /pushWebAutoStatus\('stalled',\{reason:conflict\?'conflict':'fill'/, '填字失敗時回報 stalled/conflict 或 fill');
  assert.match(webApp, /case 'stalled':/, 'App 會把 stalled 翻成白話');
  assert.match(webApp, /官網沒有送出（送出鈕沒有反應）/, '告訴玩家手動按一次送出，之後仍會自動接回');
  assert.match(webApp, /輸入框裡有您自己的未送出文字/, '說明自動化不會覆蓋玩家草稿');
});
