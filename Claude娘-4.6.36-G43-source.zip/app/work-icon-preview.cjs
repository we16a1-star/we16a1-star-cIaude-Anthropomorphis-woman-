const sharp=require('sharp');
(async()=>{
 const src='assets/icon.png';
 const meta=await sharp(src).metadata();
 const crop={left:154,top:126,width:720,height:720};
 const base=await sharp(src).extract(crop).png().toBuffer();
 await sharp(base).resize(1024,1024,{fit:'cover',kernel:'lanczos3'}).png().toFile('assets/icon-g30-preview.png');
})();
