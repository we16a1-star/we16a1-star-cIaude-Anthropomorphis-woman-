// r10（2026-10-19）：品牌字串統一「Claude娘」；同 12娘 同步版。
// 前端靜態稽核（frontend static review）——給要審查或修改前端的人一鍵檢查。
// 目的：把「人工逐檔看」的工作壓到幾秒內完成，並讓「結構地圖 vs 程式碼」不會偷偷失準。
//
// 檢查項目：
//   1. 檔案清單：app\www 全部前端檔案、行數與各模組 export 清單（導覽用）。
//   2. 語法檢查：www 內每個 .js（含 app.bundle.js 建置產物）都能通過 node --check。
//   3. app.js 結構地圖：①檔頭地圖必須是連續的 SECTION 1~N；②程式碼內
//      「// ==== SECTION n｜…====」標記數量與編號必須和地圖完全一致（順序一致、各出現一次）。
//   4. 地圖關鍵字：地圖上承諾可搜尋的符號（$／UI_EN／WEB_AI_PROVIDERS…）確實存在。
//   5. 衛生檢查：www 原始檔不得有 console.log／debug／info、debugger、TODO、FIXME
//      （console.error／warn 允許，視為錯誤通報並列出位置）。
//   6. innerHTML 稽核：app.js 內每一行 innerHTML 必須含 esc(（或屬固定的安全樣板）。
//   7. 事件綁定統計（參考用）：addEventListener 與 .onX= 的數量與位置。
//   8. id 交叉檢查（參考用）：$('…') 用到但 index.html 沒有的 id（多為動態建立）。
//   9. 對話框英譯：alert／confirm／prompt 一律經 uiText（zh 模式輸出原文、en 模式查 UI_EN）。
//
// 用法：node check-frontend-review.cjs ["app 資料夾路徑"]（預設＝本檔旁邊的 app\）
// 只讀不寫；離線可跑；全部通過時離開碼 0，有失敗時 1。
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

const appDir = path.join(process.argv[2] ? path.resolve(process.argv[2]) : path.join(__dirname, 'app'));
const wwwDir = path.join(appDir, 'www');

let failures = 0;
const ok = (cond, label) => { console.log((cond ? 'OK    ' : 'FAIL  ') + label); if (!cond) failures++; };
const info = label => { console.log('INFO  ' + label); };
const lineOf = (text, index) => text.slice(0, index).split(/\r?\n/).length;
const countLines = text => text.split(/\r?\n/).length;

if (!fs.existsSync(path.join(wwwDir, 'app.js'))) {
  console.log('找不到前端：' + path.join(wwwDir, 'app.js'));
  console.log('用法：node check-frontend-review.cjs ["app 資料夾路徑"]');
  process.exit(1);
}
console.log('前端靜態稽核（目標：' + wwwDir + '）');
console.log('');

const wwwFiles = fs.readdirSync(wwwDir, { withFileTypes: true })
  .filter(e => e.isFile() && e.name.endsWith('.js'))
  .map(e => e.name)
  .sort();

// 1) 檔案清單＋exports（導覽）
console.log('=== 1) 前端檔案清單與 export（導覽用）===');
for (const name of wwwFiles) {
  const text = fs.readFileSync(path.join(wwwDir, name), 'utf8').replace(/^\uFEFF/, '');
  const exports = [
    ...[...text.matchAll(/export\s+(?:async\s+)?function\s+([A-Za-z0-9_$]+)/g)].map(m => m[1]),
    ...[...text.matchAll(/export\s+(?:const|let|var)\s+([A-Za-z0-9_$]+)/g)].map(m => m[1])
  ];
  const lines = countLines(text);
  if (name === 'app.bundle.js') { info(`${name}（${lines} 行，建置產物，由 npm run build:web 產生）`); continue; }
  console.log(`      ${name}（${lines} 行）` + (exports.length ? `  export：${exports.join(', ')}` : ''));
}
console.log('');

// 2) 語法檢查
console.log('=== 2) 語法檢查（node --check）===');
let syntaxBad = 0;
for (const name of wwwFiles) {
  const res = spawnSync(process.execPath, ['--check', path.join(wwwDir, name)], { encoding: 'utf8' });
  if (res.status !== 0) { syntaxBad += 1; console.log('  語法錯誤：' + name + '\n' + String(res.stderr || '').split('\n').slice(0, 3).join('\n')); }
}
ok(syntaxBad === 0, `www 全部 .js 語法檢查（${wwwFiles.length} 個檔案）`);
console.log('');

const appJs = fs.readFileSync(path.join(wwwDir, 'app.js'), 'utf8').replace(/^\uFEFF/, '');

// 3) 結構地圖與 SECTION 標記一致
console.log('=== 3) app.js 結構地圖 vs SECTION 標記 ===');
const mapBlock = /\/\/ 【章節導覽】([\s\S]*?)\/\/ 【常見修改點/.exec(appJs);
ok(Boolean(mapBlock), '檔頭含「章節導覽」區塊');
const mapNumbers = mapBlock ? [...mapBlock[1].matchAll(/SECTION\s+(\d+)\s/g)].map(m => Number(m[1])) : [];
const mapSet = [...new Set(mapNumbers)].sort((a, b) => a - b);
const mapOk = mapSet.length > 0 && mapSet.every((n, i) => n === i + 1);
ok(mapOk, '地圖列出連續的 SECTION（實際：' + (mapSet.join(',') || '無') + '）');
const bannerNumbers = [...appJs.matchAll(/\/\/ ==== SECTION (\d+)｜/g)].map(m => Number(m[1]));
const bannerCount = {};
for (const n of bannerNumbers) bannerCount[n] = (bannerCount[n] || 0) + 1;
const bannersOk = bannerNumbers.length > 0 && bannerNumbers.every((n, i) => n === i + 1);
ok(bannersOk, '程式碼內 SECTION 標記連續、依序（共 ' + bannerNumbers.length + ' 個；實際：' + (bannerNumbers.join(',') || '無') + '）');
const dupBanner = Object.entries(bannerCount).filter(([, c]) => c !== 1).map(([n, c]) => `${n}×${c}`);
ok(dupBanner.length === 0, '沒有重複的 SECTION 標記' + (dupBanner.length ? '（' + dupBanner.join('、') + '）' : ''));
const sameOrder = mapSet.length === bannerNumbers.length && mapSet.every((n, i) => n === bannerNumbers[i]);
ok(sameOrder, '地圖與程式碼的 SECTION 數量與編號完全一致（地圖 ' + mapSet.join(',') + ' vs 程式碼 ' + bannerNumbers.join(',') + '）');
console.log('');

// 4) 地圖關鍵字存在
console.log('=== 4) 結構地圖關鍵字（改了程式碼就要同步地圖）===');
const keywords = [
  'document.getElementById(id)', 'UI_EN', 'applyUiLanguage', 'WEB_AUTO_FLOW_KEY', 'applyWebAutoFlow',
  'WEB_AI_PROVIDERS', 'function fresh', 'function load(', 'applyTurn', 'applyWebReply',
  'currentSceneImageKey', 'data-language-select', './token-budget.js', './prompt-rules.js', './save-storage.js',
  './world-book.js', 'setGameMenu'
];
for (const word of keywords) ok(appJs.includes(word), 'app.js 仍可搜尋到「' + word + '」');
console.log('');

// 5) 衛生檢查（原始檔；app.bundle.js 是建置產物不檢查）
console.log('=== 5) 衛生檢查（console.log／debugger／TODO／FIXME）===');
const banned = /console\.(log|debug|info)\(|\bdebugger\b|\bTODO\b|\bFIXME\b/;
let hygieneBad = 0;
for (const name of wwwFiles) {
  if (name === 'app.bundle.js') continue;
  const text = fs.readFileSync(path.join(wwwDir, name), 'utf8').replace(/^\uFEFF/, '');
  for (const m of text.matchAll(new RegExp(banned.source, 'g'))) {
    hygieneBad += 1;
    console.log(`      ${name}:${lineOf(text, m.index)}  ${m[0]}`);
  }
}
ok(hygieneBad === 0, '原始檔沒有除錯殘留（' + (wwwFiles.length - 1) + ' 個檔案）');
const reported = /console\.(error|warn)\(/g;
let reportedCount = 0;
for (const name of wwwFiles) {
  if (name === 'app.bundle.js') continue;
  const text = fs.readFileSync(path.join(wwwDir, name), 'utf8').replace(/^\uFEFF/, '');
  for (const m of text.matchAll(reported)) {
    reportedCount += 1;
    info(`錯誤通報（允許）：${name}:${lineOf(text, m.index)}  ${m[0]}`);
  }
}
if (!reportedCount) info('沒有 console.error／warn');
console.log('');

// 6) innerHTML 稽核（app.js；以「指派敘述」為單位，跨行樣板也算同一處）
console.log('=== 6) innerHTML 稽核（動態資料必須經 esc()；靜態文字可用 uiText(\'…\')）===');
const safeInnerHtml = ['Claude娘</span>的圖書館', 'system.map(card)', 'WEB_AI_GUIDE_STEPS.map'];
const innerMatches = [...appJs.matchAll(/innerHTML\s*=/g)];
let innerBad = 0;
innerMatches.forEach((m, i) => {
  const nextStart = i + 1 < innerMatches.length ? innerMatches[i + 1].index : appJs.length;
  const windowText = appJs.slice(m.index, Math.min(nextStart, m.index + 1500));
  const protectedOk = windowText.includes('esc(') || /uiText\(\s*'/.test(windowText) || safeInnerHtml.some(sig => windowText.includes(sig));
  if (!protectedOk) {
    innerBad += 1;
    console.log(`      ${lineOf(appJs, m.index)}: ${windowText.split(/\r?\n/)[0].trim().slice(0, 110)}`);
  }
});
ok(innerBad === 0, `innerHTML 指派共 ${innerMatches.length} 處：全部有 esc()／uiText('靜態文字')／固定樣板保護`);
ok(appJs.includes('function esc('), 'esc() 仍然存在（上面的保證才有意義）');
console.log('');

// 7) 事件綁定統計（參考用）
console.log('=== 7) 事件綁定統計（參考用）===');
const listeners = [...appJs.matchAll(/addEventListener\(/g)].map(m => lineOf(appJs, m.index));
const onHandlers = [...appJs.matchAll(/\.on(?:click|change|input|submit|error|load)\s*=/g)];
info(`app.js：addEventListener ${listeners.length} 處（行號 ${listeners.join(', ')}）；.onX= ${onHandlers.length} 處`);
console.log('');

// 8) id 交叉檢查（參考用）
console.log('=== 8) id 交叉檢查（$() 對 index.html；參考用）===');
const html = fs.readFileSync(path.join(wwwDir, 'index.html'), 'utf8').replace(/^\uFEFF/, '');
const htmlIds = new Set([...html.matchAll(/\bid="([^"]+)"/g)].map(m => m[1]));
const usedIds = new Set([
  ...[...appJs.matchAll(/\$\('([A-Za-z][\w-]*)'\)/g)].map(m => m[1]),
  ...[...appJs.matchAll(/querySelector\('#([A-Za-z][\w-]*)'\)/g)].map(m => m[1])
]);
const missingInHtml = [...usedIds].filter(id => !htmlIds.has(id)).sort();
const unusedInJs = [...htmlIds].filter(id => !usedIds.has(id)).sort();
info(`index.html 有 ${htmlIds.size} 個 id；app.js 以字面值使用 ${usedIds.size} 個`);
if (missingInHtml.length) info(`用到但 index.html 沒有（多為動態建立）：${missingInHtml.slice(0, 30).join(', ')}${missingInHtml.length > 30 ? ' …等 ' + missingInHtml.length + ' 個' : ''}`);
else info('用到但 index.html 沒有的 id：無');
if (unusedInJs.length) info(`index.html 有但沒被 $()／querySelector(#) 直接用到：${unusedInJs.slice(0, 30).join(', ')}${unusedInJs.length > 30 ? ' …等 ' + unusedInJs.length + ' 個' : ''}`);
console.log('');

// 9) 對話框英譯（alert／confirm／prompt 一律經 uiText；r7 追加二起）
console.log('=== 9) 對話框英譯（alert／confirm／prompt 都要經 uiText）===');
let dialogBad = 0;
for (const name of wwwFiles) {
  if (name === 'app.bundle.js') continue;
  const text = fs.readFileSync(path.join(wwwDir, name), 'utf8').replace(/^\uFEFF/, '');
  text.split(/\r?\n/).forEach((line, i) => {
    if (/\balert\(|\bconfirm\(|\bprompt\(/.test(line) && !/uiText|translateError/.test(line)) {
      dialogBad += 1;
      console.log(`      ${name}:${i + 1}  ${line.trim().slice(0, 120)}`);
    }
  });
}
ok(dialogBad === 0, 'alert／confirm／prompt 全部經 uiText（' + dialogBad + ' 處未包）');
console.log('');

console.log(failures === 0 ? '>>> 前端靜態稽核通過（0 項失敗）' : `>>> 有 ${failures} 項失敗，請看上方 FAIL`);
process.exit(failures === 0 ? 0 : 1);
