# r10（2026-10-19，協調線）：品牌字樣統一「Claude娘」。
# Claude娘 自動化：語法檢查 → 測試 → bundle → 安裝檔 → 來源 ZIP → SHA256
# 用法：在專案根目錄執行 powershell -ExecutionPolicy Bypass -File .\AUTO-VERIFY-AND-PACKAGE.ps1
# 需要網路（npm 依賴、Electron 下載）。免安裝 Node 在 %TEMP%\node-portable 或 app\_build-tools\node 下若存在會自動使用。
# 版本號單一來源＝app\package.json；本檔不寫死版本，改版只需改 package.json。
# v4.4.0 修正：Node 22 的 node --test 不接受目錄參數（node --test tests/ 會 MODULE_NOT_FOUND），改用 glob。
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$app = Join-Path $root 'app'

# 免安裝 Node 的找法：先看一鍵安裝留下的 app\_build-tools\node，再看 %TEMP%\node-portable 下的任何版本。
$nodeCandidates = @(
  (Join-Path $app '_build-tools\node\node.exe'),
  (Get-ChildItem (Join-Path $env:TEMP 'node-portable') -Filter 'node.exe' -Recurse -Depth 2 -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName)
) | Where-Object { $_ -and (Test-Path $_) }
if ($nodeCandidates.Count -gt 0) { $env:Path = (Split-Path -Parent $nodeCandidates[0]) + ';' + $env:Path }
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw '找不到 Node.js。請先執行 app\BUILD-WINDOWS11-AUTO.bat，或把免安裝版放到 %TEMP%\node-portable。' }
$env:ELECTRON_MIRROR = 'https://npmmirror.com/mirrors/electron/'

function ShortPath($p) { return (New-Object -ComObject Scripting.FileSystemObject).GetFolder($p).ShortPath }

# 版本與檔名標籤一律由 app\package.json 產生，避免各處寫死後不同步。
$pkgJson = [IO.File]::ReadAllText((Join-Path $app 'package.json'), [Text.Encoding]::UTF8) | ConvertFrom-Json
$version = $pkgJson.version
if (-not $version) { throw 'app\package.json 缺少 version 欄位' }
$tag = "v$version-r1"
$changelogName = "v$version-優化紀錄.txt"
Write-Host "== 本輪版本：$version（$tag） =="

$appShort = ShortPath $app
Push-Location $appShort
try {
  Write-Host '== 1/6 語法檢查 =='
  node --check www/app.js; node --check www/gift-system.js
  node --check server/server.js; node --check electron-main.cjs
  node --check workshop-apply.cjs; node --check scene-download.cjs
  node --check scripts/source-fingerprint.cjs
  node --check tests/story-ai.test.js; node --check tests/api-vault.test.js
  Write-Host '== 2/6 自動測試 =='
  # Node 22：node --test 只吃檔案／glob，給目錄會變成「找不到模組」。用 glob 才對。
  node --test "tests/**/*.test.js"
  if ($LASTEXITCODE -ne 0) { throw '測試失敗，中止打包' }
  Write-Host '== 3/6 重建 bundle =='
  npm run build:web
  if ($LASTEXITCODE -ne 0) { throw 'bundle 建置失敗' }
  Write-Host '== 4/6 建置安裝檔（輸出至 TEMP，避開 OneDrive 鎖定） =='
  $distOut = Join-Path $env:TEMP 'cloudo-dist-out'
  if (Test-Path $distOut) { Remove-Item $distOut -Recurse -Force }
  New-Item -ItemType Directory -Force -Path $distOut | Out-Null
  $pkgFile = Join-Path $appShort 'package.json'
  $pkgBackup = [IO.File]::ReadAllBytes($pkgFile)
  try {
    $pkg = [Text.Encoding]::UTF8.GetString($pkgBackup) | ConvertFrom-Json
    if (!$pkg.build.directories) { $pkg.build | Add-Member -NotePropertyName directories -NotePropertyValue (@{output = ($distOut -replace '\\', '/')}) }
    else { $pkg.build.directories.output = ($distOut -replace '\\', '/') }
    [IO.File]::WriteAllText($pkgFile, ($pkg | ConvertTo-Json -Depth 20), (New-Object Text.UTF8Encoding $false))
    npx electron-builder --win nsis
    if ($LASTEXITCODE -ne 0) { throw '安裝檔建置失敗' }
  } finally {
    [IO.File]::WriteAllBytes($pkgFile, $pkgBackup)
  }
  # 檔名含版本，改成萬用字元比對，這樣改版不會再弄壞這段。
  $built = Get-ChildItem $distOut -Filter '*-Setup-*.exe' | Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if (!$built) { throw '找不到建置好的 Setup exe' }
  New-Item -ItemType Directory -Force -Path 'dist' | Out-Null
  Copy-Item $built.FullName (Join-Path 'dist' $built.Name) -Force
} finally { Pop-Location }

$rootShort = ShortPath $root
$outputsDir = Join-Path (Split-Path $rootShort -Parent) 'outputs'
Push-Location $rootShort
try {
  $setup = Get-ChildItem 'app/dist' -Filter '*-Setup-*.exe' | Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if (!$setup) { throw '找不到建置好的 Setup exe' }
  New-Item -ItemType Directory -Force -Path $outputsDir | Out-Null
  Copy-Item $setup.FullName (Join-Path $outputsDir "Claude娘-Windows11-Setup-$tag-x64.exe") -Force
  if (Test-Path $changelogName) { Copy-Item $changelogName (Join-Path $outputsDir "CONTINUE-DEVELOPMENT-$tag.txt") -Force }
  Copy-Item 'README.txt' (Join-Path $outputsDir "README-$tag.txt") -Force
  Copy-Item 'README-使用方法.txt' (Join-Path $outputsDir "README-使用方法-$tag.txt") -Force
  if (Test-Path '先看這裡-安裝說明.txt') { Copy-Item '先看這裡-安裝說明.txt' (Join-Path $outputsDir "先看這裡-安裝說明-$tag.txt") -Force }
  Write-Host '== 5/6 來源 ZIP（排除 node_modules/dist/secrets） =='
  $stage = Join-Path $env:TEMP "cloudo-stage-$tag"
  if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
  New-Item -ItemType Directory -Path $stage | Out-Null
  robocopy '.' $stage /E /XD node_modules dist .git outputs work release _build-tools .workshop-backup .cache app/dist app/node_modules app/_build-tools app/.workshop-backup /XF .env source-root.json /NFL /NDL /NJH /NJS | Out-Null
  $zip = Join-Path $outputsDir "Claude娘-Windows11-source-$tag.zip"
  if (Test-Path $zip) { Remove-Item $zip -Force }
  Compress-Archive -Path "$stage/*" -DestinationPath $zip -CompressionLevel Optimal
  Write-Host '== 6/6 SHA-256 =='
  $files = @("Claude娘-Windows11-Setup-$tag-x64.exe","Claude娘-Windows11-source-$tag.zip","README-$tag.txt","README-使用方法-$tag.txt","CONTINUE-DEVELOPMENT-$tag.txt","先看這裡-安裝說明-$tag.txt") | Where-Object { Test-Path (Join-Path $outputsDir $_) }
  $lines = foreach ($f in $files) { (Get-FileHash (Join-Path $outputsDir $f) -Algorithm SHA256).Hash + '  ' + $f }
  $shaFile = Join-Path $outputsDir "SHA256-$tag.txt"
  $lines | Set-Content -Path $shaFile -Encoding utf8
  $self = Get-FileHash $shaFile -Algorithm SHA256
  Add-Content -Path $shaFile -Value ($self.Hash + "  SHA256-$tag.txt") -Encoding utf8
  Get-Content $shaFile
} finally { Pop-Location }
Write-Host '自動化管線完成。'
