@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "BUILD_SCRIPT=%~dp0app\BUILD-WINDOWS11-AUTO.bat"
if not exist "%BUILD_SCRIPT%" (
  echo [錯誤] 找不到 App 建置腳本：
  echo %BUILD_SCRIPT%
  echo 請確認 ZIP 已完整解壓縮。
  pause
  exit /b 1
)
call "%BUILD_SCRIPT%"
exit /b %errorlevel%