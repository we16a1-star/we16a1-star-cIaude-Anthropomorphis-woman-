// r10（2026-10-19）：品牌字串統一「Claude娘」；同 12娘 同步版。
// 網頁模式自動化 E2E（開發版或已安裝版都能跑；全程隔離 user-data-dir，不碰真實存檔與真實瀏覽器設定檔）：
//   A. 內建模式：開關關閉時不自動送出 → 開關打開立即自動送出 → 串流中不得提早接回 → 完成後自動接回
//   B. 外部模式：App 以「自動化專用設定檔」啟動 Chrome／Edge → 開啟官網分頁 → 由 App 自動填入並送出 → 自動接回
// 用法：node verify-web-auto.cjs <App 執行檔路徑> [應用程式資料夾（開發版才要）] [user-data-dir] [除錯埠]
//   開發版範例：node verify-web-auto.cjs "C:\...\electron-dev\electron.exe" "C:\...\cIoudo10娘\app"
//   已安裝版範例：node verify-web-auto.cjs "%LOCALAPPDATA%\Programs\claude-novel-windows11\Claude娘 - Windows 11 電腦版.exe"
// 假官網頁面注入方式：先用 CDP 把分頁導到測試用網址（內建官網視窗＝about:blank、App 網址白名單允許；
// 外部模式＝https://chatgpt.com/robots.txt，內容靜態又保住網址開頭讓 App 找得到同一個分頁），
// 再用 CDP Page.setDocumentContent 換成測試頁；官網登入頁自己的載入與轉址就蓋不掉測試頁。
// 頁面會記錄：__auto.sends（送出次數）、__auto.generating（是否串流中）、__auto.copyClicks（複製鈕被按幾次）。
// 追加十（審查項目 A–F）也在此驗：站點覆蓋矩陣先驗（E）、健康自檢全綠與輸入框消失（D）、
// 送出鈕隱藏時改走 Enter（A）、狀態條「已自動送出；等待官網回覆」（C）、
// 自動重試次數與狀態顯示詳細度（F）。
const { spawn, spawnSync } = require('node:child_process');
const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');

const electronExe = process.argv[2] || '';
const appDir = process.argv[3] || '';
const userDataDir = process.argv[4] || path.join(os.tmpdir(), 'cioudo-webauto', 'userdata');
const port = Number(process.argv[5] || 9457);
if (!electronExe || !fs.existsSync(electronExe)) {
  console.error('用法：node verify-web-auto.cjs <App 執行檔路徑> [應用程式資料夾（開發版才要）] [user-data-dir] [除錯埠]');
  console.error('  開發版範例：node verify-web-auto.cjs "C:\\...\\electron-dev\\electron.exe" "C:\\...\\cIoudo10娘\\app"');
  console.error('  已安裝版範例：node verify-web-auto.cjs "C:\\Users\\<你>\\AppData\\Local\\Programs\\claude-novel-windows11\\Claude娘 - Windows 11 電腦版.exe"');
  process.exit(1);
}
const automationPort = 4462;
const endpoint = `http://127.0.0.1:${port}`;
const automationEndpoint = `http://127.0.0.1:${automationPort}`;
const AUTO_KEY = 'claude_novel_web_auto_flow_v1';

// 追加十 E：站點覆蓋矩陣（與 App 的 ai-web-flow.cjs 同一份資料；開發版／交付版路徑都通）。
function resolveFlowModule() {
  for (const candidate of [path.join(__dirname, 'app', 'ai-web-flow.cjs'), path.join(__dirname, 'cIoudo10娘', 'app', 'ai-web-flow.cjs')]) {
    try { return require(candidate); } catch {}
  }
  return null;
}
const flow = resolveFlowModule();

// App 的接回驗證要求正文至少 500 字（含標點），不足會被拒絕，所以這裡重複到 500 字以上。
const REPLY_NARRATION = '我把外套遞過去，她先是愣了一下，才伸手接住，指尖還帶著窗邊的涼意。「謝謝。」她低聲說，把外套抱在懷裡，像抱住一件暫時不必解釋的事。雨聲在玻璃上鋪開，她又轉回窗邊，卻沒有再把自己縮得那麼小。';
const REPLY = JSON.stringify({
  narration: REPLY_NARRATION.repeat(6),
  affectionDelta: 3,
  choices: ['問她那封信是誰寫的', '替她把窗關上', '邀她一起下樓喝熱茶', '坐在她旁邊一起聽雨', '說起自己小時候的雨天', '問她要不要把外套留著', '陪她把書架上的書整理好'],
  ending: false,
  endingText: null,
  memory: '她把那封沒有署名的舊信收回抽屜，第一次讓我看見它——她說那是她母親留下的。'
});

function fakePageHtml() {
  return `<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><title>測試用官網</title>
<style>#stop{display:none;margin:6px}button{margin:4px}</style></head><body>
<div id="thread"></div>
<div id="composer">
  <div id="editor" contenteditable="true" role="textbox" aria-label="Message"></div>
  <button id="send" type="button" aria-label="Send message">Send</button>
</div>
<button id="stop" type="button" aria-label="Stop generating">Stop</button>
<script>
window.__auto={sends:0,copyClicks:0,generating:false,filled:'',sent:''};
const editor=document.getElementById('editor');
const record=()=>{window.__auto.filled=editor.innerText||'';};
editor.addEventListener('input',record);
new MutationObserver(record).observe(editor,{childList:true,subtree:true,characterData:true});
const REPLY=${REPLY};
const REPLY_TEXT=JSON.stringify(REPLY);
function send(){
  if(window.__auto.generating)return;
  const text=(editor.innerText||'').trim();
  if(!text)return;
  window.__auto.generating=true;window.__auto.sends+=1;window.__auto.sent=text;
  editor.innerHTML='';
  const bubble=document.createElement('div');
  bubble.setAttribute('data-message-author-role','assistant');
  bubble.className='markdown';
  document.getElementById('thread').appendChild(bubble);
  const toolbar=document.createElement('div');
  const copy=document.createElement('button');
  copy.setAttribute('aria-label','Copy reply');copy.textContent='Copy';
  copy.addEventListener('click',()=>{window.__auto.copyClicks+=1;try{navigator.clipboard.writeText(bubble.innerText).catch(()=>{});}catch{}});
  toolbar.appendChild(copy);
  document.getElementById('stop').style.display='inline-block';
  let i=0;
  const step=Math.max(60,Math.round(REPLY_TEXT.length/8));
  const timer=setInterval(()=>{
    i+=step;
    bubble.textContent=REPLY_TEXT.slice(0,i);
    if(i>=REPLY_TEXT.length){
      clearInterval(timer);
      window.__auto.generating=false;
      document.getElementById('stop').style.display='none';
      bubble.parentNode.appendChild(toolbar);
    }
  },400);
}
document.getElementById('send').addEventListener('click',send);
editor.addEventListener('keydown',event=>{if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();send();}});
</script></body></html>`;
}

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const get = url => new Promise((resolve, reject) => {
  http.get(url, res => { let data = ''; res.on('data', c => data += c); res.on('end', () => { try { resolve(JSON.parse(data)); } catch (e) { reject(e); } }); }).on('error', reject);
});

const problems = [];
const check = (ok, label, detail) => {
  console.log((ok ? '[OK]   ' : '[FAIL] ') + label + (detail === undefined ? '' : ' → ' + JSON.stringify(detail).slice(0, 300)));
  if (!ok) problems.push(label);
};

function launchApp() {
  fs.rmSync(userDataDir, { recursive: true, force: true });
  const args = [];
  if (appDir) args.push(appDir);
  args.push(`--user-data-dir=${userDataDir}`, `--remote-debugging-port=${port}`);
  return spawn(electronExe, args, { stdio: 'ignore', detached: false });
}

// 收尾：關閉 App、自動化瀏覽器與所有測試連線（成功、失敗都會呼叫，不會留下行程）。
let appProcess = null;
const cleanupClients = [];
async function shutdown() {
  for (const client of cleanupClients.splice(0)) { try { client.close(); } catch {} }
  if (!appProcess) return;
  const pid = appProcess.pid;
  appProcess = null;
  try { spawnSync('taskkill', ['/F', '/T', '/PID', String(pid)], { stdio: 'ignore' }); } catch {}
  spawnSync('powershell', ['-NoProfile', '-Command',
    "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -and ($_.CommandLine -like '*web-automation-browser*' -or $_.CommandLine -like '*cioudo-webauto*') } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"
  ], { stdio: 'ignore' });
  await sleep(800);
}

async function findTargets(base) {
  try { return await get(base + '/json/list'); } catch { return []; }
}

async function waitForTarget(base, predicate, label, attempts = 90) {
  for (let i = 0; i < attempts; i += 1) {
    const list = await findTargets(base);
    const hit = list.find(predicate);
    if (hit && hit.webSocketDebuggerUrl) return hit;
    await sleep(1000);
  }
  throw new Error('等不到目標：' + label);
}

function connect(target, timeoutMs = 15000) {
  return new Promise((resolve, reject) => {
    const socket = new WebSocket(target.webSocketDebuggerUrl);
    let nextId = 1;
    const waiting = new Map();
    const openTimer = setTimeout(() => reject(new Error('連線目標逾時：' + String(target.url).slice(0, 60))), timeoutMs);
    socket.onmessage = event => {
      const message = JSON.parse(typeof event.data === 'string' ? event.data : String(event.data));
      if (message.method === 'Page.javascriptDialogOpening') {
        socket.send(JSON.stringify({ id: nextId++, method: 'Page.handleJavaScriptDialog', params: { accept: true } }));
        return;
      }
      const pending = waiting.get(message.id);
      if (!pending) return;
      waiting.delete(message.id);
      pending(message);
    };
    socket.onerror = error => { clearTimeout(openTimer); reject(new Error('WebSocket 錯誤：' + error.message)); };
    socket.onopen = () => {
      clearTimeout(openTimer);
      resolve({
        send(method, params = {}) {
          const id = nextId++;
          socket.send(JSON.stringify({ id, method, params }));
          return new Promise((resolveCall, rejectCall) => {
            waiting.set(id, message => message.error ? rejectCall(new Error(method + '：' + JSON.stringify(message.error))) : resolveCall(message.result));
            setTimeout(() => { waiting.delete(id); rejectCall(new Error(method + ' 逾時')); }, 30000);
          });
        },
        close() { socket.close(); }
      });
    };
  });
}

// 新存檔是「開始故事」畫面（#startStoryBtn）；已有故事時才是 7 個選項。
async function clickNextTurn(appClient) {
  // Use a saved story so the test fixture does not need to emulate the official
  // site's temporary-chat confirmation required by the default incognito mode.
  const started = await evaluate(appClient, `(() => { const b = document.getElementById('startStoryBtn'); if (b) { const save=document.getElementById('openingRecordSave'); if(save){save.checked=true;save.dispatchEvent(new Event('change',{bubbles:true}));} b.click(); return 'start'; } const c = document.querySelectorAll('#choices button[data-i]')[0]; if (c) { c.click(); return 'choice'; } return ''; })()`);
  if (!started) throw new Error('畫面上找不到「開始故事」或任何故事選項');
  return started;
}

async function evaluate(client, expression, awaitPromise = false) {
  const result = await client.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise });
  if (result.exceptionDetails) throw new Error('頁面例外：' + JSON.stringify(result.exceptionDetails.exception?.description || result.exceptionDetails.text).slice(0, 400));
  return result.result.value;
}

async function injectFakePage(client, label, { steerUrl = '' } = {}) {
  // 直接把 DOM 換成測試頁之前，先處理「真實官網還在載入或自己轉址，把測試頁蓋掉」的問題：
  //   - steerUrl：先導到這個網址，官網後續的載入與轉址就再也蓋不到測試頁。
  //     內建官網視窗用 about:blank（App 的網址白名單有允許）。
  //     外部模式用 chatgpt.com 底下的小頁面（robots.txt）：內容靜態、載入完就沒事，
  //     而且網址開頭仍是 https://chatgpt.com，App 才找得到同一個分頁（resolveTab 用網址開頭比對）。
  if (steerUrl) {
    try { await client.send('Page.navigate', { url: steerUrl }); } catch {}
    await sleep(1200);
  } else {
    // 等真正的官網頁面載入完成，再把 DOM 換成測試頁（避免載入完成後才注入被蓋掉）。
    for (let i = 0; i < 40; i += 1) {
      try {
        const ready = await evaluate(client, 'document.readyState');
        if (ready === 'complete' || ready === 'interactive') break;
      } catch {}
      await sleep(750);
    }
  }
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      const tree = await client.send('Page.getFrameTree');
      await client.send('Page.setDocumentContent', { frameId: tree.frameTree.frame.id, html: fakePageHtml() });
    } catch {}
    await sleep(700);
    const alive = await evaluate(client, 'Boolean(window.__auto && document.getElementById("editor"))');
    if (alive) {
      console.log(`[i]    假官網頁面已注入（${label}）`);
      return true;
    }
    await sleep(800);
  }
  return false;
}

async function waitFor(client, expression, label, attempts = 60, gap = 1000) {
  for (let i = 0; i < attempts; i += 1) {
    try { if (await evaluate(client, expression)) return true; } catch {}
    await sleep(gap);
  }
  throw new Error('等不到條件：' + label);
}

const appStory = `(() => {
  const id = localStorage.getItem('claude_novel_active_slot_v1');
  let slot = null;
  try { slot = JSON.parse(localStorage.getItem('claude_novel_slot_v2_' + id) || 'null'); } catch {}
  const state = (slot && slot.state) || {};
  return {
    turns: Array.isArray(state.history) ? state.history.length : 0,
    memory: String(state.storyMemory || ''),
    pendingTurn: !!document.querySelector('#choices .pending-turn'),
    choices: document.querySelectorAll('#choices button[data-i]').length,
    autoSelect: (() => { const el = document.getElementById('pendingWebAutoFlow'); return el ? el.value : null; })(),
    autoFlowStored: localStorage.getItem('${AUTO_KEY}')
  };
})()`;

async function main() {
  // 追加十 E：站點覆蓋矩陣先驗（不用瀏覽器，先確認 12 家都有登入方式與已知限制備註）
  const matrix = (flow && flow.SITE_MATRIX) || [];
  check(matrix.length === 12, '站點覆蓋矩陣涵蓋 12 家官網', matrix.map(site => site.id).join(','));
  check(matrix.length > 0 && matrix.every(site => site.name && site.login && site.notes), '每一家官網都有名稱、登入方式與已知限制備註');
  check(matrix.length > 0 && matrix.every(site => /^[a-z]+$/.test(site.id)), '矩陣鍵名可直接對應 App 的官網清單');

  console.log('== A. 內建模式（App 內官網視窗） ==');
  const app = launchApp();
  appProcess = app;
  const appTarget = await waitForTarget(endpoint, t => t.type === 'page' && String(t.url).startsWith('file:'), 'App 主視窗');
  const appClient = await connect(appTarget);
  cleanupClients.push(appClient);
  await appClient.send('Page.enable');
  await appClient.send('Runtime.enable');

  // 啟用網頁模式（與正式流程相同：從設定頁按鈕）
  await evaluate(appClient, `document.getElementById('enableWebAiBtn').click()`);
  await sleep(800);

  // 明確選 ChatGPT（openai）：fresh() 的預設是 Gemini，這裡固定測 ChatGPT 的訊息結構
  await evaluate(appClient, `(() => { const s = document.getElementById('webAiProvider'); s.value = 'openai'; s.dispatchEvent(new Event('change')); })()`);
  await sleep(500);
  check((await evaluate(appClient, `document.getElementById('webAiProvider').value`)) === 'openai', '已把官網服務切到 ChatGPT（openai）');

  // 先開好官網視窗（內建），再把 DOM 換成測試頁
  await evaluate(appClient, `document.getElementById('openAiWebsiteBtn').click()`);
  const companionTarget = await waitForTarget(endpoint, t => t.type === 'page' && String(t.url).includes('chatgpt.com'), 'App 內官網視窗');
  const companion = await connect(companionTarget);
  cleanupClients.push(companion);
  await companion.send('Page.enable');
  await companion.send('Runtime.enable');
  const injected = await injectFakePage(companion, '內建官網視窗', { steerUrl: 'about:blank' });
  check(injected, '內建官網視窗已換成測試頁（有輸入框與送出鈕）');
  if (!injected) throw new Error('假官網頁面注入失敗（內建官網視窗）；先確認 App 能正常開官網視窗再重跑。');

  // A1. 先把開關關掉：回合開始時不得自動送出
  await evaluate(appClient, `(() => { const s = document.getElementById('webAutoFlowSelect'); s.value = 'off'; s.dispatchEvent(new Event('change')); })()`);
  await sleep(400);
  check((await evaluate(appClient, `localStorage.getItem('${AUTO_KEY}')`)) === 'off', '設定頁把「自動送出與自動接回」關閉後會記住（localStorage=off）');
  await clickNextTurn(appClient);
  await sleep(4000);
  const storyOff = await evaluate(appClient, appStory);
  const autoOff = (await evaluate(companion, 'window.__auto')) || {};
  check(storyOff.pendingTurn === true, '開局回合已建立（待辦回合面板出現）');
  check(autoOff.sends === 0, '開關關閉時不會自動送出（官網沒有收到任何送出）', autoOff.sends);
  check(autoOff.filled.length > 100, '開關關閉時仍會把提示詞填入輸入框（原本的手動流程不變）', autoOff.filled.slice(0, 24));
  check(storyOff.autoSelect === 'off', '待辦回合面板的開關同步顯示關閉', storyOff.autoSelect);

  // A2. 打開開關：同一回合立刻自動送出
  await evaluate(appClient, `(() => { const s = document.getElementById('webAutoFlowSelect'); s.value = 'on'; s.dispatchEvent(new Event('change')); })()`);
  await waitFor(companion, 'window.__auto.sends >= 1', '自動送出', 30, 700);
  const autoOn = (await evaluate(companion, 'window.__auto')) || {};
  check(autoOn.sends === 1, '打開開關後同一回合立即自動送出（只送一次）', autoOn.sends);
  check(autoOn.sent.includes(autoOn.filled.slice(0, 12)), '送出的內容就是 App 填入的提示詞', autoOn.sent.slice(0, 24));

  // A3. 串流中不得提早接回
  let sawGenerating = false;
  let premature = false;
  for (let i = 0; i < 8; i += 1) {
    const flag = await evaluate(companion, 'window.__auto.generating');
    if (flag) {
      sawGenerating = true;
      const mid = await evaluate(appClient, appStory);
      if (mid.turns !== 0 || mid.pendingTurn !== true) premature = true;
    }
    await sleep(400);
  }
  check(sawGenerating, '測試頁有進入「生成中」狀態（有停止鈕）');
  check(!premature, '生成中沒有提早把半成品接回故事');

  // A4. 完成後自動接回
  await waitFor(companion, 'window.__auto.generating === false', '生成結束', 60, 1000);
  await sleep(6000);
  const storyDone = await evaluate(appClient, appStory);
  const harvested = (await evaluate(companion, 'window.__auto')) || {};
  check(storyDone.turns === 1, '官網回覆完成後自動接回故事（序章：正文已寫入存檔）', { turns: storyDone.turns });
  check(storyDone.pendingTurn === false, '接回後待辦回合面板消失（沒有卡住）');
  check(storyDone.choices === 7, '回覆裡的 7 個新選項已顯示', storyDone.choices);
  check(storyDone.memory === '她把那封沒有署名的舊信收回抽屜，第一次讓我看見它——她說那是她母親留下的。', 'AI 的記憶改寫有寫進存檔');
  check(harvested.copyClicks >= 1, '接回時按了官網自己的複製鈕（最忠實的取法）', harvested.copyClicks);

  // A5. 追加十 D：健康自檢——全綠情境（輸入框／送出鈕／回覆區都尋得）
  const healthOk = await evaluate(appClient, `window.claudeDesktop.webAutoHealth({provider:'openai',mode:'embedded'})`, true);
  check(healthOk && healthOk.ok === true, '自動化自檢可執行（追加十 D）', healthOk && JSON.stringify(healthOk).slice(0, 120));
  check(healthOk && healthOk.report && healthOk.report.editor === true, '自檢：輸入框尋得');
  check(healthOk && healthOk.report && healthOk.report.sendButton === true, '自檢：送出鈕尋得');
  check(healthOk && healthOk.report && healthOk.report.replyNodes >= 1, '自檢：回覆區尋得（此時已有回覆）');

  // A6. 追加十 F：自動重試次數與狀態顯示詳細度（使用者自選、立即記住）
  const retryDefault = await evaluate(appClient, `(() => { const s = document.getElementById('webAutoRetrySelect'); return s ? s.value : null; })()`);
  check(retryDefault === '3', '設定頁有「自動重試次數」且預設 3 次', retryDefault);
  const detailDefault = await evaluate(appClient, `(() => { const s = document.getElementById('webAutoDetailSelect'); return s ? s.value : null; })()`);
  check(detailDefault === 'full', '設定頁有「自動化狀態顯示」且預設詳細', detailDefault);
  const retryStored = await evaluate(appClient, `(() => { const s = document.getElementById('webAutoRetrySelect'); s.value = '5'; s.dispatchEvent(new Event('change')); return localStorage.getItem('claude_novel_web_auto_retry_v1'); })()`);
  check(retryStored === '5', '重試次數的選擇會立即記住', retryStored);
  await evaluate(appClient, `(() => { const s = document.getElementById('webAutoRetrySelect'); s.value = '3'; s.dispatchEvent(new Event('change')); })()`);

  // A7. 追加十 A/C：送出鈕找不到時改走 Enter（失敗階梯）＋狀態條顯示「已自動送出；等待官網回覆」
  await evaluate(companion, `(() => { document.getElementById('send').style.display = 'none'; return true; })()`);
  const healthNoSend = await evaluate(appClient, `window.claudeDesktop.webAutoHealth({provider:'openai',mode:'embedded'})`, true);
  check(healthNoSend && healthNoSend.report && healthNoSend.report.sendButton === false, '自檢：送出鈕被藏起來時如實回報（屆時改走 Enter）');
  await clickNextTurn(appClient);
  await waitFor(companion, 'window.__auto.sends >= 2', '送出鈕隱藏時以 Enter 送出', 30, 700);
  const enterSend = (await evaluate(companion, 'window.__auto')) || {};
  check(enterSend.sends === 2, '送出鈕找不到時改按 Enter 仍成功送出（且只送一次）', enterSend.sends);
  let statusText = '';
  for (let i = 0; i < 20; i += 1) {
    statusText = await evaluate(appClient, `(() => { const el = document.getElementById('webAutoStatusNote'); return el ? el.textContent : ''; })()`);
    if (statusText && statusText.includes('等待官網回覆')) break;
    await sleep(500);
  }
  check(statusText.includes('等待官網回覆'), '待辦面板狀態條顯示「已自動送出；等待官網回覆」（追加十 C）', statusText.slice(0, 60));
  await waitFor(companion, 'window.__auto.generating === false', 'Enter 回合生成結束', 60, 1000);
  await sleep(6000);
  const storyEnter = await evaluate(appClient, appStory);
  check(storyEnter.pendingTurn === false, 'Enter 後備送出的回合也自動接回（沒有卡住）');
  check(storyEnter.turns - storyDone.turns >= 2 && storyEnter.turns - storyDone.turns <= 5, '接回後故事往前推進一回合（玩家行動＋正文；隨機禮物對話可能再 +0～3 筆）', { before: storyDone.turns, after: storyEnter.turns });

  console.log('== B. 外部模式（自動化專用瀏覽器＋CDP） ==');
  // 切到外部模式（設定頁下拉）並開始下一回合
  await evaluate(appClient, `(() => { const s = document.getElementById('webBrowserModeSelect'); s.value = 'external'; s.dispatchEvent(new Event('change')); })()`);
  await sleep(500);
  check((await evaluate(appClient, `localStorage.getItem('claude_novel_web_browser_mode_v1')`)) === 'external', '已切換到外部瀏覽器模式並記住設定');

  const beforeExternal = await evaluate(appClient, appStory);
  await clickNextTurn(appClient);
  const extTab = await waitForTarget(automationEndpoint, t => t.type === 'page' && String(t.url).includes('chatgpt.com'), '自動化瀏覽器的官網分頁', 120);
  check(true, 'App 自動啟動了自動化專用瀏覽器並開啟官網分頁（除錯埠 ' + automationPort + '）', String(extTab.url).slice(0, 48));
  await sleep(4000);
  const extInjectTarget = await waitForTarget(automationEndpoint, t => t.type === 'page' && String(t.url).includes('chatgpt.com'), '自動化瀏覽器官網分頁（第二次）', 3);
  const extClient = await connect(extInjectTarget);
  cleanupClients.push(extClient);
  await extClient.send('Page.enable');
  await extClient.send('Runtime.enable');
  const extInjected = await injectFakePage(extClient, '自動化瀏覽器分頁', { steerUrl: 'https://chatgpt.com/robots.txt' });
  check(extInjected, '自動化瀏覽器分頁已換成測試頁');
  if (!extInjected) throw new Error('假官網頁面注入失敗（自動化瀏覽器分頁）。');

  // 取這回合的提示詞（App 存檔裡的提示詞歷史），呼叫 App 的自動化 API 重新填入＋送出
  const promptHist = await evaluate(appClient, `(() => {
    const id = localStorage.getItem('claude_novel_active_slot_v1');
    let slot = null;
    try { slot = JSON.parse(localStorage.getItem('claude_novel_slot_v2_' + id) || 'null'); } catch {}
    const list = (slot && slot.state && slot.state.promptHistory) || [];
    return list.length ? list[list.length - 1].prompt : '';
  })()`);
  check(typeof promptHist === 'string' && promptHist.length > 200, '取得本回合提示詞（證明 App 已產生提示詞）', promptHist.length);
  const activation = await evaluate(appClient, `window.claudeDesktop.setWebAutoFlow({enabled:true,submit:true,prompt:${JSON.stringify(promptHist)},provider:'openai',mode:'external'})`, true);
  check(activation && activation.ok === true, '外部模式自動化啟動成功', activation && JSON.stringify(activation).slice(0, 160));
  check(activation && activation.filled && activation.filled.ok === true, '外部模式確實把提示詞填入官網分頁', activation && activation.filled);
  check(activation && activation.submitted === true, '外部模式確實按下送出', activation && activation.submitted);

  await waitFor(extClient, 'window.__auto.sends >= 1', '外部模式自動送出', 30, 700);
  let extPremature = false;
  let extSawGenerating = false;
  for (let i = 0; i < 8; i += 1) {
    const flag = await evaluate(extClient, 'window.__auto.generating');
    if (flag) {
      extSawGenerating = true;
      const mid = await evaluate(appClient, appStory);
      if (mid.turns !== beforeExternal.turns || mid.pendingTurn !== true) extPremature = true;
    }
    await sleep(400);
  }
  check(extSawGenerating, '外部模式測試頁進入「生成中」狀態');
  check(!extPremature, '外部模式生成中也沒有提早接回');

  await waitFor(extClient, 'window.__auto.generating === false', '外部模式生成結束', 60, 1000);
  await sleep(6000);
  const storyExternal = await evaluate(appClient, appStory);
  check(storyExternal.turns - beforeExternal.turns >= 2 && storyExternal.turns - beforeExternal.turns <= 5, '外部模式回覆完成後自動接回故事（隨機禮物對話可能再 +0～3 筆）', { before: beforeExternal.turns, after: storyExternal.turns });
  check(storyExternal.pendingTurn === false, '外部模式接回後待辦回合面板消失');
  check(storyExternal.choices === 7, '外部模式的新選項已套用到畫面');

  // C. 追加十 D：輸入框消失時，自檢要如實回報（哪一步卡住；改手動也不擋流程）
  await evaluate(companion, `(() => { const e = document.getElementById('editor'); if (e) e.remove(); return true; })()`);
  const healthGone = await evaluate(appClient, `window.claudeDesktop.webAutoHealth({provider:'openai',mode:'embedded'})`, true);
  check(healthGone && healthGone.ok === true && healthGone.report && healthGone.report.editor === false, '自檢：輸入框消失時如實回報（不會假裝可以全自動）', healthGone && healthGone.report);

  // D. 追加十一：接 API 提示指引＋測試連線（金鑰由主程序代打、白話排解）
  const openForm = await evaluate(appClient, `(() => { document.getElementById('addAiAccountBtn').click(); return document.getElementById('aiConnectionForm').hidden === false; })()`);
  check(openForm === true, '「新增 AI 帳號」會開啟連線表單');
  const guideFirst = await evaluate(appClient, `(() => { const box = document.getElementById('aiConnectGuide'); return box ? box.textContent : ''; })()`);
  check(typeof guideFirst === 'string' && guideFirst.includes('可以先完全不設 API、直接玩'), '接 API 指引第一句：「可以先完全不設 API、直接玩」', (guideFirst || '').slice(0, 40));
  const guideGemini = await evaluate(appClient, `(() => { const s = document.getElementById('aiProviderSelect'); s.value = 'gemini'; s.dispatchEvent(new Event('change')); const box = document.getElementById('aiConnectGuide'); return box ? box.textContent : ''; })()`);
  check(guideGemini.includes('AI Studio') && guideGemini.includes('免費'), '選 Gemini 時指引顯示該家提示（AI Studio／免費層）');
  const guideOpenai = await evaluate(appClient, `(() => { const s = document.getElementById('aiProviderSelect'); s.value = 'openai'; s.dispatchEvent(new Event('change')); const box = document.getElementById('aiConnectGuide'); return box ? box.textContent : ''; })()`);
  check(guideOpenai.includes('Billing'), '換成 OpenAI 時指引立即更新（Billing 額度提醒）');
  await evaluate(appClient, `(() => { document.getElementById('aiAccountName').value = 'E2E 測試帳號'; document.getElementById('aiProfileId').value = 'TEST'; document.getElementById('aiApiKey').value = 'sk-dummy-e2e-check-0000'; document.getElementById('saveAiAccountBtn').click(); return true; })()`);
  await sleep(1500);
  const rowCount = await evaluate(appClient, `document.querySelectorAll('[data-ai-test]').length`);
  check(rowCount >= 1, '儲存帳號後出現「測試連線」按鈕', rowCount);
  await evaluate(appClient, `(() => { const b = document.querySelector('[data-ai-test]'); b.click(); return true; })()`);
  let testStatus = '';
  for (let i = 0; i < 30; i += 1) {
    await sleep(1000);
    testStatus = await evaluate(appClient, `document.getElementById('aiAccountStatus').textContent || ''`);
    if (!testStatus.includes('正在測試連線')) break;
  }
  check(testStatus.includes('連線失敗') || testStatus.includes('連線正常'), '測試連線按鈕會回報白話結果（假金鑰預期失敗）', testStatus.slice(0, 60));
  const ipcResult = await evaluate(appClient, `window.claudeDesktop.testAiConnection({provider:'openai',profileId:'TEST'}).then(r => JSON.stringify(r))`, true);
  const allowedClasses = ['"invalid-key"', '"quota"', '"network"', '"request"', '"service"'];
  check(typeof ipcResult === 'string' && ipcResult.includes('"class"') && allowedClasses.some(c => ipcResult.includes(c)) && !ipcResult.includes('sk-dummy'), '測試連線回覆只有分類（class），不含金鑰本體', ipcResult);

  // 收尾：關閉 App、自動化瀏覽器與所有測試連線（只關測試用的行程）。
  await shutdown();

  console.log('');
  if (problems.length) {
    console.log('結果：' + problems.length + ' 項失敗');
    for (const p of problems) console.log(' - ' + p);
    process.exitCode = 1;
  } else {
    console.log('結果：全部通過');
  }
}

main().catch(async error => {
  console.error('[FAIL] 測試腳本中止：' + (error && error.message));
  process.exitCode = 1;
  await shutdown();
});
