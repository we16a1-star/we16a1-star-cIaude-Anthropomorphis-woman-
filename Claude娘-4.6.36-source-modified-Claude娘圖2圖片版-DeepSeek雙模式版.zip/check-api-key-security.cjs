// check-api-key-security.cjs（唯讀稽核）：API Key 安全性檢查＋本機服務行為抽查。
// 只讀檔案、不改任何資料；會暫時啟動一次本機 API 服務（127.0.0.1、隨機埠、用完即關）做行為驗證。
// 用法：node check-api-key-security.cjs "<app 資料夾>"
//   沒給參數時自動依位置找：原始碼最上層（.\app）、cioudo-work\cIoudo10娘\app、
//   或審查包旁的 ..\cIoudo10娘-6\app。
// 檢查面向：語法／金庫加密與原子寫入／IPC 來源驗證／金鑰不進存檔／本機 API 的 token 與 CORS 白名單／
//           官網視窗隔離與導航限制／交付衛生（無 .env 秘密檔、執行檔無金鑰樣式字串）。
// r10（2026-10-19）：審查包旁路徑系列號 -5→-6（現行交付系列）。
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const {spawnSync} = require('node:child_process');
const {pathToFileURL} = require('node:url');

const candidates = [
  process.argv[2],
  path.join(__dirname, 'cIoudo10娘', 'app'),
  path.join(__dirname, 'app'),
  path.join(__dirname, '..', 'cIoudo10娘-6', 'app'),
  path.join(__dirname, '..', '..', 'cIoudo10娘-6', 'app')
].filter(Boolean).map(p => path.resolve(p));
const appDir = candidates.find(p => fs.existsSync(path.join(p, 'electron-main.cjs')));
if (!appDir) {
  console.error('用法：node check-api-key-security.cjs "<app 資料夾>"（找不到 app 目錄）');
  process.exit(2);
}

let failures = 0;
const ok = (label, extra) => console.log(`[OK]   ${label}${extra ? ` → ${extra}` : ''}`);
const fail = (label, extra) => { failures += 1; console.log(`[FAIL] ${label}${extra ? ` → ${extra}` : ''}`); };
const expect = (cond, label, extra) => (cond ? ok(label) : fail(label, extra));
const read = p => fs.readFileSync(path.join(appDir, p), 'utf8');
console.log(`[資訊] 稽核目錄：${appDir}`);

// 1) 語法
for (const f of ['electron-main.cjs', 'electron-preload.cjs', 'server/server.js', 'www/app.js']) {
  const r = spawnSync(process.execPath, ['--check', path.join(appDir, f)], {encoding: 'utf8'});
  expect(r.status === 0, `語法檢查通過：${f}`, String(r.stderr || '').split('\n')[0]);
}

const main = read('electron-main.cjs');
const preload = read('electron-preload.cjs');
const server = read('server/server.js');
const app = read('www/app.js');

// 2) 金庫（Windows 加密服務）
expect(/safeStorage\.isAsyncEncryptionAvailable\(\)/.test(main) && main.includes('encryptStringAsync') && main.includes('decryptStringAsync'),
  '金庫使用 Electron safeStorage（Windows 使用者加密服務）；讀寫前先確認加密服務可用');
expect(!/writeFileSync\([^)]*JSON\.stringify\(/.test(main),
  '沒有任何「明文寫入金庫」的路徑（加密服務不可用時直接報錯，不落明文）');
expect(/fs\.writeFileSync\(temporary, encrypted\);[\s\S]{0,120}?fs\.renameSync\(temporary, target\);/.test(main),
  '金庫寫入＝暫存檔＋改名（原子操作）；寫入中斷不會毀掉既有金庫');
expect(main.includes("typeof raw === 'string' ? raw : String(raw?.result ?? '')"),
  '金庫讀取相容兩種回傳形狀（字串／{result}）；避免金鑰永遠讀成空、舊帳號被覆蓋');
expect(/if \(!apiKey \|\| apiKey\.length > 4096\)/.test(main),
  '金鑰驗證：拒絕空值、長度上限 4096');
expect(/VALID_PROFILE\.test\(suffix\)/.test(main),
  '環境變數名安全：供應商與帳號代號都經白名單／格式驗證');
expect(main.includes('Object.values(vault).map(({provider, profileId, label}) => ({provider, profileId, label}))'),
  '帳號列表只回傳 provider／profileId／label，永不回傳金鑰本體');

// 3) IPC 來源驗證
const channels = [...main.matchAll(/ipcMain\.handle\(\s*'([^']+)'/g)];
const unguarded = channels.filter((m, i) => {
  const end = i + 1 < channels.length ? channels[i + 1].index : m.index + 800;
  return !main.slice(m.index, end).includes('assertTrustedRenderer(event)');
}).map(m => m[1]);
expect(unguarded.length === 0,
  `全部 ${channels.length} 個 IPC 通道都先驗證畫面來源（assertTrustedRenderer）才動作`,
  unguarded.length ? '未驗證：' + unguarded.join('、') : '');

// 4) 橋接層最小權限
expect(preload.includes("contextBridge.exposeInMainWorld('claudeDesktop'") && !preload.includes('ipcRenderer.invoke(channel') && !/exposeInMainWorld\('claudeDesktop',\s*ipcRenderer\b/.test(preload),
  '橋接層只暴露具名方法；不暴露 ipcRenderer 本體、沒有萬用 invoke(channel)');

// 5) 官網視窗隔離與導航限制
expect(/partition:'persist:official-ai-web',contextIsolation:true,nodeIntegration:false,sandbox:true/.test(main),
  '官網視窗（內建模式與彈出視窗）：context 隔離＋關 Node 整合＋sandbox');
expect(/preload: path\.join\(__dirname, 'electron-preload\.cjs'\)[\s\S]{0,160}contextIsolation: true[\s\S]{0,60}nodeIntegration: false[\s\S]{0,60}sandbox: true/.test(main),
  '主視窗同樣：context 隔離＋關 Node 整合＋sandbox＋僅自家 preload');
expect(main.includes("parsed.protocol !== 'https:'") && main.includes('isAllowedAiWebsiteUrl(url)'),
  '官網導航限制：只允許 https＋官方網域白名單；其餘 https 交給系統瀏覽器、其他協定直接拒絕');

// 6) renderer 端：金鑰不進存檔
expect(/const FORBIDDEN_CREDENTIAL_FIELDS = new Set\(/.test(app) && app.includes("'apiKey'") && /FORBIDDEN_CREDENTIAL_FIELDS\.has\(k\)/.test(app),
  '存檔／localStorage 持久化排除憑證欄位（apiKey／secret／accessToken 等）');
expect(/saveCredential\(\{provider,profileId,label,apiKey\}\)/.test(app) && app.includes("$('aiApiKey').value=''"),
  '金鑰只經 saveCredential 進主程序；儲存後立即清空畫面上的金鑰輸入框');

// 6b) 追加十一：測試連線（金鑰只在主程序代打、回傳只有分類代碼）
const connectPath = path.join(appDir, 'ai-connect-check.cjs');
const connectExists = fs.existsSync(connectPath);
expect(connectExists && main.includes("require('./ai-connect-check.cjs')"), '測試連線模組存在且由主程序載入');
const connectBlock = (main.match(/ipcMain\.handle\('ai-vault:test',[\s\S]{0,700}?\n  \}\);/) || [''])[0];
expect(connectBlock.includes('assertTrustedRenderer(event)'), '測試連線 IPC 先驗證畫面來源才動作');
expect(connectBlock.includes('return await aiConnect.testAiConnection(provider, item.apiKey);'), '金鑰只在主程序內代打；回傳僅分類（永不含金鑰）');
expect(preload.includes("testAiConnection: payload => ipcRenderer.invoke('ai-vault:test'"), '橋接層以具名方法曝露測試連線（沒有萬用 invoke）');
expect(app.includes('可以先完全不設 API、直接玩'), '介面引導第一句：「可以先完全不設 API、直接玩」');

// 7) 本機 API 伺服器
expect(/app\.use\('\/api',\(req,res,next\)=>\{if\(desktopToken&&req\.get\('X-Desktop-Token'\)!==desktopToken\)/.test(server),
  '伺服器端：所有 /api 請求都必須帶正確的桌面 token');
expect(server.includes('LOCAL_CORS_ORIGIN') && !server.includes('app.use(cors());'),
  'CORS 白名單：只放行本機畫面與本機開發來源（不再使用全開的 cors() 預設）');
expect(/startApiServer\(\{host: '127\.0\.0\.1', port: 0, token: localApiToken\}\)/.test(main) && /crypto\.randomBytes\(32\)\.toString\('hex'\)/.test(main),
  '本機 API 只綁 127.0.0.1、隨機埠、每次啟動隨機 32 bytes token');

// 8) 交付衛生：執行檔無金鑰樣式字串、無 .env、金庫檔不在原始碼內
const scanFiles = [...new Set([
  ...fs.readdirSync(appDir).filter(n => n.endsWith('.cjs')),
  ...fs.readdirSync(path.join(appDir, 'www')).filter(n => n.endsWith('.js')).map(n => `www/${n}`),
  ...(fs.existsSync(path.join(appDir, 'server')) ? fs.readdirSync(path.join(appDir, 'server')).filter(n => n.endsWith('.js')).map(n => `server/${n}`) : [])
])];
const patterns = [/sk-ant-[A-Za-z0-9_\-]{20,}/, /sk-[A-Za-z0-9_\-]{20,}/, /AIza[0-9A-Za-z_\-]{30,}/, /gsk_[A-Za-z0-9]{20,}/, /xai-[A-Za-z0-9]{20,}/];
const hits = [];
for (const f of scanFiles) {
  if (!fs.existsSync(path.join(appDir, f))) continue;
  const text = read(f);
  for (const p of patterns) {
    const m = text.match(p);
    if (m) { hits.push(`${f}：${m[0].slice(0, 14)}…`); break; }
  }
}
expect(hits.length === 0, `執行檔無金鑰樣式字串（掃描 ${scanFiles.length} 檔：sk-／sk-ant-／AIza／gsk_／xai-）`, hits.join('；'));
expect(!['.env', 'server/.env'].some(f => fs.existsSync(path.join(appDir, f))), '交付不含 .env 秘密檔（僅保留 .env.example 範本）');
expect(!fs.existsSync(path.join(appDir, 'ai-credentials.bin')), '金庫檔不在原始碼內（在使用者 %APPDATA% 目錄，受 Windows 加密服務保護）');

// 9) 行為抽查：暫時啟動本機 API（127.0.0.1、隨機埠），驗證 token 強制與 CORS 白名單
(async () => {
  let mod = null;
  try {
    mod = await import(pathToFileURL(path.join(appDir, 'server', 'server.js')).href);
  } catch (e) {
    console.log(`[SKIP] 本機服務行為抽查（需先在 app 目錄 npm install，才有 express／SDK 依賴）：${String((e && e.message) || e).split('\n')[0]}`);
  }
  if (mod) {
    const token = `audit-${Date.now()}`;
    const api = await mod.startApiServer({port: 0, host: '127.0.0.1', token});
    const base = `http://127.0.0.1:${api.address().port}`;
    try {
      const evil = await fetch(`${base}/api/health`, {headers: {origin: 'https://evil.example'}});
      expect(evil.headers.get('access-control-allow-origin') === null, '行為抽查：外部網頁來源拿不到 CORS 放行標頭');
      const file = await fetch(`${base}/api/health`, {headers: {origin: 'null'}});
      expect(file.headers.get('access-control-allow-origin') === 'null', '行為抽查：本 App 畫面（Origin: null）可正常讀取回應');
      const missing = await fetch(`${base}/api/health`);
      const wrong = await fetch(`${base}/api/health`, {headers: {'X-Desktop-Token': 'wrong'}});
      const good = await fetch(`${base}/api/health`, {headers: {'X-Desktop-Token': token}});
      expect(missing.status === 401 && wrong.status === 401 && good.status === 200, '行為抽查：缺漏／錯誤 token 一律 401，正確 token 200');
    } finally {
      await new Promise(resolve => api.close(resolve));
    }
  }
  // 行為抽查（追加十一）：測試連線分類；不連外網（假 fetch）
  if (connectExists) {
    try {
      const connect = require(connectPath);
      const badKey = await connect.testAiConnection('openai', 'audit-bad-key-123', {fetchImpl: async () => ({status: 401})});
      const netErr = await connect.testAiConnection('openai', 'audit-bad-key-123', {fetchImpl: async () => { throw new Error('boom'); }});
      const quota = connect.classifyConnectStatus(429).class === 'quota' && connect.classifyConnectStatus(200).class === 'ok';
      const httpsOnly = Object.values(connect.CONNECT_ENDPOINTS).every(spec => /^https:\/\//.test(spec.url));
      expect(badKey.class === 'invalid-key' && netErr.class === 'network' && quota && httpsOnly && connect.CONNECT_TIMEOUT_MS === 10000 && !JSON.stringify(badKey).includes('audit-bad-key'),
        '行為抽查：401→金鑰無效、網路錯誤→network、429→額度；端點全 https、逾時 10 秒、回傳不含金鑰');
    } catch (e) {
      fail('行為抽查：測試連線模組載入或執行失敗', String((e && e.message) || e));
    }
  }
  console.log(failures ? `[總結] ${failures} 項未通過` : '[總結] API Key 安全性檢查全部通過');
  process.exit(failures ? 1 : 0);
})().catch(e => {
  console.error(`[FAIL] 行為抽查發生未預期錯誤：${(e && e.stack) || e}`);
  process.exit(1);
});
