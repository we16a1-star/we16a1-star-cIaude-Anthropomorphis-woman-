// r10（2026-10-19）：品牌字串統一「Claude娘」；同 12娘 同步版。
// 三家深測（Meta AI／Perplexity／Grok，可加測其他）：登出狀態下把「看不到輸入框」的原因查清楚。
// 檢查項目：等更久、列出所有 contenteditable/textarea/input（含不可見）、iframe、shadow DOM（兩層）、
//           常見登入/同意按鈕、以及最後的 body 文字開頭，方便人工判讀。
// 用法：node probe-deep-sites.cjs ["已安裝 exe 路徑"] ["app 資料夾路徑"]
const { spawn, spawnSync } = require('node:child_process');
const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');

const arg = index => String(process.argv[index] || '').trim();
const appExe = arg(2) || path.join(process.env.LOCALAPPDATA || '', 'Programs', 'claude-novel-windows11', 'Claude娘 - Windows 11 電腦版.exe');
const userDataDir = path.join(os.tmpdir(), 'opencode', 'cioudo-webauto-real', 'userdata');
const port = 9460;
const automationPort = 4462;
const endpoint = `http://127.0.0.1:${port}`;
const automationEndpoint = `http://127.0.0.1:${automationPort}`;
const SITES = [
  ['Grok', 'https://grok.com/'],
  ['Meta AI', 'https://www.meta.ai/'],
  ['Perplexity', 'https://www.perplexity.ai/'],
  ['Copilot（舊網址）', 'https://copilot.microsoft.com/']
];

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const get = url => new Promise((resolve, reject) => {
  http.get(url, res => { let data = ''; res.on('data', c => data += c); res.on('end', () => { try { resolve(JSON.parse(data)); } catch (e) { reject(e); } }); }).on('error', reject);
});
async function findTargets(base) { try { return await get(base + '/json/list'); } catch { return []; } }
async function waitForTarget(base, predicate, label, attempts = 120) {
  for (let i = 0; i < attempts; i += 1) {
    const hit = (await findTargets(base)).find(predicate);
    if (hit && hit.webSocketDebuggerUrl) return hit;
    await sleep(1000);
  }
  throw new Error('等不到目標：' + label);
}
function connect(target, timeoutMs = 15000) {
  return new Promise((resolve, reject) => {
    const socket = new WebSocket(target.webSocketDebuggerUrl);
    let nextId = 1; const waiting = new Map();
    const openTimer = setTimeout(() => reject(new Error('連線逾時')), timeoutMs);
    socket.onmessage = event => {
      const message = JSON.parse(typeof event.data === 'string' ? event.data : String(event.data));
      if (message.method === 'Page.javascriptDialogOpening') { socket.send(JSON.stringify({ id: nextId++, method: 'Page.handleJavaScriptDialog', params: { accept: true } })); return; }
      const pending = waiting.get(message.id); if (!pending) return; waiting.delete(message.id); pending(message);
    };
    socket.onerror = error => { clearTimeout(openTimer); reject(new Error('WebSocket 錯誤：' + error.message)); };
    socket.onopen = () => {
      clearTimeout(openTimer);
      resolve({
        send(method, params = {}) {
          const id = nextId++; socket.send(JSON.stringify({ id, method, params }));
          return new Promise((resolveCall, rejectCall) => {
            waiting.set(id, message => message.error ? rejectCall(new Error(method + '：' + JSON.stringify(message.error))) : resolveCall(message.result));
            setTimeout(() => { waiting.delete(id); rejectCall(new Error(method + ' 逾時')); }, 30000);
          });
        },
        close() { socket.close(); }
      });
    };
  });
}
async function evaluate(client, expression) {
  const result = await client.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  if (result.exceptionDetails) throw new Error('頁面例外：' + JSON.stringify(result.exceptionDetails.exception?.description || result.exceptionDetails.text).slice(0, 300));
  return result.result.value;
}
const info = (label, detail) => console.log('[資訊] ' + label + (detail === undefined ? '' : ' → ' + JSON.stringify(detail).slice(0, 500)));

const deepProbe = `(() => {
  const all = sel => [...document.querySelectorAll(sel)];
  const editors = all('textarea,[contenteditable="true"],[role="textbox"]');
  const describe = e => ({ tag: e.tagName.toLowerCase(), cls: String(e.className || '').slice(0, 50), aria: String(e.getAttribute('aria-label') || '').slice(0, 30), rect: (r => r.width + 'x' + r.height)(e.getBoundingClientRect()), visible: !!e.getClientRects().length });
  const shadowHosts = all('*').filter(e => e.shadowRoot).slice(0, 6);
  const shadowEditors = [];
  for (const host of all('*')) {
    if (!host.shadowRoot) continue;
    for (const e of host.shadowRoot.querySelectorAll('textarea,[contenteditable="true"],[role="textbox"]')) {
      shadowEditors.push({ host: host.tagName.toLowerCase() + '.' + String(host.className || '').slice(0, 40), ...describe(e) });
      if (shadowEditors.length > 5) break;
    }
    if (shadowEditors.length > 5) break;
  }
  const iframes = all('iframe').slice(0, 6).map(f => String(f.src || '(no src)').slice(0, 90));
  const buttons = all('button,[role="button"]').slice(0, 400).map(e => String(e.getAttribute('aria-label') || e.getAttribute('title') || e.innerText || '').replace(/\\s+/g, ' ').trim().slice(0, 26)).filter(Boolean);
  const interesting = buttons.filter(l => /(sign|log|accept|consent|agree|同意|接受|登入|登録|登录|繼續|continue|start|message|ask|send)/i.test(l)).slice(0, 12);
  return {
    url: location.href, title: document.title.slice(0, 50),
    editorsTotal: editors.length,
    editors: editors.slice(0, 6).map(describe),
    shadowHosts: shadowHosts.map(h => h.tagName.toLowerCase() + '.' + String(h.className || '').slice(0, 40)),
    shadowEditors,
    iframes,
    interestingButtons: interesting,
    bodyHead: String(document.body ? document.body.innerText : '').replace(/\\s+/g, ' ').slice(0, 160)
  };
})()`;

let appProcess = null;
const clients = [];
async function shutdown() {
  for (const client of clients.splice(0)) { try { client.close(); } catch {} }
  if (!appProcess) return;
  const pid = appProcess.pid; appProcess = null;
  try { spawnSync('taskkill', ['/F', '/T', '/PID', String(pid)], { stdio: 'ignore' }); } catch {}
  spawnSync('powershell', ['-NoProfile', '-Command',
    "Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('chrome.exe','msedge.exe') -and $_.CommandLine -and ($_.CommandLine -like '*web-automation-browser*' -or $_.CommandLine -like '*cioudo-webauto-real*') } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"
  ], { stdio: 'ignore' });
  await sleep(800);
}

async function main() {
  console.log('== 深測：Grok／Meta AI／Perplexity／Copilot（登出、隔離設定檔） ==');
  fs.rmSync(userDataDir, { recursive: true, force: true });
  appProcess = spawn(appExe, [`--user-data-dir=${userDataDir}`, `--remote-debugging-port=${port}`], { stdio: 'ignore' });
  const appTarget = await waitForTarget(endpoint, t => t.type === 'page' && String(t.url).startsWith('file:'), 'App 主視窗');
  const appClient = await connect(appTarget);
  clients.push(appClient);
  await appClient.send('Page.enable');
  await appClient.send('Runtime.enable');
  // 驅動 App：開啟網頁模式 → 外部瀏覽器 → 開始遊戲（觸發自動化瀏覽器開啟官網分頁）。
  await evaluate(appClient, `document.getElementById('enableWebAiBtn').click()`);
  await sleep(800);
  await evaluate(appClient, `(() => { const s = document.getElementById('webAiProvider'); s.value = 'openai'; s.dispatchEvent(new Event('change')); })()`);
  await evaluate(appClient, `(() => { const s = document.getElementById('webBrowserModeSelect'); s.value = 'external'; s.dispatchEvent(new Event('change')); })()`);
  await sleep(500);
  await evaluate(appClient, `document.getElementById('startStoryBtn').click()`);
  const extClient = await connect(await waitForTarget(automationEndpoint, t => t.type === 'page' && String(t.url).includes('chatgpt.com'), '自動化瀏覽器分頁', 150));
  clients.push(extClient);
  await extClient.send('Page.enable');
  await extClient.send('Runtime.enable');

  for (const [name, url] of SITES) {
    console.log('');
    console.log('──────── ' + name + '（' + url + '）────────');
    try {
      await extClient.send('Page.navigate', { url });
      await sleep(4000);
      for (let i = 0; i < 8; i += 1) {
        const state = await evaluate(extClient, '(()=>({ready:document.readyState}))()');
        if (/complete/.test(String(state.ready))) break;
        await sleep(1500);
      }
      await sleep(8000);
      info(name + ' 深測結果', await evaluate(extClient, deepProbe));
    } catch (error) { console.log('[注意] ' + name + ' 深測失敗：' + error.message); }
  }
  console.log('');
  console.log('（收尾）');
  await shutdown();
  console.log('深測完成');
}
main().catch(async error => { console.error('[中止] ' + (error && error.message)); process.exitCode = 1; await shutdown(); });
