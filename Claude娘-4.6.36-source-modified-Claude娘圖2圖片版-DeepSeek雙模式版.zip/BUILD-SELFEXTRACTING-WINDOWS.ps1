# r10（2026-10-19，協調線）：品牌字樣統一「Claude娘」。
param(
  [string]$Version = '4.3.12',
  [string]$OutputDirectory = (Join-Path $PSScriptRoot 'release')
)

$ErrorActionPreference='Stop'
if($Version -notmatch '^\d+\.\d+\.\d+$'){throw 'Version must use the form major.minor.patch, such as 4.3.12.'}
$OutputDirectory=[IO.Path]::GetFullPath($OutputDirectory)
New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
$installerPath=Join-Path $OutputDirectory "Claude娘-Windows11-auto-install-v$Version.exe"
if(Test-Path -LiteralPath $installerPath){throw "Output already exists; increment -Version to preserve it: $installerPath"}
$builder=Join-Path $PSScriptRoot 'BUILD-ONLINE-INSTALLER.ps1'
if(-not (Test-Path -LiteralPath $builder)){throw "Missing online installer builder: $builder"}

$buildRoot=Join-Path ([IO.Path]::GetTempPath()) ('ClaudeNovelOnlineBuild_'+[guid]::NewGuid().ToString('N'))
$snapshot=Join-Path $buildRoot 'source'
$payload=Join-Path $buildRoot 'payload.zip'
$skip=@('.git','node_modules','dist','outputs','work','release','_build-tools','.gradle','.idea','build')
function Copy-InstallerSource([string]$From,[string]$To){
  New-Item -ItemType Directory -Path $To -Force | Out-Null
  foreach($item in Get-ChildItem -LiteralPath $From -Force){
    if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){continue}
    if($item.PSIsContainer){if($item.Name -in $skip){continue};Copy-InstallerSource $item.FullName (Join-Path $To $item.Name);continue}
    if(($item.Name -like '.env*') -and $item.Name -ne '.env.example'){continue}
    if($item.Extension -in @('.exe','.blockmap','.asar','.pfx','.p12','.key','.pem','.zip')){continue}
    Copy-Item -LiteralPath $item.FullName -Destination (Join-Path $To $item.Name)
  }
}
try{
  New-Item -ItemType Directory -Path $buildRoot | Out-Null
  Copy-InstallerSource $PSScriptRoot $snapshot
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  [IO.Compression.ZipFile]::CreateFromDirectory($snapshot,$payload,[IO.Compression.CompressionLevel]::Optimal,$false)
  & $builder -SourceZipPath $payload -OutputPath $installerPath
  if($LASTEXITCODE -and $LASTEXITCODE -ne 0){throw "Online installer builder failed with exit code $LASTEXITCODE"}
  $installer=Get-Item -LiteralPath $installerPath
  Write-Output "Created small online installer: $($installer.FullName)"
  Write-Output "Size: $($installer.Length) bytes"
}
catch{
  if(Test-Path -LiteralPath $installerPath){Remove-Item -LiteralPath $installerPath -Force}
  throw
}
finally{
  if(Test-Path -LiteralPath $buildRoot){Remove-Item -LiteralPath $buildRoot -Recurse -Force}
}
