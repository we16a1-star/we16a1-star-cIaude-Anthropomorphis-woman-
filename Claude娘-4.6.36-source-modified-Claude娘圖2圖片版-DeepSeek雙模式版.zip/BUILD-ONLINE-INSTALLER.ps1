# r10（2026-10-19，協調線）：品牌字樣統一「Claude娘」。
param(
  [Parameter(Mandatory=$true)][string]$SourceZipPath,
  [Parameter(Mandatory=$true)][string]$OutputPath
)

$ErrorActionPreference='Stop'
$SourceZipPath=[IO.Path]::GetFullPath($SourceZipPath)
$OutputPath=[IO.Path]::GetFullPath($OutputPath)
if(-not (Test-Path -LiteralPath $SourceZipPath -PathType Leaf)){throw "Source ZIP not found: $SourceZipPath"}
if(Test-Path -LiteralPath $OutputPath){throw "Refusing to overwrite existing installer: $OutputPath"}
$compiler=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if(-not (Test-Path -LiteralPath $compiler)){$compiler=Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe'}
if(-not (Test-Path -LiteralPath $compiler)){throw 'Windows .NET Framework C# compiler was not found.'}
$outDir=Split-Path -Parent $OutputPath
New-Item -ItemType Directory -Path $outDir -Force | Out-Null
$temp=Join-Path ([IO.Path]::GetTempPath()) ('Claude娘OnlineSetup_'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $temp | Out-Null
$sourcePath=Join-Path $temp 'OnlineInstaller.cs'
$iconPath=Join-Path $PSScriptRoot 'app\assets\icon.ico'
$source=@'
using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Reflection;

internal static class OnlineInstaller
{
    private static void ExtractPayload(string destination)
    {
        string payload = Path.Combine(destination, "source.zip");
        using (Stream input = Assembly.GetExecutingAssembly().GetManifestResourceStream("payload.zip"))
        {
            if (input == null) throw new InvalidOperationException("安裝來源遺失。請重新下載安裝檔。");
            using (FileStream output = File.Create(payload)) input.CopyTo(output);
        }
        ZipFile.ExtractToDirectory(payload, destination);
        File.Delete(payload);
    }

    private static int Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        if (args.Length == 2 && args[0] == "--extract-only")
        {
            try
            {
                string destination = Path.GetFullPath(args[1]);
                Directory.CreateDirectory(destination);
                ExtractPayload(destination);
                Console.WriteLine("Source extracted: " + destination);
                return 0;
            }
            catch (Exception error)
            {
                Console.Error.WriteLine(error.Message);
                return 1;
            }
        }
        string root = Path.Combine(Path.GetTempPath(), "Claude娘_OnlineSetup_" + Guid.NewGuid().ToString("N"));
        int result = 1;
        bool keep = false;
        try
        {
            Directory.CreateDirectory(root);
            Console.WriteLine("Claude娘 Windows 11 小型自動安裝程式");
            Console.WriteLine("正在解壓安裝來源；首次安裝會連網下載 Node.js、Electron 和建置套件。\n");
            ExtractPayload(root);
            string batch = Path.Combine(root, "app", "BUILD-WINDOWS11-AUTO.bat");
            if (!File.Exists(batch)) throw new FileNotFoundException("來源 ZIP 不完整，找不到安裝流程。", batch);
            var info = new ProcessStartInfo("cmd.exe", "/d /c \"\"" + batch + "\"\"");
            info.WorkingDirectory = Path.GetDirectoryName(batch);
            info.UseShellExecute = false;
            info.CreateNoWindow = false;
            info.EnvironmentVariables["AUTO_INSTALL_SFX"] = "1";
            using (Process process = Process.Start(info))
            {
                process.WaitForExit();
                result = process.ExitCode;
            }
            if (result != 0)
            {
                keep = true;
                Console.WriteLine("安裝未完成。已保留建置檔供檢查：" + root);
            }
            else
            {
                Console.WriteLine("\n安裝完成，可從桌面或開始功能表開啟 Claude娘。");
            }
        }
        catch (Exception error)
        {
            keep = true;
            Console.Error.WriteLine("\n安裝失敗：" + error.Message);
            Console.Error.WriteLine("暫存檔案位置：" + root);
        }
        finally
        {
            if (!keep)
            {
                try { Directory.Delete(root, true); }
                catch (Exception error) { Console.WriteLine("暫存檔未能自動清除：" + error.Message); }
            }
        }
        Console.Write("\n按 Enter 關閉此視窗。");
        Console.ReadLine();
        return result;
    }
}
'@
try {
  [IO.File]::WriteAllText($sourcePath,$source,[Text.UTF8Encoding]::new($false))
  $args=@('/nologo','/target:exe','/platform:anycpu','/optimize+','/reference:System.IO.Compression.dll','/reference:System.IO.Compression.FileSystem.dll',"/out:$OutputPath", "/resource:$SourceZipPath,payload.zip")
  if(Test-Path -LiteralPath $iconPath){$args+= "/win32icon:$iconPath"}
  $args+=$sourcePath
  & $compiler @args
  if($LASTEXITCODE -ne 0){throw "C# compiler failed with exit code $LASTEXITCODE"}
  $installer=Get-Item -LiteralPath $OutputPath
  if($installer.Length -ge 25MB){Remove-Item -LiteralPath $OutputPath;throw "Installer exceeds 25 MB: $($installer.Length) bytes"}
  [pscustomobject]@{Installer=$installer.FullName;Bytes=$installer.Length;Sha256=(Get-FileHash -LiteralPath $OutputPath -Algorithm SHA256).Hash;LimitBytes=25MB}
}
finally {
  if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Recurse -Force}
}
