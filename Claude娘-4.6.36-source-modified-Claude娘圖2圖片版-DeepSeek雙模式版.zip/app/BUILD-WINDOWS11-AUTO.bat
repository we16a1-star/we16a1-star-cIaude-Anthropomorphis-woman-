@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

title Claude娘 - Windows 11 電腦版 - 一鍵建置與安裝
set "APP_DIR=%~dp0"
set "TOOLS=%APP_DIR%_build-tools"
set "NODE=%TOOLS%\node"
set "NPM=%NODE%\npm.cmd"
set "NODE_VERSION=22.23.3"
set "NODE_ZIP=%TOOLS%\node-%NODE_VERSION%-win-x64.zip"
set "ELECTRON_CACHE=%TOOLS%\electron-cache"
set "ELECTRON_BUILDER_CACHE=%TOOLS%\electron-builder-cache"
set "NPM_CACHE=%TOOLS%\npm-cache"
set "FINGERPRINT_FILE=%TOOLS%\source-fingerprint.txt"
set "FINGERPRINT_SCRIPT=%APP_DIR%scripts\source-fingerprint.cjs"
set "DIST_OUT=%TEMP%\cloudo-dist-out"
if not defined ELECTRON_MIRROR set "ELECTRON_MIRROR=https://npmmirror.com/mirrors/electron/"
set "BUILD_TOOLS=%TOOLS%"
set "NODE_ZIP_PATH=%NODE_ZIP%"

if not exist "%TOOLS%" mkdir "%TOOLS%"
if not exist "%ELECTRON_CACHE%" mkdir "%ELECTRON_CACHE%"
if not exist "%ELECTRON_BUILDER_CACHE%" mkdir "%ELECTRON_BUILDER_CACHE%"
if not exist "%NPM_CACHE%" mkdir "%NPM_CACHE%"
rem npm 快取留在專案內：重跑時不用重新下載；設 CLEAN_BUILD_TOOLS=1 成功後刪除可釋放數百 MB。
set "npm_config_cache=%NPM_CACHE%"

cls
echo ============================================================
echo   Claude娘 - Windows 11 電腦版
echo   自動下載、建置、安裝並啟動
echo ============================================================
echo.
echo 專案路徑：%APP_DIR%
echo.

rem 預先檢查：不要在 ZIP 內直接執行、磁碟至少要有 3 GB 可用空間（Electron 與打包工具很大）。
if /I not "%AUTO_INSTALL_SFX%"=="1" echo "%APP_DIR%" | find /I ".zip" >nul
if /I not "%AUTO_INSTALL_SFX%"=="1" if not errorlevel 1 goto fail_zip
if /I not "%AUTO_INSTALL_SFX%"=="1" powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "try{$d=Get-PSDrive -Name $env:APP_DIR.Substring(0,1); if($d.Free -lt 3GB){exit 7}}catch{}"
if /I not "%AUTO_INSTALL_SFX%"=="1" if "%errorlevel%"=="7" goto fail_space

rem ── [1/5] 免安裝版 Node.js（只放在本資料夾，不動使用者電腦的環境） ──────────
if not exist "%NODE%\node.exe" (
  echo [1/5] 找不到內建 Node.js，開始從 nodejs.org 下載...
  set "NODE_URL=https://nodejs.org/dist/v%NODE_VERSION%/node-v%NODE_VERSION%-win-x64.zip"
  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
    "$ErrorActionPreference='Stop'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $tools=$env:BUILD_TOOLS; $zip=$env:NODE_ZIP_PATH; $v=$env:NODE_VERSION; $urls=@('https://nodejs.org/dist/v'+$v+'/node-v'+$v+'-win-x64.zip','https://npmmirror.com/mirrors/node/v'+$v+'/node-v'+$v+'-win-x64.zip'); $tmp=Join-Path $tools 'node_extract'; if(Test-Path -LiteralPath $tmp){Remove-Item -LiteralPath $tmp -Recurse -Force}; if(Test-Path -LiteralPath $zip){Remove-Item -LiteralPath $zip -Force}; $ok=$false; foreach($u in $urls){ try{ Invoke-WebRequest -UseBasicParsing -Uri $u -OutFile $zip -TimeoutSec 900; $ok=$true; break }catch{ Write-Host ('download failed: '+$u) } }; if(-not $ok){ throw 'all download sources failed' }; Expand-Archive -LiteralPath $zip -DestinationPath $tmp -Force; $src=Join-Path $tmp ('node-v'+$v+'-win-x64'); $dst=Join-Path $tools 'node'; if(Test-Path -LiteralPath $dst){Remove-Item -LiteralPath $dst -Recurse -Force}; Move-Item -LiteralPath $src -Destination $dst; Remove-Item -LiteralPath $tmp -Recurse -Force; Remove-Item -LiteralPath $zip -Force"
  if errorlevel 1 goto fail_download
  if not exist "%NODE%\node.exe" goto fail_node
  echo Node.js 下載完成。
) else (
  echo [1/5] 已有內建 Node.js，跳過下載。
)

"%NODE%\node.exe" --version
if errorlevel 1 goto fail_node
if not exist "%NODE%\node_modules\npm\bin\npm-cli.js" goto fail_npm
set "PATH=%NODE%;%NODE%\node_modules\npm\bin;%PATH%"
rem Record the source folder so the in-app Workshop can write code edits back and rebuild. Skipped for the self-extracting installer.
if /I not "%AUTO_INSTALL_SFX%"=="1" "%NODE%\node.exe" -e "require('fs').writeFileSync('source-root.json',JSON.stringify({appDir:process.cwd(),rootDir:require('path').dirname(process.cwd())}))"
rem 版本號單一來源＝package.json；本腳本與安裝檔都直接讀取，不再寫死版本。
set "APP_VERSION="
for /f "delims=" %%V in ('"%NODE%\node.exe" -p "require('./package.json').version"') do set "APP_VERSION=%%V"
if defined APP_VERSION echo [版本] %APP_VERSION%

rem ── [2/5] 原始碼指紋：相同就沿用上次編譯好的安裝檔 ──────────────────────────
set "SOURCE_FINGERPRINT="
if exist "%FINGERPRINT_SCRIPT%" for /f "delims=" %%H in ('"%NODE%\node.exe" "%FINGERPRINT_SCRIPT%" "%APP_DIR%"') do set "SOURCE_FINGERPRINT=%%H"
set "PREVIOUS_FINGERPRINT="
if exist "%FINGERPRINT_FILE%" set /p PREVIOUS_FINGERPRINT=<"%FINGERPRINT_FILE%"
set "INSTALLER="
for /f "delims=" %%F in ('dir /b /a-d /o-d "%APP_DIR%dist\*-Setup-*.exe" 2^>nul') do if not defined INSTALLER set "INSTALLER=%APP_DIR%dist\%%F"

if not defined REBUILD_ALWAYS if defined SOURCE_FINGERPRINT if defined INSTALLER if /I "%SOURCE_FINGERPRINT%"=="%PREVIOUS_FINGERPRINT%" goto reuse_installer

echo.
echo [2/5] 正在自動安裝 Electron 與 electron-builder（第一次較久，之後會用本機快取）...
if defined CLEAN_INSTALL (call :run_npm ci --include=dev --no-audit --no-fund) else (call :run_npm install --include=dev --no-audit --no-fund --prefer-offline)
if errorlevel 1 (
  echo.
  echo 第一次安裝失敗，改用 npmmirror 鏡像自動重試一次...
  call :run_npm install --include=dev --no-audit --no-fund --registry=https://registry.npmmirror.com
  if errorlevel 1 goto fail_npm_install
)

echo.
echo [3/5] 正在編譯 Windows 11 安裝程式...
if not exist "%DIST_OUT%" mkdir "%DIST_OUT%"
call :run_npm run build:web
if errorlevel 1 goto fail_build
rem 先輸出到 %TEMP% 再複製回專案：避開 OneDrive／防毒對 dist 的檔案鎖定（scripts\build-installer.cjs）。
call :run_npm run dist:safe
if errorlevel 1 (
  echo.
  echo 第一次編譯失敗，改用預設輸出資料夾與 npmmirror 打包工具鏡像自動重試一次...
  set "ELECTRON_BUILDER_BINARIES_MIRROR=https://npmmirror.com/mirrors/electron-builder-binaries/"
  call :run_npm run dist
  if errorlevel 1 goto fail_build
)

set "INSTALLER="
rem 以萬用字元取最新的安裝檔（版本不寫死）：先看 TEMP 輸出，再看 app\dist。
for /f "delims=" %%F in ('dir /b /a-d /o-d "%DIST_OUT%\*-Setup-*.exe" 2^>nul') do if not defined INSTALLER set "INSTALLER=%DIST_OUT%\%%F"
if not defined INSTALLER for /f "delims=" %%F in ('dir /b /a-d /o-d "%APP_DIR%dist\*-Setup-*.exe" 2^>nul') do if not defined INSTALLER set "INSTALLER=%APP_DIR%dist\%%F"
if not defined INSTALLER goto fail_output
if not exist "%APP_DIR%dist" mkdir "%APP_DIR%dist"
copy /Y "%INSTALLER%" "%APP_DIR%dist\" >nul
rem 記下這次的原始碼指紋：下次重跑若程式碼沒改，就能直接沿用這個安裝檔。
if defined SOURCE_FINGERPRINT >"%FINGERPRINT_FILE%" echo %SOURCE_FINGERPRINT%
goto package_outputs

:reuse_installer
echo.
echo [2/5] 原始碼與上次相同，且安裝檔還在，直接沿用、跳過下載與編譯。
echo       （想強制重新編譯，請先執行：set REBUILD_ALWAYS=1）

:package_outputs
rem 另存一份安裝檔到專案最上層（即本 App 資料夾的上一層），之後可直接雙擊重新安裝。
if /I not "%AUTO_INSTALL_SFX%"=="1" copy /Y "%INSTALLER%" "%APP_DIR%..\" >nul 2>nul
if /I not "%AUTO_INSTALL_SFX%"=="1" if not errorlevel 1 echo 已另存一份安裝檔到專案最上層資料夾。

echo.
echo [4/5] 正在背景安裝 App，請稍候...
rem 安裝前先請舊版關閉（正常關閉，不強制），否則靜默安裝會失敗。
taskkill /IM "Claude娘*" >nul 2>nul
timeout /t 2 /nobreak >nul 2>nul
start "" /wait "%INSTALLER%" /S
if errorlevel 1 goto fail_install

echo.
echo ============================================================
echo [5/5] 安裝完成！
echo ============================================================
echo.
echo 已為目前 Windows 帳戶安裝，並建立桌面與開始功能表捷徑。
echo 安裝程式保存在：
echo %INSTALLER%
echo.
rem 安裝完成後自動開啟 App（設定環境變數 NO_LAUNCH=1 可關閉）。
set "APP_LNK="
for %%S in ("%APPDATA%\Microsoft\Windows\Start Menu\Programs\Claude娘*.lnk") do if exist "%%~fS" set "APP_LNK=%%~fS"
if not defined NO_LAUNCH if defined APP_LNK (
  echo 正在啟動 App...
  start "" "%APP_LNK%"
)
rem 設定環境變數 CLEAN_BUILD_TOOLS=1 可在成功後刪除 app\_build-tools，釋放空間（下次重跑會重新下載）。
if defined CLEAN_BUILD_TOOLS if exist "%TOOLS%" rmdir /S /Q "%TOOLS%" >nul 2>nul
if /I not "%AUTO_INSTALL_SFX%"=="1" (
  echo 本視窗將在 10 秒後自動關閉，按任意鍵可立即關閉。
  timeout /t 10 >nul 2>nul
)
exit /b 0

:fail_zip
echo.
echo [錯誤] 你正在 ZIP 壓縮檔裡直接執行本檔案。
echo 請先對 ZIP 按右鍵，選「全部解壓縮」，再到解壓後的資料夾重新執行。
goto fail

:fail_space
echo.
echo [錯誤] 這個磁碟的可用空間不足 3 GB。
echo 請清出空間，或把整個資料夾移到空間較大的磁碟後重新執行。
goto fail

:fail_download
echo.
echo [錯誤] Node.js 下載失敗。
echo 請確認 Windows 11 可以正常連上網路，並重新執行本檔案。
goto fail

:fail_node
echo.
echo [錯誤] 找不到或無法執行 Node.js：
echo %NODE%\node.exe
goto fail

:fail_npm
echo.
echo [錯誤] 內建 npm 不完整：
echo %NODE%\node_modules\npm\bin\npm-cli.js
goto fail

:fail_npm_install
echo.
echo [錯誤] Electron / electron-builder 下載或安裝失敗。
echo 請確認網路沒有封鎖 npm 或 Electron 下載站。
goto fail

:fail_build
echo.
echo [錯誤] Windows 11 安裝程式編譯失敗。
echo 請保留這個視窗中的錯誤訊息，以便定位問題。
echo （若只是上次編譯到一半中斷，可先執行：set REBUILD_ALWAYS=1 再重跑一次。）
goto fail

:fail_output
echo.
echo [錯誤] 編譯完成，但找不到 dist\*-Setup-*.exe。
goto fail

:fail_install
echo.
echo [錯誤] 安裝程式未成功完成。
echo 請手動開啟下方的安裝程式檢查：
echo %INSTALLER%
goto fail

:fail
echo.
echo ============================================================
echo 流程未完成。
echo ============================================================
if /I not "%AUTO_INSTALL_SFX%"=="1" pause
exit /b 1

:run_npm
"%NODE%\node.exe" "%NODE%\node_modules\npm\bin\npm-cli.js" %*
exit /b %errorlevel%
