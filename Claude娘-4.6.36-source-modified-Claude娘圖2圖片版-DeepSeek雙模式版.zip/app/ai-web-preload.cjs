'use strict';
// 官網視窗專用 preload：只補「標準 Chrome 身分」，不碰帳密、不讀表單內容。
// Google 登入除了看 User-Agent，還會看 JS 的 navigator.userAgentData 與 window.chrome。
// Electron 的 UA-CH 只宣告 Chromium，會被 accounts.google.com 判成不安全的內嵌瀏覽器；
// 這裡在同一個頁面的 main world、頁面腳本執行前補齊 Chrome 會有的欄位。
const { webFrame } = require('electron');

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36';
const BRANDS = [
  {brand: 'Google Chrome', version: '155'},
  {brand: 'Chromium', version: '155'},
  {brand: 'Not(A:Brand', version: '24'}
];
const FULL_VERSION = '155.0.8059.85';
const FULL_BRANDS = [
  {brand: 'Google Chrome', version: FULL_VERSION},
  {brand: 'Chromium', version: FULL_VERSION},
  {brand: 'Not(A:Brand', version: '24.0.0.0'}
];

const script = `(() => {
  const define = (object, property, value) => {
    try { Object.defineProperty(object, property, {get: () => value, configurable: true}); } catch {}
  };
  define(navigator, 'userAgent', ${JSON.stringify(UA)});
  define(navigator, 'appVersion', ${JSON.stringify(UA.replace(/^Mozilla\//, ''))});
  const brands = ${JSON.stringify(BRANDS)};
  const fullVersionList = ${JSON.stringify(FULL_BRANDS)};
  const highEntropy = {
    brands,
    mobile: false,
    platform: 'Windows',
    platformVersion: '19.0.0',
    architecture: 'x86',
    bitness: '64',
    model: '',
    uaFullVersion: ${JSON.stringify(FULL_VERSION)},
    fullVersionList,
    wow64: false
  };
  const uaData = {
    brands,
    mobile: false,
    platform: 'Windows',
    getHighEntropyValues: async () => ({...highEntropy}),
    toJSON: () => ({brands, mobile: false, platform: 'Windows'})
  };
  define(navigator, 'userAgentData', uaData);

  // 標準 Chrome 頁面會有的 window.chrome 欄位；Electron 預設是空物件。
  try {
    if (!window.chrome) window.chrome = {};
    if (!window.chrome.runtime) window.chrome.runtime = {};
    if (!window.chrome.loadTimes) window.chrome.loadTimes = () => ({
      requestTime: performance.timeOrigin / 1000,
      startLoadTime: performance.timeOrigin / 1000,
      commitLoadTime: performance.now() / 1000,
      finishDocumentLoadTime: performance.now() / 1000,
      finishLoadTime: performance.now() / 1000,
      firstPaintTime: performance.now() / 1000,
      firstPaintAfterLoadTime: 0,
      navigationType: 'Other',
      wasFetchedViaSpdy: true,
      wasNpnNegotiated: true,
      npnNegotiatedProtocol: 'h2',
      wasAlternateProtocolAvailable: false,
      connectionInfo: 'h2'
    });
    if (!window.chrome.csi) window.chrome.csi = () => ({
      onloadT: Date.now(),
      startE: performance.timeOrigin,
      pageT: performance.now(),
      tran: 15
    });
  } catch {}
})();`;

try { webFrame.executeJavaScript(script).catch(() => {}); } catch {}
