function makeCrc32Table(){
  return Array.from({length:256},(_,n)=>{
    let value=n;
    for(let i=0;i<8;i++)value=(value&1)?(0xEDB88320^(value>>>1)):(value>>>1);
    return value>>>0;
  });
}
const CRC32_TABLE=makeCrc32Table();
function crc32(buffer){let crc=0xFFFFFFFF;for(const byte of buffer)crc=CRC32_TABLE[(crc^byte)&0xFF]^(crc>>>8);return (crc^0xFFFFFFFF)>>>0;}
function createStoredZip(entries){
  const localParts=[],directoryParts=[];let offset=0;
  for(const entry of entries){
    const name=Buffer.from(entry.name,'utf8'),data=Buffer.from(entry.content,'utf8'),checksum=crc32(data);
    const local=Buffer.alloc(30);local.writeUInt32LE(0x04034B50,0);local.writeUInt16LE(20,4);local.writeUInt16LE(0x0800,6);local.writeUInt16LE(0,8);local.writeUInt16LE(0,10);local.writeUInt16LE(0x21,12);local.writeUInt32LE(checksum,14);local.writeUInt32LE(data.length,18);local.writeUInt32LE(data.length,22);local.writeUInt16LE(name.length,26);local.writeUInt16LE(0,28);
    localParts.push(local,name,data);
    const central=Buffer.alloc(46);central.writeUInt32LE(0x02014B50,0);central.writeUInt16LE(20,4);central.writeUInt16LE(20,6);central.writeUInt16LE(0x0800,8);central.writeUInt16LE(0,10);central.writeUInt16LE(0,12);central.writeUInt16LE(0x21,14);central.writeUInt32LE(checksum,16);central.writeUInt32LE(data.length,20);central.writeUInt32LE(data.length,24);central.writeUInt16LE(name.length,28);central.writeUInt16LE(0,30);central.writeUInt16LE(0,32);central.writeUInt16LE(0,34);central.writeUInt16LE(0,36);central.writeUInt32LE(0,38);central.writeUInt32LE(offset,42);
    directoryParts.push(central,name);offset+=local.length+name.length+data.length;
  }
  const directory=Buffer.concat(directoryParts),end=Buffer.alloc(22);end.writeUInt32LE(0x06054B50,0);end.writeUInt16LE(0,4);end.writeUInt16LE(0,6);end.writeUInt16LE(entries.length,8);end.writeUInt16LE(entries.length,10);end.writeUInt32LE(directory.length,12);end.writeUInt32LE(offset,16);end.writeUInt16LE(0,20);
  return Buffer.concat([...localParts,directory,end]);
}
module.exports={createStoredZip};
