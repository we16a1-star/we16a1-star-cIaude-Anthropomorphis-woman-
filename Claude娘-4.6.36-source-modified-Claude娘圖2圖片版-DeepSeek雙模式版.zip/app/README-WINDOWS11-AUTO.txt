【Windows 11 電腦版｜自動解壓、建置與安裝】

直接執行配套的自解壓安裝 EXE，程式會自動解壓專案、下載免安裝版 Node.js 與建置依賴、編譯 Windows 安裝程式並安裝到目前 Windows 帳戶。

若使用 ZIP 版本：先完整解壓縮，再雙擊根目錄「一鍵安裝-Windows11.bat」。一般 ZIP 不會在解壓完成時自行執行內容；需要自動解壓後安裝時，請使用自解壓 EXE。

首次執行需要網路並可能花幾分鐘；不需要預先安裝 Node.js 或 Electron。安裝後 App 會自動啟動本機 AI 後端。Gemini 一般 Google 帳號可在 Google AI Studio 建立 API Key，部分模型有官方免費 API 額度；Claude.ai / ChatGPT 網站免費帳號不能直接供 App 呼叫，API 用量分開計算。遇到額度限制時，故事會停在原處並保留本回合，可切換已設定且符合服務條款的 API 連線後重試；不會自動輪換帳號。API Key 使用 Windows 使用者加密保存。
網頁版輔助模式支援 ChatGPT、Claude、Gemini、DeepSeek、Grok、Qwen、Mistral、Copilot、Perplexity、Meta AI、Kimi、Z.ai 等服務。程式會把遊戲視窗縮至左側並保持最前方，網站留在右側；每回合將角色人格、故事記憶摘要與最近 8 則故事對話以純文字複製到剪貼簿。使用者需在官方網站貼上、送出並選取／複製回覆，再回到遊戲按 Ctrl+V；有效 JSON 貼入後會自動接續同一故事存檔。不必上傳故事檔案。網站登入、生成與複製仍由使用者操作；App 不操作網站，也不讀取網站輸出、截圖或登入資料。需要留在遊戲內全自動演算時，請設定官方 API Key。切換 AI 帳號或模型不會更換存檔；切換存檔才會改變故事。
