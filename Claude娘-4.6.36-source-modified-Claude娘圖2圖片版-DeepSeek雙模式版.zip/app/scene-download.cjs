// 桌面版：辨識並讀取「剛下載的場景插圖」（純 Node，可用 node --test 驗證，不依賴 Electron）。
'use strict';
const fs = require('node:fs');
const path = require('node:path');

const IMAGE_MIME_BY_EXT = Object.freeze({'.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp'});
const EXT_BY_MIME = Object.freeze({'image/png': '.png', 'image/jpeg': '.jpg', 'image/webp': '.webp'});
const PNG_SIGNATURE = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
const MAX_SCENE_IMAGE_BYTES = 12 * 1024 * 1024;      // 與前端 MAX_SCENE_IMAGE_FILE_BYTES 一致
const LATEST_WINDOW_MS = 15 * 60 * 1000;
const PARTIAL_DOWNLOAD = /\.(?:crdownload|part|tmp|download|opdownload)$/i;
const TOO_LARGE = Symbol('too-large');

// 判斷一個下載項目是不是可匯入的場景圖（只收 PNG／JPEG／WebP；SVG、GIF 一律不收）。
function describeDownload({filename = '', mimeType = ''} = {}) {
  const mime = String(mimeType || '').split(';')[0].trim().toLowerCase();
  const ext = path.extname(String(filename || '')).toLowerCase();
  if (Object.hasOwn(EXT_BY_MIME, mime)) return {isImage: true, mime, ext: EXT_BY_MIME[mime]};
  if (Object.hasOwn(IMAGE_MIME_BY_EXT, ext) && (!mime || mime === 'application/octet-stream' || mime.startsWith('image/'))) {
    if (mime.startsWith('image/')) return {isImage: false, mime, ext};
    return {isImage: true, mime: IMAGE_MIME_BY_EXT[ext], ext};
  }
  return {isImage: false, mime, ext};
}

// 在資料夾裡找最近 maxAgeMs 內修改過的最新圖片；略過子資料夾、捷徑／符號連結、未完成的下載與超大檔。
function findLatestImage(dir, {now = Date.now(), maxAgeMs = LATEST_WINDOW_MS, maxBytes = MAX_SCENE_IMAGE_BYTES, fsImpl = fs} = {}) {
  let names;
  try { names = fsImpl.readdirSync(dir); } catch { return null; }
  let best = null;
  for (const name of names) {
    if (PARTIAL_DOWNLOAD.test(name)) continue;
    const ext = path.extname(name).toLowerCase();
    if (!IMAGE_MIME_BY_EXT[ext]) continue;
    const full = path.join(dir, name);
    let stat;
    try { stat = fsImpl.lstatSync(full); } catch { continue; }
    if (!stat.isFile() || stat.size <= 0 || stat.size > maxBytes) continue;
    if (stat.mtimeMs < now - maxAgeMs || stat.mtimeMs > now + 60 * 1000) continue;
    if (!best || stat.mtimeMs > best.mtimeMs) best = {path: full, name, mime: IMAGE_MIME_BY_EXT[ext], size: stat.size, mtimeMs: stat.mtimeMs};
  }
  return best;
}

function isSupportedImage(bytes) {
  if (bytes.length >= PNG_SIGNATURE.length && bytes.subarray(0, PNG_SIGNATURE.length).equals(PNG_SIGNATURE)) return true;
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return true;
  return bytes.length >= 12 && bytes.toString('ascii', 0, 4) === 'RIFF' && bytes.toString('ascii', 8, 12) === 'WEBP';
}

function readImageFile(info, {maxBytes = MAX_SCENE_IMAGE_BYTES, fsImpl = fs} = {}) {
  if (!info) return null;
  if (typeof info.path !== 'string' || !info.path) throw new Error('無法讀取下載的圖片。');
  if (!Number.isSafeInteger(maxBytes) || maxBytes < 0) throw new Error('圖片大小上限無效。');
  maxBytes = Math.min(maxBytes, MAX_SCENE_IMAGE_BYTES);

  let pathStat;
  try { pathStat = fsImpl.lstatSync(info.path); }
  catch { throw new Error('無法讀取下載的圖片。'); }
  if (!pathStat.isFile()) throw new Error('無法讀取下載的圖片。');
  if (pathStat.size > maxBytes) throw new Error('圖片太大，請選擇 12 MB 以下的檔案。');

  let fd;
  let bytes;
  let failure;
  try {
    fd = fsImpl.openSync(info.path, fs.constants.O_RDONLY);
    const openedStat = fsImpl.fstatSync(fd);
    if (!openedStat.isFile() || openedStat.ino !== pathStat.ino || (process.platform !== 'win32' && openedStat.dev !== pathStat.dev)) {
      throw new Error('無法讀取下載的圖片。');
    }
    if (openedStat.size > maxBytes) throw TOO_LARGE;

    let buffer = Buffer.allocUnsafe(Math.min(openedStat.size + 1, maxBytes + 1));
    let total = 0;
    while (total <= maxBytes) {
      if (total === buffer.length) {
        const nextLength = Math.min(maxBytes + 1, Math.max(64 * 1024, buffer.length * 2));
        const grown = Buffer.allocUnsafe(nextLength);
        buffer.copy(grown, 0, 0, total);
        buffer = grown;
      }
      const bytesRead = fsImpl.readSync(fd, buffer, total, buffer.length - total, null);
      if (bytesRead === 0) break;
      total += bytesRead;
      if (total > maxBytes) throw TOO_LARGE;
    }
    bytes = buffer.subarray(0, total);
  } catch (error) {
    failure = error;
  }
  if (fd !== undefined) {
    try { fsImpl.closeSync(fd); }
    catch (error) { if (!failure) failure = error; }
  }
  if (failure === TOO_LARGE) throw new Error('圖片太大，請選擇 12 MB 以下的檔案。');
  if (failure) throw new Error('無法讀取下載的圖片。');
  if (!isSupportedImage(bytes)) throw new Error('圖片格式不受支援，僅支援 PNG、JPEG 或 WebP。');
  return {name: info.name, mime: info.mime, bytes};
}

module.exports = {IMAGE_MIME_BY_EXT, MAX_SCENE_IMAGE_BYTES, LATEST_WINDOW_MS, describeDownload, findLatestImage, readImageFile};
