// ai-connect-check.cjs（追加十一）：API「測試連線」的純函式模組。
// 由主程序（electron-main.cjs）代打；renderer 永遠拿不到金鑰，只拿到 {ok, class, status}。
// 設計原則：
//   - 端點表固定（官方 https 網域）＋只做 GET，不接受任何使用者輸入網址（無 SSRF 面）。
//   - 金鑰只放在請求標頭；回傳物件不含任何金鑰欄位。
//   - 逾時上限 10 秒；網路錯誤一律歸類 network（白話由 App 端 uiText 組）。
//   - fetchImpl 可注入：單元測試與安全稽核工具用假 fetch 驗分類，不連外網。
'use strict';
const CONNECT_TIMEOUT_MS = 10000;
// style：bearer＝Authorization: Bearer；x-api-key＝Anthropic；goog＝x-goog-api-key（Gemini）。
const CONNECT_ENDPOINTS = {
  anthropic: {url: 'https://api.anthropic.com/v1/models', style: 'x-api-key', headers: {'anthropic-version': '2023-06-01'}},
  openai: {url: 'https://api.openai.com/v1/models', style: 'bearer'},
  gemini: {url: 'https://generativelanguage.googleapis.com/v1beta/models', style: 'goog'},
  deepseek: {url: 'https://api.deepseek.com/models', style: 'bearer'},
  // OpenRouter 的 /models 是公開清單（不看金鑰），改用 /auth/key：帶金鑰才回 200。
  openrouter: {url: 'https://openrouter.ai/api/v1/auth/key', style: 'bearer'},
  // 阿里雲 DashScope 的 OpenAI 相容模式（Qwen 官方 API）。
  qwen: {url: 'https://dashscope.aliyuncs.com/compatible-mode/v1/models', style: 'bearer'},
  mistral: {url: 'https://api.mistral.ai/v1/models', style: 'bearer'},
  groq: {url: 'https://api.groq.com/openai/v1/models', style: 'bearer'},
  xai: {url: 'https://api.x.ai/v1/models', style: 'bearer'}
};
function buildAuthHeaders(provider, apiKey) {
  const spec = CONNECT_ENDPOINTS[provider];
  if (!spec) return null;
  const headers = {...(spec.headers || {})};
  if (spec.style === 'x-api-key') headers['x-api-key'] = apiKey;
  else if (spec.style === 'goog') headers['x-goog-api-key'] = apiKey;
  else headers.authorization = `Bearer ${apiKey}`;
  return headers;
}
// 只在官網頁面這端判斷狀態碼 → 白話分類；金鑰本身不參與分類。
function classifyConnectStatus(status) {
  const code = Number(status);
  if (code >= 200 && code < 300) return {ok: true, class: 'ok'};
  if (code === 401 || code === 403) return {ok: false, class: 'invalid-key'};
  if (code === 402 || code === 429) return {ok: false, class: 'quota'};
  if (code >= 500) return {ok: false, class: 'service'};
  return {ok: false, class: 'request'};
}
async function testAiConnection(provider, apiKey, {fetchImpl} = {}) {
  const spec = CONNECT_ENDPOINTS[provider];
  if (!spec) return {ok: false, class: 'unsupported'};
  if (!apiKey) return {ok: false, class: 'no-key'};
  const doFetch = fetchImpl || fetch;
  try {
    const response = await doFetch(spec.url, {
      method: 'GET',
      headers: buildAuthHeaders(provider, apiKey),
      signal: AbortSignal.timeout(CONNECT_TIMEOUT_MS)
    });
    return {...classifyConnectStatus(response.status), status: Number(response.status)};
  } catch {
    return {ok: false, class: 'network'};
  }
}
module.exports = {CONNECT_TIMEOUT_MS, CONNECT_ENDPOINTS, buildAuthHeaders, classifyConnectStatus, testAiConnection};
