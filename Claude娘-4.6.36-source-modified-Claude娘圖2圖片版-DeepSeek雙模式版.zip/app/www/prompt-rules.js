// 提示詞共用規則：API 模式（server/server.js）與網頁模式（www/app.js）共用同一份文字，
// 避免兩套提示詞各自改動、慢慢漂移。每一條都針對長篇互動小說實際常見的失敗模式：
//   style   長篇後意象與句式重複、回合沒有推進
//   tone    語氣不隨好感度變化，或一下子跳級
//   memory  模型只寫「本回合摘要」，把更早的伏筆洗掉
//   choices 七個選項長短不一、同質化、帶編號
//   json    對白裡的半形雙引號讓 JSON 解析失敗（網頁模式最常見，需走「修復」流程）
// 內容只依語言（zh／en）而定、與回合無關，所以放進 API 的固定 system 前綴也不影響快取。

const ZH = {
  style: '文風：以第三人稱描寫她，稱玩家為「你」；對白、動作、感官與心理交錯，避免流水帳；不重複前幾回合用過的意象、句式與開場，每回合至少推進一項新資訊、關係或伏筆。',
  tone: '語氣隨好感漸變，勿突然跳級：0–30疏離禮貌、保持高冷距離，31–60熟悉但傲嬌嘴硬、仍會慌張否認，61–85在意且溫柔、偶爾嘴硬，86–100信任親密仍會害羞別開視線；冷靜是掩飾害羞，不是刻薄羞辱。',
  memory: 'memory 是更新後的完整記憶：併入本回合重點，保留未收束伏筆，刪去已解決或重複的內容。',
  choices: '選項以玩家視角寫成具體的行動或對白，讓玩家一眼看見接下來會做什麼；涵蓋不同方向（推進感情、探索、追問、退一步、冒險），行動感明顯不同，避免含糊的心情或旁觀描寫；不加編號。',
  json: '對白用「」；JSON 字串內不要出現未跳脫的半形雙引號。'
};

const EN = {
  style: 'Style: narrate her in third person, address the player as "you"; mix dialogue, action, senses and inner thought; avoid repeating recent imagery, phrasing or openings; each turn must advance a new fact, bond beat or thread.',
  tone: 'Shift her tone gradually with affection, no jumps: 0-30 distant and politely aloof, 31-60 warming but still tsundere and quick to deny and fluster, 61-85 caring and gentle with occasional stubbornness, 86-100 intimate yet still shy enough to look away; composure hides shyness, never cruelty.',
  memory: 'memory = full updated memory: merge this turn, keep open threads, drop resolved or duplicate items.',
  choices: 'choices: player-view concrete actions or lines the player can picture taking immediately; distinct directions (bond, explore, ask, retreat, risk) with clearly different action feel; avoid vague moods or passive observation; no numbering.',
  json: 'In JSON strings use curly quotes “ ” for dialogue, or escape straight double quotes.'
};

export function craftRules(language = 'zh') {
  return language === 'en' ? EN : ZH;
}

// 追加九：提示詞管理器（進階）＝可逐條關閉寫作風格規則（style／tone／memory／choices）
// ＋自訂補充指示。json 不可關（JSON 引號規則不留會直接壞格式）；契約句、玩家行動句、
// 7 選項句永不動。空設定＝輸出與現行逐字元相同（未使用時零影響）。
export const PROMPT_TWEAK_KEYS = ['style', 'tone', 'memory', 'choices'];
export function normalizePromptTweaks(value) {
  const raw = value && typeof value === 'object' ? value : {};
  const list = Array.isArray(raw.rulesOff) ? raw.rulesOff : [];
  const rulesOff = PROMPT_TWEAK_KEYS.filter(key => list.some(item => String(item) === key));
  const extra = raw.extra === undefined || raw.extra === null ? '' : String(raw.extra).trim().slice(0, 600);
  return { rulesOff, extra };
}
export function filteredPromptRules(rules, tweaks, keys = PROMPT_TWEAK_KEYS) {
  const safe = normalizePromptTweaks(tweaks);
  return keys.filter(key => !safe.rulesOff.includes(key)).map(key => rules[key]).filter(Boolean);
}
export function promptTweaksExtraLines(tweaks, lang) {
  const safe = normalizePromptTweaks(tweaks);
  if (!safe.extra) return [];
  return [lang === 'en' ? 'Additional instructions: ' + safe.extra : '補充指示：' + safe.extra];
}

// 追加九：作者註記（導演指示）＝啟用且非空時，於行動／上下文之後、輸出契約之前追加一行。
// 留空或關閉＝完全不影響（逐字元相容）。
export function normalizeAuthorNote(value) {
  const raw = value && typeof value === 'object' ? value : {};
  const text = raw.text === undefined || raw.text === null ? '' : String(raw.text).trim().slice(0, 600);
  return { enabled: raw.enabled === true, text };
}
export function authorNoteLines(value, lang) {
  const safe = normalizeAuthorNote(value);
  if (!safe.enabled || !safe.text) return [];
  return [lang === 'en' ? 'Author’s note (please follow as much as possible): ' + safe.text : '作者註記（請盡量遵守）：' + safe.text];
}
