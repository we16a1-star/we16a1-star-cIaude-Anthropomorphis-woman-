import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createServer} from 'node:http';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {TOKEN_BUDGET, OUTPUT_TARGET, budgetFor, clipHead, clipTail, WEB_PROMPT_TARGET, webPromptBudget} from '../../www/token-budget.js';
import {requestPrompt, startApiServer} from '../../server/server.js';

const story = {narration: '序'.repeat(500), affectionDelta: 1, choices: ['一', '二', '三', '四', '五', '六', '七'], ending: false, endingText: null, memory: '記憶'};
const listen = server => new Promise(resolve => server.listen(0, '127.0.0.1', () => resolve(server.address().port)));
const close = server => new Promise(resolve => server.close(resolve));

test('budget helpers clip the right end and scale English limits', () => {
  assert.equal(clipTail('abcdef', 3), '…def');
  assert.equal(clipHead('abcdef', 3), 'abc…');
  assert.equal(clipTail('abc', 3), 'abc');
  assert.equal(budgetFor('fast').memoryChars, TOKEN_BUDGET.fast.memoryChars);
  assert.equal(budgetFor('quality', 'en').aiChars, TOKEN_BUDGET.quality.aiChars * 2);
  assert.equal(budgetFor('quality', 'en').historyEntries, TOKEN_BUDGET.quality.historyEntries, 'entry counts are not scaled');
  assert.equal(budgetFor('anything-else').historyEntries, TOKEN_BUDGET.quality.historyEntries);
});

test('網頁提示詞節省模式：上下文只縮短、不動輸出契約', () => {
  for (const mode of ['fast', 'quality']) {
    const standard = webPromptBudget(mode, false), saving = webPromptBudget(mode, true);
    assert.ok(saving.historyEntries < standard.historyEntries, mode + ' 帶入的對話則數更少');
    assert.ok(saving.transcriptChars < standard.transcriptChars, mode + ' 近期對話更短');
    assert.ok(saving.memoryChars < standard.memoryChars, mode + ' 記憶更短');
    assert.ok(saving.geminiTranscriptChars < standard.geminiTranscriptChars, mode + ' Gemini 官網上下文更短');
  }
  assert.equal(webPromptBudget('anything-else', true).historyEntries, WEB_PROMPT_TARGET.saving.historyEntries.fast, '未知模式一律用快速');
  assert.equal(webPromptBudget('quality', true).memoryChars, WEB_PROMPT_TARGET.saving.memoryChars.quality);
  assert.equal(webPromptBudget('fast', false).transcriptChars, WEB_PROMPT_TARGET.standard.transcriptChars.fast);
  assert.deepEqual(WEB_PROMPT_TARGET.standard, {
    historyEntries: {fast: 2, quality: 4},
    transcriptChars: {fast: 900, quality: 1500},
    geminiTranscriptChars: 700,
    memoryChars: {fast: 500, quality: 700}
  }, '標準模式的數字與過去版本完全相同，切換節省模式不會影响標準模式的既有行為');
});

test('輸出上限大於「最低需求」且字數是有上限的區間', () => {
  // 舊版 fast 上限 1800 tokens，但光是「旁白500字＋7個15字選項＋600字記憶＋JSON骨架」
  // 就約 1800 tokens：模型多寫一句就被截斷，JSON 不完整 → 整回合失敗 → 手動重打 = 雙倍花費。
  // 上限本身不計費（只算實際輸出），所以一定要留餘裕。
  const perChar = 1.4; // 繁體中文約 1 字 ≈ 1.3～1.5 token
  const minimum = mode => Math.round((OUTPUT_TARGET.narrationMin + OUTPUT_TARGET.choiceMin * 7 + TOKEN_BUDGET[mode].memoryChars + 90) * perChar);
  for (const mode of ['fast', 'quality']) {
    const floor = minimum(mode);
    assert.ok(OUTPUT_TARGET.maxTokens[mode] > floor * 1.1, `${mode}：上限 ${OUTPUT_TARGET.maxTokens[mode]} 必須高於最低需求 ${floor} 並留 10% 餘裕`);
  }
  assert.ok(OUTPUT_TARGET.narrationMin >= 400, '旁白下限不能太低，否則故事會變薄');
  assert.ok(OUTPUT_TARGET.narrationMax < OUTPUT_TARGET.narrationHard, '提示要求的是區間，hard 只是警戒線');
  assert.ok(OUTPUT_TARGET.choiceMax < OUTPUT_TARGET.choiceHard, '選項硬上限比提示要求寬，模型不小心寫長一點不至於整回合失敗');
});

test('request prompt keeps the ending of the newest narration and trims older turns and long memory', () => {
  const longAi = 'HEAD-MARK' + '甲'.repeat(2000) + 'TAIL-MARK';
  const longUser = 'USER-HEAD' + '乙'.repeat(900) + 'USER-TAIL';
  const body = {
    responseMode: 'quality', language: 'zh', action: '繼續',
    storyMemory: '舊記憶'.repeat(600) + 'MEMORY-END',
    history: [{role: 'user', text: '更早行動'}, {role: 'ai', text: 'OLD-HEAD' + '丙'.repeat(900) + 'OLD-TAIL'}, {role: 'user', text: longUser}, {role: 'ai', text: longAi}]
  };
  const text = requestPrompt(body);
  assert.ok(text.includes('TAIL-MARK') && !text.includes('HEAD-MARK'), 'newest narration keeps its ending');
  assert.ok(text.includes('USER-HEAD') && !text.includes('USER-TAIL'), 'player action keeps its beginning');
  assert.ok(text.includes('OLD-TAIL') && !text.includes('OLD-HEAD'), 'older narration keeps only a short ending');
  assert.ok(text.includes('MEMORY-END'), 'memory keeps its newest end');
  assert.ok(text.includes(`記憶上限${TOKEN_BUDGET.quality.memoryChars}字`));
  assert.ok(text.length < 4 * TOKEN_BUDGET.quality.aiChars + TOKEN_BUDGET.quality.memoryChars + 1200, 'prompt stays inside the configured budget');
  const fast = requestPrompt({...body, responseMode: 'fast'});
  assert.ok(fast.includes(`記憶上限${TOKEN_BUDGET.fast.memoryChars}字`));
  assert.ok(!fast.includes('OLD-TAIL'), 'fast mode carries only the last two entries');
  const en = requestPrompt({...body, language: 'en'});
  assert.ok(en.includes(`Memory cap: ${TOKEN_BUDGET.quality.memoryChars * 2} characters`));
});

// 以假上游攔截 API 轉接請求，回傳指定的原始回應
async function callThrough({provider, profile, prefix, baseSuffix = '', respond, extra = {}}) {
  let received = {};
  const upstream = createServer(async (req, res) => {
    const chunks = []; for await (const chunk of req) chunks.push(chunk);
    received = {url: req.url, body: JSON.parse(Buffer.concat(chunks).toString('utf8'))};
    res.setHeader('content-type', 'application/json'); res.end(JSON.stringify(respond(JSON.stringify(story))));
  });
  const port = await listen(upstream);
  const names = [`${prefix}_API_KEY_${profile}`, `${prefix}_BASE_URL_${profile}`];
  const previous = Object.fromEntries(names.map(name => [name, process.env[name]]));
  process.env[names[0]] = 'test-only-key'; process.env[names[1]] = `http://127.0.0.1:${port}${baseSuffix}`;
  const api = await startApiServer({port: 0, host: '127.0.0.1', token: 't'});
  try {
    const response = await fetch(`http://127.0.0.1:${api.address().port}/api/story`, {method: 'POST', headers: {'content-type': 'application/json', 'X-Desktop-Token': 't'}, body: JSON.stringify({provider, accountProfile: profile, history: [], action: '__OPENING_STYLE__:unsigned_letter', ...extra})});
    return {status: response.status, data: await response.json(), received};
  } finally {
    await close(api); await close(upstream);
    for (const [name, value] of Object.entries(previous)) { if (value === undefined) delete process.env[name]; else process.env[name] = value; }
  }
}

test('Anthropic marks the stable system prefix for caching on every Claude model and reports cache usage', async () => {
  const {data, received} = await callThrough({provider: 'anthropic', profile: 'TB_A', prefix: 'ANTHROPIC', extra: {model: 'claude-sonnet-5', responseMode: 'fast'},
    respond: text => ({id: 'm', type: 'message', role: 'assistant', model: 'x', content: [{type: 'text', text}], stop_reason: 'end_turn', stop_sequence: null, usage: {input_tokens: 10, cache_read_input_tokens: 90, cache_creation_input_tokens: 5, output_tokens: 7}})});
  assert.equal(received.body.system[0].cache_control.type, 'ephemeral');
  assert.ok(received.body.system[0].text.includes('只輸出 JSON 本體') && received.body.system[0].text.includes('恰好7個'), 'the output contract is intact');
  assert.ok(received.body.system[0].text.includes(`narration 每回合 ${OUTPUT_TARGET.narrationMin}～${OUTPUT_TARGET.narrationMax} 字`), 'the system prefix states the narration band');
  assert.deepEqual(data._usage, {input: 105, output: 7, cached: 90, reasoning: 0});
});

test('OpenAI uses medium reasoning in detailed mode, low in fast mode, and reports reasoning tokens', async () => {
  const respond = text => ({output_text: text, usage: {input_tokens: 300, output_tokens: 900, input_tokens_details: {cached_tokens: 128}, output_tokens_details: {reasoning_tokens: 600}}});
  const quality = await callThrough({provider: 'openai', profile: 'TB_O', prefix: 'OPENAI', respond, extra: {model: 'gpt-6-astra', responseMode: 'quality'}});
  assert.deepEqual(quality.received.body.reasoning, {effort: 'medium'});
  assert.deepEqual(quality.data._usage, {input: 300, output: 900, cached: 128, reasoning: 600});
  const fast = await callThrough({provider: 'openai', profile: 'TB_O2', prefix: 'OPENAI', respond, extra: {model: 'gpt-6-astra', responseMode: 'fast'}});
  assert.deepEqual(fast.received.body.reasoning, {effort: 'low'});
});

test('Gemini and OpenAI-compatible providers report normalised usage', async () => {
  const gemini = await callThrough({provider: 'gemini', profile: 'TB_G', prefix: 'GEMINI', extra: {model: 'gemini-3.8-flash'},
    respond: text => ({candidates: [{content: {role: 'model', parts: [{text}]}, finishReason: 'STOP', index: 0}], usageMetadata: {promptTokenCount: 100, candidatesTokenCount: 50, thoughtsTokenCount: 20, cachedContentTokenCount: 40}})});
  assert.deepEqual(gemini.data._usage, {input: 100, output: 70, cached: 40, reasoning: 20});
  const deepseek = await callThrough({provider: 'deepseek', profile: 'TB_D', prefix: 'DEEPSEEK', baseSuffix: '/v1', extra: {model: 'deepseek-flash'},
    respond: text => ({choices: [{message: {role: 'assistant', content: text}}], usage: {prompt_tokens: 200, completion_tokens: 80, prompt_cache_hit_tokens: 150}})});
  assert.deepEqual(deepseek.data._usage, {input: 200, output: 80, cached: 150, reasoning: 0});
});

test('usage counter is wired into the client and never stored in the story state', () => {
  const app = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');
  const html = readFileSync(new URL('../../www/index.html', import.meta.url), 'utf8');
  assert.match(app, /recordApiUsage\(data\._usage\);delete data\._usage;/);
  assert.ok(html.includes('id="apiUsageStatus"'));
  // v4.4.0：工坊可編輯整個專案，token-budget.js 不再需要登記進白名單，只要不被安全規則排除即可。
  const require = createRequire(import.meta.url);
  const W = require('../../workshop-apply.cjs');
  const appRoot = fileURLToPath(new URL('../..', import.meta.url));
  assert.ok(W.listEditableFiles(appRoot).some(item => item.path === 'www/token-budget.js'), 'budget file is editable in the workshop');
});
