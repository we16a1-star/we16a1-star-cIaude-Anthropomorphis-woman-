// 追加十一：接 API 提示指引＋測試連線（純函式模組＋主程序／橋接層／App 接線）測試。
// 紀律：每項功能對一組斷言；測試不連外網（fetchImpl 注入假 fetch）。
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const connect = require('../../ai-connect-check.cjs');
const main = readFileSync(new URL('../../electron-main.cjs', import.meta.url), 'utf8');
const preload = readFileSync(new URL('../../electron-preload.cjs', import.meta.url), 'utf8');
const webApp = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');
const indexHtml = readFileSync(new URL('../../www/index.html', import.meta.url), 'utf8');

test('追加十一：測試連線端點表與介面服務清單完全一致（全 https）', () => {
  const selectBlock = indexHtml.match(/<select id="aiProviderSelect">([\s\S]*?)<\/select>/);
  assert.ok(selectBlock, '介面有 AI 服務選單');
  const uiProviders = [...selectBlock[1].matchAll(/<option value="([^"]+)"/g)].map(m => m[1]).sort();
  const endpoints = Object.keys(connect.CONNECT_ENDPOINTS).sort();
  assert.deepEqual(endpoints, uiProviders, '每家可選服務都有測試端點，且沒有多餘端點');
  for (const [provider, spec] of Object.entries(connect.CONNECT_ENDPOINTS)) {
    assert.match(spec.url, /^https:\/\//, `${provider} 端點必須是 https`);
    assert.ok(['bearer', 'x-api-key', 'goog'].includes(spec.style), `${provider} 有定義驗證樣式`);
  }
  assert.equal(connect.CONNECT_TIMEOUT_MS, 10000, '逾時上限 10 秒');
});

test('追加十一：測試連線標頭——金鑰只放請求標頭，樣式正確', () => {
  const anthropic = connect.buildAuthHeaders('anthropic', 'dsl-audit-key');
  assert.equal(anthropic['x-api-key'], 'dsl-audit-key');
  assert.equal(anthropic['anthropic-version'], '2023-06-01');
  const gemini = connect.buildAuthHeaders('gemini', 'dsl-audit-key');
  assert.equal(gemini['x-goog-api-key'], 'dsl-audit-key');
  const openai = connect.buildAuthHeaders('openai', 'dsl-audit-key');
  assert.equal(openai.authorization, 'Bearer dsl-audit-key');
  assert.equal(connect.buildAuthHeaders('unknown-service', 'k'), null, '未知服務不產生標頭');
});

test('追加十一：測試連線分類——成功／金鑰錯／額度／服務異常／其他', () => {
  assert.deepEqual(connect.classifyConnectStatus(200), {ok: true, class: 'ok'});
  assert.deepEqual(connect.classifyConnectStatus(201), {ok: true, class: 'ok'});
  assert.deepEqual(connect.classifyConnectStatus(401), {ok: false, class: 'invalid-key'});
  assert.deepEqual(connect.classifyConnectStatus(403), {ok: false, class: 'invalid-key'});
  assert.deepEqual(connect.classifyConnectStatus(402), {ok: false, class: 'quota'});
  assert.deepEqual(connect.classifyConnectStatus(429), {ok: false, class: 'quota'});
  assert.deepEqual(connect.classifyConnectStatus(500), {ok: false, class: 'service'});
  assert.deepEqual(connect.classifyConnectStatus(404), {ok: false, class: 'request'});
});

test('追加十一：測試連線行為——假 fetch 驗證順序，回傳永不包含金鑰', async () => {
  let seen = null;
  const okResult = await connect.testAiConnection('openai', 'dsl-audit-key', {fetchImpl: async (url, init) => { seen = {url, init}; return {status: 200}; }});
  assert.deepEqual(okResult, {ok: true, class: 'ok', status: 200});
  assert.equal(seen.url, 'https://api.openai.com/v1/models', '只打官方端點');
  assert.equal(seen.init.method, 'GET', '只用 GET');
  assert.equal(seen.init.headers.authorization, 'Bearer dsl-audit-key', '金鑰只在請求標頭');
  assert.ok(seen.init.signal, '帶逾時訊號');
  assert.ok(!JSON.stringify(okResult).includes('dsl-audit-key'), '回傳不含金鑰');
  const invalid = await connect.testAiConnection('openai', 'bad', {fetchImpl: async () => ({status: 401})});
  assert.deepEqual(invalid, {ok: false, class: 'invalid-key', status: 401});
  const network = await connect.testAiConnection('openai', 'bad', {fetchImpl: async () => { throw new Error('boom'); }});
  assert.deepEqual(network, {ok: false, class: 'network'});
  let called = false;
  const noKey = await connect.testAiConnection('openai', '', {fetchImpl: async () => { called = true; return {status: 200}; }});
  assert.deepEqual(noKey, {ok: false, class: 'no-key'});
  assert.equal(called, false, '沒有金鑰時不發請求');
  const unsupported = await connect.testAiConnection('unknown-service', 'k', {fetchImpl: async () => { called = true; return {status: 200}; }});
  assert.deepEqual(unsupported, {ok: false, class: 'unsupported'});
  assert.equal(called, false, '未知服務不發請求');
});

test('追加十一：主程序與橋接層接線——IPC 先驗來源、只回分類', () => {
  assert.match(main, /const aiConnect = require\('\.\/ai-connect-check\.cjs'\);/, '主程序載入測試連線模組');
  const block = main.match(/ipcMain\.handle\('ai-vault:test',[\s\S]{0,700}?\n  \}\);/) || [''];
  assert.ok(block[0].includes('assertTrustedRenderer(event)'), '測試連線 IPC 先驗證畫面來源');
  assert.ok(block[0].includes('return await aiConnect.testAiConnection(provider, item.apiKey);'), '金鑰只在主程序內代打');
  const returnLines = block[0].split('\n').filter(line => line.includes('return'));
  assert.ok(returnLines.length > 0 && returnLines.every(line => !/apiKey\s*:/.test(line)), '回覆不含金鑰欄位');
  assert.match(preload, /testAiConnection: payload => ipcRenderer\.invoke\('ai-vault:test', payload\)/, '橋接層具名曝露，沒有萬用 invoke');
});

test('追加十一：App 指引與測試鈕——首句、九家提示、UI_EN 英譯', () => {
  assert.match(webApp, /可以先完全不設 API、直接玩/, '指引第一句「可以先完全不設 API、直接玩」');
  for (const provider of Object.keys(connect.CONNECT_ENDPOINTS)) {
    assert.match(webApp, new RegExp(`^\\s*${provider}:'`, 'm'), `${provider} 有指引提示`);
  }
  assert.match(webApp, /data-ai-test="\$\{esc\(x\.id\)\}"/, '帳號列有「測試連線」按鈕');
  assert.match(webApp, /function renderAiConnectGuide\(provider\)/, '有指引渲染函式');
  assert.match(webApp, /aiProviderSelect'\)\.onchange=\(\)=>renderAiConnectGuide/, '設定頁：換服務即更新指引');
  assert.match(webApp, /'anthropic';[\s\S]{0,60}renderAiConnectGuide\(/, '開啟表單即更新指引');
  assert.match(indexHtml, /id="aiConnectGuide"/, '表單內有指引盒');
  const samples = [
    '連線正常：這組金鑰可以使用。', '連線失敗：金鑰無效或已被刪除。', '連線失敗：額度不足或達到速率上限。',
    '連線失敗：目前連不上該服務', '連線失敗：官方服務暫時異常。', '連線失敗：官方回覆不如預期。',
    '這個帳號在本機沒有可用的金鑰紀錄。', '本機加密服務目前無法使用', '這個服務不支援自動測試；',
    '這個版本沒有本機金鑰測試功能；'
  ];
  for (const sample of samples) {
    const lines = webApp.split('\n').filter(line => line.includes(sample));
    assert.ok(lines.length > 0, `結果句存在：${sample}`);
    assert.ok(lines.some(line => line.includes("': '")), `結果句有英文對照（UI_EN）：${sample}`);
  }
});
