import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { advanceRound, CHOICE_PLAN, RESPONSE_COUNT } from '../../scripts/web-ai-roundtrip-core.mjs';

const webApp = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');
const helper = readFileSync(new URL('../../scripts/web-ai-roundtrip-test.mjs', import.meta.url), 'utf8');
const packageData = JSON.parse(readFileSync(new URL('../../package.json', import.meta.url), 'utf8'));

test('網頁操作面板可切換「節省模式」：提示詞更短、輸出契約不變', () => {
  assert.match(webApp, /function makeWebPrompt\(action\)\{ return buildWebPrompt\(action,state\.promptMode==='saving'\); \}/, '產生提示詞時依目前模式決定長度');
  assert.match(webApp, /const budget=webPromptBudget\(state\.responseMode,saving\);/, '長度數字集中在 token-budget.js');
  assert.match(webApp, /const craftLines=saving/, '節省模式改用精簡規則');
  assert.match(webApp, /,craft\.memory\]/, '節省模式仍保留記憶改寫規則（記憶每回合都重寫，改壞會連累後續回合）');
  assert.match(webApp, /outputRule\+' 不輸出Markdown或圖片。',craft\.json,/, 'JSON 引號規則與七選項契約不分模式一律保留');
  assert.equal((webApp.match(/const outputRule=/g) || []).length, 1, '輸出契約只有一份，節省模式不會改動正文長度與七個選項');
  assert.match(webApp, /id="pendingPromptMode"/, '待辦回合面板可直接切換');
  assert.match(webApp, /pendingPromptMode\.onchange=\(\)=>setPromptMode\(pendingPromptMode\.value\)/, '面板切換會立即套用並存檔');
  assert.match(webApp, /id="pendingPromptModeNote"/, '面板顯示兩種模式實際的字元數');
  assert.match(webApp, /function webPromptSizeReport\(action\)/, '字元數是即時計算，不是寫死的說明');
  assert.match(webApp, /promptMode: normalizePromptMode\(rawState\.promptMode\)/, '模式跟著存檔保存');
  assert.match(webApp, /promptMode: normalizePromptMode\(source\.promptMode\)/, '匯出與一般存檔也帶上模式');
  const html = readFileSync(new URL('../../www/index.html', import.meta.url), 'utf8');
  assert.match(html, /id="promptMode"/, '設定頁也有提示詞模式選單');
  assert.match(html, /id="promptModeBtn"/, '故事工具列有快速切換按鈕');
});

test('round-trip helper lists every website offered by the web app', () => {
  const appStart = webApp.indexOf('const WEB_AI_PROVIDERS=[');
  const appEnd = webApp.indexOf('\n];', appStart);
  assert.ok(appEnd > appStart, 'web app provider list exists');
  const appIds = [...webApp.slice(appStart, appEnd).matchAll(/\{id:'([a-z]+)',name:'[^']+',url:'https:\/\//g)].map(match => match[1]);
  const helperStart = helper.indexOf('const webProviders = {');
  const helperEnd = helper.indexOf('\n};', helperStart);
  assert.ok(helperEnd > helperStart, 'round-trip helper provider list exists');
  const helperIds = [...helper.slice(helperStart, helperEnd).matchAll(/^\s+([a-z]+): \{/gm)].map(match => match[1]);
  assert.deepEqual(helperIds, appIds);
});

test('round-trip helper applies exactly choices 2, 4, and 5 over three story turns', () => {
  assert.deepEqual(CHOICE_PLAN, [2, 4, 5]);
  assert.equal(RESPONSE_COUNT, 4);
  const state = { history: [], storyMemory: '', affection: 50 };
  const selected = [];
  let action = '__OPENING__';
  for (let responseIndex = 0; responseIndex < RESPONSE_COUNT; responseIndex++) {
    const reply = {
      narration: '測試劇情第 ' + responseIndex,
      memory: '測試記憶第 ' + responseIndex,
      affectionDelta: 1,
      choices: ['選項一', '第' + responseIndex + '輪選二', '選項三', '第' + responseIndex + '輪選四', '第' + responseIndex + '輪選五', '選項六', '選項七']
    };
    const result = advanceRound(state, action, reply, responseIndex);
    if (result.selectedAction) {
      selected.push(result.selectedAction);
      action = result.selectedAction.text;
    }
  }
  assert.deepEqual(selected.map(item => item.number), [2, 4, 5]);
  assert.deepEqual(selected.map(item => item.text), ['第0輪選二', '第1輪選四', '第2輪選五']);
  assert.deepEqual(state.history.map(item => item.role), ['assistant', 'user', 'assistant', 'user', 'assistant', 'user', 'assistant']);
  assert.deepEqual(state.history.filter(item => item.role === 'user').map(item => item.text), ['第0輪選二', '第1輪選四', '第2輪選五']);
  assert.equal(state.storyMemory, '測試記憶第 3');
  assert.equal(state.affection, 54);
});

test('web game leaves all seven AI choices to the player and adds choice eight for custom action', () => {
  const start = webApp.indexOf('const fixedChoices = state.ending?[]:(state.choices || []).slice(0,7);');
  const end = webApp.indexOf("c.querySelectorAll('.choice-btn[data-i]')", start);
  assert.ok(start >= 0 && end > start, 'story choice rendering block exists');
  const render = webApp.slice(start, end);
  assert.match(render, /fixedChoices\.map\(\(x,i\)=>`<button class="choice-btn" data-i="\$\{i\}"/, 'AI choices are individual player-selectable buttons');
  assert.match(render, /8\. \$\{uiText\('自訂行動／台詞'\)\}/, 'the eighth choice opens the custom action input');
  assert.match(webApp, /\$\('freeSend'\)\.onclick=\(\)=>\{const v=\$\('freeInput'\)\.value\.trim\(\); if\(v\) continueStory\(v\);\}/, 'custom text is used as the next story action');
  assert.match(webApp, /if\(\/\^\[1-7\]\$\/\.test\(key\)\)\{[\s\S]*?else if\(key==='8'\)/, 'keyboard 1–7 selects AI choices and 8 opens the custom action');
  assert.match(webApp, /按 1–7 選對應故事選項；按 8 開啟自訂行動/, 'keyboard help explains the player choice split');
  assert.match(webApp, /網頁版已啟用：App 會自動整理提示詞、保留故事並接續有效回覆；你仍須在官方網站登入、貼上並送出提示詞，再複製回覆/, 'web mode identifies remaining website actions');
  assert.match(webApp, /完成官方 API Key 設定後，每回合只需選 AI 的 7 個選項之一，或選第 8 項輸入自訂行動/, 'API mode supports one-choice-per-turn play after setup');
  const continueStart = webApp.indexOf('async function continueStory(action)');
  const continueEnd = webApp.indexOf('\nasync function retryPendingWithMode', continueStart);
  const continueFlow = webApp.slice(continueStart, continueEnd);
  assert.match(continueFlow, /if\(state\.aiMode==='web'\) return beginWebTurn\(playerAction\)/, 'web mode prepares the provider-site round after a choice');
  assert.match(continueFlow, /const r=await callAI\(playerAction\);[\s\S]*?applyTurn\(r\)/, 'API mode generates and applies a reply after a choice');
  assert.match(webApp, /c\.querySelectorAll\('\.choice-btn\[data-i\]'\)\.forEach\(b=>b\.onclick=\(\)=>continueStory\(state\.choices\[\+b\.dataset\.i\]\)\)/, 'clicking any displayed AI choice continues the selected action');
  assert.match(webApp, /\$\('freeSend'\)\.onclick=\(\)=>\{const v=\$\('freeInput'\)\.value\.trim\(\); if\(v\) continueStory\(v\);\}/, 'submitting custom text continues it as the action');
  assert.doesNotMatch(webApp, /CHOICE_PLAN|\[2,\s*4,\s*5\]/, 'the fixed test sequence does not enter the real game');
});

test('round-trip helper validates copied replies and has a runnable npm command', () => {
  assert.match(helper, /const reply = parse\(raw\)/);
  assert.match(helper, /只選取完整 JSON 回覆後複製/);
  assert.match(helper, /async function chooseProvider\(\)/);
  assert.match(helper, /process\.argv\.slice\(2\)\.find\(arg => arg !== '--' && !arg\.startsWith\('--'\)\)/, 'provider selection ignores the npm or pnpm separator');
  assert.match(helper, /function copyToClipboard\(text\)/);
  assert.match(helper, /function readClipboardText\(\)/);
  assert.match(helper, /async function openPromptFallbackFile\(text\)/, 'Windows has a local Notepad fallback when the clipboard cannot be used');
  assert.match(helper, /spawn\('notepad\.exe', \[filePath\]/);
  assert.match(helper, /cleanupPromptFallbackFiles\(\)/, 'temporary prompt files are cleaned when the helper exits');
  assert.match(helper, /const useClipboardRead = process\.platform === 'win32'/, 'Windows supports an explicit copy-button then Enter clipboard handoff for all providers');
  assert.match(helper, /按 Enter 讀取純文字剪貼簿/);
  assert.match(helper, /輸入 P 並按 Enter，改為手動貼回 JSON/);
  assert.match(helper, /await readClipboardText\(\)/);
  assert.match(helper, /!\/\^\\s\*\(\?:```\(\?:json\)\?\\s\*\)\?\\\{/);
  assert.match(helper, /responseIndex < RESPONSE_COUNT/);
  assert.doesNotMatch(helper, /responseIndex < responseCount/);
  assert.match(helper, /parse\(candidate\)/);
  assert.match(helper, /function openProviderPage\(url\)/);
  assert.match(helper, /function findChromeExecutable\(\)/, 'Windows test sessions look for Chrome explicitly');
  assert.match(helper, /spawn\(chromePath, \['--new-window', url\]/, 'the selected website opens in a new Chrome window when Chrome is installed');
  assert.match(helper, /browserMode === 'chrome' \? '已用 Chrome 開啟 '/);
  assert.match(helper, /最多可修復 2 次/);
  assert.match(helper, /storyTemplate: '這是三回合接續測試/);
  assert.match(packageData.scripts['web-ai-roundtrip-test'], /web-ai-roundtrip-test\.mjs/);
  assert.match(packageData.scripts['gemini:web-roundtrip-test'], /web-ai-roundtrip-test\.mjs gemini/);
  assert.doesNotMatch(helper, /playwright|puppeteer|document\.querySelector|\.evaluate\(/i);
});

test('Gemini free API model is selectable and new saves keep free web mode; pending web switching preserves the story', () => {
  const page = readFileSync(new URL('../../www/index.html', import.meta.url), 'utf8');
  const profile = readFileSync(new URL('../../www/character-profile.js', import.meta.url), 'utf8');
  const server = readFileSync(new URL('../../server/server.js', import.meta.url), 'utf8');
  const freshStart = webApp.slice(webApp.indexOf('function fresh()'), webApp.indexOf('function normalizeSlot'));
  assert.match(page, /<option value="gemini::gemini-3\.1-flash-lite">Gemini 3\.1 Flash-Lite · 免費 API 層<\/option>/);
  assert.match(webApp, /function defaultModelForProvider\(p\)\{[^\n]*gemini:'gemini-3\.1-flash-lite'/);
  assert.match(freshStart, /model: 'gemini-3\.1-flash-lite'/);
  assert.match(freshStart, /aiMode: 'web'/, 'new saves still start on the free website flow');
  assert.match(server, /model:body\.model\|\|'gemini-3\.1-flash-lite'/, 'the server uses the same Gemini model fallback');
  assert.match(webApp, /Google currently lists free-tier pricing for this model/);
  assert.match(webApp, /state\.webProvider=nextProvider/);
  const switchStart = webApp.indexOf("async function switchPendingWebProvider(");
  const switchEnd = webApp.indexOf("\nasync function beginWebTurn", switchStart);
  const switchFlow = webApp.slice(switchStart, switchEnd);
  assert.ok(switchStart >= 0 && switchEnd > switchStart, 'one-click website switch helper exists');
  assert.match(switchFlow, /const action=state\.pendingAction/, 'the original player action is kept for the new provider');
  assert.match(switchFlow, /state\.webReply='';/, 'the prior provider reply is cleared before retry');
  assert.match(switchFlow, /await prepareWebPrompt\(action/, 'the new provider receives a prompt for the same action');
  assert.doesNotMatch(switchFlow, /state\.(?:history|storyMemory|pendingAction)\s*=(?!=)/, 'switching providers does not reset story history, memory, or the pending action');
  assert.match(webApp, /button\.onclick=\(\)=>void switchPendingWebProvider\(button\.dataset\.pendingWebProvider\)/, 'ChatGPT, Claude, and Gemini buttons activate the helper directly');
  assert.match(webApp, /pendingWebProvider\.onchange=\(\)=>void switchPendingWebProvider\(pendingWebProvider\.value\)/, 'every website in the full selector switches in one action');
  assert.match(webApp, /fillWebAIProviderSelect\(pendingWebProvider,state\.webProvider\)/, 'the turn selector contains every configured website provider');
  assert.match(webApp, /async function loadWebSiteModels\(\{quiet=false,force=false\}=\{\}\)/, 'the app reads currently available choices from the signed-in website menu');
  assert.match(webApp, /async function selectWebSiteModel\(modelName\)/, 'the app can select one of the discovered website models');
  assert.match(webApp, /openAiWebsite\(provider,browserMode\)/, 'website changes honor the user-selected in-app or external browser mode');
  assert.match(webApp, /browserMode==='embedded'&&window\.claudeDesktop\?\.setWebCompanionLayout/, 'external browser mode skips in-app window layout and focus control');
  assert.match(webApp, /mode==='embedded'&&window\.claudeDesktop\?\.setWebCompanionLayout/, 'settings open only arranges the app-owned browser in embedded mode');
  assert.match(webApp, /webModelStateByProvider\.set\(key,(?:info|raw)\)/, 'each browser mode keeps the live provider model list and current name during this session');
  assert.match(webApp, /webModelStateByProvider\.get\(autoKey\)[\s\S]*?loadWebSiteModels\(\{quiet:true,force:true\}\)/, 'opening a pending turn refreshes the current model names automatically');
  assert.ok(webApp.includes('webModelAutoRefreshedAction'),'the pending panel forces one live model read per turn even within the cache window');
  const modeStart = webApp.indexOf('const webReplyControls=');
  const modeEnd = webApp.indexOf('const keyboardHint=', modeStart);
  const webControls = webApp.slice(modeStart, modeEnd);
  assert.ok(modeStart >= 0 && modeEnd > modeStart, 'web options and model controls exist');
  const modelControlsStart = webApp.indexOf('const modelControls=');
  const modelControlsEnd = webApp.indexOf('const webReplyControls=', modelControlsStart);
  assert.match(webApp.slice(modelControlsStart,modelControlsEnd),/id="pendingWebModel"/, 'the discovered provider model list is rendered');
  assert.ok(webControls.indexOf('pendingWebBrowserMode') < webControls.indexOf('${modelControls}') && webControls.indexOf('${modelControls}') < webControls.indexOf('${manualReplyEditor}'), 'browser mode and model choice appear before the reply field');
  assert.doesNotMatch([page, webApp, profile, server].join('\n'), /18\s*\+/i, 'the interface and its built-in role text contain no 18+ marking');
});

test('manual website model names are editable, persisted, merged, and rendered without losing live models', () => {
  const css = readFileSync(new URL('../../www/style.css', import.meta.url), 'utf8');
  assert.match(webApp, /const WEB_MANUAL_MODELS_KEY='claude_novel_web_manual_models_v1'/, 'manual models have a stable local key');
  assert.match(webApp, /localStorage\.setItem\(WEB_MANUAL_MODELS_KEY,JSON\.stringify\(payload\)\)/, 'manual models persist on this device');
  assert.match(webApp, /id="manualWebModelInput"/, 'the pending panel offers a manual model editor');
  assert.match(webApp, /id="saveManualWebModelsBtn"/, 'the editor saves the typed list');
  assert.match(webApp, /id="clearManualWebModelsBtn"/, 'the editor can clear only manual entries');
  assert.match(webApp, /webManualModelsByProvider\.set\(key,names\)/, 'saving updates the per-provider manual list');
  assert.match(webApp, /webManualModelsByProvider\.delete\(key\)/, 'clearing removes only the manual list for this provider');
  assert.match(webApp, /pendingModelInfo=mergeManualWebModels\(webModelStateByProvider\.get\(pendingModelKey\),pendingModelKey\)/, 'the pending panel merges manual and live names');
  assert.match(webApp, /models\[Number\(pendingWebModel\.value\)\]/, 'selection indexes the merged list, not only the live list');
  assert.match(css, /\.web-model-switch>\.web-model-manual\{/, 'the manual editor uses the existing model control layout');
  assert.match(css, /\.web-model-manual textarea\{/, 'the manual editor is styled without changing other panels');

  const normalizeStart = webApp.indexOf('function normalizeManualWebModelNames(');
  const normalizeEnd = webApp.indexOf('\nfunction loadWebManualModels(', normalizeStart);
  assert.ok(normalizeStart >= 0 && normalizeEnd > normalizeStart, 'manual model parser exists');
  const normalize = new Function(webApp.slice(normalizeStart, normalizeEnd) + '\nreturn normalizeManualWebModelNames;')();
  assert.deepEqual(normalize('模型甲\n模型乙, 模型甲；模型丙\n- 模型丁\n3. 模型戊'), ['模型甲', '模型乙', '模型丙', '模型丁', '模型戊'], 'newlines, commas, bullets, numbering, duplicates, and blanks are normalized');
  assert.equal(normalize(Array.from({length: 60}, (_, index) => 'M' + index)).length, 50, 'manual entries are bounded');

  const mergeStart = webApp.indexOf('function manualWebModelsFor(');
  const mergeEnd = webApp.indexOf('\nlet webModelAutoRefreshTimer', mergeStart);
  assert.ok(mergeStart >= 0 && mergeEnd > mergeStart, 'manual/live merger exists');
  const mergeFactory = new Function('webManualModelsByProvider', webApp.slice(mergeStart, mergeEnd) + '\nreturn {mergeManualWebModels};');
  const {mergeManualWebModels} = mergeFactory(new Map([['gemini::external', ['手動甲', '手動乙']]]));
  const merged = mergeManualWebModels({models: ['官網甲', '手動甲'], current: '官網甲'}, 'gemini::external');
  assert.deepEqual(merged.models, ['手動甲', '手動乙', '官網甲'], 'manual names appear first and live names remain available');
  assert.equal(merged.current, '官網甲', 'a live current model stays selected after merging');
  assert.equal(merged.manualCount, 2);
  assert.equal(merged.hasLiveCurrent, true);
  const manualOnly = mergeManualWebModels(undefined, 'gemini::external');
  assert.equal(manualOnly.current, '手動甲', 'manual-only lists still select their first name');
  assert.equal(manualOnly.hasLiveCurrent, false);
});
