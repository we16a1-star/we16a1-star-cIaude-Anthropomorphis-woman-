import test from 'node:test';
import assert from 'node:assert/strict';
import {existsSync, readFileSync} from 'node:fs';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {Script} from 'node:vm';
import {craftRules, filteredPromptRules, promptTweaksExtraLines, normalizePromptTweaks, normalizeAuthorNote, authorNoteLines} from '../../www/prompt-rules.js';
import {worldBookPromptLines} from '../../www/world-book.js';
import {OUTPUT_TARGET, outputTargetLines, webPromptBudget} from '../../www/token-budget.js';
import {openingStylePrompt, CUSTOM_OPENING_STYLE} from '../../www/opening-styles.js';
import {requestSystemInstruction} from '../../server/server.js';
import {normalizeStoryClock, realStoryClock, affectionStageOf, stageByKey, storyClockLabel} from '../../www/story-clock.js';
import {specialEventPromptLines} from '../../www/special-events.js';

const appSource = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');
const KEYS = ['style', 'tone', 'memory', 'choices', 'json'];

function webPrompt({lang = 'zh', mode = 'quality', provider = 'chatgpt', saving = false, action = '我想靠近一點。', stateOverride = {}} = {}) {
  const start = appSource.indexOf('function compactWebPromptText(');
  const end = appSource.indexOf('\nfunction makeWebRepairPrompt(');
  assert.ok(start >= 0 && end > start, 'web prompt builder is present');
  const context = {
    state: {
      responseMode: mode, promptMode: saving ? 'saving' : 'standard', characterName: 'Claude娘', affection: 50, webProvider: provider,
      characterProfile: '', worldSetting: '', storyTemplate: '', storyMemory: '雨夜初遇。', openingStyle: 'rainy_first_meeting',
      history: [{role: 'ai', text: '她抬起頭。'}, {role: 'user', text: '我向她道謝。'}],
      ...stateOverride
    },
    uiLanguage: lang, DEFAULT_CHARACTER_NAME: 'Claude娘',
    DEFAULT_CHARACTER_PROFILE: 'LONG_PROFILE', DEFAULT_WORLD_SETTING: 'WORLD', DEFAULT_STORY_TEMPLATE: 'RULES',
    COMPACT_DEFAULT_CHARACTER_PROMPT: 'COMPACT_PROFILE', COMPACT_DEFAULT_WORLD_PROMPT: 'COMPACT_WORLD', COMPACT_DEFAULT_RULES_PROMPT: 'COMPACT_RULES',
    normalizeWebAIProvider: value => String(value || 'chatgpt'),
    openingStylePrompt, CUSTOM_OPENING_STYLE, craftRules, outputTargetLines, webPromptBudget, String, Array,
    normalizeStoryClock, realStoryClock, affectionStageOf, stageByKey, storyClockLabel,
    filteredPromptRules, promptTweaksExtraLines, normalizePromptTweaks, normalizeAuthorNote, authorNoteLines, worldBookPromptLines,
    specialEventPromptLines
  };
  new Script(source(start, end) + '\nthis.makeWebPrompt=makeWebPrompt;').runInNewContext(context);
  return context.makeWebPrompt(action);
  function source(a, b) { return appSource.slice(a, b); }
}

test('shared craft rules exist in both languages and English has no stray Chinese', () => {
  for (const language of ['zh', 'en']) {
    const rules = craftRules(language);
    for (const key of KEYS) assert.ok(rules[key] && rules[key].length > 20, `${language}.${key} is defined`);
  }
  for (const key of KEYS) assert.ok(!/[\u4e00-\u9fff]/.test(craftRules('en')[key]), `en.${key} is pure English`);
  assert.match(craftRules('zh').json, /「」/, 'Chinese dialogue convention is stated');
  assert.equal(craftRules(), craftRules('zh'), 'Chinese is the default');
});

test('API system prefix carries every craft rule and stays identical across turns (cache-friendly)', () => {
  for (const language of ['zh', 'en']) {
    const system = requestSystemInstruction({language});
    for (const key of KEYS) assert.ok(system.includes(craftRules(language)[key]), `${language} system prefix includes ${key}`);
  }
  const base = requestSystemInstruction({language: 'zh'});
  const later = requestSystemInstruction({language: 'zh', affection: 91, action: '別的行動', history: [{role: 'ai', text: '另一回合'}], storyMemory: '另一份記憶'});
  assert.equal(base, later, 'per-turn data never leaks into the stable prefix');
  assert.ok(base.includes('只輸出 JSON 本體') && base.includes('恰好7個'), 'the original output contract is intact');
  const rulesLength = KEYS.reduce((sum, key) => sum + craftRules('zh')[key].length, 0);
  assert.ok(rulesLength < 360, 'the added Chinese rules stay compact (' + rulesLength + ' chars)');
});

test('cold-outside librarian voice keeps a shy interior, tsundere edge, and stays non-abusive', () => {
  const zh = craftRules('zh');
  assert.match(zh.tone, /高冷/);
  assert.match(zh.tone, /傲嬌/);
  assert.match(zh.tone, /慌張/);
  assert.match(zh.tone, /不是刻薄羞辱/, '冷淡仍有刻薄／羞辱護欄');
  assert.match(appSource, /const COMPACT_DEFAULT_CHARACTER_PROMPT='[^'\n]*表面冷靜少話[^'\n]*高冷[^'\n]*傲嬌[^'\n]*內在害羞[^'\n]*'/);
  const serverSource = readFileSync(new URL('../../server/server.js', import.meta.url), 'utf8');
  assert.match(serverSource, /const COMPACT_DEFAULT_CHARACTER_PROFILE='[^'\n]*表面冷靜少話[^'\n]*高冷[^'\n]*傲嬌[^'\n]*內在害羞[^'\n]*'/);
  assert.match(serverSource, /const DEFAULT_CHARACTER_PROFILE = `[^`]*表面冷靜、少話[^`]*傲嬌[^`]*`/);
  assert.match(requestSystemInstruction({language: 'zh'}), /表面冷靜少話/, 'API system prompt carries the cold-outside personality');
  assert.match(requestSystemInstruction({language: 'zh'}), /傲嬌/, 'API system prompt carries the tsundere edge');
  assert.match(requestSystemInstruction({language: 'zh'}), /內在害羞/, 'API system prompt carries the shy interior');
});

test('web prompt adds craft rules, keeps the identity lock last, and slims Gemini', () => {
  const normal = webPrompt();
  for (const key of KEYS) assert.ok(normal.includes(craftRules('zh')[key]), 'default web prompt includes ' + key);
  assert.ok(normal.trimEnd().split('\n').pop().includes('不主動自稱 AI'), 'identity lock still closes the prompt');
  assert.ok(normal.includes('誠實回答你是 AI 扮演的'), 'honest AI disclosure survives the identity lock');
  assert.ok(normal.includes('affectionDelta 必須是 -3 到 +3'), 'affection scale is unchanged');
  // 網頁模式的字數要求與 API 模式共用同一組數字（www/token-budget.js）。
  assert.ok(normal.includes(outputTargetLines('zh').length), 'the web prompt states the narration band');
  assert.ok(normal.includes(outputTargetLines('zh').choices), 'the web prompt caps choice length');
  assert.ok(!normal.includes('可以更長'), 'no open-ended "may be longer" left in the web prompt');

  const gemini = webPrompt({provider: 'gemini'});
  assert.ok(gemini.includes(craftRules('zh').tone) && gemini.includes(craftRules('zh').json), 'Gemini keeps the two stability rules');
  assert.ok(!gemini.includes(craftRules('zh').style), 'Gemini stays slim: no style rule');
  assert.ok(gemini.length < normal.length, 'Gemini prompt is still the slimmer one');

  const english = webPrompt({lang: 'en'});
  assert.ok(english.startsWith('Write all new narration'), 'English prompts keep their language header');
  assert.ok(english.includes(craftRules('en').style) && english.includes(craftRules('en').json));

  // 節省模式：只壓縮規則與上下文，輸出契約、身份鎖與兩條「不寫就會壞」的規則完整保留。
  const standardFast = webPrompt({mode: 'fast'});
  const saving = webPrompt({mode: 'fast', saving: true});
  assert.ok(saving.length < standardFast.length, '節省模式的提示詞一定比標準短');
  assert.ok(saving.includes(outputTargetLines('zh').length), '節省模式仍寫明旁白字數區間');
  assert.ok(saving.includes('恰好7個'), '節省模式仍要求七個選項');
  assert.ok(saving.includes(craftRules('zh').json), '節省模式保留 JSON 引號規則（避免整回合重打）');
  assert.ok(saving.includes(craftRules('zh').memory), '節省模式保留記憶改寫規則');
  assert.ok(!saving.includes(craftRules('zh').choices), '節省模式省略選項寫法說明（輸出契約仍有七個選項）');
  assert.ok(saving.trimEnd().split('\n').pop().includes('不主動自稱 AI'), '節省模式的身份鎖仍在最後一行');
  assert.ok(saving.includes('玩家行動：我想靠近一點。'), '節省模式仍帶入玩家行動');
});

test('repair prompt also tells the model to fix quote characters', () => {
  assert.match(appSource, /function makeWebRepairPrompt\(\)[\s\S]*?半形雙引號請改用「」/);
  assert.match(appSource, /function makeWebRepairPrompt\(\)[\s\S]*?choices 必須是陣列，恰好包含 7 個不同/, 'the seven-choice repair rule is preserved');
});

test('prompt-rules.js is registered as editable source in the workshop and Electron export', () => {
  assert.ok(existsSync(new URL('../../www/prompt-rules.js', import.meta.url)));
  // v4.4.0：工坊不再用白名單，改為「整個專案除安全排除外都能編輯」。
  // 這裡直接問工坊核心：這個檔案在不在可編輯清單裡。
  const require = createRequire(import.meta.url);
  const W = require('../../workshop-apply.cjs');
  const appRoot = fileURLToPath(new URL('../..', import.meta.url));
  assert.ok(W.listEditableFiles(appRoot).some(item => item.path === 'www/prompt-rules.js'), 'prompt-rules.js is listed as editable');
  assert.ok(!W.isBlockedRelative('www/prompt-rules.js'));
  const main = readFileSync(new URL('../../electron-main.cjs', import.meta.url), 'utf8');
  assert.ok(!main.includes('WORKSHOP_SOURCE_PATHS'), 'the Electron side no longer keeps an allowlist');
});

test('web prompt：世界書命中才注入、提示詞管理器與作者註記（未使用＝逐字元相同）', () => {
  const base = webPrompt();
  const noop = webPrompt({stateOverride: {
    worldBook: {enabled: true, entries: [{id: 'a', keywords: ['不存在的詞'], text: '不該出現', enabled: true}]},
    authorNote: {enabled: false, text: '多描寫雨聲'},
    promptTweaks: {rulesOff: [], extra: ''}
  }});
  assert.equal(noop, base, '未命中／關閉／空設定＝逐字元相同');

  const book = webPrompt({stateOverride: {worldBook: {enabled: true, entries: [{id: 'a', keywords: ['靠近'], text: '她與玩家靠近時會退一步。', enabled: true}]}}});
  assert.ok(book.includes('世界書（命中關鍵詞，僅供參考）：'), '命中＝注入標頭');
  assert.ok(book.includes('她與玩家靠近時會退一步。'), '命中＝注入設定文字');
  assert.ok(book.indexOf('世界書（命中關鍵詞') > book.indexOf('近期對話：'), '世界書在近期對話之後');

  const tweaked = webPrompt({stateOverride: {promptTweaks: {rulesOff: ['style'], extra: '少用成語'}}});
  assert.ok(!tweaked.includes(craftRules('zh').style), '關掉的規則不出現');
  assert.ok(tweaked.includes(craftRules('zh').tone) && tweaked.includes(craftRules('zh').memory) && tweaked.includes(craftRules('zh').choices), '其他規則照舊');
  assert.ok(tweaked.includes('補充指示：少用成語'), '補充指示行出現');
  assert.ok(tweaked.includes('只輸出JSON：narration'), '輸出契約不受影響');

  const noted = webPrompt({stateOverride: {authorNote: {enabled: true, text: '多描寫雨聲'}}});
  assert.ok(noted.includes('作者註記（請盡量遵守）：多描寫雨聲'));
  assert.ok(noted.indexOf('作者註記（') > noted.indexOf('玩家行動：'), '作者註記在玩家行動之後');

  const savingOff = webPrompt({mode: 'fast', saving: true, stateOverride: {promptTweaks: {rulesOff: ['style'], extra: ''}}});
  assert.ok(!savingOff.includes('文風：'), '節省模式的文風句也可關');
  assert.ok(savingOff.includes(craftRules('zh').memory), '節省模式的記憶規則保留');
});
