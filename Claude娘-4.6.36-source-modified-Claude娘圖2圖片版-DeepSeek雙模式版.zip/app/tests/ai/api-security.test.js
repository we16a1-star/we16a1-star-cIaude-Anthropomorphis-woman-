// 本機 AI 服務的行為層安全抽查：CORS 白名單與桌面 token。
// 兩道防線一起把「其他網站在使用者的瀏覽器裡偷打本機 API」的路封住：
//   1) CORS 白名單：外部來源拿不到回應標頭 → 瀏覽器端讀不到任何回應。
//   2) X-Desktop-Token：沒有本回合啟動時產生的隨機 token，一律 401。
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {startApiServer} from '../../server/server.js';

const close = server => new Promise(resolve => server.close(resolve));

test('本機 API 的 CORS 只放行本 App 畫面（Origin null／file://）與本機開發來源', async () => {
  const api = await startApiServer({port: 0, host: '127.0.0.1', token: 'audit-token'});
  const base = `http://127.0.0.1:${api.address().port}`;
  try {
    const evil = await fetch(`${base}/api/health`, {headers: {origin: 'https://evil.example'}});
    assert.equal(evil.headers.get('access-control-allow-origin'), null, '外部網站不得取得放行標頭');
    const file = await fetch(`${base}/api/health`, {headers: {origin: 'null'}});
    assert.equal(file.headers.get('access-control-allow-origin'), 'null', 'file:// 畫面（Origin: null）可用');
    const fileScheme = await fetch(`${base}/api/health`, {headers: {origin: 'file://'}});
    assert.equal(fileScheme.headers.get('access-control-allow-origin'), 'file://', '部分環境的 file:// 來源也可用');
    const dev = await fetch(`${base}/api/health`, {headers: {origin: 'http://127.0.0.1:5173'}});
    assert.equal(dev.headers.get('access-control-allow-origin'), 'http://127.0.0.1:5173', '本機開發伺服器可用');
    const localhost = await fetch(`${base}/api/health`, {headers: {origin: 'http://localhost:8080'}});
    assert.equal(localhost.headers.get('access-control-allow-origin'), 'http://localhost:8080', 'localhost 網域可用');
  } finally {
    await close(api);
  }
});

test('本機 API 沒帶或帶錯桌面 token 一律 401', async () => {
  const api = await startApiServer({port: 0, host: '127.0.0.1', token: 'audit-token'});
  const base = `http://127.0.0.1:${api.address().port}`;
  try {
    assert.equal((await fetch(`${base}/api/health`)).status, 401, '缺 token 被拒');
    assert.equal((await fetch(`${base}/api/health`, {headers: {'X-Desktop-Token': 'wrong'}})).status, 401, '錯誤 token 被拒');
    const allowed = await fetch(`${base}/api/health`, {headers: {'X-Desktop-Token': 'audit-token'}});
    assert.equal(allowed.status, 200);
    assert.equal((await allowed.json()).ok, true);
  } finally {
    await close(api);
  }
});

test('自架 API 未設定 token 時拒絕 file:// 不透明來源；設定 token 後可正常連線', async () => {
  const api = await startApiServer({port: 0, host: '127.0.0.1'});
  const base = `http://127.0.0.1:${api.address().port}`;
  try {
    const denied = await fetch(`${base}/api/health`, {headers: {origin: 'null'}});
    assert.equal(denied.status, 403, '未設 token 時拒絕 Origin: null');
    assert.equal(denied.headers.get('access-control-allow-origin'), null, '未設 token 時不放行不透明來源的 CORS');
  } finally {
    await close(api);
  }

  const protectedApi = await startApiServer({port: 0, host: '127.0.0.1', token: 'desktop-token'});
  const protectedBase = `http://127.0.0.1:${protectedApi.address().port}`;
  try {
    const allowed = await fetch(`${protectedBase}/api/health`, {headers: {origin: 'null', 'X-Desktop-Token': 'desktop-token'}});
    assert.equal(allowed.status, 200, '有桌面 token 時 file:// 畫面可連線');
    assert.equal(allowed.headers.get('access-control-allow-origin'), 'null');
  } finally {
    await close(protectedApi);
  }
});

test('自架（直接執行 server.js）模式預設只綁本機，開放區網需明確設定 HOST＋API_TOKEN', () => {
  const server = readFileSync(new URL('../../server/server.js', import.meta.url), 'utf8');
  assert.match(server, /String\(process\.env\.HOST\|\|''\)\.trim\(\)\|\|'127\.0\.0\.1'/, 'HOST 預設 127.0.0.1');
  assert.match(server, /String\(process\.env\.API_TOKEN\|\|''\)\.trim\(\)/, '支援 API_TOKEN 作為自架模式的存取權杖');
  assert.ok(!/host:'0\.0\.0\.0'/.test(server), '不再無條件綁 0.0.0.0（CORS 白名單擋不住非瀏覽器用戶端）');
  assert.match(server, /非本機位址[\s\S]{0,80}API_TOKEN/, '綁非本機位址又沒設 token 時會在主控台警告');
});
