// 追加九：提示詞管理器（進階）的閘門。
// 釘住：正規化（未知鍵剔除）、過濾（空設定＝原順序原樣＝逐字元相容）、補充指示行的產生、
// 以及「json 不可關、契約不受影響」的介面邊界。server.js 與 app.js 的接線斷言也在本檔。
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import {
  craftRules, PROMPT_TWEAK_KEYS,
  normalizePromptTweaks, filteredPromptRules, promptTweaksExtraLines, normalizeAuthorNote
} from '../../www/prompt-rules.js';

test('normalizePromptTweaks：壞資料＝空設定；未知鍵與重複鍵剔除；固定順序', () => {
  assert.deepEqual(normalizePromptTweaks(undefined), { rulesOff: [], extra: '' });
  assert.deepEqual(normalizePromptTweaks(null), { rulesOff: [], extra: '' });
  assert.deepEqual(normalizePromptTweaks('x'), { rulesOff: [], extra: '' });
  assert.deepEqual(normalizePromptTweaks({ rulesOff: 'style' }), { rulesOff: [], extra: '' });
  assert.deepEqual(normalizePromptTweaks({ rulesOff: ['style', 'style', 'json', 'bogus', 7] }), { rulesOff: ['style'], extra: '' });
  assert.deepEqual(normalizePromptTweaks({ rulesOff: ['choices', 'memory'] }), { rulesOff: ['memory', 'choices'], extra: '' });
  assert.deepEqual(normalizePromptTweaks({ extra: '  少用成語  ' }), { rulesOff: [], extra: '少用成語' });
  assert.equal(normalizePromptTweaks({ extra: 'x'.repeat(900) }).extra.length, 600);
});

test('filteredPromptRules：空設定＝原順序原樣（逐字元相容）；關掉誰就少誰', () => {
  const rules = craftRules('zh');
  assert.deepEqual(filteredPromptRules(rules, undefined), [rules.style, rules.tone, rules.memory, rules.choices]);
  assert.deepEqual(filteredPromptRules(rules, { rulesOff: [] }), [rules.style, rules.tone, rules.memory, rules.choices]);
  assert.deepEqual(filteredPromptRules(rules, { rulesOff: ['tone'] }), [rules.style, rules.memory, rules.choices]);
  assert.deepEqual(filteredPromptRules(rules, { rulesOff: ['style', 'tone', 'memory', 'choices'] }), []);
  assert.deepEqual(filteredPromptRules(rules, { rulesOff: ['json'] }), [rules.style, rules.tone, rules.memory, rules.choices], 'json 不在可關清單');
  assert.deepEqual(filteredPromptRules(rules, { rulesOff: ['tone'] }, ['tone']), [], '指定清單模式（Gemini 只帶 tone）');
  const en = craftRules('en');
  assert.deepEqual(filteredPromptRules(en, { rulesOff: ['style', 'choices'] }), [en.tone, en.memory]);
});

test('promptTweaksExtraLines：空＝零行；有值＝單行（中英）', () => {
  assert.deepEqual(promptTweaksExtraLines(undefined, 'zh'), []);
  assert.deepEqual(promptTweaksExtraLines({ extra: '   ' }, 'zh'), []);
  assert.deepEqual(promptTweaksExtraLines({ extra: '少用成語' }, 'zh'), ['補充指示：少用成語']);
  assert.deepEqual(promptTweaksExtraLines({ extra: 'Avoid idioms' }, 'en'), ['Additional instructions: Avoid idioms']);
});

test('PROMPT_TWEAK_KEYS 與 craftRules 對齊：四條可關、json 不可關', () => {
  const rules = craftRules('zh');
  for (const key of PROMPT_TWEAK_KEYS) assert.ok(typeof rules[key] === 'string' && rules[key], key);
  assert.deepEqual(PROMPT_TWEAK_KEYS, ['style', 'tone', 'memory', 'choices']);
});

test('server.js API 系統指示：開關只動四條寫作規則＋補充指示；空設定＝逐字元相同', async () => {
  const { requestSystemInstruction } = await import('../../server/server.js');
  const rules = craftRules('zh');
  const off = requestSystemInstruction({ language: 'zh' });
  assert.equal(requestSystemInstruction({ language: 'zh', promptTweaks: { rulesOff: [], extra: '' } }), off, '空設定＝逐字元相同');
  const tweaked = requestSystemInstruction({ language: 'zh', promptTweaks: { rulesOff: ['style'], extra: '少用成語' } });
  assert.ok(!tweaked.includes(rules.style));
  assert.ok(tweaked.includes(rules.tone) && tweaked.includes(rules.memory) && tweaked.includes(rules.choices));
  assert.ok(tweaked.includes('補充指示：少用成語'));
  assert.ok(tweaked.includes(rules.json), 'json 不可關');
  assert.ok(tweaked.includes('只輸出有效JSON，欄位：narration、affectionDelta、choices、ending、endingText、memory；'), '欄位列表句永遠不變');
  const en = requestSystemInstruction({ language: 'en', promptTweaks: { rulesOff: ['tone'], extra: 'Avoid idioms' } });
  assert.ok(en.includes('Additional instructions: Avoid idioms'));
  assert.ok(!en.includes(craftRules('en').tone) && en.includes(craftRules('en').style));
});

test('作者註記：啟用且非空才加一行（玩家行動之後）；空白或關閉＝逐字元相同', async () => {
  const { requestPrompt } = await import('../../server/server.js');
  const base = { language: 'zh', action: '我點頭', history: [{ role: 'ai', text: '（故事）' }] };
  const off = requestPrompt(base);
  assert.ok(!off.includes('作者註記'));
  const on = requestPrompt({ ...base, authorNote: { enabled: true, text: '多描寫雨聲' } });
  assert.ok(on.includes('作者註記（請盡量遵守）：多描寫雨聲'));
  assert.ok(on.indexOf('作者註記（') > on.indexOf('玩家行動：'), '作者註記在玩家行動之後');
  assert.equal(requestPrompt({ ...base, authorNote: { enabled: true, text: '   ' } }), off, '空白＝逐字元相同');
  assert.equal(requestPrompt({ ...base, authorNote: { enabled: false, text: '多描寫雨聲' } }), off, '關閉＝逐字元相同');
  assert.equal(normalizeAuthorNote({ text: 'x'.repeat(900) }).text.length, 600);
  assert.deepEqual(normalizeAuthorNote(undefined), { enabled: false, text: '' });
});

test('app.js 接線：狀態欄位、網頁提示詞管理器與作者註記（未使用＝零影響）', () => {
  const appSource = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');
  assert.match(appSource, /import \{ translateError \} from '\.\/ui-error\.js'; import \{ craftRules, filteredPromptRules, promptTweaksExtraLines, normalizePromptTweaks, normalizeAuthorNote, authorNoteLines \} from '\.\/prompt-rules\.js';/, '匯入管理器與作者註記 helper');
  assert.match(appSource, /promptTweaks: \{ rulesOff: \[\], extra: '' \}/, 'fresh() 預設欄位（未使用＝關閉空設定）');
  assert.match(appSource, /promptTweaks: normalizePromptTweaks\(rawState\.promptTweaks\),/, 'normalizeSlot 正規化管理器');
  assert.match(appSource, /promptTweaks: normalizePromptTweaks\(source\.promptTweaks\),/, 'serializeState 正規化管理器');
  assert.match(appSource, /promptTweaks:normalizePromptTweaks\(state\.promptTweaks\),/, 'API 請求帶上管理器');
  assert.match(appSource, /authorNote: \{ enabled: false, text: '' \},/, '作者註記預設欄位');
  assert.match(appSource, /authorNote: normalizeAuthorNote\(rawState\.authorNote\),/, 'normalizeSlot 正規化作者註記');
  assert.match(appSource, /authorNote: normalizeAuthorNote\(source\.authorNote\),/, 'serializeState 正規化作者註記');
  assert.match(appSource, /authorNote:normalizeAuthorNote\(state\.authorNote\),/, 'API 請求帶上作者註記');
  assert.match(appSource, /\(isGeminiWeb\?filteredPromptRules\(craft,state\.promptTweaks,\['tone'\]\):filteredPromptRules\(craft,state\.promptTweaks\)\)/, '網頁提示詞用過濾器組裝（Gemini 只留 tone）');
  assert.match(appSource, /\.filter\(pair=>!tweakOff\.includes\(pair\[0\]\)\)\.map\(pair=>pair\[1\]\)/, '節省模式的兩條規則也吃同一組開關');
  assert.match(appSource, /\.\.\.promptTweaksExtraLines\(state\.promptTweaks,uiLanguage\),/, '補充指示行注入');
  assert.match(appSource, /\.\.\.authorNoteLines\(state\.authorNote,uiLanguage\),/, '作者註記行注入');
});
