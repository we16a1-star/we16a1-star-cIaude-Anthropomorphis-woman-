// AI 模型通用性檢測：App 內按鈕與開發端回歸測試共用同一份 JSON 契約。
// 這裡不呼叫任何真實 API（不消耗額度），只驗證：
//   1. 純檢查器對「合格／不合格」回覆的分類；
//   2. 伺服器送出的短檢測提示詞真的要求 narration／affectionDelta／7 個不同選項／memory；
//   3. Anthropic、Gemini、OpenAI 與所有 OpenAI 相容服務都走 probe 分支；
//   4. App 的按鈕、端點與雙語文字都接上了。
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { evaluateModelCheck } from '../../www/model-check.js';
import { probeModel, requestPrompt, requestSystemInstruction } from '../../server/server.js';

const appSource = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');
const html = readFileSync(new URL('../../www/index.html', import.meta.url), 'utf8');
const serverSource = readFileSync(new URL('../../server/server.js', import.meta.url), 'utf8');

function validStory(overrides = {}) {
  return {
    narration: '她接過熱茶，指尖在杯沿停了一瞬，輕聲請你坐下。',
    affectionDelta: 1,
    choices: ['一起喝茶', '聊起今晚的雨', '問她手上的書', '安靜陪她整理書架', '提議到窗邊看雨', '幫她添一盞燈', '向她道別'],
    ending: false,
    endingText: null,
    memory: '雨夜圖書館，玩家遞上熱茶。',
    ...overrides
  };
}

test('合格回覆：六項檢查全部通過，且順序固定', () => {
  const result = evaluateModelCheck(validStory(), { provider: 'deepseek', model: 'deepseek-flash', latencyMs: 123 });
  assert.equal(result.ok, true);
  assert.equal(result.provider, 'deepseek');
  assert.equal(result.model, 'deepseek-flash');
  assert.equal(result.latencyMs, 123);
  assert.deepEqual(result.checks.map(check => check.key), ['connection', 'json', 'narration', 'choices', 'affection', 'memory']);
  assert.ok(result.checks.every(check => check.ok));
  assert.ok(result.checks.every(check => check.labelZh && check.labelEn));
});

test('不合格回覆：逐項指出缺少的契約', () => {
  const cases = [
    [{ narration: '   ' }, 'narration'],
    [{ choices: ['一', '二', '三', '四', '五', '六'] }, 'choices'],
    [{ choices: ['一', '二', '三', '四', '五', '六', '六'] }, 'choices'],
    [{ affectionDelta: '不是數字' }, 'affection'],
    [{ memory: null }, 'memory']
  ];
  for (const [override, expectedKey] of cases) {
    const result = evaluateModelCheck(validStory(override));
    assert.equal(result.ok, false, `${expectedKey} 應該讓整體失敗`);
    const check = result.checks.find(item => item.key === expectedKey);
    assert.equal(check.ok, false, `${expectedKey} 應該標成失敗`);
    assert.ok(check.detailZh && check.detailEn, `${expectedKey} 應有中英原因`);
  }
});

test('連線失敗：只回報連線原因，其餘契約不假裝通過', () => {
  const result = evaluateModelCheck(validStory(), { connected: false, error: 'HTTP 401：金鑰無效' });
  assert.equal(result.ok, false);
  const connection = result.checks.find(check => check.key === 'connection');
  assert.equal(connection.ok, false);
  assert.match(connection.detailZh, /401/);
  assert.ok(result.checks.filter(check => check.key !== 'connection').every(check => !check.ok));
});

test('提示詞契約：短檢測要求 JSON、非空旁白、7 個不同選項、好感度與記憶', () => {
  const zh = requestPrompt({ probe: true, language: 'zh' });
  assert.match(zh, /narration/);
  assert.match(zh, /affectionDelta/);
  assert.match(zh, /choices/);
  assert.match(zh, /memory/);
  assert.match(zh, /恰好 7 個/);
  assert.ok(zh.length < 2000, '檢測提示詞應保持短小');
  assert.doesNotMatch(zh, /知識之塔/, '不應載入玩家故事世界觀');

  const en = requestPrompt({ probe: true, language: 'en' });
  assert.match(en, /compatibility test/i);
  assert.match(en, /exactly 7/i);
  assert.match(en, /narration/);

  const system = requestSystemInstruction({ probe: true });
  assert.match(system, /JSON/i);
  assert.ok(system.length < 400, '檢測系統提示詞應保持短小');
  assert.doesNotMatch(system, /書庫守護者|圖書館/, '不應載入完整角色人設');
});

test('所有 API 供應商都有 probe 分支，DeepSeek 不套用 4096 下限', () => {
  assert.ok((serverSource.match(/body\.probe/g) || []).length >= 7, '每家供應商都要有 probe 分支');
  assert.match(serverSource, /const story=body\.probe\?\{__raw:text\}:parse\(text\)/);
  assert.match(serverSource, /if\(provider==='deepseek'\)\{[\s\S]*?if\(!body\.probe\)payload\.max_tokens=Math\.max\(g\.max_tokens,4096\)/);
  const configsStart = serverSource.indexOf('const configs={');
  const configsEnd = serverSource.indexOf('};', configsStart);
  const configs = serverSource.slice(configsStart, configsEnd);
  for (const provider of ['openai', 'openrouter', 'deepseek', 'groq', 'mistral', 'xai', 'qwen']) {
    assert.match(configs, new RegExp(`\\b${provider}:\\{`), `相容服務 ${provider} 仍在清單`);
  }
  assert.match(serverSource, /provider==='gemini'\?await gemini\(probeBody\):provider==='anthropic'\?await anthropic\(probeBody\):await compatible\(probeBody\)/);
  assert.match(serverSource, /app\.post\('\/api\/model-check'/);
  assert.match(serverSource, /export async function probeModel/);
});

test('不支援的服務在呼叫任何 API 前就失敗', async () => {
  await assert.rejects(() => probeModel({ provider: 'unknown-model-provider' }), /不支援的 AI 服務/);
});

test('App 接線：按鈕、端點、狀態列與雙語文字', () => {
  assert.match(html, /id="modelCheckBtn"[^>]*>模型通用性檢測</);
  assert.match(html, /id="modelCheckStatus"[^>]*role="status"[^>]*aria-live="polite"/);
  assert.match(appSource, /\$\('modelCheckBtn'\)\.onclick=\(\)=>void runModelCheck\(\)/);
  assert.match(appSource, /fetch\(base\+'\/api\/model-check'/);
  assert.match(appSource, /data\.checks\.map\(check=>/);
  const start = appSource.indexOf('const UI_EN = {');
  const end = appSource.indexOf('\n};', start);
  const dictionary = appSource.slice(start, end);
  for (const key of ['模型通用性檢測', '檢測中…', '正在用一段短場景檢查模型是否遵守 JSON 契約…', '模型通用性檢測失敗：']) {
    assert.ok(dictionary.includes(`'${key}':`), `UI_EN covers ${key}`);
  }
});
