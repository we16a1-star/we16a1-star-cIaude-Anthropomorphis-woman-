import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync, mkdtempSync, existsSync, writeFileSync, rmSync, mkdirSync, readdirSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {createRequire} from 'node:module';
import {Script, createContext} from 'node:vm';
import path from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';

const appDir = fileURLToPath(new URL('../..', import.meta.url));
const realRequire = createRequire(import.meta.url);
const mainSource = readFileSync(new URL('../../electron-main.cjs', import.meta.url), 'utf8');
const expectedRendererUrl = pathToFileURL(path.join(appDir, 'www', 'index.html')).href;

// 與真實 Electron safeStorage 相同形狀：加密回傳 Buffer，解密直接回傳字串。
function makeFakeElectron(userDataDir, handlers, shellCalls) {
  const shortcuts = new Map(); // 模擬 Windows 上的 .lnk：記錄每個捷徑目前指向哪個程式
  const shortcutControl = {failReplace: false, failCreate: false}; // 模擬 writeShortcutLink 失敗（例如權限、壞檔）
  const fakeSafeStorage = {
    isAsyncEncryptionAvailable: async () => true,
    encryptStringAsync: async plain => Buffer.from('ENC:' + String(plain), 'utf8'),
    decryptStringAsync: async buf => {
      const text = Buffer.isBuffer(buf) ? buf.toString('utf8') : String(buf ?? '');
      if (!text.startsWith('ENC:')) throw new Error('bad vault payload');
      return text.slice(4);
    }
  };
  return {
    app: {
      getPath: name => (name === 'userData' ? userDataDir : name === 'desktop' ? path.join(userDataDir, 'fake-desktop') : tmpdir()),
      getAppPath: () => appDir,
      isPackaged: true,
      whenReady: () => ({then() {}}),
      on() {},
      quit() {}
    },
    BrowserWindow: class {},
    shell: {
      openExternal: async () => {},
      writeShortcutLink: (linkPath, operation, options) => {
        shellCalls.push([linkPath, operation, options]);
        if (operation === 'replace' ? shortcutControl.failReplace : shortcutControl.failCreate) return false;
        mkdirSync(path.dirname(linkPath), {recursive: true});
        writeFileSync(linkPath, 'FAKE-LNK');
        shortcuts.set(path.resolve(linkPath).toLowerCase(), {...options, operation});
        return true;
      },
      // 真實 Electron 的 readShortcutLink 對「不存在或不是捷徑」的檔案會丟錯。
      readShortcutLink: linkPath => {
        const stored = shortcuts.get(path.resolve(linkPath).toLowerCase());
        if (!existsSync(linkPath) || !stored) throw new Error('not a shortcut link');
        return stored;
      }
    },
    shortcutStore: shortcuts,
    shortcutControl,
    dialog: {showErrorBox() {}, showSaveDialog: async () => ({canceled: true})},
    ipcMain: {handle: (name, fn) => { handlers[name] = fn; }},
    safeStorage: fakeSafeStorage,
    clipboard: {writeText() {}, readText: () => ''},
    screen: {getDisplayMatching: () => ({workArea: {x: 0, y: 0, width: 1280, height: 800}})}
  };
}

function loadMainOnce(userDataDir) {
  const handlers = {};
  const shellCalls = [];
  const fakeElectron = makeFakeElectron(userDataDir, handlers, shellCalls);
  const customRequire = request => {
    if (request === 'electron') return fakeElectron;
    if (request.startsWith('.')) return realRequire(path.join(appDir, request));
    return realRequire(request);
  };
  const context = createContext({
    require: customRequire,
    __dirname: appDir,
    module: {exports: {}},
    exports: {},
    process,
    Buffer,
    console,
    setTimeout,
    clearTimeout,
    setInterval,
    clearInterval,
    URL
  });
  new Script(mainSource, {filename: path.join(appDir, 'electron-main.cjs')}).runInContext(context);
  // 原檔在 app.whenReady() 才註冊 IPC；測試直接呼叫以取得 handlers。
  context.registerVaultIpc();
  return {handlers, context, shellCalls, shortcuts: fakeElectron.shortcutStore, shortcutControl: fakeElectron.shortcutControl};
}

const trustedEvent = {senderFrame: {url: expectedRendererUrl}};
const untrustedEvent = {senderFrame: {url: 'https://evil.example/'}};

test('API Key 可保存、列出、同步給本機後端，重開 App 後仍在，刪除後清除', async () => {
  const userDataDir = mkdtempSync(path.join(tmpdir(), 'cloudo-vault-test-'));
  const {handlers} = loadMainOnce(userDataDir);
  assert.ok(handlers['ai-vault:save'] && handlers['ai-vault:list'] && handlers['ai-vault:remove']);

  const saved = await handlers['ai-vault:save'](trustedEvent, {
    provider: 'openai', profileId: 'TEST', label: '測試帳號', apiKey: 'sk-test-123'
  });
  assert.equal(saved.ok, true);
  assert.equal(saved.envName, 'OPENAI_API_KEY_TEST');

  const listed = await handlers['ai-vault:list'](trustedEvent);
  assert.equal(listed.length, 1);
  assert.deepEqual(Object.keys(listed[0]).sort(), ['label', 'profileId', 'provider']);
  assert.ok(!JSON.stringify(listed).includes('sk-test-123'), '列出帳號時不得外洩金鑰本體');
  assert.equal(process.env.OPENAI_API_KEY_TEST, 'sk-test-123');

  // 模擬重開 App：全新模組狀態、同一 userData 目錄，必須讀回已保存的金鑰。
  // 這正是舊版 decryptStringAsync 誤用（.result）會失敗的迴歸點。
  const {handlers: handlers2} = loadMainOnce(userDataDir);
  const listedAfterRestart = await handlers2['ai-vault:list'](trustedEvent);
  assert.equal(listedAfterRestart.length, 1);
  assert.equal(listedAfterRestart[0].label, '測試帳號');
  assert.equal(process.env.OPENAI_API_KEY_TEST, 'sk-test-123');

  const removed = await handlers2['ai-vault:remove'](trustedEvent, {provider: 'openai', profileId: 'TEST'});
  assert.equal(removed.ok, true);
  assert.equal((await handlers2['ai-vault:list'](trustedEvent)).length, 0);

  // 同一實例內新增後刪除，環境變數必須同步清除（真實 App 即為單一實例）。
  const same = await handlers['ai-vault:save'](trustedEvent, {
    provider: 'openai', profileId: 'TMP', label: '暫存', apiKey: 'sk-tmp'
  });
  assert.equal(same.envName, 'OPENAI_API_KEY_TMP');
  assert.equal(process.env.OPENAI_API_KEY_TMP, 'sk-tmp');
  await handlers['ai-vault:remove'](trustedEvent, {provider: 'openai', profileId: 'TMP'});
  assert.equal(process.env.OPENAI_API_KEY_TMP, undefined);
  delete process.env.OPENAI_API_KEY_TEST;
});

test('API Key 保存會驗證格式並拒絕未授權的 renderer', async () => {
  const userDataDir = mkdtempSync(path.join(tmpdir(), 'cloudo-vault-test-'));
  const {handlers} = loadMainOnce(userDataDir);
  await assert.rejects(
    handlers['ai-vault:save'](trustedEvent, {provider: 'openai', profileId: 'bad id!', label: 'x', apiKey: 'sk-1'}),
    /帳號代號/
  );
  await assert.rejects(
    handlers['ai-vault:save'](untrustedEvent, {provider: 'openai', profileId: 'TEST', label: 'x', apiKey: 'sk-1'}),
    /未授權/
  );
  await assert.rejects(handlers['ai-vault:list'](untrustedEvent), /未授權/);
  assert.equal((await handlers['ai-vault:list'](trustedEvent)).length, 0);
});

test('金庫以原子寫入保存：先寫暫存檔再改名，寫入中斷不會毀掉既有金庫', async () => {
  const userDataDir = mkdtempSync(path.join(tmpdir(), 'cloudo-vault-test-'));
  const {handlers} = loadMainOnce(userDataDir);
  const saved = await handlers['ai-vault:save'](trustedEvent, {
    provider: 'openai', profileId: 'ATOM', label: '原子測試', apiKey: 'sk-atom-1'
  });
  assert.equal(saved.ok, true);
  assert.ok(existsSync(path.join(userDataDir, 'ai-credentials.bin')), '金庫檔已產生');
  assert.ok(!existsSync(path.join(userDataDir, 'ai-credentials.bin.tmp')), '改名後不留暫存檔');
  assert.deepEqual(readdirSync(userDataDir).filter(name => name.startsWith('ai-credentials')), ['ai-credentials.bin'], '金庫目錄只留正式檔');
  assert.match(mainSource, /fs\.writeFileSync\(temporary, encrypted\);[\s\S]{0,120}?fs\.renameSync\(temporary, target\);/,
    '金庫寫入沿用「暫存檔＋改名」的原子模式（寫壞暫存檔不會波及正式金庫）');
  await handlers['ai-vault:remove'](trustedEvent, {provider: 'openai', profileId: 'ATOM'});
});

test('金庫解不開或內容損毀時絕不當成空白金庫：讀／寫都報錯、原檔不被覆寫', async () => {
  const userDataDir = mkdtempSync(path.join(tmpdir(), 'cloudo-vault-test-'));
  const {handlers} = loadMainOnce(userDataDir);
  const vaultPath = path.join(userDataDir, 'ai-credentials.bin');
  await handlers['ai-vault:save'](trustedEvent, {provider: 'openai', profileId: 'KEEP', label: '保留', apiKey: 'sk-keep'});
  assert.ok(existsSync(vaultPath), '先建立一個有效的金庫');

  // 1) 檔案存在但解密失敗（例如別台電腦／別的 Windows 帳戶加密的檔案）
  const undecryptable = Buffer.from('無法解密-假資料');
  writeFileSync(vaultPath, undecryptable);
  await assert.rejects(handlers['ai-vault:list'](trustedEvent), /無法解密/, '列出帳號要明確報錯');
  await assert.rejects(
    handlers['ai-vault:save'](trustedEvent, {provider: 'openai', profileId: 'NEW', label: '新帳號', apiKey: 'sk-new'}),
    /無法解密/,
    '儲存不得在讀不到舊金鑰時直接覆寫整個金庫'
  );
  assert.deepEqual(readFileSync(vaultPath), undecryptable, '解不開的金庫原檔不得被覆寫');

  // 2) 解密成功但 JSON 損毀
  const brokenJson = Buffer.from('ENC:{oops');
  writeFileSync(vaultPath, brokenJson);
  await assert.rejects(handlers['ai-vault:list'](trustedEvent), /損毀/);
  await assert.rejects(handlers['ai-vault:remove'](trustedEvent, {provider: 'openai', profileId: 'KEEP'}), /損毀/);
  assert.deepEqual(readFileSync(vaultPath), brokenJson, '損毀的金庫原檔不得被覆寫');
  delete process.env.OPENAI_API_KEY_KEEP;
});

test('桌面捷徑每次啟動自我修復：缺少就建、失效就修、損毀就重建、正常或使用者自訂就不動', () => {
  const userDataDir = mkdtempSync(path.join(tmpdir(), 'cloudo-vault-test-'));
  const {context, shellCalls, shortcuts, shortcutControl} = loadMainOnce(userDataDir);
  const linkPath = path.join(userDataDir, 'fake-desktop', 'Claude娘 - Windows 11 電腦版.lnk');
  const key = path.resolve(linkPath).toLowerCase();
  assert.equal(typeof context.ensureDesktopShortcut, 'function');

  // 1) 桌面上沒有捷徑 → 建立，且指向目前執行的 exe
  assert.equal(context.ensureDesktopShortcut(), 'created');
  assert.equal(shellCalls.length, 1);
  assert.deepEqual([shellCalls[0][0], shellCalls[0][1]], [linkPath, 'create']);
  assert.equal(shellCalls[0][2].target, process.execPath);
  assert.equal(shellCalls[0][2].icon, context.appIconPath(), '圖示指向與桌面／工作列共用的 icon.ico');
  assert.match(shellCalls[0][2].icon, /icon\.ico$/i, '不是空白圖示，也不會退回 exe 內的舊快取');
  assert.equal(shellCalls[0][2].appUserModelId, 'com.claude.novel.windows11', '捷徑帶正確 AUMID，工作列才會分到同一組');

  // 2) 捷徑存在且指向正確 → 完全不打擾（不會每次啟動都重寫）
  assert.equal(context.ensureDesktopShortcut(), 'kept');
  assert.equal(shellCalls.length, 1, '正常捷徑不重寫');

  // 2b) 目標正確但圖示還是舊的／沒有 AUMID → 就地更新，不重建、不改名稱
  shortcuts.set(key, {target: process.execPath, description: '舊捷徑', icon: 'C:\\old\\icon.ico'});
  let before = shellCalls.length;
  assert.equal(context.ensureDesktopShortcut(), 'icon-repaired');
  assert.equal(shellCalls.length, before + 1, '只更新一次');
  assert.equal(shellCalls.at(-1)[1], 'update', '用 update 保留使用者的捷徑名稱與位置');
  assert.equal(shortcuts.get(key).icon, context.appIconPath(), '更新成共用的 icon.ico');
  assert.equal(shortcuts.get(key).appUserModelId, 'com.claude.novel.windows11', '補上工作列分組用的 AUMID');

  // 3) 捷徑被刪掉 → 重建。舊版會被 desktop-shortcut.created 標記檔卡住而永遠不重建。
  rmSync(linkPath);
  shortcuts.delete(key);
  assert.equal(context.ensureDesktopShortcut(), 'created');
  assert.equal(shellCalls.length, 3);
  assert.equal(shellCalls.at(-1)[1], 'create');

  // 4) 捷徑指向已經不存在的 exe（安裝升級／搬移後最常見）→ 重新指向目前的 exe
  writeFileSync(linkPath, 'FAKE-LNK');
  shortcuts.set(key, {target: path.join(userDataDir, 'old-install', 'gone.exe'), description: '舊版'});
  assert.equal(context.ensureDesktopShortcut(), 'repaired');
  assert.equal(shellCalls.at(-1)[1], 'replace');
  assert.equal(shellCalls.at(-1)[2].target, process.execPath);

  // 4b) 捷徑檔本身損毀（readShortcutLink 會丟錯）→ 直接刪掉重建成新的。
  //     實測 Electron：writeShortcutLink(..., 'replace', ...) 對壞檔只會回 false、什麼都不做，靠它修不好。
  writeFileSync(linkPath, 'not a shortcut');
  shortcuts.delete(key);
  before = shellCalls.length;
  assert.equal(context.ensureDesktopShortcut(), 'repaired');
  assert.equal(shellCalls.length, before + 1, '壞檔不浪費一次註定失敗的 replace');
  assert.equal(shellCalls.at(-1)[1], 'create');
  assert.equal(shellCalls.at(-1)[2].target, process.execPath);

  // 4c) replace 回報失敗（權限、被鎖住…）→ 也要能退回「刪掉重建」
  writeFileSync(linkPath, 'FAKE-LNK');
  shortcuts.set(key, {target: path.join(userDataDir, 'old-install', 'gone.exe')});
  shortcutControl.failReplace = true;
  before = shellCalls.length;
  assert.equal(context.ensureDesktopShortcut(), 'repaired');
  shortcutControl.failReplace = false;
  assert.deepEqual(shellCalls.slice(before).map(call => call[1]), ['replace', 'create'], 'replace 失敗就刪掉重建');
  assert.equal(shortcuts.get(key).target, process.execPath);

  // 4d) 連 create 都失敗（例如磁碟唯讀）→ 回報 failed，但絕不讓 App 啟動失敗
  writeFileSync(linkPath, 'not a shortcut');
  shortcuts.delete(key);
  shortcutControl.failCreate = true;
  assert.equal(context.ensureDesktopShortcut(), 'failed');
  shortcutControl.failCreate = false;

  // 5) 使用者自己把捷徑指到別的「有效」程式 → 尊重使用者，不覆寫
  const otherExe = path.join(userDataDir, 'other.exe');
  writeFileSync(otherExe, 'MZ');
  shortcuts.set(key, {target: otherExe});
  writeFileSync(linkPath, 'FAKE-LNK');
  before = shellCalls.length;
  assert.equal(context.ensureDesktopShortcut(), 'kept');
  assert.equal(shellCalls.length, before, '不覆寫使用者自訂的有效目標');

  // 6) 開發模式不建立指向 electron.exe 的壞捷徑、且不再用標記檔判斷
  assert.match(mainSource, /!app\.isPackaged/, '開發模式不建立指向 electron.exe 的壞捷徑');
  assert.ok(!/existsSync\([^)]*desktop-shortcut\.created/.test(mainSource), '不再用標記檔決定要不要修');
});

test('安裝程式可以自選磁碟槽，並建立桌面與開始選單捷徑', () => {
  const pkg = JSON.parse(readFileSync(new URL('../../package.json', import.meta.url), 'utf8'));
  // 使用者要求「能選擇哪個槽安裝」。NSIS 的一鍵模式（oneClick:true）不能有安裝路徑頁，
  // electron-builder 會直接丟 InvalidConfigurationError，所以必須用精靈模式 + 路徑頁；
  // 想一路裝到底的人只要連續按「安裝」即可（預設位置就是原本那個）。
  assert.equal(pkg.build.nsis.oneClick, false, '要有畫面才能選安裝位置');
  assert.equal(pkg.build.nsis.allowToChangeInstallationDirectory, true, '必須有「選擇安裝位置」頁');
  assert.equal(pkg.build.nsis.perMachine, false, '預設裝到目前帳戶，不強制提權');
  assert.equal(pkg.build.nsis.allowElevation, true, '使用者選到需要權限的位置（例如 C:\\Program Files）時要能提權');
  assert.equal(pkg.build.nsis.createDesktopShortcut, true);
  assert.equal(pkg.build.nsis.createStartMenuShortcut, true);
  assert.equal(pkg.build.nsis.runAfterFinish, true);
  assert.equal(pkg.build.nsis.deleteAppDataOnUninstall, false, '解除安裝不會刪掉玩家存檔');
});
