// 不用ID就能玩＋ID可以是選項＋有需要才用（追加九／使用者要求）：
// 代號平常自動產生（不用選），有需要才從選單挑選或自訂。
// 三層護欄：行為、畫面文案與選項、UI_EN 中英對照。
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { Script } from 'node:vm';

const app = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');
const html = readFileSync(new URL('../../www/index.html', import.meta.url), 'utf8');

test('不用ID就能玩：帳號代號平常自動產生，自訂代號仍驗證格式', () => {
  assert.match(app, /function nextAutoProfileId\(provider\)/, '自動代號產生器存在');
  assert.match(app, /const profileIdChoice=\$\('aiProfileId'\)\.value;/, '先讀代號選單');
  assert.match(app, /profileIdChoice==='__custom__'\?\$\('aiProfileIdCustom'\)\.value:profileIdChoice/, '選「自訂代號」才讀自訂輸入');
  assert.match(app, /profileIdInput\?normalizeProfileId\(profileIdInput\):nextAutoProfileId\(provider\)/, '平常（未選／留空）用自動代號；有輸入才走原本的正規化');
  assert.match(app, /帳號代號需為 1 至 32 個英文字母、數字或底線。/, '自訂但格式錯誤仍會提示（護欄不變）');

  const start = app.indexOf('function nextAutoProfileId(');
  const end = app.indexOf('\n}', start) + 2;
  assert.ok(start >= 0 && end > start, '產生器片段可截取');
  const context = {
    aiConnections: [{ provider: 'openai', profileId: 'AUTO_1' }],
    aiVaultProfiles: [{ provider: 'openai', profileId: 'AUTO_2' }],
    Date
  };
  new Script(app.slice(start, end) + '\nthis.next=nextAutoProfileId;').runInNewContext(context);
  assert.equal(context.next('openai'), 'AUTO_3', '會跳過帳號清單與金庫已使用的代號');
  assert.equal(context.next('gemini'), 'AUTO_1', '不同服務分開編號');
  assert.match(context.next('openai'), /^[A-Z0-9_]{1,32}$/, '自動產生的代號符合主程序驗證規則');
});

test('ID可以是選項：代號欄是選單（自動產生＋預設選項＋自訂），有需要才用', () => {
  assert.match(html, /<select id="aiProfileId" aria-label="API 帳號代號">/, '代號欄改成選單');
  assert.ok(html.includes('自動產生（預設，不用選）'), '預設＝自動產生（不用選）');
  for (const value of ['PERSONAL', 'WORK', 'BACKUP', 'FAMILY', 'TEST']) {
    assert.ok(html.includes(`<option value="${value}">`), `有可挑選的選項 ${value}`);
  }
  assert.ok(html.includes('id="aiProfileIdCustom"'), '有「自訂代號」輸入框（有需要才用）');
  assert.ok(html.includes('平常不用選'), '欄位說明寫明平常不用選');
  assert.match(app, /function syncAiProfileIdCustom\(\)/, '自訂框顯示切換存在');
  assert.match(app, /\$\('aiProfileId'\)\.onchange=syncAiProfileIdCustom;/, '選單切換會同步自訂框');
  assert.match(app, /const profileIdPreset=\[\.\.\.\$\('aiProfileId'\)\.options\]\.some\(o=>o\.value===profileId\);/, '編輯既有帳號時會還原選項狀態（自訂值不遺失）');
});

test('不用ID就能玩：畫面與 UI_EN 同步（標章、流程與新字串）', () => {
  assert.ok(html.includes('不想設定 API 帳號也可以完全跳過'), '帳號流程第一條說明可完全跳過');
  assert.ok(html.includes('免登入 · 免ID'), '選單標章承諾免登入免ID');
  const keys = [
    '平常不用選：系統會自動產生代號。有需要再挑選或自訂（英文字母、數字或底線；同一服務的每組 API Key 使用不同代號）。',
    '自動產生（預設，不用選）',
    '個人 · PERSONAL',
    '工作 · WORK',
    '備用 · BACKUP',
    '家人 · FAMILY',
    '測試 · TEST',
    '自訂代號…',
    '自訂代號',
    '不想設定 API 帳號也可以完全跳過：直接用下方的「免費版 AI 網頁服務」開始故事，不必在 App 裡建立任何 ID 或 API Key。',
    '免登入 · 免ID'
  ];
  for (const key of keys) {
    assert.ok(app.includes(`'${key}':`), `UI_EN 有中英對照：${key.slice(0, 12)}…`);
  }
});
