// 追加九：世界書（關鍵詞觸發）的閘門。
// 釘住三件事：純模組邊界（正規化）、命中規則（大小寫／去重／上限）、
// 注入字串（未啟用或未命中＝完全不追加任何行）。server.js 與 app.js 的接線斷言也在本檔。
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import {
  WORLD_BOOK_LIMITS, WORLD_BOOK_HEADER,
  normalizeWorldBookEntry, normalizeWorldBook, matchWorldBook, matchWorldBookDetailed,
  worldBookPromptLines, worldBookPreview, parseWorldBookImport, mergeWorldBookEntries,
  exportWorldBook, worldBookEntryKey
} from '../../www/world-book.js';

test('worldBook 正規化：壞資料不崩、關鍵詞 trim／去重（不分大小寫）與長度上限', () => {
  assert.deepEqual(normalizeWorldBook(undefined), { enabled: false, entries: [] });
  assert.deepEqual(normalizeWorldBook(null), { enabled: false, entries: [] });
  assert.deepEqual(normalizeWorldBook({ enabled: 'yes', entries: 'x' }), { enabled: false, entries: [] });
  const entry = normalizeWorldBookEntry({ id: 7, keywords: [' Dragon ', 'dragon', 'DRAGON', '', 42, '  龍  '], text: '  遠古巨龍沉睡於此  ', enabled: true });
  assert.deepEqual(entry, {
    id: '7', keywords: ['Dragon', '龍'], text: '遠古巨龍沉睡於此', enabled: true,
    constant: false, priority: 'normal', scope: 'all'
  });
  assert.deepEqual(normalizeWorldBookEntry('nope'), {
    id: '', keywords: [], text: '', enabled: false,
    constant: false, priority: 'normal', scope: 'all'
  });
  const long = normalizeWorldBookEntry({ keywords: ['字'.repeat(50)] });
  assert.equal(long.keywords[0].length, WORLD_BOOK_LIMITS.keywordLength);
  const many = normalizeWorldBookEntry({ keywords: Array.from({ length: 12 }, (_, i) => 'k' + i) });
  assert.equal(many.keywords.length, WORLD_BOOK_LIMITS.keywordsPerEntry);
  const fat = normalizeWorldBookEntry({ text: 'x'.repeat(2000) });
  assert.equal(fat.text.length, WORLD_BOOK_LIMITS.entryText);
});

test('worldBook 正規化：三新欄預設與合法值；舊資料＝現行行為', () => {
  const legacy = normalizeWorldBookEntry({ id: 'legacy', keywords: ['雨'], text: '雨天', enabled: true });
  assert.deepEqual(legacy, {
    id: 'legacy', keywords: ['雨'], text: '雨天', enabled: true,
    constant: false, priority: 'normal', scope: 'all'
  });
  const full = normalizeWorldBookEntry({
    id: 'full', keywords: ['雨'], text: '雨天', enabled: true,
    constant: true, priority: 'high', scope: 'opening'
  });
  assert.deepEqual(full, {
    id: 'full', keywords: ['雨'], text: '雨天', enabled: true,
    constant: true, priority: 'high', scope: 'opening'
  });
  const bad = normalizeWorldBookEntry({ constant: 'true', priority: 'urgent', scope: 'global' });
  assert.equal(bad.constant, false);
  assert.equal(bad.priority, 'normal');
  assert.equal(bad.scope, 'all');
});

test('worldBook 正規化：空條目剔除、條目數上限、舊存檔＝未啟用空清單', () => {
  const book = normalizeWorldBook({ enabled: true, entries: [{}, { id: 'x' }, null, { keywords: ['a'] }] });
  assert.equal(book.enabled, true);
  assert.equal(book.entries.length, 2);
  assert.deepEqual(book.entries[0], {
    id: 'x', keywords: [], text: '', enabled: false,
    constant: false, priority: 'normal', scope: 'all'
  });
  assert.deepEqual(book.entries[1], {
    id: '', keywords: ['a'], text: '', enabled: false,
    constant: false, priority: 'normal', scope: 'all'
  });
  const wide = normalizeWorldBook({ enabled: true, entries: Array.from({ length: 60 }, (_, i) => ({ id: 'e' + i, keywords: ['k'], text: 't' + i, enabled: true })) });
  assert.equal(wide.entries.length, WORLD_BOOK_LIMITS.entries);
});

test('worldBook 命中：子字串、不分大小寫；條目或總開關關閉＝不命中', () => {
  const book = { enabled: true, entries: [
    { id: 'a', keywords: ['圖書館'], text: '圖書館的設定', enabled: true },
    { id: 'b', keywords: ['Library'], text: 'LIB 的設定', enabled: true },
    { id: 'c', keywords: ['圖書館'], text: '關閉的條目', enabled: false },
    { id: 'd', keywords: ['圖書館'], text: '', enabled: true }
  ]};
  assert.deepEqual(matchWorldBook(book, '我走進圖書館深處。').map(e => e.id), ['a']);
  assert.deepEqual(matchWorldBook(book, 'The library is quiet.').map(e => e.id), ['b']);
  assert.deepEqual(matchWorldBook({ ...book, enabled: false }, '圖書館'), []);
  assert.deepEqual(matchWorldBook(book, ''), []);
  assert.deepEqual(matchWorldBook(book, undefined), []);
});

test('worldBook 常駐：無關鍵詞也命中；scope 三值依 phase 過濾；舊呼叫不帶 phase＝全部', () => {
  const book = { enabled: true, entries: [
    { id: 'constant', keywords: [], text: '常駐設定', enabled: true, constant: true, priority: 'normal', scope: 'all' },
    { id: 'opening', keywords: ['序'], text: '開場設定', enabled: true, constant: false, priority: 'normal', scope: 'opening' },
    { id: 'chat', keywords: ['序'], text: '對話設定', enabled: true, constant: false, priority: 'normal', scope: 'chat' },
    { id: 'all', keywords: ['序'], text: '全體設定', enabled: true, constant: false, priority: 'normal', scope: 'all' }
  ]};
  assert.deepEqual(matchWorldBook(book, '序', { phase: 'opening' }).map(e => e.id), ['constant', 'opening', 'all']);
  assert.deepEqual(matchWorldBook(book, '序', { phase: 'chat' }).map(e => e.id), ['constant', 'chat', 'all']);
  assert.deepEqual(matchWorldBook(book, '序').map(e => e.id), ['constant', 'opening', 'chat', 'all']);
  assert.deepEqual(matchWorldBook(book, '', { phase: 'chat' }).map(e => e.id), ['constant'], '常駐不需命中詞');
  assert.deepEqual(matchWorldBook({ ...book, enabled: false }, '序', { phase: 'chat' }), []);
  const disabled = { enabled: true, entries: [{ ...book.entries[0], enabled: false }] };
  assert.deepEqual(matchWorldBook(disabled, '', { phase: 'chat' }), []);
});

test('worldBook 排序：priority→常駐→原索引；先收集全部再取 8 條', () => {
  const book = { enabled: true, entries: [
    { id: 'l0', keywords: ['k'], text: 'L0', enabled: true, priority: 'low' },
    { id: 'h1', keywords: ['k'], text: 'H1', enabled: true, priority: 'high' },
    { id: 'h2', keywords: [], text: 'H2', enabled: true, constant: true, priority: 'high' },
    { id: 'n3', keywords: [], text: 'N3', enabled: true, constant: true, priority: 'normal' },
    { id: 'n4', keywords: ['k'], text: 'N4', enabled: true, priority: 'normal' },
    { id: 'h5', keywords: ['k'], text: 'H5', enabled: true, priority: 'high' },
    { id: 'n6', keywords: [], text: 'N6', enabled: true, constant: true, priority: 'normal' }
  ]};
  assert.deepEqual(matchWorldBook(book, 'k', { phase: 'chat' }).map(e => e.id), ['h2', 'h1', 'h5', 'n3', 'n6', 'n4', 'l0']);
  const detailed = matchWorldBookDetailed(book, 'k', { phase: 'chat' });
  assert.deepEqual(detailed.map(hit => hit.reason), ['constant', 'keyword', 'keyword', 'constant', 'constant', 'keyword', 'keyword']);
  assert.deepEqual(detailed.map(hit => hit.index), [2, 1, 5, 3, 6, 4, 0]);
  const ten = { enabled: true, entries: Array.from({ length: 10 }, (_, i) => ({
    id: 'x' + i, keywords: ['k'], text: 'T' + i, enabled: true, priority: i === 9 ? 'high' : 'low'
  })) };
  assert.deepEqual(matchWorldBook(ten, 'k', { phase: 'chat' }).map(e => e.id), ['x9', 'x0', 'x1', 'x2', 'x3', 'x4', 'x5', 'x6']);
  assert.equal(matchWorldBookDetailed(ten, 'k', { phase: 'chat' }).length, 10, '詳細命中保留全部，供預覽顯示截斷');
});

test('worldBook 注入：未命中＝零行（逐字元相容）；命中＝標頭＋文字；8 條與總字數上限', () => {
  const book = { enabled: true, entries: [{ id: 'a', keywords: ['雨'], text: '雨天設定', enabled: true }] };
  assert.deepEqual(worldBookPromptLines(book, '晴朗的午後', 'zh'), []);
  assert.deepEqual(worldBookPromptLines({ ...book, enabled: false }, '雨', 'zh'), []);
  assert.deepEqual(worldBookPromptLines(book, '雨聲沿著彩窗滑落', 'zh'), [WORLD_BOOK_HEADER.zh, '雨天設定']);
  assert.deepEqual(worldBookPromptLines(book, '雨聲', 'en'), [WORLD_BOOK_HEADER.en, '雨天設定']);
  const many = { enabled: true, entries: Array.from({ length: 12 }, (_, i) => ({ id: 'm' + i, keywords: ['關鍵'], text: 'T' + i, enabled: true })) };
  assert.equal(worldBookPromptLines(many, '關鍵字', 'zh').length, WORLD_BOOK_LIMITS.injectEntries + 1);
  const fat = { enabled: true, entries: [
    { id: 'f1', keywords: ['胖'], text: 'A'.repeat(800), enabled: true },
    { id: 'f2', keywords: ['胖'], text: 'B'.repeat(800), enabled: true }
  ]};
  const fatLines = worldBookPromptLines(fat, '胖子', 'zh');
  assert.equal(fatLines.length, 2);
  assert.equal(fatLines[1], 'A'.repeat(800));
});

test('worldBook 預覽：與實際注入同挑選器；常駐／scope／上限／預算截斷', () => {
  const ten = { enabled: true, entries: Array.from({ length: 10 }, (_, i) => ({
    id: 'p' + i, keywords: ['k'], text: 'P' + i, enabled: true, priority: 'low'
  })) };
  const preview = worldBookPreview(ten, 'k', 'zh', { phase: 'chat' });
  assert.equal(preview.count, 10);
  assert.equal(preview.chars, 16);
  assert.equal(preview.lines.length, WORLD_BOOK_LIMITS.injectEntries + 1);
  assert.equal(preview.matched.length, 10);
  assert.equal(preview.truncated, true);
  assert.deepEqual(preview.lines, worldBookPromptLines(ten, 'k', 'zh', { phase: 'chat' }));
  const eight = { enabled: true, entries: ten.entries.slice(0, 8) };
  const exact = worldBookPreview(eight, 'k', 'zh', { phase: 'chat' });
  assert.equal(exact.count, 8);
  assert.equal(exact.truncated, false);
  assert.deepEqual(exact.lines, worldBookPromptLines(eight, 'k', 'zh', { phase: 'chat' }));
  const fat = { enabled: true, entries: [
    { id: 'f1', keywords: ['胖'], text: 'A'.repeat(800), enabled: true },
    { id: 'f2', keywords: ['胖'], text: 'B'.repeat(800), enabled: true }
  ]};
  const fatPreview = worldBookPreview(fat, '胖', 'zh', { phase: 'chat' });
  assert.equal(fatPreview.count, 2);
  assert.equal(fatPreview.chars, 800);
  assert.equal(fatPreview.lines.length, 2);
  assert.equal(fatPreview.truncated, true);
  assert.deepEqual(fatPreview.lines, worldBookPromptLines(fat, '胖', 'zh', { phase: 'chat' }));
  const constant = { enabled: true, entries: [
    { id: 'c', keywords: [], text: '常駐', enabled: true, constant: true, priority: 'normal', scope: 'all' }
  ]};
  const constantPreview = worldBookPreview(constant, '', 'zh', { phase: 'chat' });
  assert.equal(constantPreview.count, 1);
  assert.deepEqual(constantPreview.lines, [WORLD_BOOK_HEADER.zh, '常駐']);
  assert.deepEqual(constantPreview.lines, worldBookPromptLines(constant, '', 'zh', { phase: 'chat' }));
});

test('單書匯出／匯入：單書、裸書、kit 三型辨識；空書＝錯誤；>50 條截斷', () => {
  const book = { enabled: true, entries: [
    { id: 'a', keywords: ['雨'], text: '雨天', enabled: true },
    { id: 'b', keywords: [], text: '常駐', enabled: true, constant: true, priority: 'high', scope: 'chat' }
  ]};
  const exported = exportWorldBook(book);
  assert.equal(exported.format, 'claude-novel-worldbook');
  assert.equal(exported.version, 1);
  assert.match(exported.exportedAt, /^\d{4}-\d{2}-\d{2}T/);
  const single = parseWorldBookImport(exported);
  assert.equal(single.ok, true);
  assert.equal(single.source, 'single');
  assert.equal(single.book.entries.length, 2);
  assert.equal(single.book.entries[1].constant, true);
  assert.equal(parseWorldBookImport(book).source, 'bare');
  assert.equal(parseWorldBookImport({ app: 'cioudo10', version: 1, payload: { worldBook: book } }).source, 'kit');
  assert.deepEqual(parseWorldBookImport({ foo: 1 }), { ok: false, error: 'format', source: '' });
  assert.deepEqual(parseWorldBookImport({ enabled: true, entries: [] }), { ok: false, error: 'empty', source: 'bare' });
  const many = parseWorldBookImport({ enabled: true, entries: Array.from({ length: 60 }, (_, i) => ({ id: 'e' + i, keywords: ['k'], text: 'T' + i, enabled: true })) });
  assert.equal(many.ok, true);
  assert.equal(many.book.entries.length, 50);
  assert.equal(many.truncated, true);
});

test('匯入衝突：合併／覆蓋／略過；缺 id 以首關鍵詞＋文字比對；不自動開主開關', () => {
  const current = { enabled: false, entries: [{ id: 'a', keywords: ['old'], text: 'OLD', enabled: true }] };
  const incoming = { enabled: true, entries: [
    { id: 'a', keywords: ['new'], text: 'NEW', enabled: true },
    { id: 'b', keywords: ['b'], text: 'B', enabled: true }
  ]};
  const merged = mergeWorldBookEntries(current, incoming, 'merge');
  assert.equal(merged.book.enabled, false, '匯入不自動開主開關');
  assert.deepEqual(merged.book.entries.map(e => e.id), ['a', 'b']);
  assert.equal(merged.book.entries[0].text, 'OLD');
  assert.equal(merged.added, 1);
  assert.equal(merged.overwritten, 0);
  assert.equal(merged.skipped, 1);
  const overwritten = mergeWorldBookEntries(current, incoming, 'overwrite');
  assert.equal(overwritten.book.entries[0].text, 'NEW');
  assert.equal(overwritten.overwritten, 1);
  assert.equal(overwritten.added, 1);
  const skipped = mergeWorldBookEntries(current, incoming, 'skip');
  assert.equal(skipped.book.entries[0].text, 'OLD');
  assert.equal(skipped.skipped, 1);
  const bareA = { keywords: ['雨'], text: '雨天', enabled: true };
  const bareB = { keywords: ['雨'], text: '雨天', enabled: true };
  assert.equal(worldBookEntryKey(bareA), worldBookEntryKey(bareB));
  const fallback = mergeWorldBookEntries({ enabled: true, entries: [bareA] }, { enabled: true, entries: [bareB] }, 'overwrite');
  assert.equal(fallback.book.entries.length, 1);
  assert.equal(fallback.overwritten, 1);
  const full = { enabled: true, entries: Array.from({ length: 50 }, (_, i) => ({ id: 'f' + i, keywords: ['k'], text: 'T' + i, enabled: true })) };
  const overflow = mergeWorldBookEntries(full, { enabled: true, entries: [{ id: 'new', keywords: ['k'], text: 'NEW', enabled: true }] }, 'merge');
  assert.equal(overflow.book.entries.length, 50);
  assert.equal(overflow.added, 0);
  assert.equal(overflow.truncated, true);
});

test('server.js API：世界書未命中＝零行；命中＝標頭＋文字（在最近對話之後）', async () => {
  const { requestPrompt } = await import('../../server/server.js');
  const base = { language: 'zh', action: '我走向圖書館深處', history: [{ role: 'ai', text: '（先前故事）' }] };
  const off = requestPrompt(base);
  assert.ok(!off.includes('世界書'), '未帶世界書＝零影響');
  const book = { enabled: true, entries: [{ id: 'a', keywords: ['圖書館'], text: '圖書館的設定文字', enabled: true }] };
  const on = requestPrompt({ ...base, worldBook: book });
  assert.ok(on.includes('世界書（命中關鍵詞，僅供參考）：'));
  assert.ok(on.includes('圖書館的設定文字'));
  assert.ok(on.indexOf('世界書（') > on.indexOf('最近1則對話'), '世界書在最近對話之後');
  const miss = requestPrompt({ ...base, action: '我靜靜坐著', worldBook: book });
  assert.ok(!miss.includes('世界書（命中關鍵詞'), '沒有命中＝不注入');
  const disabled = requestPrompt({ ...base, worldBook: { ...book, enabled: false } });
  assert.ok(!disabled.includes('世界書（命中關鍵詞'));
});

test('server.js API：phase 由伺服器自判；opening／chat scope 生效、請求不加欄位', async () => {
  const { requestPrompt } = await import('../../server/server.js');
  const book = { enabled: true, entries: [
    { id: 'open', keywords: [], text: 'OPENING_ONLY', enabled: true, constant: true, priority: 'normal', scope: 'opening' },
    { id: 'chat', keywords: [], text: 'CHAT_ONLY', enabled: true, constant: true, priority: 'normal', scope: 'chat' },
    { id: 'all', keywords: [], text: 'ALL_SCOPE', enabled: true, constant: true, priority: 'normal', scope: 'all' }
  ]};
  const opening = requestPrompt({ language: 'zh', action: '__OPENING_STYLE__:rainy_first_meeting', history: [], worldBook: book });
  assert.ok(opening.includes('OPENING_ONLY'));
  assert.ok(opening.includes('ALL_SCOPE'));
  assert.ok(!opening.includes('CHAT_ONLY'));
  const chat = requestPrompt({ language: 'zh', action: '我走進書庫', history: [{ role: 'ai', text: '先前故事' }], worldBook: book });
  assert.ok(chat.includes('CHAT_ONLY'));
  assert.ok(chat.includes('ALL_SCOPE'));
  assert.ok(!chat.includes('OPENING_ONLY'));
});

test('app.js 接線：存檔欄位、命中池與網頁提示詞注入（phase、未命中＝零追加行）', () => {
  const appSource = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');
  assert.match(appSource, /import \{ normalizeWorldBook, normalizeWorldBookEntry, worldBookPromptLines, worldBookPreview, parseWorldBookImport, mergeWorldBookEntries, exportWorldBook \} from '\.\/world-book\.js';/, '匯入世界書模組');
  assert.match(appSource, /worldBook: \{ enabled: false, entries: \[\] \},/, 'fresh() 預設欄位（未使用＝關閉空清單）');
  assert.match(appSource, /worldBook: normalizeWorldBook\(rawState\.worldBook\),/, 'normalizeSlot 正規化世界書');
  assert.match(appSource, /worldBook: normalizeWorldBook\(source\.worldBook\),/, 'serializeState 正規化世界書');
  assert.match(appSource, /worldBook:normalizeWorldBook\(state\.worldBook\),/, 'API 請求帶上世界書');
  assert.match(appSource, /const worldBookLines=worldBookPromptLines\(state\.worldBook,\(transcript\|\|''\)\+'\\n'\+chosen,uiLanguage,\{phase:isOpening\?'opening':'chat'\}\);/, '網頁提示詞命中池＝轉錄＋玩家行動＋phase');
  assert.match(appSource, /\.\.\.worldBookLines,/, '命中才展開注入行');
});
