import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createServer} from 'node:http';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {Script} from 'node:vm';
import {OPENING_STYLES, openingStylePrompt, resolveOpeningStyle} from '../../www/opening-styles.js';
import {snapshotForRollback} from '../../www/save-state.js';
import {compactSlotsForStorage, writeVerified} from '../../www/save-storage.js';
import {GIFT_CORRECT_AFFECTION,GIFT_MULTIPLE_CHANCE,GIFT_SINGLE_CHANCE,GIFT_WRONG_AFFECTION,normalizeDifficulty,normalizeGiftConversations,resolveGiftAffection,rollGiftConversations} from '../../www/gift-system.js';
import {DEFAULT_CHARACTER_PROFILE, B5_PREVIOUS_DEFAULT_CHARACTER_PROFILE, B6_PREVIOUS_DEFAULT_CHARACTER_PROFILE, B7_PREVIOUS_DEFAULT_CHARACTER_PROFILE, B8_PREVIOUS_DEFAULT_CHARACTER_PROFILE, LEGACY_PRE_TSUNDERE_CHARACTER_PROFILE, LEGACY_TSUNDERE_CHARACTER_PROFILE} from '../../www/character-profile.js';
import {MAX_CHARACTER_PORTRAIT_DATA_URL_LENGTH,normalizeCharacterPortrait} from '../../www/character-portrait.js';
import {translateError} from '../../www/ui-error.js';
import {parse, prompt, startApiServer, systemInstruction} from '../../server/server.js';
import {OUTPUT_TARGET} from '../../www/token-budget.js';
import {advanceStoryClock,affectionStageKeyOf,affectionStageOf,normalizeStoryClock,realStoryClock,stageByKey,stageIndexByKey,storyClockLabel} from '../../www/story-clock.js';

// 追加八：applyTurn／giveGift 的沙盒需要故事時間與階段函式（提示詞與存檔模組共用同一份）。
const storyClockHelpers={advanceStoryClock,affectionStageKeyOf,affectionStageOf,normalizeStoryClock,realStoryClock,stageByKey,stageIndexByKey,refreshTimeTheme:()=>{},uiText:value=>value,rollSpecialEvent:()=>''};

const story={
  narration:'她翻開書頁，墨跡裡留著一枚尚未乾透的星形印記。',
  affectionDelta:1,
  choices:['詢問印記來源','協助檢查書頁','查看窗外天色','請她說明警報','保持安靜觀察','提出一起調查','先到前台尋找線索'],
  ending:false,
  endingText:null,
  memory:'兩人初次相遇，發現古書上的異常印記。'
};

test('gift conversations use the requested single and rare multi-event probabilities',()=>{
  assert.equal(GIFT_SINGLE_CHANCE,0.03);
  assert.equal(GIFT_MULTIPLE_CHANCE,0.0002);
  const randomAfterRoll=()=>{let seed=27;return()=>{seed=(seed*1664525+1013904223)>>>0;return seed/0x100000000;};};
  const withFirst=(value,tail)=>{let first=true;return()=>first?(first=false,value):tail();};
  assert.deepEqual(rollGiftConversations(()=>0.5),[],'no gift appears outside the 3% interval');
  const single=rollGiftConversations(withFirst(0.01,randomAfterRoll()));
  assert.equal(single.length,1);
  const multiRoll=randomAfterRoll();
  let values=[0.0001,0.7];
  const multiple=rollGiftConversations(()=>values.length?values.shift():multiRoll());
  assert.ok(multiple.length>=2&&multiple.length<=3,'the 0.02% rare result presents multiple gift conversations together');
  for(const conversation of [...single,...multiple]){
    assert.equal(conversation.options.length,3);
    assert.equal(new Set(conversation.options.map(option=>option.id)).size,3);
    assert.ok(conversation.options.some(option=>option.id===conversation.correctOptionId));
    assert.ok(conversation.hint&&conversation.hintEn);
  }
});

test('gift affection rewards exact answers and very easy mode prevents deductions',()=>{
  const conversation={correctOptionId:'tea',options:[{id:'tea'},{id:'book'},{id:'pen'}]};
  assert.deepEqual(resolveGiftAffection(conversation,'tea'),{correct:true,delta:1.5});
  assert.deepEqual(resolveGiftAffection(conversation,'book'),{correct:false,delta:-1});
  assert.deepEqual(resolveGiftAffection(conversation,'book','veryEasy'),{correct:false,delta:0});
  assert.deepEqual(resolveGiftAffection(conversation,'book','easy'),{correct:false,delta:-0.5});
  assert.deepEqual(resolveGiftAffection(conversation,'book','hard'),{correct:false,delta:-1.5});
  assert.deepEqual(resolveGiftAffection(conversation,'tea','veryHard'),{correct:true,delta:1});
  assert.deepEqual(resolveGiftAffection(conversation,'book','veryHard'),{correct:false,delta:-2});
  assert.equal(resolveGiftAffection(conversation,'not-an-option'),null);
  assert.equal(normalizeDifficulty('veryEasy'),'veryEasy');
  assert.equal(normalizeDifficulty('unsupported'),'normal');
  assert.equal(normalizeGiftConversations([conversation]).length,0,'incomplete/corrupt pending events are rejected');

  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const start=source.indexOf('function handleAffectionStageChange(');
  const end=source.indexOf('\nfunction refreshGiftConversations()',start);
  const context={...storyClockHelpers,state:{affection:50,difficulty:'veryEasy',history:[],choices:[],ending:false,storyMemory:''},sanitizeChoices:list=>list,Number,Math,Date};
  new Script(source.slice(start,end)+'\nthis.applyTurn=applyTurn;').runInNewContext(context);
  context.applyTurn({affectionDelta:-0.02,narration:'故事繼續',choices:['1','2','3','4','5','6','7'],ending:false});
  assert.equal(context.state.affection,50,'very easy mode also ignores negative story-turn affection changes');
});

test('five difficulties scale affection from very easy pity to very hard penalties',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  assert.equal(normalizeDifficulty('veryEasy'),'veryEasy');
  assert.equal(normalizeDifficulty('easy'),'easy');
  assert.equal(normalizeDifficulty('normal'),'normal');
  assert.equal(normalizeDifficulty('hard'),'hard');
  assert.equal(normalizeDifficulty('veryHard'),'veryHard');
  assert.equal(normalizeDifficulty('unsupported'),'normal');
  for (const value of ['veryEasy','easy','normal','hard','veryHard']) {
    assert.match(source,new RegExp(`id="openingDifficultySelect"[\\s\\S]*?value="${value}"`),`new-story setup offers ${value}`);
  }
  const start=source.indexOf('function handleAffectionStageChange(');
  const end=source.indexOf('\nfunction refreshGiftConversations()',start);
  const runTurn=(difficulty,delta,affection=50)=>{
    const context={...storyClockHelpers,state:{affection,difficulty,affectionPityStart:Date.now(),history:[],choices:[],ending:false,storyMemory:''},sanitizeChoices:list=>list,Number,Math,Date};
    new Script(source.slice(start,end)+'\nthis.applyTurn=applyTurn;').runInNewContext(context);
    context.applyTurn({affectionDelta:delta,narration:'故事繼續',choices:['1','2','3','4','5','6','7'],ending:false});
    return context.state.affection;
  };
  assert.equal(runTurn('easy',-2),49,'easy halves deductions');
  assert.equal(runTurn('normal',-2),48,'normal applies full deductions');
  assert.equal(runTurn('hard',2),51.4,'hard discounts gains');
  assert.equal(runTurn('hard',-2),47.4,'hard amplifies deductions');
  assert.equal(runTurn('veryHard',2),51,'very hard halves gains');
  assert.equal(runTurn('veryHard',-2),47,'very hard amplifies deductions');
  assert.equal(runTurn('veryEasy',-2),50,'only very easy never deducts');
});

test('very easy mode never deducts and guarantees full affection within one hour',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const start=source.indexOf('function handleAffectionStageChange(');
  const end=source.indexOf('\nfunction refreshGiftConversations()',start);
  const makeState=(affection,pityStart)=>({affection,difficulty:'veryEasy',affectionPityStart:pityStart,history:[],choices:[],ending:false,storyMemory:''});
  const turn=(context,delta)=>context.applyTurn({affectionDelta:delta,narration:'故事繼續',choices:['1','2','3','4','5','6','7'],ending:false});
  const freshContext=(affection,pityStart)=>{const context={...storyClockHelpers,state:makeState(affection,pityStart),sanitizeChoices:list=>list,Number,Math,Date};new Script(source.slice(start,end)+'\nthis.applyTurn=applyTurn;').runInNewContext(context);return context;};
  const now=Date.now();
  const early=freshContext(50,now);
  turn(early,-5);
  assert.equal(early.state.affection,50,'negative turns never reduce affection in very easy mode');
  const halfHour=freshContext(50,now-30*60*1000);
  turn(halfHour,0);
  assert.ok(halfHour.state.affection>50,'time-based pity raises affection even on flat turns');
  assert.ok(halfHour.state.affection<=60,'pity stays bounded');
  const almost=freshContext(80,now-59*60*1000);
  turn(almost,0);
  assert.ok(almost.state.affection>80&&almost.state.affection<=100,'late pity accelerates toward full');
  const overtime=freshContext(70,now-61*60*1000);
  turn(overtime,-5);
  assert.equal(overtime.state.affection,100,'one hour of very easy play always tops affection up to full');
  assert.match(source,/affectionPityStart: 0/,'new saves track the pity clock');
  assert.match(source,/affectionPityStart: Number\.isFinite/,'loaded saves restore the pity clock');
});

test('gift buttons update the active game save, apply affection, and roll back on storage failure',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const start=source.indexOf('function handleAffectionStageChange(');
  const end=source.indexOf('\nasync function opening()',start);
  assert.ok(start>=0&&end>start,'the in-game gift action handler exists');
  const makeContext=(difficulty='normal',saveWorks=true)=>{
    const conversation={id:'gift-test',hint:'test hint',correctOptionId:'tea',options:[{id:'tea',name:'桂花熱茶',nameEn:'Osmanthus tea'},{id:'book',name:'詩集',nameEn:'Poetry book'},{id:'pen',name:'鋼筆',nameEn:'Fountain pen'}]};
    const context={...storyClockHelpers,state:{difficulty,affection:50,giftConversations:[conversation],history:[]},uiLanguage:'zh',save:()=>saveWorks,render(){},scrollDialogueIntoView(){},writeAutoSave(){},formatAffection:value=>{const safe=Number(value)||0;return Number.isInteger(safe)?String(safe):safe.toFixed(2);}};
    context.snapshotForRollback=value=>({...value,history:value.history.map(item=>({...item})),giftConversations:value.giftConversations.map(item=>({...item,options:item.options.map(option=>({...option}))}))});
    context.resolveGiftAffection=resolveGiftAffection;
    context.uiText=value=>value;
    new Script(source.slice(start,end)+'\nthis.giveGift=giveGift;').runInNewContext(context);
    return context;
  };
  const correct=makeContext();correct.giveGift('gift-test','tea');
  assert.equal(correct.state.affection,51.5);
  assert.equal(correct.state.giftConversations.length,0);
  const wrong=makeContext();wrong.giveGift('gift-test','book');
  assert.equal(wrong.state.affection,49);
  const easy=makeContext('veryEasy');easy.giveGift('gift-test','book');
  assert.equal(easy.state.affection,50);
  const failed=makeContext('normal',false);failed.giveGift('gift-test','book');
  assert.equal(failed.state.affection,50,'failed persistence restores affection');
  assert.equal(failed.state.giftConversations.length,1,'failed persistence restores the unspent gift conversation');
  assert.equal(failed.state.history.length,0);
});

test('gift events and difficulty are connected to saved dialogue controls',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const html=readFileSync(new URL('../../www/index.html',import.meta.url),'utf8');
  assert.match(source,/difficulty:\s*'normal',[\s\S]*?giftConversations:\s*\[\]/,'new saves start with the default difficulty and no pending gift conversations');
  assert.match(source,/difficulty: normalizeDifficulty\(rawState\.difficulty\)/,'old save files migrate to a valid difficulty');
  assert.match(source,/giftConversations: normalizeGiftConversations\(rawState\.giftConversations\)/,'pending gifts reload from each save');
  assert.match(source,/if\(!isOpening&&!state\.ending\)refreshGiftConversations\(\)/,'successful web story replies can refresh a gift conversation');
  assert.match(source,/if\(!state\.ending\)refreshGiftConversations\(\)/,'successful API story replies can refresh a gift conversation');
  assert.match(source,/data-gift-event=/,'each gift option is connected to a specific pending gift conversation');
  assert.match(source,/id="openingDifficultySelect"/,'difficulty is selected in the new-story setup');
  assert.doesNotMatch(html,/id="difficultyMode"/,'difficulty is no longer changed from general settings');
  assert.match(source,/state\.difficulty=difficulty;[\s\S]{0,120}state\.openingStyle=/,'the selected difficulty is applied when the story starts');
  assert.match(source,/id="openingDifficultySelect"[\s\S]*?value="veryEasy"/);
  assert.match(source,/state\.history\.push\(\{role:'gift-result'/,'gift results are kept in the story history');
});

test('save payload omits repeated built-in prompts but preserves user edits and verifies writes',()=>{
  const defaults={characterProfile:'default character prompt',worldSetting:'default world prompt',storyTemplate:'default story rules'};
  const promptHistory=[{id:'prompt-1',mode:'web',provider:'gemini',prompt:'saved web prompt'}];
  const slots=[
    {id:'one',name:'存檔 1',state:{...defaults,history:[{role:'user',text:'hello'}],promptHistory}},
    {id:'two',name:'自訂',state:{...defaults,characterProfile:'my edited character',history:[]}}
  ];
  const compact=compactSlotsForStorage(slots,defaults);
  assert.equal(compact[0].state.characterProfile,undefined);
  assert.equal(compact[0].state.worldSetting,undefined);
  assert.equal(compact[1].state.characterProfile,'my edited character');
  assert.deepEqual(compact[0].state.history,slots[0].state.history);
  assert.deepEqual(compact[0].state.promptHistory,promptHistory,'prompt history is retained in the save payload');
  assert.ok(JSON.stringify(compact).length<JSON.stringify(slots).length);
  const data=new Map();
  const storage={setItem:(key,value)=>data.set(key,value),getItem:key=>data.get(key)};
  const payload=JSON.stringify(compact);
  assert.equal(writeVerified(storage,'slots',payload),true);
  assert.deepEqual(JSON.parse(data.get('slots')),compact);
  assert.throws(()=>writeVerified({setItem(){},getItem(){return null}},'slots',payload),/did not match/);
});

test('prompt recovery is save-scoped, bounded, displayed and copyable',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const html=readFileSync(new URL('../../www/index.html',import.meta.url),'utf8');
  assert.match(source,/promptHistory: \[\]/,'new saves begin with an empty prompt archive');
  assert.match(source,/promptHistory: normalizePromptHistory\(rawState\.promptHistory\)/,'legacy saves load with validated prompt history');
  assert.match(source,/archive\.slice\(-20\)/,'only the latest twenty prompt records are saved');
  assert.match(source,/archivePrompt\(prompt,\{mode:'web',provider/,'exact website prompts are archived');
  assert.match(source,/archivePrompt\(JSON\.stringify\(requestBody,null,2\),\{mode:'api'/,'API turn input is archived with its save');
  assert.match(html,/id="promptHistoryDialog"[\s\S]*?id="promptHistoryPicker"[\s\S]*?id="promptHistoryText"[\s\S]*?id="copyPromptHistoryBtn"/,'users can select, inspect and copy an archived prompt');
});

test('character portrait images are validated, compressed and saved per story slot',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const html=readFileSync(new URL('../../www/index.html',import.meta.url),'utf8');
  const valid='data:image/jpeg;base64,SGVsbG8=';
  assert.equal(normalizeCharacterPortrait(valid),valid);
  assert.equal(normalizeCharacterPortrait('https://example.com/portrait.jpg'),'','remote image URLs are not accepted');
  assert.equal(normalizeCharacterPortrait('data:image/svg+xml;base64,PHN2Zz4='),'','SVG image payloads are rejected');
  assert.equal(normalizeCharacterPortrait('data:image/png;base64,'+'A'.repeat(MAX_CHARACTER_PORTRAIT_DATA_URL_LENGTH)),'','oversized image payloads are rejected');
  assert.match(source,/characterPortrait: ''/,'new story saves start with the bundled default portrait');
  assert.match(source,/characterPortrait: normalizeCharacterPortrait\(rawState\.characterPortrait\)/,'imported/old saves validate portrait data');
  assert.match(source,/characterPortrait: normalizeCharacterPortrait\(source\.characterPortrait\)/,'portrait data is included in serialized save state');
  assert.match(source,/image\.src=src/,'the chosen image updates the story and profile images');
  assert.match(source,/state\.characterPortrait=portrait[\s\S]*?save\(\)/,'portrait changes use the active save persistence flow');
  assert.match(source,/state\.characterPortrait='';[\s\S]*?save\(\)/,'the default portrait can be restored without deleting saves');
  assert.match(html,/id="changeCharacterPortraitBtn"[\s\S]*?id="resetCharacterPortraitBtn"[\s\S]*?id="characterPortraitInput"/,'profile controls offer image selection and reset');
});

test('every literal uiText string has an English translation',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const html=readFileSync(new URL('../../www/index.html',import.meta.url),'utf8');
  const start=source.indexOf('const UI_EN = {');
  const end=source.indexOf('\n};',start);
  assert.notEqual(start,-1,'English translation dictionary exists');
  assert.ok(end>start,'English translation dictionary is closed');
  const dictionary=source.slice(start,end);
  const keys=new Set([...dictionary.matchAll(/^  '((?:\\.|[^'])*)':/gm)].map(match=>match[1].replace(/\\'/g,"'")));
  const used=[...source.matchAll(/uiText\('((?:\\.|[^'])*)'\)/g)].map(match=>match[1].replace(/\\'/g,"'"));
  const missing=[...new Set(used.filter(key=>!keys.has(key)))];
  assert.deepEqual(missing,[],'add a UI_EN entry for every untranslated uiText key');
  for(const key of ['AI 服務回報額度或速率限制。','AI 帳號驗證失敗或沒有此模型權限。','所選模型可能已停用，或此帳號無權使用。','AI 回覆等待逾時，故事沒有前進。','目前無法連到 AI 服務。']){
    assert.ok(keys.has(key),`add a translation for the ${key} recovery message`);
  }
  const labels=[...html.matchAll(/(?:aria-label|title|placeholder)="([^"]+)"/g),...source.matchAll(/(?:aria-label|title|placeholder)="([^"]+)"/g)].map(match=>match[1]);
  const missingLabels=[...new Set(labels.filter(key=>!keys.has(key)))];
  assert.deepEqual(missingLabels,[],'add translations for static accessibility labels, tooltips, and placeholders');
  for(const key of ['💾 建立進度存檔','主流 AI 網頁服務','GPT-5.6 Sol · 旗艦','GPT-5.6 Terra · 均衡','GPT-5.6 Luna · 較快','DeepSeek Flash · 最新','使用預設／未指定帳號','依模型服務使用後端預設連線','尚未新增 API 帳號。新增後可保存金鑰並在不同帳號間切換。']){
    assert.ok(keys.has(key),`add an English translation for visible settings text: ${key}`);
  }
});

test('new saves default to free Gemini web mode and wait at the opening setup',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const css=readFileSync(new URL('../../www/style.css',import.meta.url),'utf8');
  const freshStart=source.slice(source.indexOf('function fresh()'),source.indexOf('function normalizeSlot'));
  assert.match(freshStart,/aiMode:\s*'web'/);
  assert.match(freshStart,/webProvider:\s*'gemini'/);
  assert.match(freshStart,/responseMode:\s*'quality'/,'new saves default to detailed replies (P2)');
  assert.match(source,/responseMode:item\.responseMode==='quality'\?'quality':'fast'/,'stored model configs keep their own reply mode (existing saves unchanged)');
  assert.match(source,/if\(!state\.history\.length&&!state\.pendingAction\)\{renderOpeningSetup\(c\);/);
  assert.ok(source.indexOf('const FORBIDDEN_CREDENTIAL_FIELDS = new Set(')<source.indexOf('let slots = loadSlots();'),'credential filtering must be ready before empty saves are normalized');
  assert.match(source,/classList\.toggle\('story-empty',!state\.history\.length&&!state\.pendingAction\)/,'the opening-only compact layout must not apply to active stories or pending turns');
  assert.match(css,/#tab-story\.text-only\.story-empty \.vn-dialogue-window\{min-height:0/,'compact the empty dialogue placeholder so the first-run controls appear sooner');
});

test('default character is the cold-outside, shy-inside librarian and only exact old defaults migrate',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  assert.match(DEFAULT_CHARACTER_PROFILE,/表面冷靜、少話；內在害羞、溫柔、認真/);
  assert.match(DEFAULT_CHARACTER_PROFILE,/氣質高冷|氣質冷靜、少話而高冷/);
  assert.match(DEFAULT_CHARACTER_PROFILE,/【信念】/);
  assert.match(DEFAULT_CHARACTER_PROFILE,/這一頁我還沒讀過/);
  assert.match(DEFAULT_CHARACTER_PROFILE,/不隱瞞自己是 AI 扮演的角色/);
  assert.match(DEFAULT_CHARACTER_PROFILE,/好感度提高後.*坦率/);
  assert.match(DEFAULT_CHARACTER_PROFILE,/不羞辱、不控制、不強迫|不以羞辱、刻薄、控制或強迫/);
  assert.doesNotMatch(LEGACY_PRE_TSUNDERE_CHARACTER_PROFILE,/傲嬌/);
  assert.match(LEGACY_PRE_TSUNDERE_CHARACTER_PROFILE,/表面看起來有點冷淡/);
  assert.match(LEGACY_TSUNDERE_CHARACTER_PROFILE,/嘴上逞強、偶爾否認在意/);
  assert.doesNotMatch(DEFAULT_CHARACTER_PROFILE,/嘴上逞強、偶爾否認在意/);
  assert.match(DEFAULT_CHARACTER_PROFILE,/【說話方式】/);
  assert.match(DEFAULT_CHARACTER_PROFILE,/才、才不是/);
  assert.ok(!DEFAULT_CHARACTER_PROFILE.includes('顏文字'),'批5 Ａ4：預設人設已去除顏文字');
  assert.ok(B5_PREVIOUS_DEFAULT_CHARACTER_PROFILE.includes('顏文字'),'批5 Ａ4：去除前快照凍結保留原文');
  assert.match(B6_PREVIOUS_DEFAULT_CHARACTER_PROFILE,/一點傲、很多嬌/,'v4.6.31 舊預設以快照凍結，才能安全遷移');
  assert.doesNotMatch(B6_PREVIOUS_DEFAULT_CHARACTER_PROFILE,/三分傲、七分嬌/,'舊快照不可跟著新預設漂移');
  assert.match(B7_PREVIOUS_DEFAULT_CHARACTER_PROFILE,/三分傲、七分嬌/,'v4.6.33 舊預設以快照凍結，才能安全遷移');
  assert.doesNotMatch(B7_PREVIOUS_DEFAULT_CHARACTER_PROFILE,/四分傲、六分嬌/,'舊快照不可跟著新預設漂移');
  assert.match(DEFAULT_CHARACTER_PROFILE,/高冷/,'預設人設維持高冷第一印象');
  assert.match(DEFAULT_CHARACTER_PROFILE,/冷靜的外表下，是一顆容易慌亂、很在意你的心/,'高冷是保護色，內在害羞溫柔');
  assert.match(B8_PREVIOUS_DEFAULT_CHARACTER_PROFILE,/四分傲、六分嬌/,'v4.6.34 高冷追加前的預設以快照凍結，才能安全遷移');
  assert.doesNotMatch(B8_PREVIOUS_DEFAULT_CHARACTER_PROFILE,/高冷/,'舊快照不可跟著新預設漂移');
  assert.notEqual(B8_PREVIOUS_DEFAULT_CHARACTER_PROFILE,DEFAULT_CHARACTER_PROFILE,'新舊預設必須不同，遷移才會生效');
  assert.match(source,/const DEFAULT_CHARACTER_NAME='Claude娘';/);
  assert.match(source,/const PREVIOUS_DEFAULT_CHARACTER_PROFILE=LEGACY_TSUNDERE_CHARACTER_PROFILE\.replaceAll\(/);
  assert.match(source,/const E13_PREVIOUS_DEFAULT_CHARACTER_PROFILE=B5_PREVIOUS_DEFAULT_CHARACTER_PROFILE\.replaceAll\('Claude娘的圖書館','cIoudo娘的圖書館'\)/);
  assert.match(source,/\[LEGACY_DEFAULT_CHARACTER_PROFILE,PREVIOUS_DEFAULT_CHARACTER_PROFILE,E13_PREVIOUS_DEFAULT_CHARACTER_PROFILE,B5_PREVIOUS_DEFAULT_CHARACTER_PROFILE,B6_PREVIOUS_DEFAULT_CHARACTER_PROFILE,B7_PREVIOUS_DEFAULT_CHARACTER_PROFILE,B8_PREVIOUS_DEFAULT_CHARACTER_PROFILE,LEGACY_TSUNDERE_CHARACTER_PROFILE\]\.includes\(savedCharacterProfile\)\?DEFAULT_CHARACTER_PROFILE:savedCharacterProfile/);
  assert.match(source,/LEGACY_PRE_TSUNDERE_CHARACTER_PROFILE\.replaceAll/);
});

test('free website selector includes ChatGPT, Claude, and Gemini official pages',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const main=readFileSync(new URL('../../electron-main.cjs',import.meta.url),'utf8');
  const start=source.indexOf('const WEB_AI_PROVIDERS=[');
  const end=source.indexOf('\n];',start);
  assert.ok(end>start,'website provider list exists');
  const providers=source.slice(start,end);
  assert.match(providers,/id:'openai',name:'ChatGPT',url:'https:\/\/chatgpt\.com\//);
  assert.match(providers,/id:'anthropic',name:'Claude',url:'https:\/\/claude\.ai\//);
  assert.match(providers,/id:'gemini',name:'Google Gemini',url:'https:\/\/gemini\.google\.com\//);
  const providerIds=[...providers.matchAll(/\{id:'([^']+)',name:'[^']+',url:'https:\/\//g)].map(match=>match[1]);
  const desktopMap=main.match(/const AI_WEBSITE_URLS = \{([\s\S]*?)\n\};/);
  assert.ok(desktopMap,'Electron has an allowlist for opening official AI websites');
  const desktopIds=[...desktopMap[1].matchAll(/\b([a-z]+):'https:\/\//g)].map(match=>match[1]);
  assert.deepEqual(desktopIds,providerIds,'the desktop opener must support every website offered by the UI');
  assert.match(main,/function findChromeExecutable\(\)/,'Windows desktop looks for Chrome explicitly');
  assert.match(main,/spawn\(chromePath,\s*\['--new-window',\s*url\]/,'desktop AI websites open in a new Chrome window when available');
  assert.match(main,/async function openAiProviderUrl\(url\)/,'desktop site launching has one Chrome-first helper');
  assert.match(main,/if\s*\(!chromePath\)\s*return shell\.openExternal\(url\)/,'desktop site launch falls back to the configured browser');
  assert.match(main,/return openAutomationWebsite\(String\(provider\|\|''\),url\)/,'external mode opens the dedicated automation browser');
  assert.doesNotMatch(main,/return openAiProviderUrl\(url\)/,'external mode never opens the normal Chrome profile that automation cannot attach to');
  assert.match(main,/partition:'persist:official-ai-web-r24',contextIsolation:true,nodeIntegration:false,sandbox:true,webSecurity:true/,'in-app logins use a fresh isolated browser session without Node access');
  assert.match(main,/function buildModelMenuScript\(action, modelName=''\)/,'the website model menu script is shared by the in-app and external browsers');
  assert.match(main,/async function executeModelMenuAction\(action, modelName='', options=\{\}\)/,'the embedded website can discover and select its live model menu');
  assert.match(main,/ipcMain\.handle\('ai-web:model-list'/,'the renderer can request the live provider model menu');
  assert.match(main,/ipcMain\.handle\('ai-web:model-select'/,'the renderer can select a discovered provider model');
  assert.match(main,/if\(mode==='external'\)\{[\s\S]*?createWebAutoRunner\('external',provider,url,tab\.id\)[\s\S]*?return runner\.evaluate\(script, action === 'select' \? 70000 : 12000\)/,'external Gemini uses the automation browser to read and switch its live model menu on the chosen tab with a bounded wait');
  assert.match(main,/upsell_\/i\.test\(String\(e\.getAttribute\('data-mode-id'\)\|\|''\)\)\)/,'Gemini upsell placeholders are not offered as switchable models');
  assert.match(main,/getAttribute\('aria-haspopup'\)==='true'\)return true/,'model submenu controls such as thinking level are not mistaken for models');
  assert.match(main,/return \{ok:models\.length>0,models,current,error:/,'the live list returns current model names as the provider renames them');
  assert.match(main,/const globalModelTrigger=\(\)=>\{/,'model discovery falls back to the top-bar trigger when the model picker is far from the editor');
  assert.ok(main.includes('目前.*(?:為|是|使用)'),'top-bar model triggers such as 目前為「Gemini Flash」模式 are accepted even without aria-haspopup');
  assert.match(readFileSync(new URL('../../electron-preload.cjs',import.meta.url),'utf8'),/listWebAiModels: options => ipcRenderer\.invoke\('ai-web:model-list', options\)/,'the isolated preload forwards the provider and browser mode only');
  assert.match(readFileSync(new URL('../../electron-preload.cjs',import.meta.url),'utf8'),/selectWebAiModel: \(modelName, options\) => ipcRenderer\.invoke\('ai-web:model-select', modelName, options\)/,'the isolated preload forwards model selection with its browser mode');
  assert.match(main,/async function fillAiWebsitePrompt\(prompt\)/,'the in-app browser can prefill the pending turn without submitting it');
  assert.match(main,/ipcMain\.handle\('ai-web:fill-prompt'/,'the renderer can request safe prompt filling');
  assert.match(readFileSync(new URL('../../electron-preload.cjs',import.meta.url),'utf8'),/fillWebAiPrompt: prompt => ipcRenderer\.invoke\('ai-web:fill-prompt', prompt\)/,'the isolated preload exposes only the prompt-fill operation');
  assert.match(main,/function isAllowedAiWebsiteUrl\(value\)/,'embedded navigation is restricted to official providers and login hosts');
  const modelScriptBody=main.slice(main.indexOf('function buildModelMenuScript'),main.indexOf('\nasync function executeModelMenuAction'));
  const modelScript=modelScriptBody.match(/return `([\s\S]*?)`;\s*\n\}/);
  assert.ok(modelScript,'the model menu operation script exists');
  for(const action of ['list','select']){
    const script=modelScript[1].replaceAll('${JSON.stringify(action)}',JSON.stringify(action)).replaceAll('${JSON.stringify(modelName)}',JSON.stringify('Gemini Flash')).replaceAll('${JSON.stringify(aiWebFlow.SITE_HINTS.stopWords)}',JSON.stringify('(^|[^a-z])(stop|stop generating|stop streaming|停止|停止生成|中止)([^a-z]|$)'));
    assert.doesNotThrow(()=>new Script(script),`the ${action} script sent into the website parses`);
  }
  assert.match(modelScript[1],/optionLike=e=>\['option','menuitem','menuitemradio'\]/,'all options in an accessible model list are available, including newly added model names');
  const fillBody=main.slice(main.indexOf('async function fillAiWebsitePrompt'),main.indexOf('\nfunction accountKey'));
  assert.match(fillBody,/const runner=createWebAutoRunner\('embedded',provider,AI_WEBSITE_URLS\[provider\]\|\|''\);[\s\S]*?return fillViaRunner\(runner,text\);/,'prompt filling uses the shared native-input pipeline and still never submits');
  assert.match(main,/async insertText\(text\)[\s\S]*?win\.webContents\.insertText\(String\(text\)\)/,'the in-app fill goes through Chromium native insertText so React/ProseMirror state updates');
  assert.match(source,/fillWebAIProviderSelect\(\$\('webAiProvider'\),webLoginProvider\)/,'settings uses the full provider list');
  assert.match(source,/fillWebAIProviderSelect\(pendingWebProvider,state\.webProvider\)/,'the fallback selector retains the full provider list');
  assert.match(source,/pendingWebProvider\.onchange=\(\)=>void switchPendingWebProvider\(pendingWebProvider\.value\)/,'choosing any item in the full menu immediately switches websites');
  assert.match(source,/select\.replaceChildren\(\.\.\.WEB_AI_PROVIDERS\.map/,'the service menu is populated from the complete website provider list');
  assert.match(source,/id="pendingWebBrowserMode"[\s\S]*?App 內瀏覽器（可一鍵切模型）[\s\S]*?外部自動化瀏覽器（登入會保留）/,'web mode offers in-app and the dedicated external automation browser with the same model switching');
  assert.match(source,/id="refreshWebModelsBtn"/,'users can sync the model options currently available in their signed-in provider account');
  assert.match(source,/pendingWebModel\.onchange=\(\)=>\{const key=webModelCacheKey\(state\.webProvider,normalizeWebBrowserMode\(webBrowserMode,state\.webProvider\)\),modelInfo=mergeManualWebModels\(webModelStateByProvider\.get\(key\),key\)/,'choosing a discovered or manual model switches the merged list in one action');
  assert.match(source,/id="shrinkWebInterfaceBtn"[\s\S]*?id="restoreWebInterfaceBtn"/,'the pending web interface has explicit shrink and restore controls');
  assert.match(source,/document\.body\.style\.zoom=String\(webUiZoom\)/,'shrinking and restoring applies to every prompt and interface label');
  assert.match(source,/aria-label="介面與提示大小"/,'zoom controls identify that help text is included');
  assert.match(source,/id="refreshWebModelsBtn"[\s\S]*?fillWebAiPrompt\?\.\(prompt\)[\s\S]*?loadWebSiteModels\(\{quiet:true,force:true\}\)/,'the in-app action fills the prompt and updates all available models together');
  assert.match(source,/if\(mode==='external'\)\{[\s\S]*?await loadWebSiteModels\(\{force:true\}\)/,'external mode refreshes the live website models without touching the prompt');
  assert.match(source,/const autoKey=webModelCacheKey\(state\.webProvider,pendingBrowserMode\)[\s\S]*?loadWebSiteModels\(\{quiet:true,force:true\}\)/,'opening a pending turn refreshes models as providers rename or add them');
  assert.ok(source.includes('webModelAutoRefreshedAction'),'the pending panel forces one live model read per turn even within the cache window');
  assert.match(source,/const raw=\{models:parsed\.models,current:parsed\.models\.includes\(current\)\?current:parsed\.models\[0\],at:Date\.now\(\)\}/,'the selected model name is stored with the live list before manual names are merged');
  assert.match(source,/const raw=\{\.\.\.previous,models,current:label,at:Date\.now\(\)\}/,'switching updates the displayed current model name');
  assert.match(source,/raw\.selectedAt=Date\.now\(\)/,'a manual switch records when it happened');
  assert.match(source,/keepSelected=Boolean\(previousRaw\?\.selectedAt/,'a just-selected model is not immediately overwritten by a stale website read');
  assert.match(source,/data-pending-web-provider="\$\{item\.id\}"/,'the pending turn offers direct provider buttons');
  assert.match(source,/\['openai','anthropic','gemini'\]/,'ChatGPT, Claude, and Gemini are one-click choices');
  assert.match(source,/async function switchPendingWebProvider\(provider[\s\S]*?state\.webProvider=nextProvider[\s\S]*?await prepareWebPrompt\(action,message,\{forceOpen:true\}\)/,'one click opens the selected provider and retries the same pending turn');
  assert.match(source,/button\.onclick=\(\)=>void switchPendingWebProvider\(button\.dataset\.pendingWebProvider\)/,'each provider button starts the one-click switch');
});

test('web prompts reduce quota use while preserving the same provider switch and turn data',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  assert.match(source,/const budget=webPromptBudget\(state\.responseMode,saving\)/,'web prompt sizes come from token-budget.js (standard and saving mode)');
  assert.match(source,/const recent=state\.history\.slice\(-budget\.historyEntries\)/,'fast and detailed modes keep their own recent-turn counts');
  assert.match(source,/const transcriptLimit=isGeminiWeb\?budget\.geminiTranscriptChars:budget\.transcriptChars/,'Gemini web turns use a slimmer dialogue cap while other sites keep the fast/detailed bounds');
  assert.match(source,/compactWebPromptText\(recent\.map[\s\S]*?transcriptLimit,true\)/,'the newest dialogue is kept when the prompt reaches its cap');
  assert.match(source,/const memoryLimit=budget\.memoryChars/,'story memory is compacted to a smaller mode-specific cap');
  assert.match(source,/網頁提示詞會依「回覆速度＋提示詞模式」限制記憶／近期對話長度/,'the UI explains the reduced web prompt budget');
  assert.match(source,/choices恰好7個非空且走向不同/,'the seven-choice output contract remains explicit');
  assert.match(source,/state\.webProvider=nextProvider[\s\S]*?await prepareWebPrompt\(action,message,\{forceOpen:true\}\)/,'provider changes still regenerate a prompt for the same pending turn');
});

test('model selection remembers options independently and applies saved settings',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  assert.match(source,/modelConfigs:\s*\{\}/,'new saves initialize a model options map');
  assert.match(source,/modelConfigs:\s*normalizeModelConfigs\(rawState\.modelConfigs\)/,'saved model options are normalized when loaded');
  assert.match(source,/modelConfigs:\s*normalizeModelConfigs\(source\.modelConfigs\)/,'saved model options are persisted');
  assert.match(source,/modelConfigs\[`\$\{state\.provider\}::\$\{state\.model\}`\]=captureModelOptions\(\)/,'current values are stored under the provider and model id');
  assert.match(source,/applyModelOptions\(provider,model\)/,'selecting a model restores its own saved settings');
  assert.match(source,/syncActiveModelOptions\(\);save\(\);updateModelParameterSupport\(\)/,'advanced parameter edits save without a second confirmation');
  assert.doesNotMatch(source,/syncActiveCustomModelOptions|applySavedModelOptions/,'old custom-only parameter paths are removed');
});

test('returning to a new-story screen refreshes its selected AI model label',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  assert.match(source,/if\(b\.dataset\.tab==='story'&&!state\.history\.length&&!state\.pendingAction\)renderOpeningSetup\(\$\('choices'\)\)/);
});

test('web AI reply can be continued from one explicit clipboard button on desktop and Android',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const index=readFileSync(new URL('../../www/index.html',import.meta.url),'utf8');
  const packageData=JSON.parse(readFileSync(new URL('../../package.json',import.meta.url),'utf8'));
  const cap=JSON.parse(readFileSync(new URL('../../capacitor.config.json',import.meta.url),'utf8'));
  for(const name of ['@capacitor/browser','@capacitor/clipboard','@capacitor/core'])assert.ok(packageData.dependencies[name],`${name} must ship with Android`);
  assert.equal(packageData.version,'4.6.36');
  assert.equal(cap.webDir,'www');
  assert.match(source,/Browser\.open\(\{url\}\)/,'Android opens the selected official AI site through the native browser');
  assert.match(source,/Clipboard\.write\(\{string:String\(text\)\}\)/,'the prompt is copied through the native clipboard');
  assert.match(source,/Clipboard\.read\(\)/,'the reply is read through the native clipboard');
  assert.match(source,/readWebClipboardBtn/,'all platforms get an explicit one-click read and continue action');
  assert.match(source,/readWebClipboard\.onclick=\(\)=>void readClipboardReply\(\)/,'the reply is read only after an explicit click');
  assert.match(source,/一鍵讀取已複製回覆並接續/,'the web workflow tells users exactly what to click after copying the reply');
  assert.match(source,/WEB_AI_GUIDE_STEPS_ANDROID/,'the mobile flow has touch-specific instructions');
  assert.match(index,/src="app\.bundle\.js"/,'the static page loads the Capacitor-bundled app entry');
  assert.match(packageData.scripts['android:debug'],/ensure-android-platform\.mjs/,'a first Android build creates the native platform automatically');
});

test('desktop web flow uses a keyboard paste gesture to return and auto-continues valid replies',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const style=readFileSync(new URL('../../www/style.css',import.meta.url),'utf8');
  assert.match(source,/document\.addEventListener\('keydown',event=>\{[\s\S]*?if\(!event\.ctrlKey[\s\S]*?void readClipboardReply\(\);/,'Ctrl+V in the focused game window explicitly reads the copied website reply');
  assert.match(source,/webReplyInput\.addEventListener\('paste',[\s\S]*?applyWebReply\(pastedReply\)/,'the manual text fallback auto-applies after a complete paste');
  assert.match(source,/function isCompleteWebReply\(value\)\{try\{parseWebReply\(value\);return true;\}catch\{return false;\}\}/,'the manual fallback only auto-applies a complete valid reply');
  assert.match(source,/const pastedReply=webReplyInput\.value;[\s\S]*?if\(!isCompleteWebReply\(pastedReply\)\)return;[\s\S]*?applyWebReply\(pastedReply\)/,'incomplete pasted text stays in the editor for continued typing');
  assert.match(source,/if\(editorWasOpen\)\{const restoredEditor=\$\('webAiReplyInput'\)[\s\S]*?details\.open=true;restoredEditor\.focus\(\)/,'invalid manual submissions keep the reply editor open and focused');
  assert.match(source,/event\.target\?\.id==='webAiReplyInput'[\s\S]*?applyWebReplyBtn/,'Ctrl+Enter can explicitly submit a corrected reply');
  assert.match(source,/最快接回方式：按網站的「複製」後[\s\S]*?在非文字輸入區按 Ctrl\+V/,'the guide describes the shortest keyboard workflow');
  const flow=source.slice(source.indexOf('const webReplyControls='));
  const intro=flow.indexOf('class="web-flow-intro"');
  const service=flow.indexOf('id="pendingWebProvider"',intro);
  const paste=flow.indexOf('${manualReplyEditor}',service);
  assert.ok(intro>=0&&intro<service&&service<paste,'the web switch flow shows its explanation, then service choices, then the reply field');
  assert.match(source,/classList\.toggle\('has-web-pending'/,'pending web turns use the compact recovery layout');
  assert.match(style,/\.choices>\.choice-btn\[data-i\][\s\S]*?display:none!important/,'disabled story choices are hidden while the recovery flow is open');
  assert.match(source,/<textarea class="web-ai-reply" id="webAiReplyInput" rows="3"/,'the paste field is visible and compact by default');
  assert.match(source,/按一次 Enter 送出/,'the web instructions clearly identify the only unavoidable submission gesture');
  assert.match(source,/repair\.id='repairWebChoicesBtn'/,'the app offers a one-click copied repair prompt after a rejected reply');
  assert.match(source,/function makeWebRepairPrompt\(\)[\s\S]*?choices 必須是陣列，恰好包含 7 個不同/,'the repair script preserves the story and explicitly restores seven choices');
  assert.match(source,/if\(state\.pendingAction&&state\.aiMode==='web'&&state\.webReply\)/,'repair is offered only after there is a rejected web reply to repair');
});

test('clipboard auto-return is provider-independent and only applies a newly copied valid story reply',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const main=readFileSync(new URL('../../electron-main.cjs',import.meta.url),'utf8');
  const preload=readFileSync(new URL('../../electron-preload.cjs',import.meta.url),'utf8');
  const monitor=source.slice(source.indexOf('function syncWebClipboardMonitor('),source.indexOf('\nasync function readClipboardReply(',source.indexOf('function syncWebClipboardMonitor(')));
  assert.match(monitor,/!state\.pendingAction\|\|state\.aiMode!=='web'\|\|busy/,'monitoring exists only for an active web reply');
  assert.match(monitor,/webClipboardMonitorSlotId===activeSlotId&&webClipboardMonitorAction===state\.pendingAction/,'the monitor stays bound to one save and pending turn');
  assert.match(monitor,/setInterval\(\(\)=>void poll\(\),850\)/,'the app checks the shared clipboard periodically while a reply is pending');
  assert.match(monitor,/if\(text&&isCompleteWebReply\(text\)\)applyWebReply\(text\)/,'the same response parser accepts valid replies from any selected website');
  assert.match(preload,/readPendingClipboard: \(\) => ipcRenderer\.invoke\('ai-web:read-pending-clipboard'\)/);
  assert.match(main,/ipcMain\.handle\('ai-web:read-pending-clipboard'/);
  assert.doesNotMatch(main.slice(main.indexOf("ipcMain.handle('ai-web:read-pending-clipboard'"),main.indexOf("ipcMain.handle('ai-web:read-manual-clipboard'")),/isFocused\(\)/,'clipboard polling still works while the user is on the AI website');
  assert.match(source,/WEB_AI_PROVIDERS\.filter\(item=>\['openai','anthropic','gemini'\]\.includes\(item\.id\)\)/,'quick choices list the three major sites while the general service selector remains provider-independent');
});

test('clipboard monitor ignores the prompt and unrelated copy, then applies one new valid reply',async()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const start=source.indexOf('function stopWebClipboardMonitor()');
  const end=source.indexOf('\nasync function readClipboardReply()',start);
  assert.ok(start>=0&&end>start,'clipboard monitor helpers exist');
  let clipboard='copied prompt',tick=null,cleared=false;
  const applied=[];
  const context={
    state:{pendingAction:'choose the archive door',aiMode:'web'},activeSlotId:'slot-a',busy:false,storyExited:false,
    window:{claudeDesktop:{readPendingClipboard:async()=>clipboard}},navigator:{clipboard:{readText:async()=>clipboard}},
    webClipboardMonitorTimer:null,webClipboardMonitorBusy:false,webClipboardMonitorSlotId:'',webClipboardMonitorAction:'',webClipboardLastText:'',webClipboardMonitorStartedAt:0,
    Date,String,isAndroidApp:()=>false,readClipboardText:async()=>clipboard,
    isCompleteWebReply:value=>value==='complete-story-json',applyWebReply:value=>applied.push(value),
    setInterval:callback=>{tick=callback;return 17;},clearInterval:()=>{cleared=true;},
  };
  new Script(source.slice(start,end)).runInNewContext(context);
  context.syncWebClipboardMonitor();
  await new Promise(resolve=>setTimeout(resolve,0));
  clipboard='unrelated copied text';tick();await new Promise(resolve=>setTimeout(resolve,0));
  assert.deepEqual(applied,[],'non-story clipboard data is ignored');
  clipboard='complete-story-json';tick();await new Promise(resolve=>setTimeout(resolve,0));
  assert.deepEqual(applied,['complete-story-json'],'a new valid reply is applied once without checking which website is open');
  tick();await new Promise(resolve=>setTimeout(resolve,0));
  assert.deepEqual(applied,['complete-story-json'],'the same clipboard reply is not applied twice');
  context.state.pendingAction='';tick();await new Promise(resolve=>setTimeout(resolve,0));
  assert.equal(cleared,true,'monitoring stops as soon as the pending web turn ends');
});

test('story opening offers old or new saves and manual-save mode protects unsaved changes',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const html=readFileSync(new URL('../../www/index.html',import.meta.url),'utf8');
  assert.match(source,/picker\.replaceChildren\(\)/);
  assert.match(source,/createOption\.value='__new_story_slot__'/);
  assert.match(source,/function resolveManualSaveBeforeLeaving\(\)/);
  assert.match(source,/switchGuardSaveBtn/,'the manual-save guard uses the in-app three-button dialog');
  assert.match(source,/openPromptDialog/,'name prompts use the in-app dialog');
  assert.ok(!/[^A-Za-z0-9_.]prompt\(/.test(source),'window.prompt is no longer used');
  assert.match(html,/id="switchGuardDialog"/);
  assert.match(html,/id="promptDialog"/);
  assert.match(source,/if\(!autoSaveEnabled&&!force&&active\.kind!=='incognito'\)\{manualSaveDirty=true;renderSaveStatus\(\);return true;\}/,'manual mode marks dirty state; temporary-chat stories always persist');
  assert.match(source,/if\(!autoSaveEnabled\)\{[\s\S]*?if\(save\(true\)\)/,'the story toolbar becomes an explicit Save button in manual mode');
  assert.match(source,/beforeunload[\s\S]*?if\(autoSaveEnabled\|\|!manualSaveDirty\)return/,'closing with unsaved manual changes asks before leaving');
  assert.match(html,/id="autoSaveToggle" type="checkbox"/);
  assert.match(html,/id="saveModeStatus"/);
  assert.match(html,/id="storySlotPicker" aria-label="故事存檔"/);
});

test('autosave switches live between automatic and manual modes and saves pending edits when re-enabled',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const saveStart=source.indexOf('function save(force=false)');
  const saveEnd=source.indexOf('\nfunction resolveManualSaveBeforeLeaving()',saveStart);
  assert.ok(saveStart>=0&&saveEnd>saveStart);
  const globals={
    autoSaveEnabled:true,manualSaveDirty:false,AUTO_SAVE_KEY:'autosave',KEY:'legacy',
    activeSlotId:'slot-a',state:{history:[{role:'user',text:'進度'}]},
    slots:[{id:'slot-a',state:{history:[]},updatedAt:0}],
    storage:new Map(),writes:0,failWrite:false,
    localStorage:{setItem(key,value){globals.storage.set(key,value);},removeItem(key){globals.storage.delete(key);}},
    serializeState(){return structuredClone(globals.state);},
    persistSlots(){globals.writes++;return !globals.failWrite;},
    renderSaveStatus(){},alert(){},Date
  };
  new Script(source.slice(saveStart,saveEnd)+'\nthis.save=save;this.setAutoSaveEnabled=setAutoSaveEnabled;').runInNewContext(globals);
  assert.equal(globals.save(),true);
  assert.equal(globals.writes,1,'automatic mode writes each change');
  assert.equal(globals.setAutoSaveEnabled(false),true);
  assert.equal(globals.storage.get('autosave'),'false');
  assert.equal(globals.save(),true);
  assert.equal(globals.manualSaveDirty,true,'manual mode marks gameplay changes as unsaved');
  assert.equal(globals.writes,1,'manual mode waits without writing');
  assert.equal(globals.setAutoSaveEnabled(true),true);
  assert.equal(globals.writes,2,'switching back to automatic mode saves pending gameplay changes');
  assert.equal(globals.manualSaveDirty,false);
  assert.equal(globals.storage.get('autosave'),'true');
});

test('autosave does not switch back on if saving pending manual edits fails',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const saveStart=source.indexOf('function save(force=false)');
  const saveEnd=source.indexOf('\nfunction resolveManualSaveBeforeLeaving()',saveStart);
  const globals={autoSaveEnabled:false,manualSaveDirty:true,AUTO_SAVE_KEY:'autosave',KEY:'legacy',activeSlotId:'slot-a',state:{history:[]},slots:[{id:'slot-a',state:{history:[]},updatedAt:0}],storage:new Map([['autosave','false']]),writes:0,localStorage:{setItem(key,value){globals.storage.set(key,value);},removeItem(){}},serializeState(){return{};},persistSlots(){globals.writes++;return false;},renderSaveStatus(){},alert(){},Date};
  new Script(source.slice(saveStart,saveEnd)+'\nthis.setAutoSaveEnabled=setAutoSaveEnabled;').runInNewContext(globals);
  assert.equal(globals.setAutoSaveEnabled(true),false);
  assert.equal(globals.autoSaveEnabled,false);
  assert.equal(globals.manualSaveDirty,true);
  assert.equal(globals.storage.get('autosave'),'false');
});

test('save manager keeps per-slot delete controls and protects cancellation and failed writes',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const html=readFileSync(new URL('../../www/index.html',import.meta.url),'utf8');
  const deleteStart=source.indexOf('function deleteSlot(id)');
  const deleteEnd=source.indexOf('function renameSlot(id, name)',deleteStart);
  assert.match(source,/class="slot-delete" data-delete="\$\{slot\.id\}" title="刪除存檔"/);
  assert.match(source,/box\.querySelectorAll\('\[data-delete\]'\)\.forEach\(b=>b\.onclick=\(\)=>deleteSlot\(b\.dataset\.delete\)\)/);
  assert.match(html,/id="saveSlots"/);
  assert.ok(deleteStart>=0&&deleteEnd>deleteStart,'the slot deletion handler exists');
  const deleteCode=source.slice(deleteStart,deleteEnd);
  assert.match(deleteCode,/if \(!confirm\([\s\S]*?\)\) return;/,'deletion requires an in-app confirmation');
  assert.match(deleteCode,/const previousSlots = slots;/,'the original saves are restored if persistence fails');
  assert.match(deleteCode,/if \(!persistSlots\(\)\) \{[\s\S]*?slots = previousSlots;/,'failed deletion writes roll back the in-memory slot list');
  assert.match(deleteCode,/if \(!slots\.some\(x => x\.kind === 'manual'\)\) \{[\s\S]*?makeSlot\('存檔 1'/,'deleting the final manual slot creates a new blank slot while system slots stay');
  assert.match(deleteCode,/target\.kind === 'auto' \|\| target\.kind === 'quick'/,'system auto/quick slots cannot be deleted; the temporary-chat slot can be deleted like a manual save');
});

test('turn rollback snapshots isolate the history and are used on both reply paths',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const original={history:[{role:'ai',text:'Before'}],choices:['Continue'],pendingAction:'Act'};
  const snapshot=snapshotForRollback(original);
  original.history[0].text='Mutated';
  original.history.push({role:'user',text:'Act'});
  original.choices.push('Another');
  assert.deepEqual(snapshot.history,[{role:'ai',text:'Before'}]);
  assert.deepEqual(snapshot.choices,['Continue']);
  for(const [name,signature] of [['applyWebReply','function applyWebReply('],['continueStory','async function continueStory('],['opening','async function opening(']]){
    const start=source.indexOf(signature);
    const end=source.indexOf('\n}',start)+2;
    assert.ok(start>=0&&end>start,`${name} exists`);
    assert.match(source.slice(start,end),/snapshotForRollback\(state\)/,`${name} must retain an isolated rollback snapshot`);
  }
});

test('asynchronous web prompt recovery is tied to its original save and pending action',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const start=source.indexOf('async function prepareWebPrompt(');
  const end=source.indexOf('\nfunction beginWebTurn(',start);
  const prepare=source.slice(start,end);
  assert.match(prepare,/const expectedState=state/);
  assert.match(prepare,/const expectedSlotId=activeSlotId/);
  assert.match(prepare,/const expectedAction=expectedState\.pendingAction/);
  assert.match(prepare,/state===expectedState&&activeSlotId===expectedSlotId&&state\.pendingAction===expectedAction/);
  assert.ok((prepare.match(/if\(!isCurrent\(\)\)return false;/g)||[]).length>=3,'recheck ownership after awaited browser and clipboard operations');
  assert.ok(source.includes('if(state!==initiatingState||activeSlotId!==initiatingSlotId){'),'finishing API account setup must not select it in a newly active save');
  assert.ok(source.includes('try{await window.claudeDesktop?.restoreWebCompanionLayout();}catch{}\n   if(state!==expectedState||activeSlotId!==expectedSlotId)return;'),'async mode switching must stop if the active save changed');
});

test('workshop editor exposes and permits export of the modules it imports',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const main=readFileSync(new URL('../../electron-main.cjs',import.meta.url),'utf8');
  const packageData=JSON.parse(readFileSync(new URL('../../package.json',import.meta.url),'utf8'));
  const require=createRequire(import.meta.url);
  const W=require('../../workshop-apply.cjs');
  const projectRoot=fileURLToPath(new URL('../../../',import.meta.url));
  const listed=new Set(W.listEditableFiles(projectRoot).map(item=>item.path));
  for(const file of ['app/www/opening-styles.js','app/www/save-state.js','app/www/save-storage.js','app/www/gift-system.js','app/www/ui-error.js','app/www/character-portrait.js','app/workshop-apply.cjs','README.txt','一鍵安裝-Windows11.bat']){
    assert.ok(listed.has(file),`${file} is editable in the workshop`);
  }
  assert.ok([...listed].every(file=>!file.includes('node_modules/')&&!file.includes('_build-tools/')&&!/(^|\/)\.env(\.|$)/.test(file)),'相依、建置產物與秘密檔不會出現在清單裡');
  assert.match(source,/refreshWorkshopFileList/,'the editor menu is filled from the main process');
  assert.match(source,/select\.append\(option\)/,'files missing from the menu are still added');
  assert.ok(!source.includes('WORKSHOP_CODE_FILES'),'v4.4.0 removed the renderer allowlist');
  assert.ok(!main.includes('WORKSHOP_SOURCE_PATHS'),'v4.4.0 removed the Electron allowlist');
  assert.match(main,/ipcMain\.handle\('workshop-code:list'/,'the main process serves the file list');
  assert.ok(packageData.build.files.includes('www/**/*'),'all imported web modules are packaged');
});

test('AI error localization translates the guidance and preserves provider diagnostics',()=>{
  const translations={'AI 服務回報額度':'Quota reached.','AI 服務回報額度或速率限制。':'Quota or rate limit reached.'};
  const message='AI 服務回報額度或速率限制。\n\nHTTP 429: provider quota details';
  assert.equal(translateError(message,'en',translations),'Quota or rate limit reached.\n\nHTTP 429: provider quota details');
  assert.equal(translateError(message,'zh',translations),message);
});

function listen(server){return new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',()=>resolve(server.address().port));});}
function close(server){return new Promise(resolve=>{server.closeAllConnections?.();server.close(()=>resolve());});}

test('opening styles are distinct and random selection resolves to a stable style id',()=>{
  assert.ok(OPENING_STYLES.length>=15,'provide a broad range of preset and AI-generated prologue styles');
  assert.equal(new Set(OPENING_STYLES.map(item=>item.id)).size,OPENING_STYLES.length);
  assert.equal(resolveOpeningStyle('random',()=>0),'rainy_first_meeting');
  assert.equal(resolveOpeningStyle('random',()=>0.99),'ai_random');
  assert.equal(resolveOpeningStyle('custom'),'custom');
  assert.equal(resolveOpeningStyle('unsigned_letter'),'unsigned_letter');
});

test('API prompts include the selected opening and state the narration band every turn',()=>{
  for(const style of OPENING_STYLES){
    const value=prompt({history:[],action:`__OPENING_STYLE__:${style.id}`,language:'zh'});
    assert.ok(value.includes(style.prompt.zh),style.id);
    assert.ok(value.includes('choices恰好7個彼此明顯不同'));
    assert.ok(value.includes(`narration 每回合 ${OUTPUT_TARGET.narrationMin}～${OUTPUT_TARGET.narrationMax} 字`),'輸出字數是明確區間，不是開放式「可以更長」');
    assert.ok(value.includes(`最多不要超過 ${OUTPUT_TARGET.narrationHard} 字`),'仍有尾端警戒線');
  }
  const continuing=prompt({history:[{role:'ai',text:'已在溫室找到一本舊書。'}],action:'我替她扶住書頁。',openingStyle:'unsigned_letter'});
  assert.ok(!continuing.includes(openingStylePrompt('unsigned_letter')));
  assert.ok(continuing.includes('我替她扶住書頁。'));
  assert.ok(!prompt({history:[{role:'ai',text:'故事已開始。'}],action:'接續',openingCustomPrompt:'序章才使用的秘密靈感'}).includes('序章才使用的秘密靈感'));
  assert.ok(continuing.includes(`narration 每回合 ${OUTPUT_TARGET.narrationMin}～${OUTPUT_TARGET.narrationMax} 字`));
});

test('AI-random and custom prologues use AI-created opening content without changing the seven-choice contract',()=>{
  const aiRandom=prompt({history:[],action:'__OPENING_STYLE__:ai_random'});
  assert.match(aiRandom,/完全自由創作一個原創序章/);
  assert.match(aiRandom,/照常生成恰好七個不同選項/);
  const idea='她正在修復一本記錄夢境的書，我帶來一張陌生書頁。';
  const custom=prompt({history:[],action:'__OPENING_STYLE__:custom',openingCustomPrompt:idea});
  assert.ok(custom.includes(idea));
  assert.match(custom,/玩家自訂序章靈感/);
  const aiRandomWithStaleIdea=prompt({history:[],action:'__OPENING_STYLE__:ai_random',openingCustomPrompt:'不應影響完全隨機序章'});
  assert.ok(!aiRandomWithStaleIdea.includes('不應影響完全隨機序章'));
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  assert.match(source,/isOpening\?\{openingCustomPrompt:state\.openingStyle===CUSTOM_OPENING_STYLE\?String\(state\.openingCustomPrompt\|\|''\)\.slice\(0,600\):''\}:\{\}/);
});

test('short narration remains playable below the 500-character prompt target',()=>{
  const minimumStory={...story,narration:'序'.repeat(500)};
  const longerStory={...story,narration:'序'.repeat(650)};
  const shortStory={...story,narration:'短回覆也能顯示'};
  assert.equal(Array.from(parse(JSON.stringify(minimumStory)).narration).length,500);
  assert.equal(Array.from(parse(JSON.stringify(longerStory)).narration).length,650);
  assert.equal(parse(JSON.stringify(shortStory)).narration,'短回覆也能顯示');
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  assert.doesNotMatch(source,/narrationLength<500/,'web replies accept complete playable turns even when their narration is shorter than the prompt target');
  assert.match(source,/const target=outputTargetLines\('zh'\);[\s\S]{0,200}?每回合新生成的正文必須/,'web repair prompts request the same narration band');
});

test('模型寫太長的選項只會被截短，不會讓整個回合失敗重打',()=>{
  // 選項只是按鈕文字。舊版若任何一個選項超過 180 字就整回合丟錯，使用者得手動重打一次，
  // 那一次重打要再付一整個回合的錢；截短成一個稍長的按鈕明顯划算。
  const longChoice='先陪她把整疊受潮的古籍搬到修復室，再一起檢查書脊上的印記，順便問問她昨晚那封信到底是誰寄來的，最後約她明天一起去看鐘樓，順路帶一壺熱茶給她暖手，也把修復進度寫進筆記';
  const withLongChoice={...story,narration:'序'.repeat(500),choices:[longChoice,...story.choices.slice(1)]};
  const parsed=parse(JSON.stringify(withLongChoice));
  assert.equal(parsed.choices.length,7);
  assert.ok(parsed.choices[0].length<=OUTPUT_TARGET.choiceHard+1,`截短後長度 ${parsed.choices[0].length} 應在硬上限附近`);
  assert.ok(parsed.choices[0].startsWith('先陪她把整疊受潮的古籍'));
  assert.ok(parsed.choices[0].endsWith('…'),'截短處有省略標記');
  assert.deepEqual(parsed.choices.slice(1),story.choices.slice(1),'其他選項原封不動');
});

test('fast prompts trim repeated context and keep Claude娘 feminine pronouns',()=>{
  const history=Array.from({length:8},(_,index)=>({role:index%2?'user':'ai',text:`HISTORY_${index}`}));
  const fast=prompt({responseMode:'fast',history,action:'CURRENT_ACTION'});
  assert.ok(fast.includes('HISTORY_6')&&fast.includes('HISTORY_7'));
  assert.ok(!fast.includes('HISTORY_5'),'fast mode sends only the latest two history entries');
  assert.ok(fast.includes('恰好7個彼此明顯不同'));
  assert.ok(fast.includes(`narration 每回合 ${OUTPUT_TARGET.narrationMin}～${OUTPUT_TARGET.narrationMax} 字`));
  const quality=prompt({responseMode:'quality',history,action:'CURRENT_ACTION'});
  assert.ok(quality.includes('HISTORY_4'),'quality mode keeps the wider four-entry context');
  assert.ok(!quality.includes('HISTORY_3'),'quality mode trims older context');
  const system=systemInstruction({characterProfile:'CUSTOM_PERSONA',language:'en',responseMode:'fast'});
  assert.ok(system.includes('CUSTOM_PERSONA'));
  assert.ok(system.includes('she/her'));
  assert.ok(system.includes('natural English'));
});

test('Fable 5.1 and GPT-6 are selectable and use compact per-turn prompts',()=>{
  const html=readFileSync(new URL('../../www/index.html',import.meta.url),'utf8');
  const source=readFileSync(new URL('../../server/server.js',import.meta.url),'utf8');
  for(const model of ['claude-fable-5-1','gpt-6-astra','gpt-6-sol','gpt-6-luna'])assert.ok(html.includes(model),`${model} must be selectable`);
  assert.match(source,/function compactRequestPrompt\(body=\{\}\)/,'provider requests use a compact dynamic prompt');
  assert.match(source,/cache_control:\{type:'ephemeral'\}/,'Fable requests reuse a stable cached system prompt');
  assert.ok(source.includes('gpt-(?:5\\.6|6)-'),'GPT-6 uses the Responses API reasoning configuration');
});

test('repeated default prompt is compact while customized story settings remain intact',()=>{
  const system=systemInstruction({});
  assert.ok(system.length<DEFAULT_CHARACTER_PROFILE.length*.65,'the built-in character profile uses a shorter equivalent API prompt');
  const customWorld='使用者自訂世界：玻璃溫室下方有一座被遺忘的鐘樓。';
  const customRules='使用者自訂規則：每次敲鐘都會讓角色想起一段不同的共同回憶。';
  const custom=prompt({history:[{role:'assistant',text:'故事已開始。'}],worldSetting:customWorld,storyTemplate:customRules,action:'尋找鐘樓的入口'});
  assert.ok(custom.includes(customWorld));
  assert.ok(custom.includes(customRules));
  assert.ok(custom.includes('尋找鐘樓的入口'));
  const appSource=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  assert.match(appSource,/characterProfile===DEFAULT_CHARACTER_PROFILE\?'':state\.characterProfile/,'the API request does not resend the long built-in profile');
  assert.match(appSource,/rawProfile===DEFAULT_CHARACTER_PROFILE\?COMPACT_DEFAULT_CHARACTER_PROMPT/,'web prompts compact only the unedited built-in profile');
});

test('production prompt keeps plot continuity while AI controls special events and ending timing',()=>{
  const fast=prompt({
    responseMode:'fast',
    history:[{role:'ai',text:'前情：她在地下書庫找到一封未寄出的信。'}],
    storyMemory:'重要伏筆：信件上的印記與她失蹤的導師有關。',
    action:'我詢問她是否認得信上的印記。'
  });
  assert.ok(fast.includes('前情：她在地下書庫找到一封未寄出的信。'));
  assert.ok(fast.includes('信件上的印記與她失蹤的導師有關。'));
  assert.ok(fast.includes('我詢問她是否認得信上的印記。'));
  assert.match(fast,/依因果安排事件和結局/);
  assert.match(fast,/主線或伏筆未收束就繼續/);
  assert.match(fast,/無固定回合數/);
});

test('story parser handles braces and quotes inside narration and rejects invalid options',()=>{
  const narration='她說「別怕 {這不是錯誤}」後，輕輕合上書。'+'字'.repeat(480);
  const wrapped=`AI 回覆：\n${JSON.stringify({...story,narration})}\n完成`;
  assert.match(parse(wrapped).narration,/\{這不是錯誤\}/);
  assert.throws(()=>parse(JSON.stringify({...story,narration:'序'.repeat(500),choices:['重複','重複','三','四','五','六','七']})),/彼此不同/);
});

async function callFakeProvider(provider,{status=200,model,responseMode='fast',worldSetting,storyTemplate}={}){
  let received={};
  const upstream=createServer(async(req,res)=>{
    const chunks=[];for await(const chunk of req)chunks.push(chunk);
    received={url:req.url,headers:req.headers,body:JSON.parse(Buffer.concat(chunks).toString('utf8'))};
    res.statusCode=status;res.setHeader('content-type','application/json');
    if(status!==200){res.end(JSON.stringify({error:{message:'temporary test quota limit'}}));return;}
    const json=JSON.stringify({...story,narration:'序'.repeat(500)});
    const response=provider==='openai'?{output_text:json}
      :provider==='anthropic'?{id:'msg_test',type:'message',role:'assistant',model:'claude-sonnet-5',content:[{type:'text',text:json}],stop_reason:'end_turn',stop_sequence:null,usage:{input_tokens:1,output_tokens:1}}
      :{candidates:[{content:{role:'model',parts:[{text:json}]},finishReason:'STOP',index:0}],usageMetadata:{promptTokenCount:1,candidatesTokenCount:1,totalTokenCount:2},modelVersion:'gemini-3.8-flash'};
    res.end(JSON.stringify(response));
  });
  const upstreamPort=await listen(upstream);
  const profile='CODEX_TEST';
  const prefix={openai:'OPENAI',anthropic:'ANTHROPIC',gemini:'GEMINI'}[provider];
  const envNames=[`${prefix}_API_KEY_${profile}`,`${prefix}_BASE_URL_${profile}`];
  const previous=Object.fromEntries(envNames.map(name=>[name,process.env[name]]));
  for(const name of envNames)process.env[name]=name.includes('API_KEY')?'test-only-key':`http://127.0.0.1:${upstreamPort}`;
  const api=await startApiServer({port:0,host:'127.0.0.1',token:'test-token'});
  try{
    const apiPort=api.address().port;
    const response=await fetch(`http://127.0.0.1:${apiPort}/api/story`,{
      method:'POST',headers:{'content-type':'application/json','X-Desktop-Token':'test-token'},
      body:JSON.stringify({provider,accountProfile:profile,model:model||(provider==='openai'?'gpt-5.6-terra':provider==='anthropic'?'claude-sonnet-5':'gemini-3.8-flash'),history:[],action:'__OPENING_STYLE__:unsigned_letter',responseMode,worldSetting,storyTemplate})
    });
    const data=await response.json();
    return {response,data,received};
  }finally{
    await close(api);await close(upstream);
    for(const [name,value] of Object.entries(previous)){if(value===undefined)delete process.env[name];else process.env[name]=value;}
  }
}

for(const provider of ['openai','anthropic','gemini']){
  test(`${provider} API adapter sends the selected model and returns a validated story`,async()=>{
    const {response,data,received}=await callFakeProvider(provider);
    assert.equal(response.status,200);
    assert.equal(data.narration.length,500);
    assert.equal(data.choices.length,7);
    assert.ok(JSON.stringify(received.body).includes(openingStylePrompt('unsigned_letter')));
    assert.ok(JSON.stringify(received.body).includes('she/her'));
    const maxOutput=provider==='openai'?received.body.max_output_tokens:provider==='anthropic'?received.body.max_tokens:received.body.generationConfig.maxOutputTokens;
    assert.equal(maxOutput,OUTPUT_TARGET.maxTokens.fast,'fast mode leaves enough room to finish the JSON without getting truncated');
    const userPrompt=provider==='openai'?received.body.input:provider==='anthropic'?received.body.messages[0].content:received.body.contents;
    assert.ok(!String(userPrompt).includes('你是沉浸式互動小說主持人'),'shared role instructions are not repeated in the user prompt');
    if(provider==='openai')assert.equal(received.headers.authorization,'Bearer test-only-key');
    if(provider==='anthropic')assert.equal(received.headers['x-api-key'],'test-only-key');
    if(provider==='gemini')assert.match(received.url,/gemini-3\.8-flash:generateContent/);
  });
}

test('GPT-6 Astra uses Responses API reasoning without legacy sampling parameters',async()=>{
  const customWorld='玻璃溫室下方有一座被遺忘的鐘樓。';
  const customRules='每次敲鐘都會讓角色想起一段不同的共同回憶。';
  const {response,received}=await callFakeProvider('openai',{model:'gpt-6-astra',responseMode:'fast',worldSetting:customWorld,storyTemplate:customRules});
  assert.equal(response.status,200);
  assert.equal(received.body.model,'gpt-6-astra');
  assert.deepEqual(received.body.reasoning,{effort:'low'});
  assert.equal('temperature' in received.body,false);
  assert.equal('top_p' in received.body,false);
  assert.ok(received.body.instructions.includes(customWorld));
  assert.ok(received.body.instructions.includes(customRules));
  assert.ok(received.body.instructions.includes(`narration 每回合 ${OUTPUT_TARGET.narrationMin}～${OUTPUT_TARGET.narrationMax} 字`));
  assert.ok(received.body.input.length<prompt({action:'__OPENING_STYLE__:unsigned_letter',responseMode:'fast'}).length,'the live per-turn prompt omits repeated static settings and output instructions');
});

test('Claude Fable 5.1 marks the stable system prefix for prompt caching',async()=>{
  const {response,received}=await callFakeProvider('anthropic',{model:'claude-fable-5-1'});
  assert.equal(response.status,200);
  assert.equal(received.body.model,'claude-fable-5-1');
  assert.equal(received.body.system[0].cache_control.type,'ephemeral');
  assert.ok(received.body.system[0].text.includes(`narration 每回合 ${OUTPUT_TARGET.narrationMin}～${OUTPUT_TARGET.narrationMax} 字`));
  assert.ok(received.body.messages[0].content.length<prompt({action:'__OPENING_STYLE__:unsigned_letter',responseMode:'fast'}).length);
});

async function callFakeCompatibleProvider(provider){
  let received={};
  const upstream=createServer(async(req,res)=>{
    const chunks=[];for await(const chunk of req)chunks.push(chunk);
    received={path:req.url,headers:req.headers,body:JSON.parse(Buffer.concat(chunks).toString('utf8'))};
    res.statusCode=200;res.setHeader('content-type','application/json');
    res.end(JSON.stringify({choices:[{message:{role:'assistant',content:JSON.stringify({...story,narration:'序'.repeat(500)})}}]}));
  });
  const upstreamPort=await listen(upstream);
  const profile=`CODEX_COMPAT_${provider.toUpperCase()}`;
  const prefix={openrouter:'OPENROUTER',deepseek:'DEEPSEEK',groq:'GROQ',mistral:'MISTRAL',xai:'XAI',qwen:'QWEN'}[provider];
  const envNames=[`${prefix}_API_KEY_${profile}`,`${prefix}_BASE_URL_${profile}`];
  const previous=Object.fromEntries(envNames.map(name=>[name,process.env[name]]));
  for(const name of envNames)process.env[name]=name.includes('API_KEY')?'test-only-key':`http://127.0.0.1:${upstreamPort}/v1`;
  const api=await startApiServer({port:0,host:'127.0.0.1',token:'test-token'});
  try{
    const response=await fetch(`http://127.0.0.1:${api.address().port}/api/story`,{
      method:'POST',headers:{'content-type':'application/json','X-Desktop-Token':'test-token'},
      body:JSON.stringify({provider,accountProfile:profile,model:`test-${provider}-model`,history:[],action:'__OPENING_STYLE__:unsigned_letter',responseMode:'fast'})
    });
    return {response,data:await response.json(),received};
  }finally{
    await close(api);await close(upstream);
    for(const [name,value] of Object.entries(previous)){if(value===undefined)delete process.env[name];else process.env[name]=value;}
  }
}

for(const provider of ['openrouter','deepseek','groq','mistral','xai','qwen']){
  test(`${provider} OpenAI-compatible adapter sends chat-completions requests`,async()=>{
    const {response,data,received}=await callFakeCompatibleProvider(provider);
    assert.equal(response.status,200);
    assert.equal(data.narration.length,500);
    assert.equal(data.choices.length,7);
    assert.equal(received.path,'/v1/chat/completions');
    assert.equal(received.body.model,`test-${provider}-model`);
    assert.deepEqual(received.body.messages.map(message=>message.role),['system','user']);
    assert.ok(received.body.messages[0].content.includes('she/her'));
    assert.ok(received.body.messages[1].content.includes(openingStylePrompt('unsigned_letter')));
    // DeepSeek V4 預設啟用 thinking，推理會吃掉 max_tokens 並讓嚴格 JSON 空白／截斷；
    // 轉接器必須明確關閉推理並要求 JSON 輸出，其他相容服務則不應收到這兩個專屬欄位。
    if(provider==='deepseek'){
      assert.deepEqual(received.body.thinking,{type:'disabled'});
      assert.deepEqual(received.body.response_format,{type:'json_object'});
      assert.ok(received.body.max_tokens>=4096);
    }else{
      assert.equal('thinking' in received.body,false);
      assert.equal('response_format' in received.body,false);
      assert.equal(received.body.max_tokens,OUTPUT_TARGET.maxTokens.fast);
    }
    assert.equal(received.headers.authorization,'Bearer test-only-key');
  });
}

test('DeepSeek reasoning-only replies fail with a clear message instead of a generic JSON error',async()=>{
  const upstream=createServer(async(req,res)=>{
    const chunks=[];for await(const chunk of req)chunks.push(chunk);
    res.statusCode=200;res.setHeader('content-type','application/json');
    res.end(JSON.stringify({choices:[{message:{role:'assistant',content:'',reasoning_content:'先分析劇情再輸出 JSON…'},finish_reason:'length'}]}));
  });
  const upstreamPort=await listen(upstream);
  const profile='CODEX_DEEPSEEK_REASONING';
  const envNames=[`DEEPSEEK_API_KEY_${profile}`,`DEEPSEEK_BASE_URL_${profile}`];
  const previous=Object.fromEntries(envNames.map(name=>[name,process.env[name]]));
  process.env[envNames[0]]='test-only-key';process.env[envNames[1]]=`http://127.0.0.1:${upstreamPort}`;
  const api=await startApiServer({port:0,host:'127.0.0.1',token:'test-token'});
  try{
    const response=await fetch(`http://127.0.0.1:${api.address().port}/api/story`,{
      method:'POST',headers:{'content-type':'application/json','X-Desktop-Token':'test-token'},
      body:JSON.stringify({provider:'deepseek',accountProfile:profile,model:'deepseek-flash',history:[],action:'__OPENING_STYLE__:unsigned_letter',responseMode:'fast'})
    });
    const data=await response.json();
    assert.equal(response.status,500);
    assert.match(data.error,/只回傳推理內容/);
    assert.match(data.error,/推理佔滿輸出上限/);
  }finally{
    await close(api);await close(upstream);
    for(const [name,value] of Object.entries(previous)){if(value===undefined)delete process.env[name];else process.env[name]=value;}
  }
});

test('DeepSeek endpoints that reject thinking fall back to a plain JSON request',async()=>{
  const bodies=[];
  const upstream=createServer(async(req,res)=>{
    const chunks=[];for await(const chunk of req)chunks.push(chunk);
    const body=JSON.parse(Buffer.concat(chunks).toString('utf8'));bodies.push(body);
    res.setHeader('content-type','application/json');
    if(body.thinking||body.response_format){
      res.statusCode=400;res.end(JSON.stringify({error:{message:'Unknown parameter: thinking'}}));return;
    }
    res.statusCode=200;
    res.end(JSON.stringify({choices:[{message:{role:'assistant',content:JSON.stringify({...story,narration:'序'.repeat(500)})}}]}));
  });
  const upstreamPort=await listen(upstream);
  const profile='CODEX_DEEPSEEK_LEGACY';
  const envNames=[`DEEPSEEK_API_KEY_${profile}`,`DEEPSEEK_BASE_URL_${profile}`];
  const previous=Object.fromEntries(envNames.map(name=>[name,process.env[name]]));
  process.env[envNames[0]]='test-only-key';process.env[envNames[1]]=`http://127.0.0.1:${upstreamPort}`;
  const api=await startApiServer({port:0,host:'127.0.0.1',token:'test-token'});
  try{
    const response=await fetch(`http://127.0.0.1:${api.address().port}/api/story`,{
      method:'POST',headers:{'content-type':'application/json','X-Desktop-Token':'test-token'},
      body:JSON.stringify({provider:'deepseek',accountProfile:profile,model:'deepseek-flash',history:[],action:'__OPENING_STYLE__:unsigned_letter',responseMode:'fast'})
    });
    const data=await response.json();
    assert.equal(response.status,200);
    assert.equal(data.narration.length,500);
    assert.equal(bodies.length,2,'should retry exactly once');
    assert.deepEqual(bodies[0].thinking,{type:'disabled'});
    assert.equal('thinking' in bodies[1],false);
    assert.equal('response_format' in bodies[1],false);
    assert.ok(bodies[1].max_tokens>=4096,'retry keeps the larger output budget');
  }finally{
    await close(api);await close(upstream);
    for(const [name,value] of Object.entries(previous)){if(value===undefined)delete process.env[name];else process.env[name]=value;}
  }
});

test('API quota status is preserved so the app can offer a useful fallback',async()=>{
  const original=console.error;console.error=()=>{};
  try{
    const {response,data}=await callFakeProvider('openai',{status:429});
    assert.equal(response.status,429);
    assert.match(data.error,/temporary test quota limit/);
  }finally{console.error=original;}
});

test('story updates auto-scroll to the dialogue box and show noticeable affection changes',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const css=readFileSync(new URL('../../www/style.css',import.meta.url),'utf8');
  assert.match(source,/function scrollDialogueIntoView\(\)/,'a dialogue auto-scroll helper exists');
  assert.match(source,/scrollDialogueIntoView\(\);/,'successful turns jump back to the description box');
  assert.match(source,/lastScrolledHistoryLength/,'auto-scroll only fires when new story content arrives');
  assert.match(source,/lastScrolledSlotId!==activeSlotId/,'switching saves resets the scroll tracker');
  assert.match(css,/\.affection-delta/,'affection changes have a visible badge style');
  assert.match(source,/id="affDelta"|getElementById\('affDelta'\)/,'the affection badge is rendered next to the meter');
  assert.match(source,/Math\.max\(-5,Math\.min\(5/,'story affection deltas are clamped to a noticeable -5..+5 range');
  assert.match(source,/affectionDelta 必須是 -3 到 \+3/,'web prompts request a noticeable -3..+3 affection scale');
  assert.match(source,/GIFT_CORRECT_AFFECTION|好感度 \+1\.5/,'gift rewards use the amplified scale');
});

test('prompt slimming never drops story essentials',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const promptFn=source.slice(source.indexOf('function makeWebPrompt(action){'),source.indexOf('\nfunction makeWebRepairPrompt('));
  assert.match(promptFn,/角色設定：\\n'\+profile/,'character profile is always in the prompt');
  assert.match(promptFn,/世界觀：\\n'\+world/,'world setting is always in the prompt');
  assert.match(promptFn,/劇情規則：\\n'\+rules/,'story rules are always in the prompt');
  assert.match(promptFn,/好感：'\+state\.affection/,'affection value is always in the prompt');
  assert.match(promptFn,/記憶：\\n'\+memory/,'story memory is always in the prompt');
  assert.match(promptFn,/const memoryLimit=budget\.memoryChars/,'memory cap comes from the shared budget (standard and saving mode)');
  assert.match(promptFn,/const recent=state\.history\.slice\(-budget\.historyEntries\)/,'recent-turn count is mode-based and untouched by provider slimming');
  assert.match(promptFn,/affectionRule,/,'the noticeable affection scale ships with every prompt');
  assert.match(promptFn,/identityRule$/m,'the identity lock closes the prompt');
  assert.match(promptFn,/compactWebPromptText\(recent\.map[\s\S]*?transcriptLimit,true\)/,'trimmed dialogue keeps the newest turns');
});

test('web prompts lock the heroine identity and stay compact for Gemini',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  assert.match(source,/不主動自稱 AI、語言模型/,'web prompts keep AI disclosure optional unless asked');
  assert.match(source,/只輸出 JSON 本體/,'web prompts repeat the JSON-only rule for Gemini stability');
  assert.match(source,/isGeminiWeb/,'Gemini web turns use a slimmer context for speed');
});

test('web replies tolerate fences and trailing commas before validation',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const start=source.indexOf('function parseWebReply(value){');
  const end=source.indexOf('\nfunction isCompleteWebReply',start);
  assert.ok(start>=0&&end>start,'web reply parser exists');
  const context={sanitizeChoices:list=>list,Number,Math,JSON};
  new Script(source.slice(source.indexOf('function stripJsonFences'),end)+'\nthis.parseWebReply=parseWebReply;').runInNewContext(context);
  const narration='故事正文'.padEnd(398,'字');
  const payload={narration,affectionDelta:9,choices:['一','二','三','四','五','六','七'],ending:false,endingText:null,memory:'記憶'};
  const fenced='Gemini 回覆如下：\n```json\n'+JSON.stringify(payload).replace(/"choices":\[/,'"choices":[')+',\n]\n```\n以上是完整回覆';
  const parsed=context.parseWebReply(fenced);
  assert.equal(parsed.affectionDelta,5,'oversized affection deltas are clamped instead of rejected');
  assert.equal(parsed.choices.length,7);
  assert.equal(Array.from(parsed.narration).length,398,'short but complete web replies remain playable');
});

test('server parser clamps affection and tolerates fences without leaking keys',()=>{
  const narration='序'.repeat(500);
  const wrapped='說明文字\n```json\n'+JSON.stringify({...story,narration,affectionDelta:-9})+'\n```';
  const out=parse(wrapped);
  assert.equal(out.affectionDelta,-5);
  assert.equal(out.choices.length,7);
});

test('API accounts can be switched and deleted without touching other saves',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const start=source.indexOf('function useAiConnection(id){');
  const end=source.indexOf('\nasync function removeAiConnection',start);
  assert.ok(start>=0&&end>start,'the account switching handler exists');
  const modelStart=source.indexOf('function defaultModelForProvider(p){');
  const modelEnd=source.indexOf('\nfunction modelOptionsFor',modelStart);
  assert.ok(modelStart>=0&&modelEnd>modelStart,'the per-provider default model helper exists');
  const makeContext=(saveWorks=true)=>{
    const context={
      aiConnections:[
        {id:'ai_gemini',provider:'gemini',profileId:'DEFAULT',label:'Gemini 帳號'},
        {id:'ai_openai',provider:'openai',profileId:'WORK',label:'OpenAI 帳號'}
      ],
      state:{aiConnectionId:'ai_gemini',provider:'gemini',model:'gemini-3.1-flash-lite',aiMode:'web'},
      save:()=>saveWorks,settings(){},render(){},refreshAiStatus(){}
    };
    new Script(source.slice(modelStart,modelEnd)+source.slice(start,end)+'\nthis.useAiConnection=useAiConnection;').runInNewContext(context);
    return context;
  };
  const ok=makeContext();
  ok.useAiConnection('ai_openai');
  assert.equal(ok.state.aiConnectionId,'ai_openai');
  assert.equal(ok.state.provider,'openai');
  assert.equal(ok.state.model,'gpt-5.6-terra');
  assert.equal(ok.state.aiMode,'api');
  ok.useAiConnection('no-such-account');
  assert.equal(ok.state.aiConnectionId,'ai_openai','unknown accounts leave the active connection alone');
  const failed=makeContext(false);
  failed.useAiConnection('ai_openai');
  assert.equal(failed.state.aiConnectionId,'ai_gemini','failed persistence rolls the switch back');
  assert.equal(failed.state.aiMode,'web');
});

test('galgame saves carry memos, kinds, summaries, and delete-protected system slots',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  assert.match(source,/memo: String\(slot\.memo \|\| ''\)\.trim\(\)\.slice\(0,200\)/,'saves keep a short memo');
  assert.match(source,/kind: String\(slot\.id\)===AUTO_SLOT_ID\?/,'slots derive auto/quick/manual kinds');
  assert.match(source,/function ensureSystemSlots\(\)/,'auto and quick slots always exist');
  assert.match(source,/memo: '', kind: 'manual'/,'new manual saves start with memo and kind fields');
  assert.match(source,/class="slot-rename" data-rename="\$\{slot\.id\}" title="重新命名"/,'all save types can be renamed');
  assert.match(source,/const canDelete = slot\.kind === 'manual' \|\| slot\.kind === 'incognito'/,'auto/quick system slots stay delete-protected');
  const start=source.indexOf('function slotSummary(slot) {');
  const end=source.indexOf('\nfunction systemSlot',start);
  assert.ok(start>=0&&end>start,'the save card summary helper exists');
  const context={Number,Math,Date,Array,String,normalizeStoryClock,realStoryClock,storyClockLabel,uiLanguage:'zh'};
  new Script(source.slice(start,end)+'\nthis.slotSummary=slotSummary;').runInNewContext(context);
  const summary=context.slotSummary({updatedAt:1700000000000,state:{history:[{role:'user',text:'走進書庫'},{role:'ai',text:'她抬起頭，燭光落在長髮上。'}],affection:63,ending:false,pendingAction:''}});
  assert.equal(summary.turns,1);
  assert.equal(summary.affection,63);
  assert.equal(summary.ending,false);
  assert.match(summary.excerpt,/燭光/);
});

test('quick save, quick load, and auto slots are wired to buttons and keys',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const html=readFileSync(new URL('../../www/index.html',import.meta.url),'utf8');
  assert.match(source,/function quickSave\(\)/,'one-action quick save exists');
  assert.match(source,/function quickLoad\(\)/,'one-action quick load exists');
  assert.match(source,/function writeAutoSave\(\)/,'successful turns refresh the auto slot');
  assert.match(source,/\$\('quickSaveBtn'\)\.onclick=\(\)=>quickSave\(\)/,'the story bar has a quick-save button');
  assert.match(source,/\$\('quickLoadBtn'\)\.onclick=\(\)=>quickLoad\(\)/,'the story bar has a quick-load button');
  assert.match(html,/id="quickSaveBtn"/,'quick-save control is in the page');
  assert.match(html,/id="quickLoadBtn"/,'quick-load control is in the page');
  assert.match(source,/key==='q'\|\|key==='Q'/,'Q triggers quick save');
  assert.match(source,/key==='l'\|\|key==='L'/,'L triggers quick load');
  assert.match(source,/快速鍵：Q 快速存檔，L 快速讀檔。/,'the keyboard hint documents the quick keys');
  assert.match(source,/class="slot-badge/,'save cards show system/active/ending/pending badges');
  assert.match(source,/class="slot-excerpt/,'save cards show a story excerpt');
  assert.match(source,/data-memo=/,'save cards offer memo editing');
  assert.match(source,/slot-system-row/,'system slots render in their own row');
});

test('startup slot loading never runs before its provider constants',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const providersAt=source.indexOf('const CUSTOM_MODEL_PROVIDERS=[');
  const loadAt=source.indexOf('let slots = loadSlots()');
  assert.ok(providersAt>=0&&loadAt>=0&&providersAt<loadAt,'provider constants must be declared before slots load or the opening screen crashes');
});

test('story text size is adjustable in seven steps and scales the whole interface',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const html=readFileSync(new URL('../../www/index.html',import.meta.url),'utf8');
  const css=readFileSync(new URL('../../www/style.css',import.meta.url),'utf8');
  assert.match(source,/STORY_TEXT_SIZES=\['xs','s','m','l','xl','xxl','xxxl'\]/,'seven text sizes exist');
  assert.match(source,/xs:\.85,s:\.925,m:1,l:1\.15,xl:1\.35,xxl:1\.6,xxxl:2/,'each step has an explicit scale up to 200%');
  assert.match(source,/document\.documentElement\.style\.setProperty\('--story-font-scale'/,'scaling uses a CSS variable');
  assert.match(source,/localStorage\.setItem\(STORY_TEXT_SIZE_KEY,storyTextSize\)/,'the chosen size persists');
  assert.match(source,/\$\('storyTextShrinkBtn'\)\.onclick=\(\)=>stepStoryTextSize\(-1\)/,'the shrink button steps down');
  assert.match(source,/\$\('storyTextGrowBtn'\)\.onclick=\(\)=>stepStoryTextSize\(1\)/,'the grow button steps up');
  assert.match(html,/id="storyTextShrinkBtn"/,'the shrink control is in the page');
  assert.match(html,/id="storyTextGrowBtn"/,'the grow control is in the page');
  assert.match(html,/id="storyTextSizeLabel"/,'the current percentage is visible');
  assert.match(css,/--story-font-scale:1/,'the default scale is defined');
  assert.match(css,/\.vn-dialogue-text\{[^}]*calc\(14px \* var\(--story-font-scale/,'dialogue text scales');
  assert.match(css,/\.bubble\{[^}]*calc\(14px \* var\(--story-font-scale/,'transcript bubbles scale');
  assert.match(css,/\.choice-btn\{[^}]*calc\(13\.5px \* var\(--story-font-scale/,'choice buttons scale');
  assert.match(css,/\.brand\{font-size:calc\(17px \* var\(--story-font-scale/,'the brand bar scales');
  assert.match(css,/\.vn-speaker\{font-size:calc\(14px \* var\(--story-font-scale/,'speaker names scale');
  assert.match(css,/\.stage-scene-label\{font-size:calc\(11px \* var\(--story-font-scale/,'scene labels scale');
  assert.match(css,/#tab-story\.text-only \.vn-dialogue-text\{font-size:calc\(15px \* var\(--story-font-scale/,'text-only mode keeps scaling');
  assert.match(css,/#tab-story\.has-web-pending \.vn-dialogue-text\{font-size:calc\(11\.5px \* var\(--story-font-scale/,'pending mode keeps scaling');
});

test('manual mode writes nothing until the player saves by hand',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  assert.match(source,/function writeAutoSave\(\)\{\s*if \(!autoSaveEnabled\) return;/,'the auto slot stays untouched while manual mode is on');
  assert.match(source,/if\(!autoSaveEnabled&&!force&&active\.kind!=='incognito'\)\{manualSaveDirty=true/,'manual turns only mark dirty state');
  assert.match(source,/localStorage\.setItem\(AUTO_SAVE_KEY/,'the auto/manual switch persists');
  const sysStart=source.indexOf('function systemSlot(id){');
  const writeStart=source.indexOf('function writeAutoSave(){');
  const writeEnd=source.indexOf('\nfunction renameSlot',writeStart);
  assert.ok(sysStart>=0&&writeStart>sysStart&&writeEnd>writeStart,'auto-save helpers exist');
  const runGate=(enabled)=>{
    const context={autoSaveEnabled:enabled,AUTO_SLOT_ID:'auto-save',QUICK_SLOT_ID:'quick-save',slots:[{id:'auto-save',kind:'auto',state:{history:[]},updatedAt:0}],serializeCalls:0,persistCalls:0};
    context.serializeState=()=>{context.serializeCalls++;return {history:[{role:'ai',text:'x'}]};};
    context.persistSlots=()=>{context.persistCalls++;return true;};
    new Script(source.slice(sysStart,writeEnd)+'\nthis.writeAutoSave=writeAutoSave;').runInNewContext(context);
    context.writeAutoSave();
    return context;
  };
  const manual=runGate(false);
  assert.equal(manual.serializeCalls,0,'manual mode performs zero writes on a successful turn');
  assert.equal(manual.persistCalls,0);
  const auto=runGate(true);
  assert.equal(auto.serializeCalls,1,'auto mode refreshes the auto slot');
  assert.equal(auto.persistCalls,1);
  assert.equal(auto.slots[0].state.history.length,1);
});

test('slot writes keep a per-slot backup and recover from a corrupt primary',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  assert.match(source,/SLOTS_BACKUP_KEY = 'claude_novel_slots_backup_v1'/,'the legacy full-payload backup key is still read during migration');
  assert.match(source,/localStorage\.setItem\(slotBackupKey\(write\.id\), previous\)/,'each overwritten slot keeps a backup of its previous payload');
  assert.match(source,/readStoredSlot\(localStorage, meta\.id\)/,'each slot is read from its own key with a per-slot backup fallback');
  assert.match(source,/parseSlotsIndex\(localStorage\.getItem\(SLOTS_INDEX_KEY\)\)/,'the v2 index decides which slots exist');
  assert.match(source,/slotsRecoveredFromBackup = true/,'a corrupt primary falls back to backup');
  assert.match(source,/已從備份還原存檔。/,'recovery is reported in the save status');
});

test('old monolithic saves migrate to the per-slot format without touching story content',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  assert.match(source,/const SLOTS_KEY = 'claude_novel_slots_v1'/,'the legacy key is still the migration source');
  assert.match(source,/return parseSlots\(legacyRaw\)/,'loading without a v2 index falls back to the legacy payload');
  assert.match(source,/if \(!degraded\) \{[\s\S]{0,80}?slotsIndexClean = true;[\s\S]{0,60}?localStorage\.removeItem\(SLOTS_KEY\)/,'the legacy key is only removed after a clean v2 read');
  assert.match(source,/slotIdFromKey\(key\)/,'keys of deleted slots are pruned');
});

test('API keys never enter saves, exports, or archived prompts',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const main=readFileSync(new URL('../../electron-main.cjs',import.meta.url),'utf8');
  assert.match(source,/FORBIDDEN_CREDENTIAL_FIELDS\.has\(k\)/,'save serialization strips credential fields');
  assert.match(source,/delete safeState\.aiConnectionId/,'exports drop even the account reference');
  assert.match(source,/\{id,provider,profileId,label,createdAt\}/,'local account storage keeps metadata only');
  assert.match(main,/safeStorage\.encryptStringAsync/,'desktop keys use Windows user encryption');
  assert.match(main,/ipcMain\.handle\('ai-vault:list'/,'listing credentials returns labels without secrets');
  assert.doesNotMatch(source,/localStorage\.setItem\(.*apiKey/i,'no API key is written to browser storage');
  assert.match(main,/const AI_WEB_CHROME_UA = `Mozilla\/5\.0 \(Windows NT 10\.0; Win64; x64\)/,'embedded official-site windows use a standard Chrome user agent');
  assert.match(main,/app\.userAgentFallback = AI_WEB_CHROME_UA/,'the fallback covers Google login popups before their first navigation');
  assert.match(main,/sec-ch-ua-full-version-list/,'UA client hints stay consistent with the Chrome user agent');
  assert.match(main,/setUserAgent\(AI_WEB_CHROME_UA\)/,'official-site windows apply the shared Chrome identity');
  assert.ok(readFileSync(new URL('../../ai-web-preload.cjs',import.meta.url),'utf8').includes('userAgentData'),'the official-site preload fills Chrome UA-CH before page scripts run');
});

test('website opens automatically only for the opening turn',()=>{
  const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
  const start=source.indexOf('async function prepareWebPrompt(action');
  const end=source.indexOf('async function openPendingWebSite',start);
  assert.ok(start>=0&&end>start,'prompt preparation and the manual opener exist');
  const body=source.slice(start,end);
  assert.match(body,/const autoOpen=expectedAction==='__OPENING__'/,'auto-open is gated on the opening turn');
  assert.ok(!body.includes('forceOpen||'),'no turn reopens the site automatically');
  assert.match(source,/function openPendingWebSite\(\)/,'reopening has a single explicit entry point');
  assert.match(source,/openWebSiteBtn/,'the pending turn has an open-site button');
  assert.match(source,/openSite.*openPendingWebSite|openPendingWebSite.*openSite/,'the button is wired to the opener');
});
