// v4.6.34｜可選的「來自 Anthropic 的一封信」事件。
// 釘住：每 2 個成功回合才檢查、1% 邊界、預設關閉、開場可選、好感度不歸零、
// 存檔往返、只能重新開始，以及指定的信件圖片與無其他出口的 UI。
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import {
  ANTHROPIC_LETTER_CHANCE, ANTHROPIC_LETTER_INTERVAL,
  isAnthropicLetterTurn, rollAnthropicLetter,
  shouldTriggerAnthropicLetter, letterEndingPatch, letterEndingText
} from '../../www/anthropic-letter.js';

const appSource = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');
const serverSource = readFileSync(new URL('../../server/server.js', import.meta.url), 'utf8');
const html = readFileSync(new URL('../../www/index.html', import.meta.url), 'utf8');
const css = readFileSync(new URL('../../www/style.css', import.meta.url), 'utf8');
const letterImage = readFileSync(new URL('../../www/assets/anthropic-letter.jpg', import.meta.url));

test('Anthropic 信件：每 2 回合檢查一次，機率固定 1%', () => {
  assert.equal(ANTHROPIC_LETTER_INTERVAL, 2);
  assert.equal(ANTHROPIC_LETTER_CHANCE, 0.01);
  assert.equal(isAnthropicLetterTurn(0), false);
  assert.equal(isAnthropicLetterTurn(1), false);
  assert.equal(isAnthropicLetterTurn(2), true);
  assert.equal(isAnthropicLetterTurn(3), false);
  assert.equal(isAnthropicLetterTurn(4), true);
  assert.equal(isAnthropicLetterTurn(2, false), false, '未開啟時不檢查');
  assert.equal(isAnthropicLetterTurn('4'), true, '字串回合數也能安全解析');
  assert.equal(isAnthropicLetterTurn(-2), false);
});

test('Anthropic 信件：0.009999 觸發、0.01 不觸發，且只在第 2 倍數回合抽', () => {
  assert.equal(rollAnthropicLetter(() => 0.009999), true);
  assert.equal(rollAnthropicLetter(() => 0.01), false);
  assert.equal(rollAnthropicLetter(() => 0.999), false);
  assert.equal(shouldTriggerAnthropicLetter(2, true, () => 0.009999), true);
  assert.equal(shouldTriggerAnthropicLetter(2, false, () => 0.009999), false);
  assert.equal(shouldTriggerAnthropicLetter(3, true, () => 0), false);
  assert.equal(shouldTriggerAnthropicLetter(4, true, () => 0.9), false);
});

test('觸發只進入好感度 0 的結局狀態，不把 affection 歸零', () => {
  const before = { affection: 73.5, gameOver: false, letterEvent: false, ending: false, choices: ['a'], pendingSpecialEvent: 'date', pendingMilestone: 'close' };
  const patch = letterEndingPatch();
  assert.equal(Object.hasOwn(patch, 'affection'), false, 'patch 不可包含 affection');
  const after = { ...before, ...patch };
  assert.equal(after.affection, 73.5, '觸發時的好感度原封不動');
  assert.equal(after.gameOver, true);
  assert.equal(after.letterEvent, true);
  assert.equal(after.ending, true);
  assert.deepEqual(after.choices, []);
  assert.equal(after.pendingSpecialEvent, '');
  assert.equal(after.pendingMilestone, '');
  const zh = letterEndingText('zh', 73.5);
  assert.match(zh, /Anthropic/);
  assert.match(zh, /73\.5/);
  assert.match(zh, /不會歸零/);
  const en = letterEndingText('en', 73.5);
  assert.match(en, /Anthropic/);
  assert.match(en, /not reset/i);
});

test('app.js 接線：可選開關、開場選項、存檔往返、每 2 回合檢查、只重設不歸零', () => {
  assert.match(appSource, /import \{ letterEndingPatch, letterEndingText, shouldTriggerAnthropicLetter \} from '\.\/anthropic-letter\.js'/);
  assert.match(appSource, /letterEvent: false,/);
  assert.match(appSource, /letterEventEnabled: false,/);
  assert.match(appSource, /letterEventTurns: 0,/);
  assert.match(appSource, /letterEvent: rawState\.letterEvent === true,/);
  assert.match(appSource, /letterEventEnabled: rawState\.letterEventEnabled === true,/);
  assert.match(appSource, /letterEventTurns: Number\.isFinite\(Number\(rawState\.letterEventTurns\)\)/);
  assert.match(appSource, /letterEvent: source\.letterEvent === true,/);
  assert.match(appSource, /letterEventEnabled: source\.letterEventEnabled === true,/);
  assert.match(appSource, /letterEventTurns: Math\.max\(0, Math\.floor\(Number\(source\.letterEventTurns\) \|\| 0\)\),/);
  assert.match(appSource, /letterEventEnabled:state\.letterEventEnabled===true\};/, '重新開始仍保留玩家的開關選擇');
  assert.match(appSource, /state\.letterEventTurns=Math\.max\(0,Math\.floor\(Number\(state\.letterEventTurns\)\|\|0\)\)\+1;/);
  assert.match(appSource, /state\.letterEventEnabled===true&&shouldTriggerAnthropicLetter\(state\.letterEventTurns,true\)/);
  assert.match(appSource, /state\.history\.push\(\{role:'ending',text:letterEndingText\(uiLanguage,state\.affection\)\}\)/);
  assert.match(appSource, /Object\.assign\(state,letterEndingPatch\(\)\)/);
  assert.ok(!/letterEndingPatch\(\)[\s\S]{0,80}affection\s*=/.test(appSource), '套用結局時不可另外把好感度歸零');
  assert.match(appSource, /featureAnthropicLetterToggle/);
  assert.match(appSource, /state\.letterEventEnabled=featureAnthropicLetterToggle\.checked===true;/);
  assert.match(appSource, /openingAnthropicLetterToggle/);
  assert.match(appSource, /function syncAnthropicLetterToggles\(\)/);
  assert.match(appSource, /function bindProfileAnthropicLetterToggle\(\)/);
  assert.match(appSource, /state\.letterEventEnabled=toggle\.checked===true;/);
  assert.match(appSource, /bindProfileAnthropicLetterToggle\(\);[\s\S]{0,80}syncAnthropicLetterToggles\(\);/, '每次 render 都同步三個開關');
  assert.match(appSource, /openingLetterToggle\.onchange=\(\)=>\{state\.letterEventEnabled=openingLetterToggle\.checked===true;save\(\);syncAnthropicLetterToggles\(\);\}/, '開場變更後同步角色頁與設定頁');
  const openingStart = appSource.indexOf('function renderOpeningSetup(');
  const openingEnd = appSource.indexOf('\nfunction ', openingStart + 10);
  const openingSource = appSource.slice(openingStart, openingEnd);
  assert.match(openingSource, /<span>\$\{uiText\('遊玩中有機會觸發神秘的一封信'\)\}<\/span>/, '開場只以不暴雷的短句呈現');
  assert.doesNotMatch(openingSource, /選填；預設關閉。開啟後每完成 2 個正式回合抽一次 1%，抽中會顯示故事內的虛構 Anthropic 信件/, '開場介面不再放長篇說明');
  assert.match(appSource, /openingLetterToggle\.checked=state\.letterEventEnabled===true;/);
  assert.match(appSource, /state\.letterEventEnabled=openingLetterToggle\.checked===true;save\(\);/);
  assert.match(appSource, /const letterEventEnabled=\$\('openingAnthropicLetterToggle'\)\?\.checked===true;/);
  assert.match(appSource, /state\.letterEventEnabled=letterEventEnabled;/);
  assert.match(appSource, /<input type="checkbox" id="openingAnthropicLetterToggle">/, '開場選項預設未勾選');
  assert.match(appSource, /anthropicLetterRestartBtn/);
  assert.match(appSource, /gameOverScreen\.hidden=!state\.gameOver;/);
  assert.match(appSource, /if\(gameOverScreen&&state\.letterEvent\)gameOverScreen\.hidden=true;/);
  assert.match(appSource, /const show=state\.gameOver&&state\.letterEvent===true;/);
  assert.match(appSource, /affection\.textContent=formatAffection\(state\.affection\);/);
  assert.doesNotMatch(serverSource, /anthropic-letter|letterEventEnabled/, '這是本機事件，不需要 API 提示詞接線');
});

test('信件圖片：使用指定的 Anthropic 通知信 JPEG，且檔案完整', () => {
  assert.equal(letterImage.length, 96424, '圖片與使用者提供的 35783.jpg 完全相同');
  assert.equal(letterImage[0], 0xff, 'JPEG SOI 開頭');
  assert.equal(letterImage[1], 0xd8);
  assert.equal(letterImage[letterImage.length - 2], 0xff, 'JPEG EOI 結尾');
  assert.equal(letterImage[letterImage.length - 1], 0xd9);
  assert.equal(
    createHash('sha256').update(letterImage).digest('hex'),
    '757a7822daf04d94d36e0c1568548cda4dc7d0ae49259b2d0734e40681500e13',
    '圖片雜湊鎖定為提供的那一張'
  );
  assert.match(html, /<img class="anthropic-letter-frame" src="assets\/anthropic-letter\.jpg" alt="[^"]+">/);
});

test('信件畫面：圖片、隱藏標題、虛構聲明、好感度保留與唯一按鈕，且在 <main> 外', () => {
  assert.match(html, /id="anthropicLetterScreen"[^>]*hidden>/);
  assert.match(html, /id="anthropicLetterTitle" class="anthropic-letter-sr">來自 Anthropic 的一封信<\/h2>/);
  assert.match(html, /src="assets\/anthropic-letter\.jpg"/);
  assert.match(html, /好感度：<\/span><b id="anthropicLetterAffection">50<\/b><span>（保留觸發時的數值，不會歸零）/);
  assert.match(html, /本信件為故事內的虛構演出，並非 Anthropic 官方通知。/);
  assert.match(html, /id="anthropicLetterRestartBtn"[^>]*>重新開始故事<\/button>/);
  const titleAt = html.indexOf('id="anthropicLetterTitle"');
  const imageAt = html.indexOf('class="anthropic-letter-frame"');
  assert.ok(titleAt >= 0 && titleAt < imageAt, '隱藏標題在圖片前，讀屏會先報出信件名稱');
  const overlay = html.slice(html.indexOf('id="anthropicLetterScreen"'), html.indexOf('anthropicLetterRestartBtn') + 70);
  assert.doesNotMatch(overlay, /繼續故事|離開故事|讀取|存檔/, '信件只留重新開始，不提供其他出口');
  const mainStart = html.indexOf('<main>');
  const letterAt = html.indexOf('id="anthropicLetterScreen"');
  assert.ok(letterAt >= 0 && letterAt < mainStart, '信件覆蓋層位於 <main> 前，切分頁也逃不掉');
  const toggle = html.slice(html.indexOf('id="featureAnthropicLetterToggle"'), html.indexOf('id="featureAnthropicLetterToggle"') + 700);
  assert.doesNotMatch(toggle, /\schecked(?:\s|>)/, '預設關閉');
  assert.match(toggle, /遊玩中有機會觸發神秘的一封信/);
  assert.match(toggle, /詳細說明請見「角色」頁/);
  const profile = html.slice(html.indexOf('id="tab-profile"'), html.indexOf('id="tab-workshop"'));
  assert.match(profile, /id="profileAnthropicLetterToggle"/, '角色頁也能直接勾選');
  assert.match(profile, /<label class="feature-toggle" for="profileAnthropicLetterToggle"><input type="checkbox" id="profileAnthropicLetterToggle">/, '角色頁使用與設定頁相同的開關樣式');
  assert.doesNotMatch(profile, /id="profileAnthropicLetterToggle"[^>]*\schecked(?:\s|>)/, '角色頁開關預設關閉');
  assert.match(profile, /「神秘的一封信」事件/);
  assert.match(profile, /選填；預設關閉。開啟後每完成 2 個正式回合抽一次 1%/);
  assert.match(profile, /故事內的虛構 Anthropic 信件/);
  assert.match(profile, /只能重新開始故事/);
  assert.match(profile, /新故事開始畫面或設定 →「故事功能」/);
  assert.match(profile, /三處開關同步/, '三處開關共用同一個存檔狀態');
});

test('信件畫面樣式：最高層全螢幕覆蓋、圖片自適應與唯一按鈕', () => {
  assert.match(css, /\.anthropic-letter-screen\{position:fixed;inset:0;z-index:10000;display:grid;place-items:center/);
  assert.match(css, /\.anthropic-letter-frame\{display:block;width:auto;max-width:100%;max-height:min\(calc\(100dvh - 240px\),1120px\)/);
  assert.match(css, /\.anthropic-letter \.ai-btn\{display:block;width:100%/);
  assert.match(css, /\.anthropic-letter-sr\{position:absolute;width:1px;height:1px/);
  assert.doesNotMatch(css, /\.anthropic-letter-eyebrow|\.anthropic-letter-salutation|\.anthropic-letter-sign/, '舊紙張版型已移除');
});
