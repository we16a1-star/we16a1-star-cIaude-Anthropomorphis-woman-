import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {Script} from 'node:vm';
import {collectStoredSlots, isSlotPayload, listStoredSlotKeys, parseSlotsIndex, readStoredSlot, slotBackupKey, slotIdFromKey, slotKey, slotsIndexPayload, writeVerified, SLOTS_INDEX_KEY, SLOTS_INDEX_VERSION} from '../../www/save-storage.js';

const source = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');

function loadRenderHelpers(globals) {
  const start = source.indexOf('function findLastEntry(');
  const end = source.indexOf('function render() {', start);
  assert.ok(start >= 0 && end > start, 'render helpers exist before render()');
  const context = {
    Array, String,
    esc: value => String(value),
    uiText: value => value,
    activeCharacterName: () => 'C',
    busy: false,
    ...globals
  };
  new Script(
    source.slice(start, end) +
    '\nthis.findLastEntry=findLastEntry;this.renderTranscript=renderTranscript;' +
    '\nthis.setLog=v=>{storyLogOpen=v};this.setHistory=v=>{state={history:v}};this.getState=()=>state;this.setSlot=v=>{activeSlotId=v};'
  ).runInNewContext(Object.assign(context, {storyLogOpen: false, state: {history: []}, activeSlotId: 'a', uiLanguage: 'zh'}));
  return context;
}

function fakeTranscript() {
  const box = {writes: 0, _html: ''};
  Object.defineProperty(box, 'innerHTML', {get() { return box._html; }, set(v) { box.writes++; box._html = v; }});
  return box;
}

test('findLastEntry returns the newest match without copying the history', () => {
  const ctx = loadRenderHelpers({});
  const list = [{role: 'ai', text: '1'}, {role: 'user', text: '2'}, {role: 'ai', text: '3'}, {role: 'user', text: '4'}];
  assert.equal(ctx.findLastEntry(list, x => x.role === 'ai').text, '3');
  assert.equal(ctx.findLastEntry(list, x => x.role === 'ending'), undefined);
  assert.equal(ctx.findLastEntry(undefined, () => true), undefined);
  assert.equal(list.length, 4, 'the input array is left untouched');
});

test('story log is not rebuilt while collapsed or unchanged, and rebuilds on real changes', () => {
  const ctx = loadRenderHelpers({});
  const box = fakeTranscript();
  const history = [{role: 'ai', text: 'hello'}];
  ctx.setHistory(history);

  ctx.renderTranscript(box);
  assert.equal(box.writes, 0, 'collapsed log never touches the DOM');

  ctx.setLog(true);
  ctx.renderTranscript(box);
  assert.equal(box.writes, 1, 'opening the log builds it once');
  assert.match(box.innerHTML, /hello/);

  ctx.renderTranscript(box);
  ctx.renderTranscript(box);
  assert.equal(box.writes, 1, 'unchanged history is not rebuilt');

  history.push({role: 'user', text: 'next'});
  ctx.renderTranscript(box);
  assert.equal(box.writes, 2, 'a pushed entry triggers a rebuild');
  assert.match(box.innerHTML, /next/);

  ctx.setHistory([...history]);
  ctx.renderTranscript(box);
  assert.equal(box.writes, 3, 'a replaced history array (e.g. rollback or slot switch) triggers a rebuild');

  ctx.setSlot('b');
  ctx.renderTranscript(box);
  assert.equal(box.writes, 4, 'switching slot triggers a rebuild even with equal content');

  ctx.setLog(false);
  ctx.setHistory([{role: 'ai', text: 'changed while hidden'}]);
  ctx.renderTranscript(box);
  assert.equal(box.writes, 4, 'hidden log stays untouched');
  ctx.setLog(true);
  ctx.renderTranscript(box);
  assert.equal(box.writes, 5, 'content changed while hidden is rebuilt when the log is reopened');
  assert.match(box.innerHTML, /changed while hidden/);
});

test('persistSlots writes only the changed slot, keeps that slot backup, and writes the index last', () => {
  assert.match(source, /persistedSlotPayloads\.get\(id\) === payload\) continue/, 'identical slots are not rewritten (or re-backed-up)');
  assert.match(source, /localStorage\.setItem\(slotBackupKey\(write\.id\), previous\)/, 'the previous per-slot payload is still backed up before a real overwrite');
  assert.match(source, /persistedSlotPayloads\.get\(SLOTS_INDEX_CACHE_KEY\) !== indexPayload/, 'the small index is skipped when it did not change');
  assert.match(source, /for \(const write of writes\) writeVerified\(localStorage, write\.key, write\.payload, isSlotPayload\);[\s\S]{0,400}writeVerified\(localStorage, SLOTS_INDEX_KEY/, 'slot payloads are written before the index that lists them');
});

test('v2 save format: one key per slot, backup fallback per slot, index stays small', () => {
  const values = new Map();
  const storage = {
    getItem: key => (values.has(key) ? values.get(key) : null),
    setItem: (key, value) => values.set(key, String(value)),
    removeItem: key => values.delete(key),
    key: index => Array.from(values.keys())[index],
    get length() { return values.size; }
  };
  const slot = {id: 'slot_a', name: '存檔 1', state: {history: [{role: 'ai', text: 'x'}]}};
  writeVerified(storage, slotKey(slot.id), JSON.stringify(slot), isSlotPayload);
  writeVerified(storage, SLOTS_INDEX_KEY, slotsIndexPayload([{...slot, kind: 'manual', updatedAt: 123}]),
    parsed => parsed.v === SLOTS_INDEX_VERSION && Array.isArray(parsed.slots));
  const index = parseSlotsIndex(storage.getItem(SLOTS_INDEX_KEY));
  assert.equal(index.length, 1);
  assert.equal(index[0].id, 'slot_a');
  assert.equal(index[0].kind, 'manual');
  assert.equal(Object.prototype.hasOwnProperty.call(index[0], 'state'), false, 'the index never carries story content');
  assert.equal(storage.getItem(slotKey('slot_a')), JSON.stringify(slot));

  // 主 key 壞掉時退回同一格的備份
  storage.setItem(slotBackupKey('slot_a'), JSON.stringify({...slot, name: '上一版'}));
  storage.setItem(slotKey('slot_a'), '{壞掉的 JSON');
  const found = readStoredSlot(storage, 'slot_a');
  assert.equal(found.fromBackup, true);
  assert.equal(found.parsed.name, '上一版');

  // 刪掉不存在的格子時需要能從 key 反推 id
  assert.equal(slotIdFromKey(slotKey('slot_a')), 'slot_a');
  assert.equal(slotIdFromKey(slotBackupKey('slot_a')), 'slot_a');
  assert.equal(slotIdFromKey('claude_novel_slots_v1'), null);
  assert.deepEqual(listStoredSlotKeys(storage).sort(),
    [slotKey('slot_a'), slotBackupKey('slot_a')].sort());

  // 壞掉或舊版本的索引一律回 null，讓 app.js 走舊格式搬遷
  assert.equal(parseSlotsIndex(''), null);
  assert.equal(parseSlotsIndex('{'), null);
  assert.equal(parseSlotsIndex(JSON.stringify({v: 1, slots: [{id: 'a'}]})), null);
  assert.equal(parseSlotsIndex(JSON.stringify({v: SLOTS_INDEX_VERSION, slots: []})), null);
});

test('readStoredSlot ignores payloads that are not real saves and rescues slots without an index', () => {
  const values = new Map();
  const storage = {
    getItem: key => (values.has(key) ? values.get(key) : null),
    setItem: (key, value) => values.set(key, String(value)),
    removeItem: key => values.delete(key),
    key: index => Array.from(values.keys())[index],
    get length() { return values.size; }
  };
  const slot = (id, updatedAt) => ({id, name: id, kind: 'manual', updatedAt, state: {history: []}});

  // 只剩 {} 或陣列的主 key 不算存檔，要退回這一格的備份
  storage.setItem(slotKey('slot_a'), JSON.stringify({}));
  storage.setItem(slotBackupKey('slot_a'), JSON.stringify(slot('slot_a', 10)));
  const found = readStoredSlot(storage, 'slot_a');
  assert.equal(found.fromBackup, true, 'an empty object is not accepted as a save');
  assert.equal(found.parsed.name, 'slot_a');
  storage.setItem(slotKey('slot_a'), JSON.stringify([]));
  assert.equal(readStoredSlot(storage, 'slot_a').fromBackup, true, 'an array is not accepted as a save');

  // 索引不見時，直接掃描磁碟上的 v2 key 把清單建回來（主 key 讀不到就用備份，壞到底的跳過）
  storage.setItem(slotKey('slot_b'), JSON.stringify(slot('slot_b', 50)));
  storage.setItem(slotKey('slot_c'), '{壞掉的 JSON');
  const rescued = collectStoredSlots(storage);
  assert.deepEqual(rescued.map(entry => entry.id), ['slot_b', 'slot_a'], 'readable slots come back newest first; broken ones are skipped');
  assert.equal(rescued[0].raw, storage.getItem(slotKey('slot_b')), 'raw is exactly what is on disk');
  assert.equal(rescued[1].fromBackup, true, 'a slot rescued from its backup is marked as such');
});

test('saves survive a lost index and no keys are deleted after a degraded load', () => {
  assert.match(source, /function loadSlots\(\) \{[\s\S]{0,400}?slotsIndexClean = false;/, 'every load starts out untrusted');
  assert.match(source, /if \(!degraded\) \{[\s\S]{0,80}?slotsIndexClean = true;/, 'only a fully clean v2 read is trusted');
  assert.match(source, /if \(slotsIndexClean\) removeOrphanSlotKeys\(\)/, 'stray keys are only pruned after a trusted load');
  assert.match(source, /collectStoredSlots\(localStorage\)/, 'a lost index is rebuilt from the per-slot keys');
  assert.match(source, /if \(!legacyRaw\) \{/, 'the rebuild never runs while a legacy payload is still present');
  assert.match(source, /rank = id => id === QUICK_SLOT_ID[\s\S]{0,140}?sort\(\(a, b\) => rank\(a\.id\) - rank\(b\.id\)\)/, 'rescued slots keep the normal system-first order');
  assert.match(source, /slotPayloadParses\(previous\)/, 'a broken previous payload is never kept as a backup');
  assert.match(source, /localStorage\.removeItem\(slotKey\(id\)\);[\s\S]{0,160}?localStorage\.removeItem\(slotBackupKey\(id\)\);/, 'deleting a slot clears its payload and backup');
});

test('installer excludes stale nested copies and local secrets', () => {
  const pkg = JSON.parse(readFileSync(new URL('../../package.json', import.meta.url), 'utf8'));
  for (const pattern of ['www/**/*', '!www/www/**', '!server/server/**', '!server/.env']) {
    assert.ok(pkg.build.files.includes(pattern), pattern + ' is configured');
  }
});
