import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';

// 版本號只有一個來源：app/package.json。這個測試把「所有會寫到版本的地方」綁在一起，
// 避免像先前 AUTO-VERIFY 寫死 4.3.22、README 還停在 4.3.17 那樣各自漂移。
const read = rel => readFileSync(new URL('../../' + rel, import.meta.url), 'utf8');
const readRoot = rel => readFileSync(new URL('../../../' + rel, import.meta.url), 'utf8');

const pkg = JSON.parse(read('package.json'));
const version = pkg.version;

test('release version: package.json is the single source of truth', () => {
  assert.match(version, /^\d+\.\d+\.\d+$/, 'version is plain semver');
  const lock = JSON.parse(read('package-lock.json'));
  assert.equal(lock.version, version, 'package-lock.json top-level version matches');
  assert.equal(lock.packages[''].version, version, 'package-lock.json packages[""] version matches');
  assert.match(read('tests/story/story-ai.test.js'), new RegExp(`assert\\.equal\\(packageData\\.version,'${version.replace(/\./g, '\\.')}'\\)`), 'the Android clipboard test asserts the current version');
});

test('release version: docs and changelog follow the version bump', () => {
  const tag = `v${version}`;
  const changelog = `${tag}-優化紀錄.txt`;
  assert.ok(existsSync(new URL('../../../' + changelog, import.meta.url)), `${changelog} exists at the project root`);
  assert.ok(readRoot('README.txt').includes(tag), 'README.txt shows the current version');
  assert.ok(readRoot('README-使用方法.txt').includes(tag), 'README-使用方法.txt shows the current version');
  assert.ok(readRoot('先看這裡-安裝說明.txt').includes(version), 'install guide shows the current version');
  assert.ok(!readRoot('先看這裡-安裝說明.txt').includes('4.3.22'), 'install guide no longer pins the old version');
});

test('release version: the one-click installer reads the version instead of hard-coding it', () => {
  const auto = readRoot('AUTO-VERIFY-AND-PACKAGE.ps1');
  const bat = read('BUILD-WINDOWS11-AUTO.bat');
  // AUTO-VERIFY：從 package.json 讀版本、檔名用萬用字元、不再出現寫死的 4.3.x。
  assert.match(auto, /package\.json/, 'AUTO-VERIFY reads package.json');
  assert.match(auto, /-Filter '\*-Setup-\*\.exe'/, 'AUTO-VERIFY matches the Setup exe by wildcard');
  assert.doesNotMatch(auto, /4\.3\.\d+/, 'AUTO-VERIFY has no hard-coded release version');
    assert.match(auto, /node --test "tests\/\*\*\/\*\.test\.js"/, 'AUTO-VERIFY recursively runs tests in categorized folders');
  // 一鍵安裝 BAT：一樣用萬用字元並顯示讀到的版本。
  assert.match(bat, /\*-Setup-\*\.exe/, 'the one-click BAT matches the Setup exe by wildcard');
  assert.match(bat, /require\('\.\/package\.json'\)\.version/, 'the one-click BAT prints the version from package.json');
  assert.doesNotMatch(bat, /Setup-4\.3\.\d+-/, 'the one-click BAT has no hard-coded Setup version');
});
