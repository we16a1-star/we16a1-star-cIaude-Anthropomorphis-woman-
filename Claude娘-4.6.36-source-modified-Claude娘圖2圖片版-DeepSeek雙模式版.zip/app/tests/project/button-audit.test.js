import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

// 「每個按鍵都要能用」：把靜態按鈕、事件委派、IPC 與 API 路由契約綁進測試。
// 實際行為由其他測試與 packaged UI 冒煙測試覆蓋；這裡先擋住「按鈕新增了卻忘了接線」。
test('every shipped button, IPC channel and API route has a handler', () => {
  const script = fileURLToPath(new URL('../../scripts/audit-buttons.cjs', import.meta.url));
  const result = spawnSync(process.execPath, [script], { encoding: 'utf8' });
  assert.equal(result.status, 0, result.stdout + result.stderr);
  assert.match(result.stdout, /結果：PASS/);
  assert.match(result.stdout, /靜態按鈕：\d+/);
  assert.match(result.stdout, /IPC：invoke \d+、handler \d+/);
});
