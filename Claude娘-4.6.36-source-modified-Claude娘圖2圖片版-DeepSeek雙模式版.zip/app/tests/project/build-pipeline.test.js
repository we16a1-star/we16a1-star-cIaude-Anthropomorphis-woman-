import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync, mkdtempSync, writeFileSync, mkdirSync, rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';

// v4.4.0 的一鍵安裝／.exe 產生流程：指紋、安全輸出資料夾、重跑沿用。
const read = rel => readFileSync(new URL('../../' + rel, import.meta.url), 'utf8');
const appDir = fileURLToPath(new URL('../..', import.meta.url));
const fingerprintScript = path.join(appDir, 'scripts', 'source-fingerprint.cjs');

function fingerprint(dir) {
  return execFileSync(process.execPath, [fingerprintScript, dir], {encoding: 'utf8'}).trim();
}

test('source fingerprint is stable for the same tree, changes with content, and ignores build output', () => {
  const dir = mkdtempSync(path.join(tmpdir(), 'fp-'));
  try {
    mkdirSync(path.join(dir, 'www'));
    writeFileSync(path.join(dir, 'www', 'app.js'), 'export const v = 1;\n');
    writeFileSync(path.join(dir, 'package.json'), '{"name":"x"}\n');
    const first = fingerprint(dir);
    assert.match(first, /^[0-9a-f]{16}$/, '16 hex chars');
    assert.equal(fingerprint(dir), first, 'same content gives the same fingerprint');
    writeFileSync(path.join(dir, 'www', 'app.js'), 'export const v = 2;\n');
    const changed = fingerprint(dir);
    assert.notEqual(changed, first, 'a content change changes the fingerprint');
    // 相依、建置產物、備份與 source-root.json 不列入指紋（否則每次建置都會不一樣）
    mkdirSync(path.join(dir, 'node_modules'));
    writeFileSync(path.join(dir, 'node_modules', 'junk.js'), 'junk');
    mkdirSync(path.join(dir, 'dist'));
    writeFileSync(path.join(dir, 'dist', 'app.exe'), 'binary');
    mkdirSync(path.join(dir, '.workshop-backup'));
    writeFileSync(path.join(dir, '.workshop-backup', 'old.js'), 'old');
    writeFileSync(path.join(dir, 'source-root.json'), '{"appDir":"C:/somewhere"}');
    assert.equal(fingerprint(dir), changed, 'build output, backups and the marker do not affect the fingerprint');
  } finally { rmSync(dir, {recursive: true, force: true}); }
});

test('the safe packager exists, is wired into npm scripts, and always restores package.json', () => {
  const pkg = JSON.parse(read('package.json'));
  assert.match(pkg.scripts['dist:safe'] || '', /node scripts\/build-installer\.cjs/, 'npm run dist:safe uses the safe packager');
  const script = read('scripts/build-installer.cjs');
  assert.match(script, /finally\s*\{[\s\S]*fs\.writeFileSync\(pkgFile, original\)/, 'package.json is restored even when the build fails');
  assert.match(script, /CLOUDO_DIST_OUT/, 'the output folder can be overridden by an environment variable');
  assert.match(script, /-Setup-\.\*\\\.exe\$/i, 'the built installer is found by wildcard, never by a pinned version');
  assert.match(script, /electron-builder/, 'it drives electron-builder');
  assert.ok(!/-Setup-\d/.test(script), 'the packager never pins an installer file name');
});

test('the one-click BAT reuses a matching build, falls back safely, and never pins a version', () => {
  const bat = read('BUILD-WINDOWS11-AUTO.bat');
  assert.match(bat, /source-fingerprint\.cjs/, 'the BAT computes the source fingerprint');
  assert.match(bat, /REBUILD_ALWAYS/, 'a rebuild can be forced');
  assert.match(bat, /reuse_installer/, 'an unchanged tree reuses the previous installer');
  assert.match(bat, /run dist:safe/, 'the primary build path uses the safe packager');
  assert.match(bat, /run dist\b/, 'there is still a fallback to the plain build');
  assert.match(bat, /npm_config_cache=/, 'npm keeps its cache inside the project');
  assert.match(bat, /--prefer-offline/, 'installs prefer the local cache');
  assert.match(bat, /CLEAN_INSTALL/, 'npm ci is available when a clean install is wanted');
  assert.match(bat, /\*-Setup-\*\.exe/, 'the installer is found by wildcard');
  assert.match(bat, /rootDir/, 'the marker records the whole delivery folder for the workshop');
  assert.match(bat, /require\('\.\/package\.json'\)\.version/, 'the version still comes from package.json');
  assert.ok(!/Setup-\d+\.\d+\.\d+-/.test(bat), 'no pinned Setup version');
});

test('the installer never ships third-party source maps, type definitions, or docs', () => {
  const pkg = JSON.parse(read('package.json'));
  const files = pkg.build.files;
  assert.ok(Array.isArray(files) && files.length > 0);

  // 每個排除規則都必須是「執行期不可能被 require 到」的型式。
  const excludeNodeModules = files.filter(p => p.startsWith('!node_modules/'));
  for (const pattern of ['!node_modules/**/*.map', '!node_modules/**/*.d.ts', '!node_modules/**/*.ts', '!node_modules/**/*.md']) {
    assert.ok(excludeNodeModules.includes(pattern), `${pattern} must stay excluded (measured: 16 MB of app.asar)`);
  }
  // 不能連 .js/.cjs/.mjs/.json 一起排除，那才是執行期真正載入的檔案。
  for (const pattern of excludeNodeModules) {
    assert.ok(/\.(map|ts|mts|cts|md|markdown)$/.test(pattern), `${pattern} must not exclude executable code`);
  }

  // 排除規則必須排在納入規則之後，否則 glob 會先納入再排除失效。
  const firstExclude = files.findIndex(p => p.startsWith('!'));
  assert.ok(firstExclude > 0, 'negations come after the includes');

  // 自家前端也要排除 map（www/app.bundle.js 就夠了）。
  assert.ok(files.includes('!www/**/*.map'), 'our own source maps stay out too');
});
