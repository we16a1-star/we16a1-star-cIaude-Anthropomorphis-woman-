import test from 'node:test';
import assert from 'node:assert/strict';
import {existsSync, readFileSync} from 'node:fs';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';

// v4.4.0 的「開源化」驗收：授權檔要在、授權條款要對、安裝檔要帶上授權、
// 而且任何人都能用同一套流程自己編出安裝檔。
const read = rel => readFileSync(new URL('../../' + rel, import.meta.url), 'utf8');
const readRoot = rel => readFileSync(new URL('../../../' + rel, import.meta.url), 'utf8');
const existsRoot = rel => existsSync(new URL('../../../' + rel, import.meta.url));

const require = createRequire(import.meta.url);
const W = require('../../workshop-apply.cjs');
const projectRoot = fileURLToPath(new URL('../../../', import.meta.url));

test('the project ships the MIT licence at the root and inside the packaged app', () => {
  assert.ok(existsRoot('LICENSE'), 'root LICENSE exists');
  assert.ok(existsSync(new URL('../../LICENSE', import.meta.url)), 'app/LICENSE exists (packaged copy)');
  const rootLicence = readRoot('LICENSE');
  assert.match(rootLicence, /^MIT License\r?\n/, 'root LICENSE is the MIT licence');
  assert.match(rootLicence, /Copyright \(c\) \d{4} .+/, 'root LICENSE keeps a copyright line');
  assert.match(rootLicence, /WITHOUT WARRANTY OF ANY KIND/, 'the MIT warranty disclaimer is intact');
  assert.equal(read('LICENSE').replace(/\r\n/g, '\n'), rootLicence.replace(/\r\n/g, '\n'), 'both copies stay identical');
});

test('package metadata declares the licence and an author, and the installer carries the licence', () => {
  const pkg = JSON.parse(read('package.json'));
  assert.equal(pkg.license, 'MIT');
  assert.equal(pkg.private, false, 'the package is publishable');
  assert.ok(String(pkg.author || '').trim().length > 0, 'author is set (electron-builder warns when it is missing)');
  assert.ok(pkg.build.files.includes('LICENSE'), 'LICENSE is packed into the installer, as MIT requires');
  assert.ok(pkg.build.files.includes('www/**/*') && pkg.build.files.includes('electron-main.cjs'), 'the editable source is packed (the workshop edits these)');
});

test('the open-source guide answers "what may I change, and where?"', () => {
  const guideName = '開源說明-授權與修改.txt';
  assert.ok(existsRoot(guideName), `${guideName} exists at the root`);
  const guide = readRoot(guideName);
  assert.match(guide, /MIT License/);
  assert.match(guide, /創意工坊/, 'it points at the in-app workshop as the fastest way to edit');
  assert.match(guide, /v4\.4\.0 起沒有白名單/, 'it states that the whitelist is gone');
  assert.match(guide, /build:web/, 'it warns that www/*.js needs a bundle rebuild');
  assert.match(guide, /app\\BUILD-WINDOWS11-AUTO\.bat/, 'it documents the one-click build');
  assert.match(guide, /npm test/, 'it tells contributors to run the tests');
  assert.match(guide, /不要提交 node_modules/, 'it lists what must not be committed');
  assert.match(guide, /未做程式碼簽章/, 'it is honest about code signing');
});

test('README and the install guide both point at the licence and the editing paths', () => {
  const readme = readRoot('README.txt');
  assert.match(readme, /【開源】/);
  assert.match(readme, /MIT/);
  assert.match(readme, /LICENSE/);
  assert.match(readme, /開源說明-授權與修改\.txt/);
  assert.match(readme, /創意工坊/);
  const install = readRoot('先看這裡-安裝說明.txt');
  assert.match(install, /【開源】/);
  assert.match(install, /開源說明-授權與修改\.txt/);
});

test('anyone can build the installer from a fork: the CI workflow mirrors the local one-click flow', () => {
  assert.ok(existsRoot('.github/workflows/build-windows.yml'), 'a Windows workflow exists');
  const flow = readRoot('.github/workflows/build-windows.yml');
  assert.match(flow, /runs-on: windows-latest/);
  assert.match(flow, /node-version: 22/);
  assert.match(flow, /npm install --no-audit --no-fund/);
  assert.match(flow, /npm test/, 'CI runs the same tests as the local pipeline');
  assert.match(flow, /npm run build:web/, 'CI rebuilds the bundle before packing');
  assert.match(flow, /electron-builder --win nsis/, 'CI produces the same NSIS installer');
  assert.match(flow, /app\/dist\/\*-Setup-\*\.exe/, 'CI uploads the installer by wildcard');
  assert.ok(!/-Setup-\d/.test(flow), 'the workflow never pins an installer version');
});

test('the source files the open-source docs talk about are all editable in the workshop', () => {
  const listed = new Set(W.listEditableFiles(projectRoot).map(item => item.path));
  for (const file of [
    'LICENSE', '開源說明-授權與修改.txt', 'README.txt', '先看這裡-安裝說明.txt',
    '一鍵安裝-Windows11.bat', 'AUTO-VERIFY-AND-PACKAGE.ps1', '.github/workflows/build-windows.yml',
    'app/package.json', 'app/www/app.js', 'app/www/style.css', 'app/electron-main.cjs',
    'app/workshop-apply.cjs', 'app/server/server.js', 'app/tests/project/open-source.test.js',
    'app/scripts/build-installer.cjs', 'app/scripts/source-fingerprint.cjs'
  ]) {
    assert.ok(listed.has(file), `${file} must be openable in the workshop`);
  }
  // 但相依、建置產物與秘密檔仍然不可編輯。
  for (const blocked of ['app/node_modules/electron/package.json', 'app/dist/x.exe', 'app/_build-tools/node/node.exe', 'app/.env', 'app/source-root.json']) {
    assert.ok(!listed.has(blocked), `${blocked} must stay out of the workshop`);
  }
});
