import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync, statSync } from 'node:fs';
import { createHash } from 'node:crypto';

// G17 美術動畫更新：立繪去背重製＋人物進場／待機動畫＋選項按鈕 hover 修復。
// 這個測試把更新包的關鍵內容釘住，避免之後換版時又退回舊立繪或把動畫區塊刪掉。
const read = rel => readFileSync(new URL('../../' + rel, import.meta.url), 'utf8');
const fileUrl = rel => new URL('../../' + rel, import.meta.url);
const sha = rel => createHash('sha256').update(readFileSync(fileUrl(rel))).digest('hex');

test('G17 CSS: portrait entrance and idle animations are appended and reduced-motion safe', () => {
  const css = read('www/style.css');
  assert.match(css, /\/\* ==== G17｜人物動畫與質感優化/, 'G17 區塊存在');
  assert.match(css, /@keyframes g17-portrait-in\{[\s\S]*?opacity:0[\s\S]*?translate:26px 10px[\s\S]*?scale:\.985/, '進場由右下淡入');
  assert.match(css, /@keyframes g17-idle\{[\s\S]*?translateY\(-4px\)[\s\S]*?skewX\(-\.18deg\)/, '待機有呼吸與微風幅度');
  assert.match(css, /#app #tab-story:not\(\.text-only\):not\(\.has-web-pending\):not\(\.g16-x\) \.story-portrait\{[^}]*animation:g17-portrait-in \.9s[^}]*g17-idle 9s[^}]*infinite/, '立繪同時套用進場與待機');
  assert.match(css, /@media \(prefers-reduced-motion:no-preference\)\{[\s\S]*?#tab-story \.choices\.g15-choices-in>\.choice-btn\{animation-fill-mode:backwards\}/, '選項改用 fill-mode:backwards，hover 不再被鎖住');
  assert.match(css, /#tab-story \.choices\.g15-choices-in>\.choice-btn:nth-child\(8\)\{animation-delay:\.27s\}/, '第 8 個選項補上延遲');
  assert.match(css, /@media \(prefers-reduced-motion:reduce\)\{[\s\S]*?\.story-portrait\{animation:none;will-change:auto\}/, '減少動態時停用立繪動畫');
  const g17 = css.slice(css.indexOf('/* ==== G17'));
  assert.ok(!g17.includes('!important'), 'G17 不使用 !important');
  assert.ok(!/font-size\s*:/.test(g17), 'G17 不改 font-size');
});

test('G17 assets: the redone portrait and transparent splash art are shipped', () => {
  assert.ok(existsSync(fileUrl('www/assets/portrait-start.webp')), '開始畫面立繪存在');
  assert.equal(statSync(fileUrl('www/assets/portrait-start.webp')).size, 419602, '開始畫面使用重製版立繪');
  assert.equal(sha('www/assets/portrait-start.webp'), 'e3c323bac86c9839a2a254a83b17c85774c17585290a1ab1ee38aa57030f23e9', '立繪內容固定');

  const png = readFileSync(fileUrl('www/assets/claude-splash-user/Claude娘圖2-transparent.png'));
  assert.equal(png.slice(1, 4).toString('ascii'), 'PNG', '啟動畫面立繪是 PNG');
  assert.equal(png.readUInt32BE(16), 937, '啟動畫面立繪寬度不變');
  assert.equal(png.readUInt32BE(20), 1678, '啟動畫面立繪高度不變');
  assert.equal(png.length, 2145629, '啟動畫面使用重製版透明圖');
});

test('splash page points at the transparent art and keeps skip controls working', () => {
  const html = read('www/splash-image.html');
  assert.ok(html.includes('src="assets/claude-splash-user/Claude娘圖2-transparent.png"'), '啟動畫面引用透明 PNG');
  assert.ok(!html.includes('src="assets/claude-splash-user/Claude娘圖2.jpg"'), '不再引用舊 JPG');
  assert.match(html, /id="skip"[^>]*type="button"/, '跳過按鈕存在');
  assert.match(html, /skip\.addEventListener\('click', go\)/, '跳過按鈕有點擊處理');
  assert.match(html, /\['Escape', ' ', 'Enter'\]/, 'Esc／空白／Enter 可跳過');
  assert.match(html, /@media\(prefers-reduced-motion:reduce\)/, '啟動畫面尊重減少動態');
});
