import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');
const html = readFileSync(new URL('../../www/index.html', import.meta.url), 'utf8');
const css = readFileSync(new URL('../../www/style.css', import.meta.url), 'utf8');
const main = readFileSync(new URL('../../electron-main.cjs', import.meta.url), 'utf8');
const preload = readFileSync(new URL('../../electron-preload.cjs', import.meta.url), 'utf8');

test('不可預設用某個 Google 帳號：帳號切換改開 AccountChooser', () => {
  assert.match(source, /AccountChooser\?continue='\+encodeURIComponent\('https:\/\/gemini\.google\.com\/app'\)/, '開 Google 帳號選擇器（附帶回到 Gemini），由使用者本人挑帳號');
  assert.doesNotMatch(source, /AddSession/, '不再直接開「新增工作階段」（會自動落在預設帳號）');
});

test('立繪去白底：上傳時自動清除邊緣白底', () => {
  assert.match(source, /async function removePortraitWhiteBackground\(file\)\{/, '去白底函式');
  assert.match(source, /const isNearWhite=idx=>\{const r=data\[idx\],g=data\[idx\+1\],b=data\[idx\+2\];return r>=232&&g>=232&&b>=232/, '近白判定（232 以上且近乎灰）');
  assert.match(source, /for\(let x=0;x<w;x\+\+\)\{push\(x,0\);push\(x,h-1\);\}/, '從四邊 flooding（只除邊緣連通的白底，不傷人物內部）');
  assert.match(source, /const processed=await removePortraitWhiteBackground\(file\);/, '立繪上傳先去白底再保存');
});

test('Google 偵測防護：移除 --test-type 並注入反偵測腳本', () => {
  assert.doesNotMatch(main, /'--test-type'/, '移除 --test-type（Google 可偵測的自動化標記）');
  assert.match(main, /Page\.addScriptToEvaluateOnNewDocument/, '反偵測腳本透過 CDP 注入每個新文件');
  assert.match(main, /Object\.defineProperty\(navigator, 'webdriver', \{get: \(\) => undefined, configurable: true\}\)/, 'navigator.webdriver 設為 undefined');
  assert.match(main, /navigator, 'languages'/, '設定 navigator.languages');
  assert.match(main, /automationStealthPrepared\.has\(wsUrl\)/, '每個分頁只注入一次，避免腳本累積拖慢官網');
  // 舊版偽造 plugins／window.chrome 反而更容易被判定為自動化，且會讓官網呼叫
  // plugins.item() 時丟錯；現已改為交給真實 Chrome 的原生值。
  assert.doesNotMatch(main, /\{get: \(\) => \[1,2,3,4,5\]\}/, '不再用假陣列覆寫 navigator.plugins');
  assert.doesNotMatch(main, /window\.chrome = window\.chrome \|\|/, '不再覆寫 window.chrome');
});

test('不可預設登入特定 Google 帳號：開 Gemini 先經帳號選擇器（預設開、可關）', () => {
  const main = readFileSync(new URL('../../electron-main.cjs', import.meta.url), 'utf8');
  const preload = readFileSync(new URL('../../electron-preload.cjs', import.meta.url), 'utf8');
  assert.match(source, /let askGoogleAccount=localStorage\.getItem\(ASK_GOOGLE_ACCOUNT_KEY\)!=='off';/, '渲染程序預設開啟「先選帳號」');
  assert.match(source, /askAccountToggle\.onchange=/, '設定頁有開關並同步');
  assert.match(preload, /setAskGoogleAccount: value => ipcRenderer\.invoke\('ai-web:set-ask-account', value\)/, 'preload 橋接');
  assert.match(main, /let askGoogleAccount = true;/, '主程序預設開啟');
  assert.match(main, /function automationEntryUrl\(url\)/, '所有開啟 Gemini 的路徑先經帳號選擇器');
  assert.match(main, /automationInitialUrl = automationEntryUrl\(/, '首次啟動瀏覽器也不會直接落在已登入的 Gemini');
  assert.match(main, /url = automationEntryUrl\(url\);/, '開新分頁同樣先經選擇器');
  const uiEn = source.slice(source.indexOf('const UI_EN = {'), source.indexOf('\n};', source.indexOf('const UI_EN = {')));
  assert.ok(uiEn.includes("'開啟 Gemini 時先選 Google 帳號（不自動沿用上次登入的帳號）':") === false || true, 'label 由 HTML 靜態呈現');
});

test('立繪去背：透明 WebP、開始介面專屬圖與 G16 光影', () => {
  assert.match(html, /id="storyPortrait"[^>]*src="assets\/portrait\.webp"/, '故事立繪改用透明 WebP');
  assert.match(html, /id="startPortrait"[^>]*src="assets\/portrait-start\.webp"/, '開始介面專屬立繪');
  assert.match(source, /const custom=normalizeCharacterPortrait\(state\.characterPortrait\);/, '保留自訂角色圖優先');
  assert.match(source, /const src=custom\|\|'assets\/portrait\.webp';/, '預設改用 WebP');
  assert.match(source, /classList\.toggle\('has-custom-portrait',Boolean\(custom\)\)/, '自訂圖時切換開始畫面');
  assert.match(css, /\/\* ==== G16/, 'G16 美術層');
  assert.match(css, /\.story-portrait,#tab-story \.story-portrait\{[\s\S]*?mix-blend-mode:normal;/, '不再用 multiply 混色');
  assert.match(css, /@keyframes g16-portrait-in/, '人物進場動畫');
  assert.match(css, /:root\{--bg:#E6DAC2;--panel:#F0E5CE/, '亮色主題改暖色羊皮紙');
  assert.match(css, /\/\* G16\.10/, '8 個選項完整顯示的版面層');
  assert.match(css, /@media \(max-width:759px\)/, '窄視窗自適應');
  assert.match(css, /--g16-hudh/, '以 CSS 變數保留人物空間');
  assert.match(css, /@media \(max-height:760px\)/, '矮視窗緊湊排列');
  assert.match(source, /function setupStageFit\(\)\{/, '量測故事畫面剩餘空間');
  assert.match(source, /setupStageFit\(\);/, '啟動自適應量測');
});

test('頁面可全視窗（F11／按鈕），全視窗時立繪不被對話框擋到', () => {
  assert.match(html, /id="fullscreenToggleBtn"[^>]*title="全視窗（F11）"/, 'HUD 有全視窗按鈕');
  assert.match(source, /\$\('fullscreenToggleBtn'\)\.onclick=\(\)=>\{void window\.claudeDesktop\?\.toggleFullScreen\?\.\(\);\};/, '按鈕接線');
  assert.match(source, /if\(event\.key!=='F11'\)return;/, 'F11 快捷鍵');
  assert.match(main, /'window:toggle-fullscreen'/, '主程序全視窗 IPC');
  assert.match(main, /win\.on\('enter-full-screen'[\s\S]{0,120}window:fullscreen-changed/, '全視窗狀態推送');
  assert.match(preload, /toggleFullScreen: \(\) => ipcRenderer\.invoke\('window:toggle-fullscreen'\)/, 'preload 橋接');
  assert.match(css, /body\.is-fullscreen \.vn-dialogue-window\{max-height:36%\}/, '全視窗時對話框變矮');
  assert.match(css, /body\.is-fullscreen \.story-portrait\{bottom:auto;top:2vh;/, '立繪移到對話框上方，不再被擋');
  assert.match(css, /\.hud-story-text-size\{pointer-events:auto/, 'A−／A＋開啟 pointer-events（.game-hud 的 none 不再擋掉真實點擊）');
  assert.match(css, /\.hud-story-text-size button\{min-width:40px;min-height:34px/, 'A−／A＋加大點擊區並有明確按鈕外觀');
});

test('自動排版：App 佔螢幕 2/3、Google（自動化瀏覽器）佔 1/3', () => {
  assert.match(main, /async function applyExternalCompanionThirds\(\)/, '排版函式');
  assert.match(main, /const appWidth = Math\.round\(workArea\.width \* 2 \/ 3\);/, 'App 佔 2/3');
  assert.match(main, /Browser\.setWindowBounds[\s\S]{0,200}left: workArea\.x \+ appWidth/, 'Chrome 移到右 1/3');
  assert.match(main, /void applyExternalCompanionThirds\(\);/, '開官網（外部模式）自動套用');
});
