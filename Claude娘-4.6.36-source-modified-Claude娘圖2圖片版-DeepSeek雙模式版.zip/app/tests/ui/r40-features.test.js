import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');
const html = readFileSync(new URL('../../www/index.html', import.meta.url), 'utf8');
const main = readFileSync(new URL('../../electron-main.cjs', import.meta.url), 'utf8');
const flow = readFileSync(new URL('../../ai-web-flow.cjs', import.meta.url), 'utf8');

test('開始故事時可直接使用既有存檔', () => {
  assert.match(source, /const continueSlots=slots\.filter\(slot=>slot\.id!==activeSlotId&&/, '開局面板收集其他有進度的存檔');
  assert.match(source, /id="openingContinueSlot"/, '開局面板有「繼續既有存檔」下拉');
  assert.match(source, /id="openingContinueBtn"[^>]*>\$\{uiText\('繼續這個存檔'\)\}/, '有一鍵繼續按鈕');
  assert.match(source, /if\(openingContinueBtn\)openingContinueBtn\.onclick=\(\)=>\{const id=\$\('openingContinueSlot'\)\?\.value;if\(id\)void switchSlot\(id\);\};/, '繼續按鈕走既有 switchSlot（保存與還原邏輯共用）');
  assert.match(source, /\$\{continueOptions\?[\s\S]{0,700}:''\}/, '沒有其他有進度存檔時整列不出現');
});

test('故事中（暫停選單）能建立存檔點', () => {
  assert.match(html, /id="exitCheckpointBtn"[^>]*>建立存檔點/, '暫停選單有「建立存檔點」按鈕');
  assert.match(source, /\$\('exitCheckpointBtn'\)\.onclick=\(\)=>\{void createCheckpointSlot\(\);\};/, '按鈕接上既有的進度存檔流程（命名→複製→留在故事）');
});

test('角色卡刪除按鈕常駐可用（只要有額外卡）', () => {
  assert.match(source, /if\(del\)del\.hidden=!cards\.length;/, '刪除按鈕顯示條件＝有任何額外角色卡');
  assert.match(source, /const card=sheetEditTargetCard\(\)\|\|cards\[cards\.length-1\];/, '沒有選定卡時刪最後一張');
});

test('插圖自動下載（點官網下載鈕）', () => {
  assert.match(flow, /function buildSceneDownloadClickScript\(\)/, '下載點擊腳本存在');
  assert.match(flow, /naturalWidth\|\|0\)>=256/, '只認生成的大圖，不誤點介面小圖');
  assert.match(flow, /下載\|下载\|download\|save/, '以官網下載鈕字樣比對');
  assert.match(flow, /buildSceneDownloadClickScript,\n  replyProgress/, '模組匯出腳本');
});

test('插圖自動匯入（監看下載資料夾）', () => {
  assert.match(main, /function startSceneAutoHarvest\(runner\)/, '自動下載＋匯入流程存在');
  assert.match(main, /sceneAutoHarvestTimer = setInterval/, '自動下載計時器存在');
  assert.match(main, /void runner\.evaluate\(aiWebFlow\.buildSceneDownloadClickScript\(\)\)\.catch/, '每 20 秒自動點官網下載鈕');
  assert.match(main, /sceneDownload\.findLatestImage\(app\.getPath\('downloads'\)\)/, '輪詢下載資料夾的最新圖檔');
  assert.match(main, /hit\.mtimeMs <= sceneDownloadsStartedAt/, '只收流程啟動後才出現的檔案');
  assert.match(main, /fs\.statSync\(hit\.path\)\.size !== before/, '檔案大小穩定後才匯入（避免抓到半成品）');
  assert.match(main, /const payload = sceneDownload\.readImageFile\(hit\);[\s\S]{0,120}deliverSceneImage\(payload\);\s*stopSceneAutoHarvest\(\);/, '匯入成功即停止');
  assert.match(main, /stopSceneAutoHarvest\(\);\s*\/\/ 自動下載→匯入→刪除[\s\S]{0,80}fs\.rmSync\(hit\.path, \{force: true\}\)/, '匯入成功後刪除下載資料夾裡的來源檔');
  assert.match(main, /startSceneAutoHarvest\(runner\);/, '插圖啟動（外部模式）自動接上此流程');
});

test('設定頁可立即更新模型清單', () => {
  assert.match(html, /id="webRefreshModelsBtn"[^>]*>立即更新模型清單/, '設定頁有按鈕');
  assert.match(source, /\$\('webRefreshModelsBtn'\)\.onclick=async\(\)=>\{[\s\S]{0,320}loadWebSiteModels\(\{force:true\}\)/, '按鈕強制重讀官網模型');
  assert.match(source, /官網模型清單已更新；待辦回合的面板會顯示最新清單。/, '更新結果有明確回饋（不再無聲）');
});

test('資料包（DLC）可自由分享：角色卡陣列隨包匯出，匯入用合併', () => {
  assert.match(source, /characterCards:characterCardsList\(\),\s*characterCardIds:\[\.\.\.usedCharacterCardIds\(\)\]\.slice\(0,12\)/, '匯出包含額外角色卡與勾選');
  assert.match(source, /const incomingCards=normalizeCharacterCards\(incoming\.characterCards\);/, '匯入端正規化角色卡 DLC');
  assert.match(source, /const byId=new Map\(existing\.map\(card=>\[card\.id,card\]\)\);[\s\S]{0,160}state\.characterCards=\[\.\.\.byId\.values\(\)\]\.slice\(0,12\);/, '同 id 覆蓋、新 id 新增（合併不刪現有）');
  assert.match(source, /uiText\('角色卡 DLC'\)/, '匯入清單顯示角色卡 DLC');
});

test('Gemini 可使用不同 Google 帳號（本人操作，App 不碰帳密）', () => {
  assert.match(html, /id="webSwitchAccountBtn"[^>]*>新增／切換 Google 帳號/, '設定頁有帳號切換按鈕');
  assert.match(source, /\$\('webSwitchAccountBtn'\)\.onclick=\(\)=>void switchGoogleAccountFromSettings\(\);/, '按鈕接線');
  assert.match(source, /AccountChooser\?continue=/, 'R47 改開 Google 帳號選擇器（不預設某帳號）');
  assert.ok(main.includes("/^https:\\/\\/accounts\\.google\\.com\\//.test(String(payload.url || ''))"), '主程序只接受 accounts.google.com 的自訂網址');
  assert.ok(main.includes('if (AI_WEBSITE_URLS[provider] && url === AI_WEBSITE_URLS[provider]) rememberAutomationTab(provider, tab);'), '帳號頁不覆蓋故事分頁的釘選');
});

test('工作列圖標與桌面捷徑一致（AppUserModelID＋視窗 icon＋捷徑圖示修復）', () => {
  assert.match(main, /const APP_USER_MODEL_ID = 'com\.claude\.novel\.windows11'/, '以 appId 設定共用 AppUserModelID');
  assert.match(main, /app\.setAppUserModelId\(APP_USER_MODEL_ID\)/, '啟動時套用 AppUserModelID，工作列不再用暫時識別碼');
  assert.match(main, /function appIconPath\(\)[\s\S]{0,420}process\.resourcesPath, 'icon\.ico'/, '打包後優先讀 resources\\icon.ico（與捷徑同一張圖）');
  assert.match(main, /const windowIconPath = appIconPath\(\);/, '視窗使用共用的圖示路徑');
  assert.match(main, /const windowIcon = loadAppIcon\(\);/, '以 nativeImage 載入圖示，避免 asar／ICO 讀取差異');
  assert.match(main, /icon: windowIcon \|\| \(windowIconPath \? windowIconPath : undefined\)/, '視窗建立時套用圖標');
  assert.match(main, /win\.setIcon\(windowIcon\)/, '建立後再明確套用一次視窗圖標');
  assert.match(main, /icon: iconPath,[\s\S]{0,120}appUserModelId: APP_USER_MODEL_ID/, '桌面捷徑也使用同一張 icon 與 AUMID');
  assert.match(main, /return iconOk && aumidOk \? 'ok' : 'update'/, '既有捷徑圖示為空或不同時會就地修復');
  const pkg = JSON.parse(readFileSync(new URL('../../package.json', import.meta.url), 'utf8'));
  assert.deepEqual(pkg.build.extraResources, [{from: 'assets/icon.ico', to: 'icon.ico'}], 'icon.ico 會複製到 resources 供 Explorer／工作列讀取');
});

test('立繪呈現（v4.6.28：恢復原本 1.24，不使用過曝的 2.8）', () => {
  const css = readFileSync(new URL('../../www/style.css', import.meta.url), 'utf8');
  assert.doesNotMatch(css, /brightness\(2\.8\)/, '不使用過曝的 2.8 提亮');
  assert.match(css, /#tab-story \.story-portrait\{filter:brightness\(1\.24\)/, '立繪維持原本 1.24');
});

test('R40 新字串都有英文翻譯', () => {
  const uiEn = source.slice(source.indexOf('const UI_EN = {'), source.indexOf('\n};', source.indexOf('const UI_EN = {')));
  for (const key of ['繼續既有存檔', '繼續這個存檔', '選一個舊存檔直接回到該故事；目前未開始的進度不受影響。', '建立存檔點', '立即更新模型清單']) {
    assert.ok(uiEn.includes(`'${key}':`), `UI_EN covers ${key}`);
  }
});
