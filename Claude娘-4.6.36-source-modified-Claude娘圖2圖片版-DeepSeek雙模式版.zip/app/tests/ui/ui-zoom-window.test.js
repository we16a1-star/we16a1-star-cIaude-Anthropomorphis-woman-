import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');
const html = readFileSync(new URL('../../www/index.html', import.meta.url), 'utf8');
const css = readFileSync(new URL('../../www/style.css', import.meta.url), 'utf8');
const main = readFileSync(new URL('../../electron-main.cjs', import.meta.url), 'utf8');
const preload = readFileSync(new URL('../../electron-preload.cjs', import.meta.url), 'utf8');

test('介面縮放：可放大可縮小、有入口、會保存，不再鎖在 100%', () => {
  assert.match(source, /const WEB_UI_ZOOM_MIN=\.7,WEB_UI_ZOOM_MAX=1\.6,WEB_UI_ZOOM_STEP=\.05;/, 'PC 版開放 70%～160%、每次 5%');
  assert.match(source, /document\.body\.style\.zoom=String\(webUiZoom\)/, '整個介面用 CSS zoom 等比縮放（版面不破、不空白）');
  assert.match(source, /requestAnimationFrame\(\(\)=>\{try\{window\.dispatchEvent\(new Event\('resize'\)\);\}catch\{\}\}\);/, '縮放套用後立即補發 resize，dvh／固定定位立刻重算，開啟時不重疊');
  assert.match(source, /startSceneIllustration\(prompt,normalizeWebBrowserMode\(webBrowserMode\),sceneProvider\)/, '插圖沿用目前故事的官網供應商');
  assert.match(css, /html\{background:var\(--bg\)\}/, '縮小時露出的視窗外框跟隨主題底色，不是米白視窗底');
  assert.match(css, /\.choices>\.choice-btn\[data-i\]\{padding-left:26px;padding-right:16px\}/, '選項文字與菱形指標不再重疊（左內距清出指標空間）');
  assert.match(source, /localStorage\.setItem\(WEB_UI_ZOOM_KEY,String\(webUiZoom\)\)/, '縮放值保存在 claude_novel_web_ui_zoom_v1');
  assert.doesNotMatch(source, /Math\.min\(1,Math\.max\(\.75,value\)\)/, '舊版「上限 100%、下限 75%」的鎖定已移除');
  assert.match(source, /function stepWebUiZoom\(direction\)/, '步進調整');
  assert.match(source, /function resetWebUiZoom\(\)/, '百分比標籤／Ctrl+Alt+0 可切換自適應與手動 100%');
});

test('介面縮放自適應：依視窗大小自動縮放，調整後才轉手動並記住', () => {
  assert.match(source, /const WEB_UI_ZOOM_AUTO_KEY='claude_novel_web_ui_zoom_auto_v1';/, '自適應模式有獨立儲存鍵');
  assert.match(source, /const WEB_UI_ZOOM_BASE_WIDTH=1280,WEB_UI_ZOOM_BASE_HEIGHT=820;/, '以預設視窗 1280×820 為基準');
  assert.match(source, /function computeAutoUiZoom\(width,height\)\{[\s\S]{0,320}Math\.min\(w\/WEB_UI_ZOOM_BASE_WIDTH,h\/WEB_UI_ZOOM_BASE_HEIGHT\)/, '取寬高比例較小者，避免其中一邊溢出');
  assert.match(source, /if\(webUiZoomAuto\)webUiZoom=computeAutoUiZoom\(\);/, '套用縮放時自適應會即時重算');
  assert.match(source, /window\.addEventListener\('resize',\(\)=>\{[\s\S]{0,260}computeAutoUiZoom\(\)!==webUiZoom\)applyWebUiZoom\(\)/, '視窗大小改變（最大化／拖曳）會自動重新縮放');
  assert.match(source, /webUiZoomAuto=false;[\s\S]{0,160}WEB_UI_ZOOM_AUTO_KEY,'off'/, '按 A−／A+ 是手動意圖，會關閉自適應並記住');
  assert.match(source, /label\.textContent=\(webUiZoomAuto\?uiText\('自動'\)/, 'HUD 百分比會標示「自動」');
  assert.match(source, /setWebUiZoomAuto\(true\)/, '設定頁的還原介面會回到自適應');
  assert.match(source, /shrinkWebInterfaceBtn'\);if\(shrinkWebInterface\)shrinkWebInterface\.onclick=\(\)=>\{stepWebUiZoom\(-1\);\}/, '設定頁的縮小介面也會切換成手動，不會被自適應覆蓋');
  const uiEn = source.slice(source.indexOf('const UI_EN = {'), source.indexOf('\n};', source.indexOf('const UI_EN = {')));
  for (const key of ['自動', '依視窗大小自動縮放；點一下改為手動 100%', '點一下恢復自動縮放']) {
    assert.ok(uiEn.includes(`'${key}':`), `UI_EN covers ${key}`);
  }
});

test('介面縮放的控制入口：HUD 的 A−／A＋ 與標籤重設＋Ctrl+Alt 快捷鍵', () => {
  assert.match(html, /id="storyTextShrinkQuickBtn"[^>]*aria-label="縮小介面"[^>]*>A−<\/button>/, 'HUD 的 A− 按鈕是介面縮放控制（不用放大鏡圖標）');
  assert.match(html, /id="storyTextGrowQuickBtn"[^>]*aria-label="放大介面"[^>]*>A\+<\/button>/, 'HUD 的 A+ 按鈕是介面縮放控制');
  assert.doesNotMatch(html, /uiZoomShrinkBtn|uiZoomGrowBtn|uiZoomLabel/, '沒有另外的放大鏡控制');
  assert.match(source, /\$\('storyTextShrinkQuickBtn'\)\.onclick=\(\)=>stepWebUiZoom\(-1\);/, 'HUD A− 縮小介面');
  assert.match(source, /\$\('storyTextGrowQuickBtn'\)\.onclick=\(\)=>stepWebUiZoom\(1\);/, 'HUD A+ 放大介面');
  assert.match(source, /const label=\$\('storyTextQuickSizeLabel'\);[\s\S]{0,420}resetWebUiZoom/, 'HUD 百分比標籤點一下重設介面縮放 100%');
  assert.match(source, /\$\('storyTextShrinkBtn'\)\.onclick=\(\)=>stepStoryTextSize\(-1\);/, '設定頁 A− 維持故事字級');
  assert.match(source, /if\(!event\.ctrlKey\|\|!event\.altKey\|\|event\.metaKey\)return;/, 'Ctrl+Alt 組合鍵不與故事字級 Ctrl+= 衝突');
  assert.match(source, /key==='='\|\|key==='\+'\|\|code==='NumpadAdd'\)\{\s*event\.preventDefault\(\);stepWebUiZoom\(1\)/, 'Ctrl+Alt+= 放大介面');
  assert.match(source, /key==='0'\|\|code==='Numpad0'\)\{\s*event\.preventDefault\(\);resetWebUiZoom\(\)/, 'Ctrl+Alt+0 回 100%');
  const uiEn = source.slice(source.indexOf('const UI_EN = {'), source.indexOf('\n};', source.indexOf('const UI_EN = {')));
  for (const key of ['介面縮放', '縮小介面', '放大介面', '縮小介面（Ctrl+Alt+-）', '放大介面（Ctrl+Alt+=）']) {
    assert.ok(uiEn.includes(`'${key}':`), `UI_EN covers ${key}`);
  }
});

test('A−／A＋ 進駐 HUD 帳號列：不會浮在下方蓋住第一個故事選項', () => {
  const barStart = html.indexOf('<div class="account-bar">');
  assert.ok(barStart >= 0, 'HUD 有帳號列');
  const barEnd = html.indexOf('</div>', barStart);
  const accountBar = html.slice(barStart, barEnd);
  assert.match(accountBar, /class="story-text-size hud-story-text-size"/, 'A−／A＋ 是帳號列的子元素，留在 HUD 內');
  assert.equal(html.split('hud-story-text-size').length - 1, 1, '頁面只有一組 A−／A＋');
  const baseRule = css.indexOf('.hud-story-text-size{position:absolute');
  const dockRule = css.indexOf('.game-hud .account-bar .hud-story-text-size{');
  assert.ok(baseRule >= 0, '保留原本的浮動樣式作為基底');
  assert.ok(dockRule > baseRule, '駐紮樣式寫在基底之後，才能覆蓋絕對定位');
  const dockCss = css.slice(dockRule, css.indexOf('}', dockRule));
  assert.match(dockCss, /position:static/, '不再用 absolute 浮到 HUD 下方');
  assert.match(dockCss, /top:auto;right:auto;left:auto/, '清掉浮動座標，避免與選項重疊');
});

test('視窗大小與位置會記住，且不會還原到看不見的螢幕上', () => {
  assert.match(main, /WINDOW_STATE_FILE = 'window-state\.json'/, '視窗狀態存 userData\\window-state.json');
  assert.match(main, /function loadWindowState\(\)/, '啟動時讀回狀態');
  assert.match(main, /function windowStateVisibleOnAnyDisplay\(bounds\)/, '還原前檢查螢幕範圍');
  assert.match(main, /screen\.getAllDisplays\(\)\.some\(display => \{/, '以目前接著的螢幕工作區驗證');
  assert.match(main, /win\.on\('resize', scheduleWindowStateSave\);/, '縮放後防抖保存');
  assert.match(main, /win\.on\('move', scheduleWindowStateSave\);/, '移動後防抖保存');
  assert.match(main, /win\.on\('close', \(\) => \{[\s\S]*?saveWindowState\(win\); \}\);/, '關閉時立即保存');
  assert.match(main, /getNormalBounds \? win\.getNormalBounds\(\) : win\.getBounds\(\)/, '最大化時保存未放大的大小');
  assert.match(main, /if \(savedState && savedState\.maximized\) win\.maximize\(\);/, '還原最大化狀態');
});

test('插圖接入使用目前官網供應商（Gemini 已登入即可出圖）', () => {
  assert.match(main, /provider = mode === 'external' && requestedProvider === 'gemini' \? 'gemini' : 'openai';/, '外部模式沿用目前故事供應商');
  assert.match(preload, /startSceneIllustration: \(prompt, mode, provider\) => ipcRenderer\.invoke\('scene-image:start', prompt, mode, provider\)/, 'preload 傳遞插圖供應商');
});

test('Google 登入修復：新分頁完成登入會改用新分頁；非對話頁會導回 /app', () => {
  assert.match(main, /watcher\.lastGate = gate;/, 'watcher 記住最近的登入閘門結果');
  assert.match(main, /if \(gate\.loginPage && Date\.now\(\) - watcher\.lastRecoveryAt >= 5000\) \{[\s\S]{0,220}recoverAutomationTab/, '卡在 accounts.google.com 時定期重掃分頁，改用已回到 Gemini 的分頁');
  assert.match(main, /watcher\.noEditorCount >= 6 && watcher\.lastGate && watcher\.lastGate\.ok && !watcher\.lastGate\.loggedOut/, '已登入卻沒有輸入框時不誤報需要登入');
  assert.match(main, /location\.hostname==='gemini\.google\.com'&&!location\.pathname\.startsWith\('\/app'\)\)\{location\.href=appUrl/, '自動把非對話頁導回 /app 再繼續');
  assert.match(main, /登入由使用者親自操作，時間無法預估[\s\S]{0,120}watcher\.startedAt = Date\.now\(\);/, '等待登入期間不計入自動化逾時（避免登入後不再自動填入／送出／接回）');
  assert.match(main, /if \(watcher\.loginNotified && gate && gate\.ok && !gate\.loggedOut\) \{[\s\S]{0,220}watcher\.startedAt = Date\.now\(\);/, '登入完成後重置逾時，填入→送出→接回拿到完整時間窗');
});
