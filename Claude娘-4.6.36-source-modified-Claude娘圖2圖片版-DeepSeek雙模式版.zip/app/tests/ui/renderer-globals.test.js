import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync, readdirSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';

// 這個測試專門擋一種很難發現的錯：在模組裡「賦值給一個從沒宣告過的變數」。
// 例如 `workshopEditorLoaded=true;` 卻忘了 `let workshopEditorLoaded=false;`
// ——測試與 esbuild 都不會叫，只有玩家打開那個畫面時才會 ReferenceError（ESM 是嚴格模式）。
// 做法：先把字串／樣板／註解拿掉（否則 HTML 屬性會被誤判），再收集所有宣告，
// 最後檢查每個「陳述句開頭的賦值目標」是否宣告過。
const source = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');
const wwwDir = fileURLToPath(new URL('../../www', import.meta.url));
const rendererFiles = readdirSync(wwwDir).filter(name => name.endsWith('.js') && !name.endsWith('.bundle.js')).sort();

// code 檔中本來就存在的瀏覽器／Node 全域，不需要宣告。
const GLOBALS = new Set([
  'window', 'document', 'globalThis', 'self', 'console', 'localStorage', 'sessionStorage', 'location', 'navigator',
  'fetch', 'alert', 'confirm', 'prompt', 'setTimeout', 'setInterval', 'clearTimeout', 'clearInterval',
  'requestAnimationFrame', 'cancelAnimationFrame', 'queueMicrotask', 'structuredClone',
  'atob', 'btoa', 'TextEncoder', 'TextDecoder', 'URL', 'URLSearchParams', 'Blob', 'File', 'FileReader',
  'Image', 'Audio', 'CustomEvent', 'Event', 'AbortController', 'MutationObserver', 'ResizeObserver', 'IntersectionObserver',
  'Intl', 'crypto', 'performance', 'process', 'module', 'exports', 'require', 'global',
  'JSON', 'Math', 'Date', 'Object', 'Array', 'String', 'Number', 'Boolean', 'Promise', 'Map', 'Set', 'WeakMap', 'WeakSet',
  'RegExp', 'Error', 'TypeError', 'RangeError', 'SyntaxError', 'Symbol', 'BigInt', 'Proxy', 'Reflect',
  'isNaN', 'isFinite', 'parseInt', 'parseFloat', 'encodeURIComponent', 'decodeURIComponent', 'escape', 'unescape'
]);

function stripLiterals(text) {
  let out = '';
  let index = 0;
  while (index < text.length) {
    const ch = text[index];
    if (ch === '/' && text[index + 1] === '/') { while (index < text.length && text[index] !== '\n') index++; out += ' '; continue; }
    if (ch === '/' && text[index + 1] === '*') { index += 2; while (index < text.length && !(text[index] === '*' && text[index + 1] === '/')) index++; index += 2; out += ' '; continue; }
    if (ch === "'" || ch === '"' || ch === '`') {
      const quote = ch;
      index++;
      while (index < text.length && text[index] !== quote) { if (text[index] === '\\') index++; index++; }
      index++;
      out += '""';
      continue;
    }
    out += ch;
    index++;
  }
  return out;
}

// 參數列／宣告列 → 識別字集合（去掉預設值、解構符號與逗號）。
function declaredNames(fragment) {
  return fragment.split(/[,{}[\]\s:()=]+/).filter(name => /^[A-Za-z_$][\w$]*$/.test(name));
}

function collectDeclared(code) {
  const names = new Set(GLOBALS);
  const add = fragment => { for (const name of declaredNames(fragment)) names.add(name); };
  for (const match of code.matchAll(/\b(?:let|const|var)\s+([^;\n]+)/g)) add(match[1]);
  for (const match of code.matchAll(/\bfunction\s*[\w$]*\s*\(([^)\n]*)\)/g)) add(match[1]);
  for (const match of code.matchAll(/\(([^)\n]*)\)\s*=>/g)) add(match[1]);
  for (const match of code.matchAll(/\b([A-Za-z_$][\w$]*)\s*=>/g)) names.add(match[1]);
  for (const match of code.matchAll(/\bcatch\s*\(([^)\n]*)\)/g)) add(match[1]);
  for (const match of code.matchAll(/\bfor\s*\(\s*(?:const|let|var)\s+([^;\n)]+)/g)) add(match[1]);
  return names;
}

function collectAssigned(code) {
  const assigned = new Set();
  for (const match of code.matchAll(/(?:^|[;{}])\s*([A-Za-z_$][\w$]*)\s*(?:=(?!=)|\+=|-=|\?\?=)/g)) assigned.add(match[1]);
  return assigned;
}

test('renderer source never assigns to an undeclared variable', () => {
  assert.ok(rendererFiles.length >= 10, 'the www folder was found');
  for (const name of rendererFiles) {
    const code = stripLiterals(readFileSync(path.join(wwwDir, name), 'utf8'));
    const declared = collectDeclared(code);
    const undeclared = [...collectAssigned(code)].filter(identifier => !declared.has(identifier));
    assert.deepEqual(undeclared, [], `${name}: these identifiers are assigned but never declared (add let/const, or a parameter)`);
  }
});

test('the workshop state variables used by the editor are all declared once', () => {
  const code = stripLiterals(source);
  const declared = collectDeclared(code);
  for (const name of ['workshopCodeEdits', 'workshopCodeDirty', 'workshopCurrentFile', 'workshopEditorLoaded', 'workshopFileList', 'workshopSourceInfo']) {
    assert.ok(declared.has(name), `${name} must be declared`);
    assert.match(source, new RegExp(`let\\s+${name}\\b`), `${name} is renderer state`);
  }
});

test('the undeclared-variable guard actually catches the bug it was written for', () => {
  // 反向驗證：拿掉宣告後，偵測器必須抓到（避免這個測試本身變成永遠通過的空殼）。
  const code = stripLiterals(source).replace(/let workshopEditorLoaded=false;\r?\n/, '');
  const declared = collectDeclared(code);
  assert.deepEqual([...collectAssigned(code)].filter(name => !declared.has(name)), ['workshopEditorLoaded']);
});
