// E13（2026-10-18）品牌統一：使用者可見「cIoudo」字樣＝0。
// 白名單（凍結）：遷移矩陣常數、LEGACY 快照、localStorage 鍵 'cioudo.bgAdjust'、
// 匯出識別碼 'cioudo10'（payload app 欄＋版本檢查）。完整清單見《開發線-E13-完成回報-2026-10-18.txt》。
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(import.meta.dirname, '../..');
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8').replace(/^\uFEFF/, '');
const readLines = (rel) => read(rel).split(/\r?\n/);

test('E13：index.html／manifest.json 品牌統一且無舊字樣', () => {
  const index = read('www/index.html');
  assert.equal(/cioudo/i.test(index), false, 'index.html 不得殘留 cIoudo');
  assert.match(index, /<title>Claude娘[^<]*<\/title>/);
  assert.match(index, /<span>Claude娘<\/span>的圖書館/);
  const manifest = read('www/manifest.json');
  assert.equal(/cioudo/i.test(manifest), false, 'manifest.json 不得殘留 cIoudo');
  assert.match(manifest, /"name": "Claude娘的圖書館｜AI互動文字小說"/);
  assert.match(manifest, /"short_name": "Claude娘"/);
});

test('E13：app.js 舊識別碼僅存白名單（遷移矩陣／匯出格式／鍵值）', () => {
  const lines = readLines('www/app.js');
  const allow = [
    /LEGACY_DEFAULT_CHARACTER_PROFILE=LEGACY_PRE_TSUNDERE_CHARACTER_PROFILE\.replaceAll\('Claude娘','claude 娘'\)/,
    /PREVIOUS_DEFAULT_CHARACTER_PROFILE=LEGACY_TSUNDERE_CHARACTER_PROFILE\.replaceAll\('Claude娘','cIoudo 娘'\)/,
    /E13_PREVIOUS_DEFAULT_CHARACTER_PROFILE=B5_PREVIOUS_DEFAULT_CHARACTER_PROFILE\.replaceAll\('Claude娘的圖書館','cIoudo娘的圖書館'\)/,
    /hasLegacyDefaultName=\['claude 娘','cIoudo 娘','cIoudo娘'\]/,
    /const KEY='cioudo\.bgAdjust'/,
    /app:'cioudo10'/,
    /!=='cioudo10'/,
  ];
  allow.forEach((re, idx) => {
    assert.ok(lines.some((l) => re.test(l)), '白名單第 ' + (idx + 1) + ' 條未命中：' + re);
  });
  const bad = [];
  lines.forEach((line, i) => {
    if (!/cioudo/i.test(line)) return;
    if (!allow.some((re) => re.test(line))) bad.push((i + 1) + ': ' + line.trim().slice(0, 160));
  });
  assert.deepEqual(bad, [], '非白名單舊識別碼殘留：\n' + bad.join('\n'));
  const src = lines.join('\n');
  assert.match(src, /✦ <span>Claude娘<\/span>的圖書館/);
  assert.match(src, /不是有效的 Claude娘資料包/);
  assert.match(src, /'Claude娘-kit-'/);
  assert.match(src, /'Claude娘-資料包-'/);
  assert.match(src, /const DEFAULT_CHARACTER_NAME='Claude娘'/);
});

test('E13：安裝身分（package.json／electron-main）品牌更新、技術識別碼凍結', () => {
  const raw = read('package.json');
  assert.equal(/cioudo/i.test(raw), false, 'package.json 不得殘留 cIoudo');
  const pkg = JSON.parse(raw);
  assert.equal(pkg.name, 'claude-novel-windows11');
  assert.equal(pkg.build.appId, 'com.claude.novel.windows11');
  assert.equal(pkg.build.productName, 'Claude娘 - Windows 11 電腦版');
  assert.equal(pkg.build.artifactName, 'Claude娘 - Windows 11 電腦版-Setup-${version}-${arch}.${ext}');
  assert.equal(pkg.build.nsis.shortcutName, 'Claude娘 - Windows 11 電腦版');
  assert.match(pkg.description, /^Claude娘/);
  const main = read('electron-main.cjs');
  assert.equal(/cioudo/i.test(main), false, 'electron-main.cjs 不得殘留 cIoudo');
  assert.match(main, /Claude娘 - Windows 11 電腦版/);
});

test('E13：DEFAULT 換新品牌、LEGACY 快照凍結、server.js 訊息更新', () => {
  const profLines = readLines('www/character-profile.js');
  const firstCioudo = profLines.findIndex((l) => /cioudo/i.test(l));
  assert.ok(firstCioudo > 0, '應保留 LEGACY 快照（含舊字樣）');
  const defaultPart = profLines.slice(0, firstCioudo).join('\n');
  assert.equal(/cioudo/i.test(defaultPart), false, 'DEFAULT 段不得殘留 cIoudo');
  assert.equal(profLines.filter((l) => /cioudo/i.test(l)).length, 3, '僅 3 行 LEGACY 快照／註解保留舊字樣');
  assert.match(defaultPart, /你是「Claude娘」，「Claude娘的圖書館」的管理者/);
  const server = read('server/server.js');
  assert.equal(/cioudo/i.test(server), false, 'server.js 不得殘留 cIoudo');
  assert.match(server, /Claude娘 server listening/);
});
