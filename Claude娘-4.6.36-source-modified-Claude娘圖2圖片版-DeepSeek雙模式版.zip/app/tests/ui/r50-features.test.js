import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';

const source = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');
const html = readFileSync(new URL('../../www/index.html', import.meta.url), 'utf8');
const css = readFileSync(new URL('../../www/style.css', import.meta.url), 'utf8');

test('好感度歸 0 即遊戲結束（applyTurn 判定）', () => {
  assert.match(source, /if\(state\.affection<=0&&state\.history\.length>=1\)\{[\s\S]{0,200}state\.gameOver=true;/, '好感夾在 0 後立即觸發 gameOver');
  assert.match(source, /state\.choices=\[\];/, 'Game Over 時清空七選項');
});

test('Game Over 狀態隨存檔往返', () => {
  assert.match(source, /gameOver: !!rawState\.gameOver,/, 'normalizeSlot 讀回 gameOver');
  assert.match(source, /gameOver: !!source\.gameOver,/, 'serializeState 寫入 gameOver');
  assert.match(source, /gameOver: false,/, 'fresh() 預設 false（重新開局自動歸零）');
});

test('Game Over 畫面：只有圖片與「重新開始故事」按鈕（無標題），且在 main 外不受分頁切換影響', () => {
  assert.match(html, /id="gameOverScreen"[^>]*hidden>/, '覆蓋層存在');
  assert.match(html, /class="game-over-image" src="assets\/game-over\.jpg"/, '使用打包的 game-over.jpg');
  assert.match(html, /id="gameOverRestartBtn"[^>]*>重新開始故事<\/button>/, '唯一按鈕＝重新開始故事');
  const overlay = html.slice(html.indexOf('id="gameOverScreen"'), html.indexOf('gameOverRestartBtn') + 60);
  assert.ok(!overlay.includes('<h1') && !overlay.includes('<h2'), '沒有標題文字');
  assert.doesNotMatch(overlay, /繼續故事|離開|存檔/, '沒有其他選項');
  assert.ok(existsSync(new URL('../../www/assets/game-over.jpg', import.meta.url)), '圖片已入包（www/assets/game-over.jpg）');
  // R51 修復：覆蓋層必須在 <main> 外（body 層級），否則切到設定分頁時會被 display:none 藏掉而逃離 Game Over。
  const mainStart = html.indexOf('<main>');
  const goAt = html.indexOf('id="gameOverScreen"');
  assert.ok(goAt >= 0 && goAt < mainStart, '覆蓋層位於 <main> 之前（body 層級）');
});

test('Game Over 只能重新開始：render 綁定＋按鈕直接重置（不 confirm）', () => {
  assert.match(source, /gameOverScreen\.hidden=!state\.gameOver;/, 'render 依 state.gameOver 顯示');
  assert.match(source, /\$\('gameOverRestartBtn'\)\.onclick=\(\)=>\{[\s\S]{0,300}pauseStoryForExit\(\);[\s\S]{0,200}state=restartBaseState\(\);/, '點按鈕直接走重置流程');
  assert.doesNotMatch(source, /gameOverRestartBtn[\s\S]{0,300}confirm\(/, '不彈 confirm（點按鈕即選擇）');
});

test('Game Over 中封鎖存檔與 Esc', () => {
  assert.match(source, /if \(state\.gameOver\) return; \/\/ R50：Game Over 中不可存檔/, 'quickSave 封鎖');
  assert.match(source, /if \(state\.gameOver\) return; \/\/ R50：Game Over 覆蓋層不受 Esc 影響/, 'Esc 封鎖');
});

test('Game Over 樣式：全螢幕覆蓋、圖片置中', () => {
  assert.match(css, /\.game-over-screen\{position:fixed;inset:0;z-index:9999/, '全螢幕最高層');
  assert.match(css, /\.game-over-image\{max-width:min\(92vw,860px\);max-height:72vh;object-fit:contain/, '圖片 contain 置中');
});
