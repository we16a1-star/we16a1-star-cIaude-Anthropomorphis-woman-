// 批4／E11：字級調整「全頁面覆蓋」釘樁測試。
// 背景：A-／A+ 原本只縮放故事文字區，選單／面板／對話框為寫死 px 不受影響；
// 修復＝style.css 全量就地轉換：font-size:N px → calc(N px * var(--story-font-scale,1))，
// 只動字級、不動 cascade 順序，100% 時外觀零變化（E11 批4）。
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const css = readFileSync(new URL('../../www/style.css', import.meta.url), 'utf8');

test('every px font size scales with --story-font-scale (no raw px left)', () => {
  const raw = css.match(/font-size:\s*\d+(?:\.\d+)?px/g) || [];
  assert.equal(raw.length, 0, 'no hard-coded px font sizes may remain: ' + raw.slice(0, 5).join(' / '));
  const scaled = css.match(/font-size:calc\(\d+(?:\.\d+)?px \* var\(--story-font-scale,1\)\)/g) || [];
  assert.ok(scaled.length >= 180, 'the whole interface is covered by the story-font-scale variable (found ' + scaled.length + ')');
  assert.match(css, /--story-font-scale:1/, 'the default scale is still defined');
});

test('menus and panels scale with the control', () => {
  assert.match(css, /#gameMenu \.game-menu-item\{[^}]*font-size:calc\(14px \* var\(--story-font-scale,1\)\)/, 'game menu entries scale');
  assert.match(css, /h2\.sec\{[^}]*font-size:calc\(15px \* var\(--story-font-scale,1\)\)/, 'panel headings scale');
  assert.match(css, /p\.sec-body\{font-size:calc\(13\.5px \* var\(--story-font-scale,1\)\)/, 'panel body text scales');
  assert.match(css, /\.ai-status\{[^}]*font-size:calc\(12px \* var\(--story-font-scale,1\)\)/, 'status notes scale');
  assert.match(css, /\.slot-excerpt\{margin:6px 0 0;font-size:calc\(11\.5px \* var\(--story-font-scale,1\)\)/, 'save slot excerpts scale');
});

test('story surfaces added in batch 4 scale too', () => {
  assert.match(css, /\.story-clock\{[^}]*font-size:calc\(10\.5px \* var\(--story-font-scale,1\)\)/, 'the story clock chip scales');
  assert.match(css, /\.story-notice\{[^}]*font-size:calc\(11px \* var\(--story-font-scale,1\)\)/, 'story notices scale');
  assert.match(css, /\.free-row input\{[^}]*font-size:calc\(13\.5px \* var\(--story-font-scale,1\)\)/, 'the free input line scales');
  assert.match(css, /\.free-row textarea\{[^}]*font-size:calc\(13\.5px \* var\(--story-font-scale,1\)\)/, 'the free textarea scales');
});

test('the speaker name plate (G12a hard-coded break) scales again', () => {
  assert.match(css, /#tab-story\.has-web-pending \.vn-speaker\{[^}]*font-size:calc\(12px \* var\(--story-font-scale,1\)\)/, 'pending-mode speaker plate scales');
  assert.match(css, /\.vn-speaker\{top:-26px;[^}]*font-size:calc\(12\.5px \* var\(--story-font-scale,1\)\)/, 'regular speaker plate scales');
});

test('prompt history dialog keeps its monospace editor while scaling', () => {
  assert.match(css, /\.prompt-history-dialog textarea\{[^}]*font-family:Consolas,monospace;font-size:calc\(12px \* var\(--story-font-scale,1\)\);line-height:1\.55\}/, 'the shorthand was split and scaled');
});

// 批5／E11：端點禁用態釘樁——85% 禁 A-、200% 禁 A+（α.35＋not-allowed）；
// 級距七段維持、點按端點不再改變級距（僅呈現與 aria，不新增 CSS）。
import {Script} from 'node:vm';
const appSource = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');

test('E11：端點禁用態——85% 禁 A-、200% 禁 A+（α.35＋not-allowed）', () => {
  const buttons = {};
  for (const id of ['storyTextSizeLabel', 'storyTextShrinkBtn', 'storyTextGrowBtn']) {
    buttons[id] = { textContent: '', style: {}, attrs: {}, setAttribute(name, value) { this.attrs[name] = value; } };
  }
  const props = {};
  const start = appSource.indexOf('const STORY_TEXT_SIZE_KEY');
  const endMarker = '\napplyStoryTextSize();';
  const end = appSource.indexOf(endMarker, start);
  assert.ok(start >= 0 && end > start, '字級常數與函式區塊存在');
  const code = appSource.slice(start, end + endMarker.length);
  const context = {
    localStorage: { getItem: () => null, setItem: () => {} },
    document: { documentElement: { style: { setProperty(name, value) { props[name] = value; } } } },
    $: id => buttons[id] || null
  };
  new Script(code + `
this.setSize=value=>{storyTextSize=value;applyStoryTextSize();};
this.getSize=()=>storyTextSize;
this.step=stepStoryTextSize;
this.atMin=storyTextSizeAtMin;this.atMax=storyTextSizeAtMax;this.sizes=STORY_TEXT_SIZES;this.scales=STORY_TEXT_SCALES;`).runInNewContext(context);

  context.setSize('m');
  assert.equal(props['--story-font-scale'], '1', '100%＝scale 1');
  assert.equal(buttons.storyTextSizeLabel.textContent, '100%');
  assert.equal(buttons.storyTextShrinkBtn.attrs['aria-disabled'], 'false', '中段＝A- 可用');
  assert.equal(buttons.storyTextGrowBtn.attrs['aria-disabled'], 'false', '中段＝A+ 可用');

  context.setSize('xs');
  assert.equal(props['--story-font-scale'], '0.85', '85%＝scale 0.85');
  assert.equal(buttons.storyTextSizeLabel.textContent, '85%');
  assert.equal(buttons.storyTextShrinkBtn.attrs['aria-disabled'], 'true', '85%＝A- 禁用');
  assert.equal(buttons.storyTextShrinkBtn.style.opacity, '.35', '禁用＝α.35');
  assert.equal(buttons.storyTextShrinkBtn.style.cursor, 'not-allowed', '禁用＝not-allowed');
  assert.equal(buttons.storyTextGrowBtn.attrs['aria-disabled'], 'false', '85%＝A+ 仍可用');
  context.step(-1);
  assert.equal(context.getSize(), 'xs', '端點點按不再改變級距');
  context.step(1);
  assert.equal(context.getSize(), 's', '非端點照常級距');

  context.setSize('xxxl');
  assert.equal(props['--story-font-scale'], '2', '200%＝scale 2');
  assert.equal(buttons.storyTextSizeLabel.textContent, '200%');
  assert.equal(buttons.storyTextGrowBtn.attrs['aria-disabled'], 'true', '200%＝A+ 禁用');
  assert.equal(buttons.storyTextGrowBtn.style.opacity, '.35', '禁用＝α.35');
  assert.equal(buttons.storyTextGrowBtn.style.cursor, 'not-allowed', '禁用＝not-allowed');
  assert.equal(buttons.storyTextShrinkBtn.attrs['aria-disabled'], 'false', '200%＝A- 仍可用');
  context.step(1);
  assert.equal(context.getSize(), 'xxxl', '上端點點按不再改變級距');
  assert.deepEqual([...context.sizes], ['xs', 's', 'm', 'l', 'xl', 'xxl', 'xxxl'], '級距七段維持');
  assert.deepEqual(Object.values(context.scales), [0.85, 0.925, 1, 1.15, 1.35, 1.6, 2], '級距比例維持（85–200%）');
});
