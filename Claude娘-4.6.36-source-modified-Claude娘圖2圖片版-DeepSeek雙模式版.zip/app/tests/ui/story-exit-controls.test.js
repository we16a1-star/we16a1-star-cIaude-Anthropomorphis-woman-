import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const html = readFileSync(new URL('../../www/index.html', import.meta.url), 'utf8');
const source = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');
const css = readFileSync(new URL('../../www/style.css', import.meta.url), 'utf8');
const main = readFileSync(new URL('../../electron-main.cjs', import.meta.url), 'utf8');
const preload = readFileSync(new URL('../../electron-preload.cjs', import.meta.url), 'utf8');

test('故事中可見存檔與離開控制，且只在有故事時顯示', () => {
  assert.match(html, /id="storySaveHudBtn"[\s\S]*?id="exitStoryHudBtn"/, 'HUD has save/load and leave-story buttons');
  assert.match(html, /id="storySaveHudBtn"[^>]*>存檔<\/button>/, 'HUD save uses the text 存檔, not an icon');
  assert.match(html, /id="exitStoryMenuBtn"[\s\S]*?<\/div>/, 'game menu has a leave-story item');
  assert.match(source, /const hasStory=Boolean\(state\.history\.length\|\|state\.pendingAction\)/, 'controls follow whether a story exists');
  assert.match(source, /if\(saveHud\)\{saveHud\.hidden=!hasStory;saveHud\.disabled=busy;\}/, 'save button is hidden without a story and disabled while busy');
  assert.match(source, /if\(exitHud\)exitHud\.hidden=!hasStory;/, 'leave button is hidden without a story');
  assert.match(source, /\$\('storySaveHudBtn'\)\.onclick=openStorySlots;/, 'HUD save opens the slot panel');
  assert.match(source, /\$\('exitStoryHudBtn'\)\.onclick=leaveStory;/, 'HUD leave opens the exit overlay');
  assert.match(source, /\$\('exitStoryMenuBtn'\)\.onclick=leaveStory;/, 'game-menu leave opens the exit overlay');
});

test('離開故事只暫停並保留存檔，繼續或重新開局各有明確入口', () => {
  assert.match(html, /id="storyExitScreen"[\s\S]*?id="resumeStoryBtn"[\s\S]*?id="exitOpenSlotsBtn"[\s\S]*?id="exitRestartStoryBtn"/, 'overlay offers resume, save/load, and restart');
  assert.match(source, /function leaveStory\(\)\{[\s\S]*?storyExited=true;[\s\S]*?pauseStoryForExit\(\);[\s\S]*?render\(\);/, 'leaving pauses automation without clearing the slot');
  assert.match(source, /function resumeStory\(\)\{[\s\S]*?storyExited=false;[\s\S]*?queueWebAutoReply\(queued\)/, 'resuming restores the screen and flushes a reply that arrived while paused');
  assert.match(source, /function restartCurrentStory\(\)\{[\s\S]*?pauseStoryForExit\(\);[\s\S]*?state=restartBaseState\(\);[\s\S]*?save\(true\)/, 'restart shares the reset flow and force-saves the cleared slot');
  assert.match(source, /if\(storyExited\)\{webAutoQueuedReply=reply;return;\}/, 'replies are queued instead of advancing the story behind the overlay');
  assert.match(source, /const active=Boolean\(webAutoFlow\)[\s\S]*?&&!storyExited;/, 'automation is inactive while the story is paused');
  assert.match(source, /!state\.pendingAction\|\|state\.aiMode!=='web'\|\|busy\|\|storyExited\)\{stopWebClipboardMonitor/, 'clipboard watching stops while paused');
  assert.match(source, /event\.key !== 'Escape'[\s\S]*?if\s*\(gameMenuOpen\)\s*\{\s*setGameMenu\(false\); return; \}/, 'Escape closes the game menu without erasing the story');
  assert.match(source, /if \(storyExited\) \{ resumeStory\(\); return; \}/, 'Escape resumes the paused story');
  assert.match(source, /storyTab\?\.classList\.contains\('active'\) && \(state\.history\.length \|\| state\.pendingAction\)\) leaveStory\(\)/, 'Escape opens the exit overlay like a galgame menu');
});

test('字級重設與存檔快捷鍵都有可見與鍵盤入口', () => {
  assert.match(html, /<b id="storyTextQuickSizeLabel" aria-live="polite" title="依視窗大小自動縮放；點一下改為手動 100%">100%<\/b>/, 'HUD percentage (interface zoom) shows the adaptive-zoom hint');
  assert.match(source, /for\(const id of \['storyTextSizeLabel'\]\)/, 'the settings percentage label resets the story font size');
  assert.match(source, /label\.addEventListener\('click',reset\)/, 'clicking the percentage resets to 100%');
  assert.match(source, /const label=\$\('storyTextQuickSizeLabel'\);[\s\S]{0,420}resetWebUiZoom/, 'the HUD percentage label resets the interface zoom');
  assert.match(source, /key==='\+'[\s\S]*?stepStoryTextSize\(1\)/, 'Ctrl+= enlarges the story text');
  assert.match(source, /key==='-'[\s\S]*?stepStoryTextSize\(-1\)/, 'Ctrl+- shrinks the story text');
  assert.match(source, /key==='0'[\s\S]*?resetStoryTextSize\(\)/, 'Ctrl+0 resets the story text');
  assert.match(source, /if\(\(key==='s'\|\|code==='KeyS'\)&&!event\.shiftKey\)\{[\s\S]*?quickSave\(\)/, 'Ctrl+S quick-saves without hijacking Ctrl+Shift+S');
});

test('設定頁有完整登入與接入檢查，外部模式共用自動化專用瀏覽器', () => {
  assert.match(html, /id="webOpenLoginBtn"[\s\S]*?id="webCheckConnectionBtn"[\s\S]*?id="webRestartAutomationBtn"/, 'settings exposes open, check, and restart');
  assert.match(source, /\$\('webOpenLoginBtn'\)\.onclick=\(\)=>void openWebLoginFromSettings\(\)/, 'open button uses the dedicated login flow');
  assert.match(source, /\$\('webCheckConnectionBtn'\)\.onclick=\(\)=>void checkWebConnection\(\)/, 'check button reports login/editor/reply state');
  assert.match(source, /\$\('webRestartAutomationBtn'\)\.onclick=\(\)=>void restartAutomationBrowserFromSettings\(\)/, 'restart button is wired');
  assert.match(source, /await window\.claudeDesktop\.reconnectAutomationBrowser\(\{provider\}\)/, 'external login reuses the automation profile and navigates a real page');
  assert.match(main, /ipcMain\.handle\('ai-web:automation-reconnect'/, 'main exposes reconnect IPC');
  assert.match(main, /ipcMain\.handle\('ai-web:automation-restart'/, 'main exposes restart IPC');
  assert.match(preload, /reconnectAutomationBrowser: payload => ipcRenderer\.invoke\('ai-web:automation-reconnect', payload\)/, 'preload exposes reconnect');
  assert.match(preload, /restartAutomationBrowser: payload => ipcRenderer\.invoke\('ai-web:automation-restart', payload\)/, 'preload exposes restart');
});

test('新控制項使用故事字級縮放，overlay 不會被 hidden 覆蓋', () => {
  assert.match(css, /\.story-exit-screen\[hidden\]\{display:none\}/, 'hidden attribute always wins over the flex layout');
  assert.match(css, /\.story-exit-card h2\{[\s\S]*?font-size:calc\(24px \* var\(--story-font-scale,1\)\)/, 'overlay title follows the story font scale');
  assert.match(css, /\.web-connection-actions button\{[\s\S]*?font-size:calc\(12\.5px \* var\(--story-font-scale,1\)\)/, 'connection buttons follow the story font scale');
  assert.doesNotMatch(css, /font-size:\s*\d+(?:\.\d+)?px/, 'no raw px font sizes are reintroduced');
});
