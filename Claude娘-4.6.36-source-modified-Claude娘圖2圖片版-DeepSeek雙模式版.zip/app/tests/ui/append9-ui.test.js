// 追加九（UI 與回退）：世界書辭典／作者註記／回合回退／歷史編輯／資料包／設定開關。
// 資料層（world-book／prompt-rules）已有各自測試；這裡驗證畫面節點、接線與回退行為。
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {Script} from 'node:vm';
import {advanceStoryClock,affectionStageKeyOf,affectionStageOf,normalizeStoryClock,realStoryClock,normalizeMilestoneKey,stageByKey,stageIndexByKey} from '../../www/story-clock.js';
import {normalizeGiftConversations} from '../../www/gift-system.js';
import {normalizeSpecialEventKey} from '../../www/special-events.js';

const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
const html=readFileSync(new URL('../../www/index.html',import.meta.url),'utf8');
const css=readFileSync(new URL('../../www/style.css',import.meta.url),'utf8');
const worldBookSource=readFileSync(new URL('../../www/world-book.js',import.meta.url),'utf8');
const storyClockHelpers={advanceStoryClock,affectionStageKeyOf,affectionStageOf,normalizeStoryClock,realStoryClock,stageByKey,stageIndexByKey,refreshTimeTheme:()=>{}};
const testSanitizeChoices=list=>(Array.isArray(list)?list:[]).map(item=>String(item)).slice(0,7);

function loadNormalizeLastTurnUndo(){
  const start=source.indexOf('function normalizeLastTurnUndo(');
  const end=source.indexOf('function normalizeSlot(',start);
  assert.ok(start>=0&&end>start,'回合回退正規化函式存在');
  const context={sanitizeChoices:testSanitizeChoices,normalizeStoryClock,normalizeMilestoneKey,normalizeSpecialEventKey,normalizeGiftConversations,Number,Math,String};
  new Script(source.slice(start,end)+'\nthis.normalizeLastTurnUndo=normalizeLastTurnUndo;').runInNewContext(context);
  return context.normalizeLastTurnUndo;
}
const normalizeLastTurnUndo=loadNormalizeLastTurnUndo();

test('追加九 UI：辭典／資料／回想回退／作者註記／歷史編輯／設定開關的節點都在',()=>{
  for(const id of ['gmMenuDictBtn','gmMenuDict','gmDictBackBtn','worldBookToggle','worldBookCount','worldBookAddBtn','worldBookList','gmMenuDataBtn','gmMenuData','gmDataBackBtn','exportKitBtn','importKitBtn','importKitFile','kitStatus','rewriteLastBtn','deleteLastBtn','historyEditDialog','historyEditText','historyEditSaveBtn','historyEditCancelBtn','authorNoteBtn','authorNoteDialog','authorNoteToggle','authorNoteText','authorNoteSaveBtn','worldBookEditDialog','worldBookKeywords','worldBookEntryText','worldBookEntrySaveBtn','worldBookEntryDeleteBtn','featureWorldBookToggle','featureAuthorNoteToggle','featureUndoToggle','featureHistoryEditToggle','tweakRuleStyle','tweakRuleTone','tweakRuleMemory','tweakRuleChoices','tweakExtra']){
    assert.match(html,new RegExp(`id="${id}"`),`節點 ${id} 存在`);
  }
  assert.match(html,/id="worldBookEntryEnabled" type="checkbox"/);
  assert.match(html,/id="historyEditText" rows="8" maxlength="100000"/,'歷史編輯上限 100000 字');
  assert.match(css,/\.dict-card\{/,'辭典卡外觀');
  assert.match(css,/\.game-overlay-foot\{/,'回想底部回退列外觀');
  assert.match(css,/\.feature-settings\{/,'設定頁功能列外觀');
});

test('normalizeLastTurnUndo：壞值＝null（回退鈕停用）；合法值寬容正規化',()=>{
  assert.equal(normalizeLastTurnUndo(undefined),null);
  assert.equal(normalizeLastTurnUndo(null),null);
  assert.equal(normalizeLastTurnUndo('x'),null);
  assert.equal(normalizeLastTurnUndo({keepLen:99999}),null,'超過上限視為損壞');
  assert.equal(normalizeLastTurnUndo({keepLen:'x'}).keepLen,0,'非數字寬容為 0');
  const undo=normalizeLastTurnUndo({action:'前進',keepLen:2.9,affection:'80',affectionPityStart:'123',memory:'m',choices:['a','b'],storyClock:{enabled:true,day:2,slot:1},pendingMilestone:'',ending:'yes',giftConversations:[]});
  assert.equal(undo.action,'前進');
  assert.equal(undo.keepLen,2);
  assert.equal(undo.affection,80);
  assert.equal(undo.affectionPityStart,123);
  assert.deepEqual(undo.choices,['a','b']);
  assert.deepEqual(undo.storyClock,{mode:'story',enabled:true,day:2,slot:1,anchor:0});
  assert.equal(undo.ending,false,'只有嚴格的 true 才算結局');
  assert.ok(Array.isArray(undo.giftConversations));
});

test('applyTurn：成功才寫回退快照（含選擇點前值）；失敗的回合不寫',()=>{
  const start=source.indexOf('function handleAffectionStageChange(');
  const end=source.indexOf('\nfunction refreshGiftConversations()',start);
  assert.ok(start>=0&&end>start);
  const oldChoices=['o1','o2','o3','o4','o5','o6','o7'];
  const makeContext=()=>{
    const context={...storyClockHelpers,rollSpecialEvent:()=>'',state:{affection:50,difficulty:'normal',affectionPityStart:7,history:[{role:'user',text:'行動A'}],choices:[...oldChoices],ending:false,storyMemory:'舊記憶',storyClock:{enabled:false,day:1,slot:0},pendingMilestone:'',giftConversations:[],pendingAction:'行動A',lastTurnUndo:null},sanitizeChoices:testSanitizeChoices,Number,Math,Date,String};
    new Script(source.slice(start,end)+'\nthis.applyTurn=applyTurn;').runInNewContext(context);
    return context;
  };
  const goodReply={affectionDelta:2,narration:'她點了點頭。',choices:['n1','n2','n3','n4','n5','n6','n7'],ending:false,memory:'新記憶'};
  const ok=makeContext();
  ok.applyTurn(goodReply);
  const undo=ok.state.lastTurnUndo;
  assert.ok(undo,'成功回合寫入快照');
  assert.equal(undo.action,'行動A');
  assert.equal(undo.keepLen,0,'快照指向玩家行動那一行之前（選擇點）');
  assert.equal(undo.affection,50);
  assert.equal(undo.affectionPityStart,7);
  assert.equal(undo.memory,'舊記憶');
  assert.deepEqual(undo.choices,oldChoices,'還原後仍是原本的七個選項');
  assert.equal(undo.ending,false);

  const bad=makeContext();
  const badReply={affectionDelta:1,narration:'半截。',choices:['只有一個'],ending:false,memory:'x'};
  assert.throws(()=>bad.applyTurn(badReply),/7/);
  assert.equal(bad.state.lastTurnUndo,null,'失敗回合不寫快照');

  const opening=makeContext();
  opening.state.pendingAction='__OPENING__';
  opening.state.history=[];
  opening.applyTurn({...goodReply,choices:['a1','a2','a3','a4','a5','a6','a7']});
  assert.equal(opening.state.lastTurnUndo.action,'__OPENING__');
  assert.equal(opening.state.lastTurnUndo.keepLen,0,'開場回退＝整個重來');
});

test('刪除／重寫上一回合：還原到選擇點；沒有快照或忙碌時不動',()=>{
  const start=source.indexOf('function restoreTurnUndo(');
  const end=source.indexOf('function giveGift(',start);
  assert.ok(start>=0&&end>start,'回退函式區塊存在');
  const calls=[];
  const baseUndo=()=>({action:'行動A',keepLen:1,affection:50,affectionPityStart:0,memory:'舊記憶',choices:['o1','o2','o3','o4','o5','o6','o7'],storyClock:{enabled:false,day:1,slot:0},pendingMilestone:'',ending:false,giftConversations:[]});
  const makeState=()=>({history:[{role:'user',text:'更早'},{role:'user',text:'行動A'},{role:'ai',text:'正文'}],affection:60,affectionPityStart:0,storyMemory:'新記憶',choices:['n1','n2'],storyClock:{enabled:false,day:1,slot:0},pendingMilestone:'',ending:false,giftConversations:[],pendingAction:'',lastTurnUndo:baseUndo()});
  const context={
    normalizeLastTurnUndo,
    save:()=>{calls.push('save');return true;},
    render:()=>{calls.push('render');},
    writeAutoSave:()=>{calls.push('autoSave');},
    scrollDialogueIntoView:()=>{},
    snapshotForRollback:value=>({...value}),
    confirm:()=>true,
    uiText:value=>value,
    opening:()=>{calls.push('opening');},
    continueStory:action=>{calls.push('continue:'+action);},
    busy:false,
    storyNoticeText:'',
    state:makeState()
  };
  new Script(source.slice(start,end)+'\nthis.restoreTurnUndo=restoreTurnUndo;this.rewriteLastTurn=rewriteLastTurn;this.deleteLastTurn=deleteLastTurn;').runInNewContext(context);

  context.deleteLastTurn();
  assert.deepEqual(context.state.history,[{role:'user',text:'更早'}],'刪除＝切回選擇點（玩家行動也移除）');
  assert.deepEqual(context.state.choices,['o1','o2','o3','o4','o5','o6','o7'],'原本的七個選項復原');
  assert.equal(context.state.affection,50);
  assert.equal(context.state.storyMemory,'舊記憶');
  assert.equal(context.state.lastTurnUndo,null,'快照用完即清');
  assert.ok(calls.includes('save')&&calls.includes('autoSave'),'刪除後存檔');

  calls.length=0;
  Object.assign(context.state,makeState());
  context.rewriteLastTurn();
  assert.deepEqual(context.state.history,[{role:'user',text:'更早'}]);
  assert.ok(calls.includes('continue:行動A'),'重寫＝用同一行動重新生成');
  assert.equal(context.state.pendingAction,'','交給 continueStory 重新排隊');
  assert.equal(context.state.lastTurnUndo,null);

  calls.length=0;
  Object.assign(context.state,makeState());
  context.state.pendingAction='__OPENING__';
  context.state.lastTurnUndo={...baseUndo(),action:'__OPENING__',keepLen:0};
  context.rewriteLastTurn();
  assert.ok(calls.includes('opening'),'開場的重寫走 opening()');

  calls.length=0;
  Object.assign(context.state,makeState());
  context.state.lastTurnUndo=null;
  context.rewriteLastTurn();
  context.deleteLastTurn();
  assert.deepEqual(calls,[],'沒有快照＝兩顆按鈕都不動作');
  assert.equal(context.state.history.length,3,'沒有快照時歷史不變');
});

test('追加九接線：序列化欄位、選單視圖、回退鈕顯示、歷史編輯與資料包格式',()=>{
  assert.match(source,/state\.lastTurnUndo=\{[\s\S]{0,90}?action:undoBefore\.action,/,'applyTurn 寫入快照');
  assert.match(source,/undoBefore\.keepLen=undoBefore\.action==='__OPENING__'\?state\.history\.length:Math\.max\(0,state\.history\.length-1\);/,'快照長度＝玩家行動之前');
  assert.match(source,/undoToolsEnabled: rawState\.undoToolsEnabled !== false,/);
  assert.match(source,/historyEditEnabled: rawState\.historyEditEnabled !== false,/);
  assert.match(source,/lastTurnUndo: normalizeLastTurnUndo\(rawState\.lastTurnUndo\),/);
  assert.match(source,/undoToolsEnabled: source\.undoToolsEnabled !== false,/);
  assert.match(source,/historyEditEnabled: source\.historyEditEnabled !== false,/);
  assert.match(source,/lastTurnUndo: normalizeLastTurnUndo\(source\.lastTurnUndo\),/);
  assert.match(source,/showGameMenuView\('gmMenuDict'\)/,'辭典子視圖');
  assert.match(source,/showGameMenuView\('gmMenuData'\)/,'資料子視圖');
  assert.match(source,/rewriteBtn\.hidden=!undoReady/,'回退鈕隨快照顯示');
  assert.match(source,/if\(book\.entries\.length===1\)book\.enabled=true;/,"新增第一條自動開世界書（設計 A）");
  assert.match(source,/state\.history = state\.history\.map\(\(entry,index\)=>index===historyEditIndex\?\{\.\.\.entry,text:value\}:entry\);/, '歷史編輯換新陣列（快取失效）');
  assert.match(source,/app:'cioudo10',version:1/,'資料包格式');
  assert.match(source,/parsed\?\.app!=='cioudo10'\|\|parsed\?\.version!==1/,'資料包驗證');
  assert.match(source,/featureUndoToggle\.onchange/,'設定頁回退開關');
  assert.match(source,/historyEditEnabled!==false/,'歷史編輯鈕受開關控制');
});

test('批6 Ｂ6-2 世界書 UI／IO：節點、事件、i18n 與 append-only CSS', () => {
  for (const id of ['worldBookSearch','worldBookFilter','worldBookExportBtn','worldBookImportBtn','worldBookImportFile','worldBookIoStatus','worldBookPreview','worldBookTestInput','worldBookTestBtn','worldBookTestResult','worldBookImportDialog','worldBookImportSummary','worldBookImportConfirmBtn','worldBookImportCancelBtn','worldBookEntryConstant','worldBookEntryPriority','worldBookEntryScope','worldBookKeywordChips']) {
    assert.match(html, new RegExp('id="' + id + '"'), '節點 ' + id + ' 存在');
  }
  for (const value of ['all','on','const','off']) assert.match(html, new RegExp('data-filter="' + value + '"'), '篩選 chip ' + value);
  for (const value of ['merge','overwrite','skip']) assert.match(html, new RegExp('name="worldBookImportConflict" value="' + value + '"'), '匯入衝突選項 ' + value);
  assert.match(html, /id="worldBookSearch"[^>]*placeholder="🔍 搜尋條目／觸發詞…"/, '搜尋框');
  assert.match(html, /id="worldBookTestInput"[^>]*placeholder="輸入測試句…"/, '測試輸入框');
  assert.match(source, /worldBookSearchInput\.oninput = \(\) => \{ worldBookSearch = worldBookSearchInput\.value; renderWorldBook\(\); \};/, '搜尋即時過濾');
  assert.match(source, /worldBookFilter = button\.dataset\.filter \|\| 'all'; renderWorldBook\(\);/, '篩選 chip 接線');
  assert.match(source, /worldBookExport\.onclick = \(\) => exportWorldBookFile\(\);/, '單書匯出接線');
  assert.match(source, /worldBookImportFile\.onchange = event => \{[\s\S]{0,160}?handleWorldBookImportFile\(file\);/, '單書匯入選檔接線');
  assert.match(source, /worldBookTestInput\.oninput = \(\) => renderWorldBookTest\(\);/, '測試觸發即時接線');
  assert.match(source, /radio\.onchange = \(\) => updateWorldBookImportSummary\(\);/, '衝突三選更新預覽');
  assert.match(source, /worldBookImportConfirm\.onclick = \(\) => confirmWorldBookImport\(\);/, '匯入確認');
  assert.match(source, /worldBookImportCancel\.onclick = \(\) => cancelWorldBookImport\(\);/, '匯入取消');
  assert.match(source, /worldBookImportDialog\.oncancel = event => \{ event\.preventDefault\(\); cancelWorldBookImport\(\); \};/, 'Esc 取消匯入');
  assert.match(source, /worldBookDraftKeywords=entry\?entry\.keywords\.slice\(\):\[\];/, '編輯器觸發詞 chips 草稿');
  assert.match(source, /worldBookEntryConstant'\)\.checked=entry\?entry\.constant:false;/, '常駐欄位接線');
  assert.match(source, /worldBookEntryPriority'\)\.value=entry\?entry\.priority:'normal';/, '優先級欄位接線');
  assert.match(source, /worldBookEntryScope'\)\.value=entry\?entry\.scope:'all';/, '作用域欄位接線');
  assert.match(source, /data-wb-chip-remove/, '觸發詞 chip 移除');
  assert.match(worldBookSource, /export function parseWorldBookImport\(/, '世界書模組已有三型解析');
  assert.match(worldBookSource, /export function mergeWorldBookEntries\(/, '世界書模組已有衝突三選');
  assert.match(worldBookSource, /export function exportWorldBook\(/, '世界書模組已有單書匯出');
  assert.match(source, /worldBookImportPending/, '匯入暫存與回滾');
  assert.match(source, /snapshotForRollback\(state\)[\s\S]{0,180}?state\.worldBook=normalizeWorldBook\(merged\.book\)/, '匯入前快照');
  const marker = '批6 Ｂ6-2／Ｂ6-3：世界書管理器與輸入引導';
  const at = css.indexOf(marker);
  assert.ok(at > 0, 'CSS append-only 標記存在');
  const patch = css.slice(at);
  assert.doesNotMatch(patch, /!important/, '新 CSS 零 !important');
  assert.doesNotMatch(patch, /font-size\s*:/, '新 CSS 零新字級');
  assert.match(patch, /\.dict-search-row\{/, '搜尋列樣式');
  assert.match(patch, /\.dict-filter\[/, '篩選 chip 樣式');
  assert.match(patch, /\.wb-chips\{/, '編輯器 chips 樣式');
  const uiStart = source.indexOf('const UI_EN = {');
  const uiEnd = source.indexOf('\n};', uiStart) + 3;
  const context = {};
  new Script(source.slice(uiStart, uiEnd) + '\nthis.__uiEn=UI_EN;').runInNewContext(context);
  const uiEn = context.__uiEn;
  const keys = ['🔍 搜尋條目／觸發詞…','搜尋世界書','篩選世界書','全部','啟用中','⭐ 常駐','停用','⬇ 匯出世界書','⬆ 匯入世界書','世界書預覽','輸入測試句…','世界書測試句','測試觸發','觸發詞','輸入觸發詞，按 Enter 或逗號新增','常駐（一律注入）','優先級','高','中','低','作用域','對話','開場','同名條目處理','合併（預設）：保留現有，只新增不重複的條目。','覆蓋同名：同鍵以匯入版取代。','略過同名：同鍵保留現有。','匯入','還沒有條目——從「＋ 新增」開始，或匯入一本世界書。','沒有符合「','」的條目。','目前篩選沒有條目。','（無觸發詞）','常駐','複製條目','已複製條目。','命中 ',' 條・約 ',' 字（上限 8 條／1500 字）','（部分截斷）','命中：','未命中','世界書已匯出。','世界書已匯入。','不是有效的世界書檔案（格式／空書）。','世界書沒有任何條目。','AI 正在生成；請等這一回合完成後再匯入世界書。','世界書檔案超過 50 條，將只保留前 50 條。','匯入預覽：','新增 ','／覆蓋 ','／略過 ','來源：','單書','裸書','資料包','匯入不會自動開啟世界書總開關。','移除觸發詞','最多 8 個觸發詞。','選「做／說／想」快速帶入，或直接寫下你這回合的行動、台詞或念頭。','不知道怎麼寫？從模板開始：','做一件事','說一句話','想一個念頭','帶入「做」模板','帶入「說」模板','帶入「想」模板','我做出行動：……','我看著她，說：「……」','我心裡想：……','三個模板只會填入文字框，不會自動送出，也不會改變存檔格式。'];
  for (const key of keys) assert.ok(Object.prototype.hasOwnProperty.call(uiEn, key), 'UI_EN 缺鍵：' + key);
});

test('v4.6.34 滑鼠滾輪：表單元件不再吃掉頁面滾動，聚焦的文字框仍可捲內文', () => {
  const start = source.indexOf('function wheelDeltaPixels(');
  const end = source.indexOf("document.addEventListener('wheel'", start);
  assert.ok(start >= 0 && end > start, '滾輪輔助函式存在');
  const context = {window: {innerHeight: 800}, document: {body: {}, documentElement: {}, scrollingElement: null}};
  new Script(source.slice(start, end) + '\nthis.wheelDeltaPixels=wheelDeltaPixels;this.canScrollVertically=canScrollVertically;this.scrollAncestorsFromWheel=scrollAncestorsFromWheel;').runInNewContext(context);
  assert.equal(context.wheelDeltaPixels({deltaY: 120, deltaMode: 0}), 120, '像素模式的 delta 原樣使用');
  assert.equal(context.wheelDeltaPixels({deltaY: 3, deltaMode: 1}), 48, '行模式換算成像素');
  assert.equal(context.wheelDeltaPixels({deltaY: 1, deltaMode: 2}), 800, '頁模式以視窗高度換算');

  const panel = {clientHeight: 100, scrollHeight: 500, scrollTop: 0, parentElement: null};
  const area = {tagName: 'TEXTAREA', clientHeight: 120, scrollHeight: 500, scrollTop: 0, parentElement: panel};
  assert.equal(context.canScrollVertically(area, -1), false, '文字框在頂端不能再往上');
  assert.equal(context.canScrollVertically(area, 1), true, '文字框還有內文可以往下');
  assert.equal(context.scrollAncestorsFromWheel(area.parentElement, 40), true, '往上找到可捲動面板');
  assert.equal(panel.scrollTop, 40, '面板真的被捲動');
  panel.scrollTop = 400;
  assert.equal(context.canScrollVertically(panel, 1), false, '面板到底後不再吃滾輪');

  const body = {};
  const scroller = {clientHeight: 600, scrollHeight: 1200, scrollTop: 0, parentElement: null};
  context.document.body = body;
  context.document.scrollingElement = scroller;
  assert.equal(context.scrollAncestorsFromWheel(body, 30), true, '面板到底後退回頁面捲動');
  assert.equal(scroller.scrollTop, 30, '頁面捲動生效');

  assert.match(source, /document\.addEventListener\('wheel',wheelOverFormControl,\{passive:false\}\)/, '滾輪監聽已接線');
  assert.match(source, /control\.tagName==='TEXTAREA'&&document\.activeElement===control/, '只有聚焦的文字框保留內文捲動');
  assert.match(source, /scrollAncestorsFromWheel\(control\.parentElement,dy\);/, '下拉與單行輸入把滾輪交給頁面');
});

test('批6 Ｂ6-3 輸入引導：placeholder、三個模板、只填文字框不改資料模型', () => {
  assert.match(source, /const INPUT_TEMPLATES=\{/, '模板表');
  for (const kind of ['do','say','think']) assert.match(source, new RegExp('data-input-template="' + kind + '"'), '模板 chip ' + kind);
  assert.match(source, /placeholder="選「做／說／想」快速帶入，或直接寫下你這回合的行動、台詞或念頭。"/, '輸入框引導 placeholder');
  assert.match(source, /function insertInputTemplate\(kind\)\{[\s\S]{0,420}?input\.value=current\?current\+'\\n'\+template:template;/, '點擊只填入文字框');
  const start = source.indexOf('function insertInputTemplate(');
  const end = source.indexOf('\n}', start) + 2;
  const body = source.slice(start, end);
  assert.doesNotMatch(body, /continueStory|save\(|state\./, '模板不改資料模型、不自動送出');
  assert.match(source, /document\.querySelectorAll\('\[data-input-template\]'\)\.forEach\(button=>\{button\.onclick=\(\)=>insertInputTemplate\(button\.dataset\.inputTemplate\);}\);/, '模板點擊接線');
  assert.match(css, /\.input-guide\{/, '輸入引導樣式');
  assert.match(css, /\.input-template\{/, '模板 chip 樣式');
});
