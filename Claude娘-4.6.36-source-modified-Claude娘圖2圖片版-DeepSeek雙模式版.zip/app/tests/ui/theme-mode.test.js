// 主題模式（亮色／暗色／跟隨系統／依時間／依故事時間）：設定頁切換選單、套用與持久化、樣式鉤子、時間連動與英譯。
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {Script} from 'node:vm';
import {normalizeStoryClock, realStoryClock} from '../../www/story-clock.js';

const source=readFileSync(new URL('../../www/app.js',import.meta.url),'utf8');
const html=readFileSync(new URL('../../www/index.html',import.meta.url),'utf8');
const css=readFileSync(new URL('../../www/style.css',import.meta.url),'utf8');

test('主題切換：設定頁有「主題」選單（五選：跟隨系統／亮色／暗色／依時間／依故事時間）',()=>{
  assert.match(html,/id="themeModeLabel" for="themeMode"/);
  assert.match(html,/id="themeMode"/);
  assert.match(html,/<option value="auto" selected>跟隨系統<\/option>/);
  assert.match(html,/<option value="light">亮色<\/option>/);
  assert.match(html,/<option value="dark">暗色<\/option>/);
  assert.match(html,/<option value="time">依時間<\/option>/);
  assert.match(html,/<option value="story">依故事時間<\/option>/);
  const order=['跟隨系統','亮色','暗色','依時間','依故事時間'].map(label=>html.indexOf(label));
  assert.ok(order.every((pos,i)=>pos>=0&&(i===0||pos>order[i-1])),'選項序：跟隨系統→亮色→暗色→依時間→依故事時間');
  assert.match(html,/id="themeModeHint"/);
  assert.match(html,/依故事時間＝跟隨故事時段：早晨／中午＝亮色、傍晚／夜晚＝暗色；沒有進行中的故事時，自動跟隨系統/);
  assert.match(source,/const THEME_STORAGE_KEY='claude_novel_theme_v1'/);
  assert.match(source,/const THEME_CHOICES=\['auto','light','dark','time','story'\]/);
});

test('主題切換：applyTheme 設／移 data-theme；偏好存 localStorage、壞值回退跟隨系統',()=>{
  const start=source.indexOf('function storedThemeChoice(');
  const end=source.indexOf('function settings()',start);
  assert.ok(start>=0&&end>start,'主題函式區塊存在且位於 settings() 之前');
  const memory={};
  const root={_theme:null,setAttribute(name,value){this._theme=value;},removeAttribute(){this._theme=null;}};
  const context={
    THEME_STORAGE_KEY:'claude_novel_theme_v1',
    THEME_CHOICES:['auto','light','dark','time','story'],
    localStorage:{getItem:key=>(key in memory?memory[key]:null),setItem:(key,value)=>{memory[key]=String(value);}},
    document:{documentElement:root}
  };
  new Script(source.slice(start,end)+`
this.storedThemeChoice=storedThemeChoice;this.applyTheme=applyTheme;this.applyThemePreference=applyThemePreference;`).runInNewContext(context);
  assert.equal(context.storedThemeChoice(),'auto','沒存過＝跟隨系統');
  context.applyThemePreference('dark');
  assert.equal(memory['claude_novel_theme_v1'],'dark','選擇立刻持久化');
  assert.equal(root._theme,'dark','選擇立刻套用 data-theme');
  context.applyThemePreference('light');
  assert.equal(root._theme,'light','切到亮色');
  context.applyThemePreference('auto');
  assert.equal(root._theme,null,'跟隨系統＝移除 data-theme');
  assert.equal(memory['claude_novel_theme_v1'],'auto','跟隨系統也持久化');
  memory['claude_novel_theme_v1']='bogus';
  assert.equal(context.storedThemeChoice(),'auto','壞值回退跟隨系統');
});

test('主題切換：CSS 具備亮色預設與暗色覆蓋（prefers-color-scheme＋data-theme）',()=>{
  assert.match(css,/--bg:#F5EFE3/,'亮色色票＝檔案預設');
  assert.match(css,/@media \(prefers-color-scheme: dark\)/,'未指定時跟隨系統');
  assert.match(css,/:root:not\(\[data-theme="light"\]\)\{/,'系統深色時可被「亮色」覆蓋');
  assert.match(css,/:root\[data-theme="dark"\]\{/,'可強制深色');
});

test('主題切換：英譯字典齊全（主題／五態／tooltip 二則／說明）',()=>{
  assert.match(source,/'主題': 'Theme'/);
  assert.match(source,/'跟隨系統': 'Follow system'/);
  assert.match(source,/'亮色': 'Light'/);
  assert.match(source,/'暗色': 'Dark'/);
  assert.match(source,/'依時間': 'By time'/);
  assert.match(source,/'依故事時間': 'By story time'/);
  assert.match(source,/'依故事時間（無進行中的故事＝跟隨系統）': 'By story time \(no story in progress = follow system\)'/);
  assert.match(source,/'由故事節奏推進（跨日自動＋1）': 'Advances with the story/);
  assert.match(source,/'只影響外觀顯示，不影響故事與存檔；選擇後立即套用並記住。依故事時間＝跟隨故事時段：早晨／中午＝亮色、傍晚／夜晚＝暗色；沒有進行中的故事時，自動跟隨系統。': 'Display only/);
});

test('主題切換：依時間＝依系統時鐘日夜切換（界線 07:00／19:00；即時生效、重開保留、零額外步驟）',()=>{
  const start=source.indexOf('function storedThemeChoice(');
  const end=source.indexOf('function settings()',start);
  assert.ok(start>=0&&end>start,'主題函式區塊存在且位於 settings() 之前');
  const memory={};
  const root={_theme:null,setAttribute(name,value){this._theme=value;},removeAttribute(){this._theme=null;}};
  const listeners={};
  let timer=null;
  const context={
    THEME_STORAGE_KEY:'claude_novel_theme_v1',
    THEME_CHOICES:['auto','light','dark','time','story'],
    localStorage:{getItem:key=>(key in memory?memory[key]:null),setItem:(key,value)=>{memory[key]=String(value);}},
    document:{documentElement:root,addEventListener:(type,fn)=>{listeners[type]=fn;}},
    setInterval:(fn,ms)=>{timer={fn,ms};return 1;}
  };
  new Script(source.slice(start,end)+`
this.storedThemeChoice=storedThemeChoice;this.applyTheme=applyTheme;this.applyThemePreference=applyThemePreference;this.themeTimePhase=themeTimePhase;this.refreshTimeTheme=refreshTimeTheme;this.startThemeTimeWatch=startThemeTimeWatch;`).runInNewContext(context);
  assert.equal(context.themeTimePhase(new Date(2026,9,18,6,59)),'dark','06:59＝暗色');
  assert.equal(context.themeTimePhase(new Date(2026,9,18,7,0)),'light','07:00＝亮色');
  assert.equal(context.themeTimePhase(new Date(2026,9,18,12,30)),'light','12:30＝亮色');
  assert.equal(context.themeTimePhase(new Date(2026,9,18,18,59)),'light','18:59＝亮色');
  assert.equal(context.themeTimePhase(new Date(2026,9,18,19,0)),'dark','19:00＝暗色');
  assert.equal(context.themeTimePhase(new Date(2026,9,18,23,59)),'dark','23:59＝暗色');
  const hostHour=new Date().getHours();
  const expectNow=(hostHour>=7&&hostHour<19)?'light':'dark';
  context.applyThemePreference('time');
  assert.equal(memory['claude_novel_theme_v1'],'time','「依時間」立刻持久化（重開保留）');
  assert.equal(root._theme,expectNow,'「依時間」＝依當下系統時間套用日夜');
  memory['claude_novel_theme_v1']='dark';
  root._theme=null;
  context.refreshTimeTheme();
  assert.equal(root._theme,null,'非「依時間」時巡檢不變更外觀');
  memory['claude_novel_theme_v1']='time';
  context.startThemeTimeWatch();
  assert.ok(timer&&timer.ms===30000,'註冊 30 秒巡檢（跨時段即時生效）');
  assert.equal(typeof listeners.visibilitychange,'function','回前景時即時重算');
  const kept=timer;
  context.startThemeTimeWatch();
  assert.equal(timer,kept,'重複啟動不疊加計時器');
  root._theme=null;
  timer.fn();
  assert.equal(root._theme,expectNow,'巡檢 tick 依當下時間重新套用');
});

// R3B（批5）：第五態「依故事時間」——恆用真實 story-clock 模組驗證解析與回退鏈。
function themeContext(){
  const memory={};
  const root={_theme:null,setAttribute(name,value){this._theme=value;},removeAttribute(){this._theme=null;}};
  const start=source.indexOf('function storedThemeChoice(');
  const end=source.indexOf('function settings()',start);
  assert.ok(start>=0&&end>start,'主題函式區塊存在且位於 settings() 之前');
  const context={
    THEME_STORAGE_KEY:'claude_novel_theme_v1',
    THEME_CHOICES:['auto','light','dark','time','story'],
    QUICK_THEME_ICONS:{auto:'◐',light:'☀',dark:'☾',time:'◔',story:'⌛︎'},
    localStorage:{getItem:key=>(key in memory?memory[key]:null),setItem:(key,value)=>{memory[key]=String(value);}},
    document:{documentElement:root},
    normalizeStoryClock, realStoryClock,
    state:{storyClock:null,history:[]},
    uiLanguage:'zh',
    uiText:text=>text
  };
  new Script(source.slice(start,end)+`
this.storedThemeChoice=storedThemeChoice;this.applyTheme=applyTheme;this.applyThemePreference=applyThemePreference;
this.storyThemePhase=storyThemePhase;this.storyThemeClock=storyThemeClock;this.nextThemeChoice=nextThemeChoice;this.quickThemeTitle=quickThemeTitle;`).runInNewContext(context);
  return {context,root,memory};
}

test('R3B：story 解析器——早晨／中午亮、晚上暗；沿故事日界跨午夜正確',()=>{
  const {context,root}=themeContext();
  context.state.history=[{role:'ai',text:'開場'}];
  context.state.storyClock={mode:'story',enabled:true,day:3,slot:0};
  assert.equal(context.storyThemePhase(),'light','第 3 天・早晨＝亮');
  context.state.storyClock={mode:'story',enabled:true,day:3,slot:1};
  assert.equal(context.storyThemePhase(),'light','第 3 天・中午＝亮');
  context.state.storyClock={mode:'story',enabled:true,day:3,slot:2};
  assert.equal(context.storyThemePhase(),'dark','第 3 天・晚上＝暗');
  context.applyTheme('story');
  assert.equal(root._theme,'dark','晚上＝data-theme dark');
  context.state.storyClock={mode:'story',enabled:true,day:4,slot:0};
  context.applyTheme('story');
  assert.equal(root._theme,'light','跨日（晚上→隔天早晨）＝亮');
});

test('R3B：回退鏈——無故事或未啟用＝退回跟隨系統（不設 data-theme，交媒體查詢鏈）',()=>{
  const {context,root,memory}=themeContext();
  context.applyThemePreference('story');
  assert.equal(memory['claude_novel_theme_v1'],'story','第五態持久化＝story');
  assert.equal(root._theme,null,'無進行中的故事＝跟隨系統');
  context.state.storyClock={mode:'off',enabled:false,day:1,slot:2};
  context.state.history=[{role:'ai',text:'x'}];
  context.applyTheme('story');
  assert.equal(root._theme,null,'故事時間未啟用＝跟隨系統（即使時段為晚）');
  context.state.storyClock=null;
  context.applyTheme('story');
  assert.equal(root._theme,null,'無 storyClock 欄位＝跟隨系統');
  context.state.storyClock={mode:'real',enabled:true,day:1,slot:0,anchor:Date.now()};
  const expected=realStoryClock(context.state.storyClock).slot>=2?'dark':'light';
  context.applyTheme('story');
  assert.equal(root._theme,expected,'real 模式＝依當下現實時段解析（與「依時間」日界互不干擾）');
});

test('R3B：快速列五態循環序＋第五態圖示（U+231B＋VS15）＋設定↔快速列同權杖',()=>{
  const {context}=themeContext();
  let value='auto';
  const seen=[];
  for(let i=0;i<5;i++){value=context.nextThemeChoice(value);seen.push(value);}
  assert.deepEqual(seen,['light','dark','time','story','auto'],'循環序：跟隨系統→亮→暗→依時間→依故事時間→回');
  assert.deepEqual(context.QUICK_THEME_ICONS,{auto:'◐',light:'☀',dark:'☾',time:'◔',story:'⌛︎'},'五態圖示表（四態沿用＋⌛︎）');
  const glyph=[...context.QUICK_THEME_ICONS.story].map(char=>char.codePointAt(0));
  assert.deepEqual(glyph,[0x231B,0xFE0E],'第五態字形＝U+231B＋VS15（文字呈現）');
  assert.match(source,/\$\('quickThemeBtn'\)\.onclick=\(\)=>\{applyThemePreference\(nextThemeChoice\(storedThemeChoice\(\)\)\);\}/,'快速鈕＝五態循環並走同一偏好入口');
  assert.match(source,/themeSelect\.value=storedThemeChoice\(\);/,'設定頁與快速列共用同一權杖、開啟即同步');
});

test('R3B：tooltip 二則（有故事＝第 N 天・時段；無故事＝跟隨系統）',()=>{
  const {context}=themeContext();
  context.state.history=[{role:'ai',text:'x'}];
  context.state.storyClock={mode:'story',enabled:true,day:4,slot:2};
  assert.equal(context.quickThemeTitle('story'),'依故事時間（現況：第 4 天・時段＝暗）');
  context.state.storyClock={mode:'story',enabled:true,day:4,slot:0};
  assert.equal(context.quickThemeTitle('story'),'依故事時間（現況：第 4 天・時段＝亮）');
  context.state.history=[];
  assert.equal(context.quickThemeTitle('story'),'依故事時間（無進行中的故事＝跟隨系統）');
  context.uiLanguage='en';
  context.state.history=[{role:'ai',text:'x'}];
  assert.equal(context.quickThemeTitle('story'),'By story time (now: Day 4 · light)');
});

test('R3B：快速列主題鈕在 A+ 右側同一分段組內（零新 CSS）＋觸發重解析接點齊備',()=>{
  assert.match(html,/<span class="story-text-size"[^>]*>\s*<button id="storyTextShrinkBtn"[\s\S]*?<button id="storyTextGrowBtn"[\s\S]*?<button id="quickThemeBtn"[\s\S]*?<\/span>/,'主題鈕位於 [A-｜100%｜A+] 同組右端');
  assert.match(source,/function refreshTimeTheme\(\)\{[\s\S]*?refreshOpeningClockPreview\(\);\s*\n\}/,'巡檢涵蓋第五態與開場預覽句');
  assert.match(source,/if\(choice==='time'\|\|choice==='story'\)applyTheme\(choice\);/,'巡檢條件含 story');
  const triggers=[
    /state = \{\.\.\.fresh\(\), \.\.\.\(target\.state \|\| \{\}\)[\s\S]*?settings\(\); render\(\);\s*\n  refreshTimeTheme\(\);/,
    /settings\(\); render\(\);\s*\n  refreshTimeTheme\(\);\s*\n\}\s*\nfunction checkpointStory\(\)/,
    /if\(!save\(\)\)return;\s*\n    opening\(\);\s*\n    refreshTimeTheme\(\);/,
    /state\.storyClock=realStoryClock\(clock\);\s*\n  refreshTimeTheme\(\);/,
    /save\(true\)[\s\S]{0,500}?render\(\);\s*\n  refreshTimeTheme\(\);/
  ];
  for(const pattern of triggers)assert.match(source,pattern,'觸發重解析接點（存檔切換／新存檔／故事開始／跨日時段／重新開始）');
});
