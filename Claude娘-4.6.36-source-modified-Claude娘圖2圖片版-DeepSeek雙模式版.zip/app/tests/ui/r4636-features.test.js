import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { Script } from 'node:vm';

// 4.6.36 驗收條件：所有存檔類型都能重新命名，暫停按鈕與暫停畫面統一使用 ⏸︎。
// 這裡直接執行 renameSlot，確認自動／快速／臨時／手動四種存檔都不再被種類擋下。
const read = rel => readFileSync(new URL('../../' + rel, import.meta.url), 'utf8');
const source = read('www/app.js');
const html = read('www/index.html');

function runRename(slot) {
  const context = {
    slots: [slot],
    persistSlots: () => true,
    render: () => {},
  };
  const start = source.indexOf('function renameSlot(id, name)');
  const end = source.indexOf('\n}', start) + 2;
  new Script(source.slice(start, end) + '\nthis.renameSlot = renameSlot;').runInNewContext(context);
  return context;
}

test('4.6.36 saves: every slot kind can be renamed and names are capped at 60 characters', () => {
  assert.match(source, /const name=await openPromptDialog\(\{title:'新的存檔名稱',value:slot\?\.name\|\|'',maxLength:60\}\)/, 'rename prompt caps input at 60 characters');
  assert.doesNotMatch(source, /slot\.kind !== 'manual'\) \{ alert\(uiText\('系統存檔格不可重新命名。'\)\)/, 'rename no longer rejects non-manual slots');
  assert.match(source, /const value = \(name \|\| ''\)\.trim\(\)\.slice\(0, 60\)/, 'stored names are capped at 60 characters');
  for (const kind of ['manual', 'auto', 'quick', 'incognito']) {
    const context = runRename({ id: kind + '-slot', kind, name: '原名', updatedAt: 1, state: { history: [] } });
    context.renameSlot(kind + '-slot', '  ' + kind + ' 名稱  ');
    assert.equal(context.slots[0].name, kind + ' 名稱', kind + ' 存檔可以重新命名');
  }
  const long = runRename({ id: 'long', kind: 'quick', name: '原名', updatedAt: 1 });
  long.renameSlot('long', '長'.repeat(80));
  assert.equal(long.slots[0].name.length, 60, '過長的名稱會截斷為 60 字');
});

test('4.6.36 save cards expose a rename button for system, temporary and manual slots', () => {
  assert.match(source, /<button class="slot-rename" data-rename="\$\{slot\.id\}" title="重新命名">✎<\/button>/, '每張存檔卡都有重新命名按鈕');
  assert.match(source, /const canMemo = slot\.kind === 'manual';/, '備註仍只提供給手動存檔');
  assert.match(source, /const canDelete = slot\.kind === 'manual' \|\| slot\.kind === 'incognito';/, '刪除仍只提供給手動與臨時存檔');
});

test('4.6.36 pause controls and title share the ⏸︎ icon', () => {
  assert.match(html, /<button id="exitStoryHudBtn"[^>]*aria-label="暫停故事（保留存檔）"[^>]*title="暫停故事（保留存檔）"[^>]*>⏸︎<\/button>/, 'HUD 暫停按鈕使用 ⏸︎');
  assert.match(html, /<button class="game-menu-item" id="exitStoryMenuBtn" type="button" hidden>⏸︎　暫停故事（保留存檔）<\/button>/, '選單暂停項目使用 ⏸︎');
  assert.match(html, /<h2 id="storyExitTitle">⏸︎ 故事已暫停<\/h2>/, '暫停畫面標題使用 ⏸︎');
  assert.match(source, /'⏸︎　暫停故事（保留存檔）': '⏸︎　Pause story \(keep save\)'/, '暫停選單有英文翻譯');
  assert.match(source, /'⏸︎ 故事已暫停': '⏸︎ Story paused'/, '暫停標題有英文翻譯');
});
