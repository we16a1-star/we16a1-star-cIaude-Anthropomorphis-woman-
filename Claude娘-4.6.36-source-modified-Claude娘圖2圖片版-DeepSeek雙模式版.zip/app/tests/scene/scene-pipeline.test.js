import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {mkdtempSync, writeFileSync, mkdirSync, utimesSync, symlinkSync, readFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {buildSceneImagePrompt, condenseScene, SCENE_NARRATION_CHARS} from '../../www/scene-prompt.js';
import {pickSceneImageEvictions, parseSceneImageKey} from '../../www/scene-image-store.js';
import {encodeSceneIllustration, MAX_SCENE_IMAGE_BLOB_BYTES} from '../../www/character-portrait.js';

const require = createRequire(import.meta.url);
const D = require('../../scene-download.cjs');
const W = require('../../workshop-apply.cjs');
const appRoot = fileURLToPath(new URL('../..', import.meta.url));

// ── 提示詞 ────────────────────────────────────────────
test('prompt: default character and world keep the original look, add landscape framing, and cap the scene text', () => {
  const narration = '她把書頁輕輕翻過。'.repeat(300);
  const zh = buildSceneImagePrompt({language: 'zh', narration, characterProfile: 'P', defaultProfile: 'P', worldSetting: 'W', defaultWorld: 'W'});
  assert.ok(zh.includes('極長暖橘紅色長髮') && zh.includes('雨夜古老圖書館'));
  assert.ok(zh.includes('3:2') && zh.includes('不要文字'));
  assert.ok(zh.length < 1300, 'scene text is capped (was 1800 chars of raw narration)');
  const en = buildSceneImagePrompt({language: 'en', narration: 'She turned the page. '.repeat(100), characterProfile: 'P', defaultProfile: 'P', worldSetting: 'W', defaultWorld: 'W'});
  assert.ok(en.includes('warm auburn hair') && en.includes('about 3:2') && en.includes('No lettering'));
});

test('prompt: a customised character and world replace the hard-coded heroine and library', () => {
  const zh = buildSceneImagePrompt({language: 'zh', narration: '列車駛過雲海。', characterName: '星野', characterProfile: '黑短髮的年輕星象師，穿深藍長袍', defaultProfile: 'P', worldSetting: '浮空列車上的長途旅行', defaultWorld: 'W'});
  assert.ok(zh.includes('黑短髮的年輕星象師') && zh.includes('「星野」') && zh.includes('浮空列車'));
  assert.ok(!zh.includes('暖橘紅') && !zh.includes('圖書館'), 'no leftover default heroine or library');
  assert.ok(zh.includes('成年'), 'adult-character guard stays in the prompt');
  const en = buildSceneImagePrompt({language: 'en', narration: 'The train crosses the clouds.', characterProfile: 'A young astrologer in a navy robe', defaultProfile: 'P', worldSetting: 'A floating railway', defaultWorld: 'W'});
  assert.ok(en.includes('All characters are adults') && en.includes('astrologer') && !en.includes('auburn'));
});

test('prompt: empty narration falls back to a default scene; condenseScene starts at a clean sentence', () => {
  assert.ok(buildSceneImagePrompt({language: 'zh'}).includes('雨夜中的古老圖書館閱覽室'));
  const text = '甲'.repeat(600) + '。' + '乙'.repeat(100) + '。' + '丙'.repeat(90);
  const out = condenseScene(text, 300);
  assert.ok(out.length <= 300);
  assert.ok(!out.startsWith('甲'), 'does not start mid-sentence in the older part');
  assert.ok(out.endsWith('丙'.repeat(90)));
  assert.equal(condenseScene('  短  文  '), '短 文');
  assert.ok(SCENE_NARRATION_CHARS < 1800);
});

// ── 儲存額度 ──────────────────────────────────────────
test('store: parse keys and stay silent while under budget', () => {
  assert.deepEqual(parseSceneImageKey('s1:runA:12'), {prefix: 's1:runA', index: 12});
  assert.equal(parseSceneImageKey('oops'), null);
  const entries = [{key: 's1:runA:1', size: 100}, {key: 's1:runA:2', size: 100}];
  assert.deepEqual(pickSceneImageEvictions(entries, {maxCount: 5, maxBytes: 1000, protectKey: 's1:runA:2'}), []);
});

test('store: evicts other runs first, then the oldest turns, and never the protected image', () => {
  const entries = [
    {key: 's1:runOld:0', size: 10}, {key: 's1:runOld:1', size: 10},
    {key: 's1:runA:0', size: 10}, {key: 's1:runA:1', size: 10}, {key: 's1:runA:2', size: 10}, {key: 's1:runA:3', size: 10}
  ];
  assert.deepEqual(pickSceneImageEvictions(entries, {maxCount: 4, maxBytes: 1e9, protectKey: 's1:runA:3'}), ['s1:runOld:0', 's1:runOld:1']);
  assert.deepEqual(pickSceneImageEvictions(entries, {maxCount: 2, maxBytes: 1e9, protectKey: 's1:runA:3'}), ['s1:runOld:0', 's1:runOld:1', 's1:runA:0', 's1:runA:1']);
  const heavy = [{key: 's1:runA:0', size: 600}, {key: 's1:runA:1', size: 600}, {key: 's1:runA:2', size: 600}];
  assert.deepEqual(pickSceneImageEvictions(heavy, {maxCount: 99, maxBytes: 1000, protectKey: 's1:runA:2'}), ['s1:runA:0', 's1:runA:1']);
  assert.ok(!pickSceneImageEvictions(heavy, {maxCount: 1, maxBytes: 1, protectKey: 's1:runA:1'}).includes('s1:runA:1'));
});

// ── 下載圖片偵測 ──────────────────────────────────────
test('download: only PNG, JPEG and WebP downloads are treated as scene images', () => {
  assert.deepEqual(D.describeDownload({filename: 'a.png', mimeType: 'image/png'}), {isImage: true, mime: 'image/png', ext: '.png'});
  assert.deepEqual(D.describeDownload({filename: 'photo.JPEG', mimeType: 'application/octet-stream'}), {isImage: true, mime: 'image/jpeg', ext: '.jpeg'});
  assert.equal(D.describeDownload({filename: 'x.webp', mimeType: ''}).mime, 'image/webp');
  for (const bad of [{filename: 'a.svg', mimeType: 'image/svg+xml'}, {filename: 'a.gif', mimeType: 'image/gif'}, {filename: 'doc.pdf', mimeType: 'application/pdf'}, {filename: 'noext', mimeType: ''}]) {
    assert.equal(D.describeDownload(bad).isImage, false, JSON.stringify(bad));
  }
});

test('download: finds the newest recent image and skips partial, old, oversized, folders and links', () => {
  const dir = mkdtempSync(path.join(tmpdir(), 'dl-'));
  const now = Date.now();
  const put = (name, bytes, ageMs) => { const file = path.join(dir, name); writeFileSync(file, Buffer.isBuffer(bytes) ? bytes : Buffer.alloc(bytes, 1)); const t = new Date(now - ageMs); utimesSync(file, t, t); return file; };
  put('old.png', 10, 40 * 60 * 1000);
  put('mid.jpg', 10, 5 * 60 * 1000);
  put('newest.webp', Buffer.from('RIFF0000WEBP'), 60 * 1000);
  put('newest-partial.png.crdownload', 10, 1000);
  put('notes.txt', 10, 1000);
  put('huge.png', 200, 2000);
  mkdirSync(path.join(dir, 'folder.png'));
  try { symlinkSync(path.join(dir, 'mid.jpg'), path.join(dir, 'link.png')); } catch { /* 部分系統不允許建立連結 */ }
  const found = D.findLatestImage(dir, {now, maxBytes: 100});
  assert.equal(found.name, 'newest.webp');
  assert.equal(found.mime, 'image/webp');
  assert.equal(D.findLatestImage(dir, {now: now + 3 * 60 * 60 * 1000}), null, 'nothing recent');
  assert.equal(D.findLatestImage(path.join(dir, 'missing')), null);
  const read = D.readImageFile(found);
  assert.equal(read.name, 'newest.webp'); assert.equal(read.bytes.length, 12);
  assert.throws(() => D.readImageFile(found, {maxBytes: 5}), /太大/);
  assert.throws(() => D.readImageFile({path: path.join(dir, 'gone.png'), name: 'gone.png', mime: 'image/png'}), /無法讀取/);
});

// ── 編碼 ──────────────────────────────────────────────
function installImageStubs({width = 4000, height = 2000, support = true, factor = 0.12} = {}) {
  const calls = [];
  const canvas = {width: 0, height: 0, getContext: () => ({fillRect() {}, drawImage() {}, set fillStyle(_) {}}),
    toBlob(callback, type, quality) {
      const outType = type === 'image/webp' && !support ? 'image/png' : type;
      const size = Math.round(canvas.width * canvas.height * quality * (outType === 'image/jpeg' ? factor * 1.5 : factor));
      calls.push({type, quality, width: canvas.width, height: canvas.height, size});
      callback(new Blob([new Uint8Array(size)], {type: outType}));
    }};
  globalThis.createImageBitmap = async () => ({width, height, close() {}});
  globalThis.document = {createElement: () => canvas};
  return calls;
}
const png = new File([new Uint8Array(10)], 'a.png', {type: 'image/png'});

test('encode: prefers WebP, caps the long edge at 1600px and stays under the size budget', async () => {
  const calls = installImageStubs();
  const blob = await encodeSceneIllustration(png);
  assert.equal(blob.type, 'image/webp');
  assert.ok(blob.size <= MAX_SCENE_IMAGE_BLOB_BYTES);
  assert.equal(calls.length, 1);
  assert.equal(Math.max(calls[0].width, calls[0].height), 1600);
});

test('encode: falls back to JPEG when the engine cannot encode WebP', async () => {
  const calls = installImageStubs({support: false});
  const blob = await encodeSceneIllustration(png);
  assert.equal(blob.type, 'image/jpeg');
  assert.deepEqual(calls.map(call => call.type), ['image/webp', 'image/jpeg']);
});

test('encode: lowers quality first, then shrinks, until the image fits', async () => {
  const calls = installImageStubs({factor: 1.2});
  const blob = await encodeSceneIllustration(png);
  assert.ok(blob.size <= MAX_SCENE_IMAGE_BLOB_BYTES);
  assert.ok(calls.length >= 5, 'needed several attempts');
  assert.ok(calls.slice(0, 4).every(call => call.width === calls[0].width), 'first four attempts keep the size');
  assert.ok(calls.at(-1).width < calls[0].width, 'then the image is scaled down');
  assert.ok(calls[1].quality < calls[0].quality);
});

test('encode: rejects SVG, non-images, oversized files and hopeless images', async () => {
  installImageStubs();
  await assert.rejects(() => encodeSceneIllustration(new File(['x'], 'a.svg', {type: 'image/svg+xml'})), /JPG、PNG 或 WebP/);
  await assert.rejects(() => encodeSceneIllustration(new File(['x'], 'a.txt', {type: 'text/plain'})), /請選擇圖片/);
  const big = new File([new Uint8Array(1)], 'big.png', {type: 'image/png'});
  Object.defineProperty(big, 'size', {value: 13 * 1024 * 1024});
  await assert.rejects(() => encodeSceneIllustration(big), /12 MB/);
  installImageStubs({factor: 50});
  await assert.rejects(() => encodeSceneIllustration(png), /仍超過存檔容量/);
});

// ── 接線檢查（Electron／介面／打包／一鍵安裝）──────────
const read = rel => readFileSync(new URL('../../' + rel, import.meta.url), 'utf8');

test('wiring: desktop capture, context menu and IPC exist and are guarded', () => {
  const main = read('electron-main.cjs');
  const preload = read('electron-preload.cjs');
  assert.match(main, /session\.fromPartition\('persist:official-ai-web-r24'\)\.on\('will-download'/);
  assert.match(main, /Date\.now\(\) >= sceneCaptureUntil\) return;/, 'only captures after the player asked for an illustration');
  assert.match(main, /if \(!info\.isImage\) return;/, 'other downloads keep the default behaviour');
  assert.match(main, /params\.mediaType === 'image'/);
  assert.match(main, /用作本場景插圖/);
  for (const channel of ['scene-image:start', 'scene-image:latest-download']) {
    const at = main.indexOf(`ipcMain.handle('${channel}'`);
    assert.ok(at > 0, channel);
    assert.ok(main.slice(at, at + 120).includes('assertTrustedRenderer(event)') || main.slice(at, at + 200).includes('assertTrustedRenderer(event)'), `${channel} checks the sender`);
  }
  assert.match(main, /registerSceneImageIpc\(\);\s*attachSceneImageCapture\(\);/);
  const sceneStart=main.slice(main.indexOf("ipcMain.handle('scene-image:start'"),main.indexOf("ipcMain.handle('scene-image:latest-download'"));
  assert.match(sceneStart,/await ensureAutomationBrowserFor\(url\)/,'external illustration mode uses the controllable Chrome/Edge profile and starts on the real site');
  assert.match(sceneStart,/provider = mode === 'external' && requestedProvider === 'gemini' \? 'gemini' : 'openai';/,'external illustration follows the story provider (Gemini works without a separate ChatGPT sign-in)');
  assert.match(sceneStart,/createWebAutoRunner\('external', provider, url\)/,'external prompt filling targets that same browser tab');
  assert.match(sceneStart,/aiWebFlow\.buildFillScript\(text\)/,'both browser modes fill the generated scene prompt');
  assert.doesNotMatch(sceneStart,/submitViaRunner/,'the user reviews and sends the image prompt manually');
  for (const name of ['startSceneIllustration', 'readLatestDownloadedImage', 'onSceneImageDownloaded']) assert.ok(preload.includes(name), name);
});

test('wiring: renderer buttons, translations, allowlists and packaging line up', () => {
  const app = read('www/app.js');
  const html = read('www/index.html');
  const main = read('electron-main.cjs');
  const pkg = JSON.parse(read('package.json'));
  for (const id of ['importLatestImageBtn', 'portraitToggleBtn', 'removeSceneImageBtn']) {
    assert.ok(html.includes(`id="${id}"`) && app.includes(`$('${id}')`), id);
  }
  for (const file of ['www/scene-prompt.js', 'www/scene-image-store.js', 'scene-download.cjs']) {
    // v4.4.0：工坊改為「整個專案都能開」，不再用白名單；改為直接向工坊核心確認檔案可被列出與編輯。
    assert.ok(W.listEditableFiles(appRoot).some(item => item.path === file), `${file} is editable in the workshop`);
    assert.ok(main.includes(file) || app.includes(file.replace('www/', './')), `${file} is part of the app`);
  }
  assert.ok(pkg.build.files.includes('scene-download.cjs') && pkg.build.files.includes('www/**/*'));
  assert.match(app, /composeSceneImagePrompt\(\{/);
  assert.match(app,/提示詞已填入自動化瀏覽器，尚未送出/,'external mode clearly tells the user the prompt is filled but not sent');
  assert.match(app,/readLatestDownloadedImage/,'the downloaded scene image has an import path back into the app');
  assert.match(app, /pickSceneImageEvictions\(entries/);
  assert.match(app, /sceneMode==='text'\)\{\s*sceneMode='offer'/);
  for (const text of ['⬇ 匯入最新下載', '👤 立繪：隱藏', '👤 立繪：顯示', '🗑 移除插圖']) assert.ok(app.includes(`'${text}':`), `English entry for ${text}`);
  assert.match(read('www/style.css'), /#tab-story\.has-scene-image:not\(\.keep-portrait\) \.story-portrait\{display:none\}/);
});

test('wiring: image and model-switch errors are translated for English mode', () => {
  const app = read('www/app.js');
  const main = read('electron-main.cjs');
  for (const text of ['請選擇圖片檔案。', '圖片太大，請選擇 12 MB 以下的檔案。', '圖片太大，請選擇 20 MB 以下的檔案。', '目前無法處理這張圖片。', '圖片壓縮後仍超過存檔容量。', '圖片壓縮後仍超過存檔容量，請選擇較小圖片。', '圖片下載未完成，請再試一次。', '無法讀取下載的圖片。', '無法讀取這張圖片，請改用官網的下載按鈕。', '無法讀取這張圖片。', '人物圖片更新失敗。']) {
    assert.ok(app.includes(`'${text}':`), `English entry for ${text}`);
  }
  assert.ok(app.includes('uiErrorText(String(payload.error))'), 'auto-import errors go through the dictionary');
  assert.ok(app.includes('uiErrorText(ipcMessage(error,'), 'latest-download errors go through the dictionary');
  assert.equal(app.split('uiErrorText(String(error.message))').length - 1, 2, 'import and portrait errors go through the dictionary');
  assert.ok(app.includes("uiErrorText(String(error.message||'找不到此模型選項。請重新讀取官網模型清單。'))"), 'model-switch errors go through the dictionary');
  assert.ok(!app.includes('uiText(payload.error)') && !app.includes('uiText(error.message'), 'no dynamic error bypasses the dictionary');
  assert.ok(app.includes("querySelectorAll('[alt]')") && app.includes("'本場景插圖':"), 'scene image alt is translated');
  assert.ok(main.includes('sceneCaptureUntil = Math.max(sceneCaptureUntil, Date.now() + 60 * 1000)'), 'fallback download keeps a longer capture window');
});

test('one-click install script: structure, fallbacks and launch are intact', () => {
  const bytes = readFileSync(new URL('../../BUILD-WINDOWS11-AUTO.bat', import.meta.url));
  const text = bytes.toString('utf8');
  assert.equal(text.split('\r\n').length - 1, text.split('\n').length - 1, 'CRLF line endings only');
  const lines = text.split('\r\n');
  const labels = new Set(lines.map(line => /^:([A-Za-z0-9_]+)\s*$/.exec(line)?.[1]).filter(Boolean));
  for (const line of lines) for (const match of line.matchAll(/(?:goto\s+|call\s+:)([A-Za-z0-9_]+)/gi)) {
    if (match[1].toLowerCase() !== 'eof') assert.ok(labels.has(match[1]), `label ${match[1]} exists`);
  }
  assert.ok(!lines.some(line => line.includes('!') && !/^\s*rem\b/i.test(line)), 'no "!" (delayed expansion is on)');
  assert.match(text, /npmmirror\.com\/mirrors\/node\//, 'Node download has a mirror fallback');
  assert.match(text, /--registry=https:\/\/registry\.npmmirror\.com/, 'npm install retries with a mirror');
  assert.match(text, /ELECTRON_BUILDER_BINARIES_MIRROR/, 'build retries with a tools mirror');
  assert.match(text, /taskkill \/IM "Claude娘\*"/, 'closes the running app before the silent install');
  assert.match(text, /start "" "%APP_LNK%"/, 'launches the app after installing');
  assert.match(text, /source-root\.json/, 'workshop marker is still written');
  assert.ok(!/start "" explorer\.exe/.test(text), 'no Explorer window pops up after success');
});
