import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');

function extractFunction(name) {
  const start = source.indexOf(`async function ${name}(`);
  assert.ok(start >= 0, `${name} exists`);
  let depth = 0, i = source.indexOf('{', start);
  for (; i < source.length; i++) {
    if (source[i] === '{') depth++;
    else if (source[i] === '}' && --depth === 0) break;
  }
  return source.slice(start, i + 1);
}

function makeReader(stored) {
  const db = {
    closed: false,
    close() { this.closed = true; },
    transaction() {
      const tx = {
        objectStore: () => ({
          get(key) {
            const request = {};
            queueMicrotask(() => { request.result = stored.get(key); request.onsuccess?.(); });
            return request;
          },
        }),
      };
      return tx;
    },
  };
  const openSceneImageDb = async () => db;
  const factory = new Function('openSceneImageDb', 'Blob', `${extractFunction('readSceneImageBlob')}; return readSceneImageBlob;`);
  return { read: factory(openSceneImageDb, Blob), db };
}

test('upgrade restores the initial illustrated scene while retaining the text-only option', () => {
  assert.match(source, /const SCENE_MODE_KEY = 'claude_novel_scene_mode_v2';/);
  assert.match(source, /let sceneMode = localStorage\.getItem\(SCENE_MODE_KEY\) === 'text' \? 'text' : 'offer';/);
  const html = readFileSync(new URL('../../www/index.html', import.meta.url), 'utf8');
  assert.match(html, /<option value="text">/,'text-only mode remains available');
  const css = readFileSync(new URL('../../www/style.css', import.meta.url), 'utf8');
  const normalizedCss = css.replace(/\r\n/g, '\n');
  assert.ok(normalizedCss.includes([
    '@media (min-width:621px){',
    '  #tab-story .story-portrait{',
    '    height:min(88%,740px);',
    '    max-width:70%;',
    '    right:4%;',
    '    bottom:0;',
    '  }',
    '  #tab-story .vn-dialogue-window{',
    '    width:min(1120px,calc(100% - 48px));',
    '  }',
    '  #tab-story .choices{',
    '    width:min(960px,calc(100% - 48px));',
    '  }',
    '}',
  ].join('\n')), 'desktop Galgame layout enlarges the heroine and dialogue without changing the mobile layout');
});

test('scene image: current turn image wins', async () => {
  const current = new Blob(['now']), older = new Blob(['old']);
  const { read, db } = makeReader(new Map([['s1:runA:3', current], ['s1:runA:1', older]]));
  assert.equal(await read('s1:runA:3'), current);
  assert.equal(db.closed, true);
});

test('scene image: falls back to the latest earlier image of the same save and run', async () => {
  const older = new Blob(['old']);
  const { read } = makeReader(new Map([['s1:runA:1', older], ['s1:runB:2', new Blob(['other run'])], ['s2:runA:2', new Blob(['other save'])]]));
  assert.equal(await read('s1:runA:5'), older);
});

test('scene image: returns null when nothing earlier exists', async () => {
  const { read } = makeReader(new Map([['s1:runA:7', new Blob(['future'])]]));
  assert.equal(await read('s1:runA:4'), null);
});

test('scene image: paste, drop and always-visible entry points are wired', () => {
  assert.match(source, /document\.addEventListener\('paste'/);
  assert.match(source, /stage\.addEventListener\('drop'/);
  assert.match(source, /\$\('importSceneImageBtn'\)\.hidden=false/);
  assert.match(source, /sceneMode==='text'\)\{\s*sceneMode='offer'/);
});
