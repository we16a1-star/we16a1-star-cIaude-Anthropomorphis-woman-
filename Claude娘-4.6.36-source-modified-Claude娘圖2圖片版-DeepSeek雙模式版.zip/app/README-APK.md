# Claude娘 APK（Windows 一鍵建置）

本專案是真正的 MIT 開源專案。App 會以 Capacitor 建成 Android APK；安裝後會以手機遊戲方式在桌面建立「Claude娘的書庫」App 圖示，點擊即可直接啟動。

## 一鍵建置
1. Windows 安裝 Node.js LTS、Android Studio（包含 Android SDK）與 JDK 17+。
2. 直接雙擊 `BUILD-APK-Windows.bat`。
3. 成功後，專案根目錄會出現 `Claude娘-Android.apk`。
4. 把該 APK 傳到 Android 手機，點擊安裝即可。

## 角色人格
`www/character-profile.js` 是預設人設。前端每次呼叫 `/api/story` 都會把這個人格設定送給後端；後端再把人格設定注入 Claude、Gemini 或 OpenAI 相容模型的提示詞，因此「角色性格由使用者選定的模型進行模擬」。

## AI
API Key 不放進 APK。後端環境變數可設定 Anthropic/Gemini/OpenAI 相容 API。未設定後端時 App 仍可開啟並使用本機示範劇情，方便先測試遊戲介面。

## 開源
License: MIT
