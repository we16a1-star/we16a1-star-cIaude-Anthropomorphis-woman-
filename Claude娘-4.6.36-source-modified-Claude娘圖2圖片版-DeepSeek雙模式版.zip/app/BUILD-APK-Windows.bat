@echo off
setlocal
cd /d "%~dp0"
echo === Claude娘 Android APK 建置 ===
where node >nul 2>nul || (echo 請先安裝 Node.js LTS. & pause & exit /b 1)
where npm >nul 2>nul || (echo 找不到 npm. & pause & exit /b 1)
where java >nul 2>nul || (echo 請先安裝 JDK 21 與 Android Studio. & pause & exit /b 1)
if not defined ANDROID_HOME set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
if not exist "%ANDROID_HOME%\platform-tools" (echo 找不到 Android SDK：%ANDROID_HOME% & echo 請在 Android Studio 的 SDK Manager 安裝 Android SDK Platform 36、Build Tools 36.0.0 及 Platform Tools. & pause & exit /b 1)
echo [1/3] 安裝 Node 套件...
call npm install --no-audit --no-fund
if errorlevel 1 goto fail
echo [2/3] 準備手機版程式、圖示及 Android 專案...
echo [3/3] 編譯 Android APK...
call npm run android:debug
if errorlevel 1 goto fail
echo.
echo APK 位於：%CD%\dist\Claude娘-Android-[版本]-debug.apk
echo 把 APK 傳到 Android 手機，允許此來源安裝後即可安裝。
pause
exit /b 0
:fail
echo.
echo 建置失敗。請把上方紅色錯誤訊息貼給開發者/ChatGPT。
pause
exit /b 1
