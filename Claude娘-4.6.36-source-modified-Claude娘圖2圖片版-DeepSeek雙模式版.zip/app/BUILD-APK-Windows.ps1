$ErrorActionPreference='Stop'
Set-Location $PSScriptRoot
Write-Host '=== Claude娘 Android APK 建置 ==='
$required=Get-Content .\package.json -Raw | ConvertFrom-Json
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw '找不到 Node.js；請安裝 Node.js 22 LTS 後重試。' }
if (-not (Get-Command npm -ErrorAction SilentlyContinue)) { throw '找不到 npm；請重新安裝 Node.js 22 LTS。' }
if (-not (Get-Command java -ErrorAction SilentlyContinue)) { throw '找不到 Java；請安裝 JDK 21。' }
if (-not $env:ANDROID_HOME) { $env:ANDROID_HOME=Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
if (-not (Test-Path (Join-Path $env:ANDROID_HOME 'platform-tools'))) { throw "找不到 Android SDK：$env:ANDROID_HOME。請先以 Android Studio 的 SDK Manager 安裝 Android SDK Platform 36、Build Tools 36.0.0 與 Platform Tools。" }
node --version | Out-Host
npm --version | Out-Host
java -version
npm install --no-audit --no-fund
if ($LASTEXITCODE -ne 0) { throw 'npm install 失敗。' }
npm run android:debug
if ($LASTEXITCODE -ne 0) { throw 'Android APK 建置失敗。請查看上方 Gradle 診斷。' }
$apk=Join-Path $PSScriptRoot ("dist\Claude娘-Android-$($required.version)-debug.apk")
Write-Host "成功：$apk"
Write-Host '此為供個人實機安裝的 Debug APK，不是 Google Play 簽章發行版。'
