# Claude娘 Android APK 建置

此專案使用 Capacitor，把 `www/` 包成 Android App。Android 版以免費網頁 AI 輔助為主，並以原生瀏覽器開啟 AI 官網、使用原生剪貼簿；使用者返回遊戲並點「貼上 AI 回覆」後，App 會自動驗證和接續同一故事。登入、挑選網站模型及送出仍在 AI 官網由使用者操作。

## GitHub Actions（建議）

將專案推到 GitHub 後，Actions → **Build Claude娘 Android APK** → Run workflow。
完成後在該次 workflow 的 Artifacts 下載 `Claude娘-release-debug-apk`，裡面就是可直接在 Android 手機安裝的 `app-debug.apk`。

## 本機建置

需要 Node.js 22、JDK 21、Android SDK Platform 36、Build Tools 36.0.0、Platform Tools 與 Android Studio。Android APK 不內嵌 API Key。若啟用 API 全自動生成，請使用自己的 HTTPS 後端。

```bash
npm install
npm run android:debug
```

APK 位於：

```text
dist/Claude娘-Android-<版本>-debug.apk
```

此為可側載的 Debug APK；上架 Google Play 前需使用正式發布簽章及符合當時 Play 規定的商店流程。
