import { spawnSync } from 'node:child_process';
import { copyFileSync, existsSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const appDir = fileURLToPath(new URL('../', import.meta.url));
const androidDir = join(appDir, 'android');
const gradle = join(androidDir, process.platform === 'win32' ? 'gradlew.bat' : 'gradlew');
if (!existsSync(gradle)) throw new Error('找不到 Android Gradle wrapper；請先執行 npx cap add android。');

const build = spawnSync(gradle, ['assembleDebug'], { cwd: androidDir, stdio: 'inherit', shell: process.platform === 'win32' });
if (build.error) throw build.error;
if (build.status !== 0) process.exit(build.status || 1);

const source = join(androidDir, 'app', 'build', 'outputs', 'apk', 'debug', 'app-debug.apk');
const pkg = JSON.parse(await (await import('node:fs/promises')).readFile(join(appDir, 'package.json'), 'utf8'));
const destDir = join(appDir, 'dist');
const dest = join(destDir, `Claude娘-Android-${pkg.version}-debug.apk`);
if (!existsSync(source)) throw new Error(`Android build did not produce the expected APK: ${source}`);
if (existsSync(dest)) throw new Error(`Versioned APK already exists; preserving it: ${dest}`);
mkdirSync(destDir, { recursive: true });
copyFileSync(source, dest);
console.log(`Android debug APK created: ${dest}`);
