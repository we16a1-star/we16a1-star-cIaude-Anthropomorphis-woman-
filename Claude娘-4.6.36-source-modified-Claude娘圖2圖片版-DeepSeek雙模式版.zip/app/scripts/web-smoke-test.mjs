// 網頁版自動化驗證：免開瀏覽器、免手動，全自動跑完「麻煩回覆 → 解析 → 套用」管線。
// 用法：node scripts/web-smoke-test.mjs
// 做法：從 www/app.js 載入「真實」的 sanitizeChoices／parseWebReply／applyTurn，
//  餵入 4 種常見的 Gemini 麻煩形狀（前言後記＋圍欄、尾逗號、多物件一次貼上、
//   超標好感值），逐一驗證解析容錯、七選項、好感刻度與 veryEasy 不扣分。
// 注意：本腳本只驗證本機管線，不會操作任何 AI 官網（供應商禁止自動擷取／送出）。
import {readFileSync} from 'node:fs';
import {Script, createContext} from 'node:vm';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {openingStylePrompt} from '../www/opening-styles.js';
import {affectionStageKeyOf, affectionStageOf, advanceStoryClock, normalizeStoryClock, realStoryClock, stageByKey, storyClockLabel} from '../www/story-clock.js';
import {webPromptBudget, outputTargetLines} from '../www/token-budget.js';
import {craftRules, filteredPromptRules, promptTweaksExtraLines, normalizePromptTweaks, authorNoteLines} from '../www/prompt-rules.js';
import {worldBookPromptLines} from '../www/world-book.js';

const appDir = fileURLToPath(new URL('..', import.meta.url));
const source = readFileSync(path.join(appDir, 'www', 'app.js'), 'utf8');

function sliceFn(startMarker, endMarker) {
  const start = source.indexOf(startMarker);
  const end = source.indexOf(endMarker, start);
  if (start < 0 || end <= start) throw new Error('找不到函數切片：' + startMarker);
  return source.slice(start, end);
}

const sandbox = {
  Number, Math, JSON, Date,
  affectionStageKeyOf, advanceStoryClock, normalizeStoryClock, realStoryClock,
  webPromptBudget,
  handleAffectionStageChange() {}, refreshTimeTheme() {},
  state: {affection: 50, difficulty: 'normal', history: [], choices: [], ending: false, storyMemory: ''}
};
createContext(sandbox);
const helperCode = sliceFn('function sanitizeChoices(list) {', '\nfunction formatAffection')
  + sliceFn('function stripJsonFences', '\nfunction isCompleteWebReply')
  + sliceFn("function applyTurn(r, role='ai') {", '\nfunction refreshGiftConversations')
  + '\nthis.api={sanitizeChoices,parseWebReply,applyTurn};';
new Script(helperCode).runInContext(sandbox);
const {sanitizeChoices, parseWebReply, applyTurn} = sandbox.api;

const narration = n => '她把書頁翻到摺痕處，雨聲正好落在窗欞上。' + '字'.repeat(n);
const base = over => ({
  narration: narration(500),
  affectionDelta: over?.affectionDelta ?? 2,
  choices: ['詢問印記來源', '協助檢查書頁', '查看窗外天色', '請她說明警報', '保持安靜觀察', '提出一起調查', '先到前台尋找線索'],
  ending: false, endingText: null, memory: '兩人初次相遇，發現古書異常印記。'
});
const shapes = [
  ['前言＋圍欄＋後記', 'Gemini 回覆如下：\n```json\n' + JSON.stringify(base()) + '\n```\n以上是完整回覆'],
  ['尾逗號', JSON.stringify(base({affectionDelta: -2})).replace(/("choices":\[[^\]]*)\]/, '$1,]')],
  ['多物件一次貼上', '{"note":"舊草稿"}\n' + JSON.stringify(base({affectionDelta: 1}))],
  ['超標好感值', JSON.stringify(base({affectionDelta: 9}))]
];

let pass = 0, fail = 0;
const check = (name, cond, extra = '') => {
  console.log(`${cond ? '通過' : '失敗'}：${name}${extra}`);
  cond ? pass++ : fail++;
};

for (const [name, text] of shapes) {
  try {
    const r = parseWebReply(text);
    check(`${name} 可解析`, true);
    check(`${name} 七選項`, r.choices.length === 7);
  } catch (e) { check(`${name} 可解析（${e.message}）`, false); }
}

sandbox.state = {affection: 50, difficulty: 'normal', history: [], choices: [], ending: false, storyMemory: ''};
applyTurn.call(sandbox, {narration: narration(500), affectionDelta: 2.5, choices: base().choices, ending: false});
check('好感 +2.5 有感（50→52.5）', sandbox.state.affection === 52.5, `（實際 ${sandbox.state.affection}）`);
applyTurn.call(sandbox, {narration: narration(500), affectionDelta: -3, choices: base().choices, ending: false});
check('扣分 -3 有感（52.5→49.5）', sandbox.state.affection === 49.5, `（實際 ${sandbox.state.affection}）`);
applyTurn.call(sandbox, {narration: narration(500), affectionDelta: 99, choices: base().choices, ending: false});
check('超標值夾在 +5（49.5→54.5）', sandbox.state.affection === 54.5, `（實際 ${sandbox.state.affection}）`);

sandbox.state = {affection: 50, difficulty: 'veryEasy', history: [], choices: [], ending: false, storyMemory: ''};
applyTurn.call(sandbox, {narration: narration(500), affectionDelta: -3, choices: base().choices, ending: false});
check('非常簡單不扣分（維持 50）', sandbox.state.affection === 50, `（實際 ${sandbox.state.affection}）`);

console.log(`\n合計：通過 ${pass}／失敗 ${fail}`);
if (fail) process.exit(1);

// ---- 第二部分：提示詞優化不影響故事（實際組裝驗證） ----
console.log('\n-- 提示詞故事完整性驗證 --');
let p2pass = 0, p2fail = 0;
const check2 = (name, cond, extra = '') => {
  console.log(`${cond ? '通過' : '失敗'}：${name}${extra}`);
  cond ? p2pass++ : p2fail++;
};
try {
  const webSlices =
    sliceFn('function compactWebPromptText(value, limit,', '\nfunction makeWebPrompt(action){')
    + sliceFn('const WEB_AI_PROVIDERS=[', '\nconst WEB_AI_URL=')
    + '\n' + sliceFn('function normalizeWebAIProvider(id){', '\nfunction webAIProviderName')
    + sliceFn('function makeWebPrompt(action){', '\nfunction makeWebRepairPrompt');
  const longTurn = i => `第${i}回合劇情：她在雨夜書庫翻到一頁泛黃的手稿，燭光把兩人的影子疊在一起。`;
  const pSandbox = {
    Number, Math, JSON, String, Array,
  webPromptBudget, outputTargetLines,
  affectionStageKeyOf, affectionStageOf, advanceStoryClock, normalizeStoryClock, realStoryClock, stageByKey, storyClockLabel,
  craftRules, filteredPromptRules, promptTweaksExtraLines, normalizePromptTweaks, authorNoteLines, worldBookPromptLines,
    handleAffectionStageChange() {}, refreshTimeTheme() {},
    uiLanguage: 'zh',
    DEFAULT_CHARACTER_NAME: 'Claude娘',
    DEFAULT_CHARACTER_PROFILE: '__real_default_profile__',
    COMPACT_DEFAULT_CHARACTER_PROMPT: '__compact__',
    DEFAULT_WORLD_SETTING: '__real_default_world__',
    COMPACT_DEFAULT_WORLD_PROMPT: '__compact__',
    DEFAULT_STORY_TEMPLATE: '__real_default_rules__',
    COMPACT_DEFAULT_RULES_PROMPT: '__compact__',
    CUSTOM_OPENING_STYLE: '__custom__',
    openingStylePrompt,
    state: {
      characterName: 'Claude娘',
      characterProfile: '自訂人格：沉穩博學又溫柔，雨天會泡桂花茶給重要的人。',
      worldSetting: '自訂世界：知識之塔古老圖書館，雨夜古籍閱覽室。',
      storyTemplate: '自訂規則：細寫感官與因果，感情漸進。',
      affection: 62,
      storyMemory: 'M'.repeat(2000),
      history: Array.from({length: 10}, (_, i) => ({role: i % 2 ? 'ai' : 'user', text: longTurn(i)})),
      responseMode: 'fast', webProvider: 'gemini', openingStyle: 'rainy_first_meeting', openingCustomPrompt: ''
    }
  };
  createContext(pSandbox);
  new Script(webSlices + '\nthis.builtPrompt=makeWebPrompt("玩家推門走進閱覽室");').runInContext(pSandbox);
  const prompt = pSandbox.builtPrompt;
  check2('角色／世界／規則全文保留', prompt.includes('自訂人格') && prompt.includes('自訂世界') && prompt.includes('自訂規則'));
  check2('好感值帶入（62/100）', prompt.includes('62/100'));
  check2('記憶保留（上限內完整）', prompt.includes('M'.repeat(400)));
  check2('最新兩回合保留', prompt.includes(longTurn(8)) && prompt.includes(longTurn(9)));
  check2('過舊回合被裁掉（只留最新）', !prompt.includes(longTurn(0)));
  check2('本次玩家行動帶入', prompt.includes('玩家推門走進閱覽室'));
  check2('身份鎖定在場', prompt.includes('絕不自稱 AI'));
  check2('好感刻度在場', prompt.includes('affectionDelta 必須是 -3 到 +3'));
  check2('七選項契約在場', prompt.includes('choices恰好7個'));
  check2('JSON-only 結尾在場', prompt.includes('只輸出 JSON 本體'));
  check2('提示詞長度合理（<6000字）', prompt.length < 6000, `（實際 ${prompt.length} 字）`);
} catch (e) { check2('提示詞組裝（' + e.message + '）', false); }

console.log(`\n提示詞部分：通過 ${p2pass}／失敗 ${p2fail}`);
process.exit(p2fail ? 1 : 0);
