export const CHOICE_PLAN = Object.freeze([2, 4, 5]);
export const RESPONSE_COUNT = CHOICE_PLAN.length + 1;

export function advanceRound(state, action, reply, responseIndex) {
  if (!Number.isInteger(responseIndex) || responseIndex < 0 || responseIndex >= RESPONSE_COUNT) {
    throw new RangeError('responseIndex 超出三回合測試範圍');
  }

  const isOpening = responseIndex === 0;
  if (!isOpening) state.history.push({ role: 'user', text: String(action) });
  state.history.push({ role: 'assistant', text: reply.narration });
  state.storyMemory = reply.memory;

  const affectionDelta = Number(reply.affectionDelta || 0);
  state.affection = Math.max(0, Math.min(100, state.affection + (Number.isFinite(affectionDelta) ? affectionDelta : 0)));

  if (responseIndex >= CHOICE_PLAN.length) return { selectedAction: null };
  const number = CHOICE_PLAN[responseIndex];
  return {
    selectedAction: {
      round: responseIndex + 1,
      number,
      text: reply.choices[number - 1]
    }
  };
}
