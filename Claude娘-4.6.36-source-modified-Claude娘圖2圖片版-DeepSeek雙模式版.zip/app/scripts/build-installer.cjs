#!/usr/bin/env node
// 一鍵建置用的打包器（Windows）：先把 electron-builder 的輸出導到暫存資料夾，
// 完成後再把安裝檔複製回 app\dist。
// 為什麼要繞這一段：專案資料夾常在 OneDrive／桌面，打包時 dist 很容易被同步或防毒鎖住而失敗；
// 輸出到 %TEMP% 就不會。package.json 只在建置期間暫時改寫，結束後（含失敗）一律還原。
//
// 用法：npm run dist:safe（等同 npm run dist，但輸出安全）
// 需要強制指定輸出資料夾：設定環境變數 CLOUDO_DIST_OUT。
'use strict';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const {spawnSync} = require('node:child_process');

const appDir = path.resolve(__dirname, '..');
const pkgFile = path.join(appDir, 'package.json');
const cli = path.join(appDir, 'node_modules', 'electron-builder', 'cli.js');
const outDir = process.env.CLOUDO_DIST_OUT || path.join(os.tmpdir(), 'cloudo-dist-out');

if (!fs.existsSync(cli)) {
  console.error('[打包] 找不到 electron-builder，請先執行 npm install。');
  process.exit(1);
}

const original = fs.readFileSync(pkgFile);
let exitCode = 1;
try {
  const pkg = JSON.parse(original.toString('utf8'));
  pkg.build = pkg.build && typeof pkg.build === 'object' ? pkg.build : {};
  pkg.build.directories = {...(pkg.build.directories || {}), output: outDir.split(path.sep).join('/')};
  fs.writeFileSync(pkgFile, JSON.stringify(pkg, null, 2) + '\n');
  const result = spawnSync(process.execPath, [cli, '--win', 'nsis'], {stdio: 'inherit', cwd: appDir, env: process.env});
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error('electron-builder 結束碼 ' + result.status);
  const built = fs.readdirSync(outDir)
    .filter(name => /-Setup-.*\.exe$/i.test(name))
    .map(name => ({name, at: fs.statSync(path.join(outDir, name)).mtimeMs}))
    .sort((a, b) => b.at - a.at);
  if (!built.length) throw new Error(`在 ${outDir} 找不到 *-Setup-*.exe`);
  fs.mkdirSync(path.join(appDir, 'dist'), {recursive: true});
  for (const file of built) fs.copyFileSync(path.join(outDir, file.name), path.join(appDir, 'dist', file.name));
  console.log('[打包] 完成：' + built.map(file => path.join('dist', file.name)).join('、'));
  exitCode = 0;
} catch (error) {
  console.error('[打包] 失敗：' + (error?.message || error));
} finally {
  fs.writeFileSync(pkgFile, original);
}
process.exit(exitCode);
