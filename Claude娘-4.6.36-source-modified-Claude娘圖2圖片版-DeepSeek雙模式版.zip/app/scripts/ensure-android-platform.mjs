import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const appDir = fileURLToPath(new URL('../', import.meta.url));
if (existsSync(join(appDir, 'android', 'gradlew')) || existsSync(join(appDir, 'android', 'gradlew.bat'))) process.exit(0);
const result = spawnSync('npx', ['cap', 'add', 'android'], { cwd: appDir, stdio: 'inherit', shell: process.platform === 'win32' });
if (result.error) throw result.error;
if (result.status !== 0) process.exit(result.status || 1);
