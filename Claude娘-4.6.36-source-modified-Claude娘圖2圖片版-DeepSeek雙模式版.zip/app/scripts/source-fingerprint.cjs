// 一鍵建置用：算出「原始碼指紋」，判斷上次編譯之後程式碼有沒有再改過。
// 指紋相同＋安裝檔還在 → 一鍵安裝直接沿用（跳過 npm install 與編譯），重跑只要幾十秒。
// 想強制重新編譯：執行前先設定 REBUILD_ALWAYS=1。
// 指紋＝所有程式檔的路徑＋內容（相依、建置產物、備份與 source-root.json 不列入）。
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const SKIP_DIRS = new Set(['node_modules', '_build-tools', 'dist', 'dist-app', 'release', '.workshop-backup', '.git', 'outputs', '.cache']);
const SKIP_FILES = new Set(['source-root.json']);
const root = path.resolve(process.argv[2] || process.cwd());
const files = [];

(function walk(dir) {
  let entries;
  try { entries = fs.readdirSync(dir, {withFileTypes: true}); } catch { return; }
  for (const entry of entries) {
    if (SKIP_DIRS.has(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) { walk(full); continue; }
    if (!entry.isFile() || SKIP_FILES.has(entry.name)) continue;
    files.push(full);
  }
})(root);

files.sort();
const hash = crypto.createHash('sha256');
for (const file of files) {
  hash.update(path.relative(root, file).split(path.sep).join('/'));
  hash.update('\0');
  try { hash.update(fs.readFileSync(file)); } catch { hash.update('unreadable'); }
  hash.update('\0');
}
process.stdout.write(hash.digest('hex').slice(0, 16));
