var fs = require('fs');
var vm = require('vm');
var path = require('path');
var appDir = path.join(__dirname, '..');
var source = fs.readFileSync(path.join(appDir, 'www', 'app.js'), 'utf8');
function sl(a, b) { var i = source.indexOf(a); return source.slice(i, source.indexOf(b, i)); }
var parts =
  sl('function compactWebPromptText(value, limit,', '\nfunction makeWebPrompt(action){') +
  sl('const WEB_AI_PROVIDERS=[', '\nconst WEB_AI_URL=') + '\n' +
  sl('function normalizeWebAIProvider(id){', '\nfunction webAIProviderName') +
  sl('function makeWebPrompt(action){', '\nfunction makeWebRepairPrompt');
var sandbox = {
  Number: Number, Math: Math, JSON: JSON, String: String, Array: Array,
  uiLanguage: 'zh',
  DEFAULT_CHARACTER_NAME: 'Claude娘',
  DEFAULT_CHARACTER_PROFILE: '__R__',
  COMPACT_DEFAULT_CHARACTER_PROMPT: '[COMPACT_PROFILE]',
  DEFAULT_WORLD_SETTING: '__R__',
  COMPACT_DEFAULT_WORLD_PROMPT: '[COMPACT_WORLD]',
  DEFAULT_STORY_TEMPLATE: '__R__',
  COMPACT_DEFAULT_RULES_PROMPT: '[COMPACT_RULES]',
  CUSTOM_OPENING_STYLE: '__custom__',
  openingStylePrompt: function() { return ''; },
  state: {
    characterName: 'Claude娘',
    characterProfile: '__R__',
    worldSetting: '__R__',
    storyTemplate: '__R__',
    affection: 62,
    storyMemory: 'M'.repeat(2000),
    history: Array.from({length: 10}, function(_, i) { return {role: i % 2 ? 'ai' : 'user', text: 'TURN' + i + ' x'.repeat(120)}; }),
    responseMode: 'fast', webProvider: 'gemini', openingStyle: 'rainy_first_meeting', openingCustomPrompt: ''
  }
};
vm.createContext(sandbox);
vm.runInContext(parts + '\nthis.P = makeWebPrompt("ACTION");', sandbox);
var p = sandbox.P;
console.log('TOTAL=' + p.length);
p.split('\n').forEach(function(line, i) {
  console.log(('' + line.length).padStart(5) + '  L' + i + ' ' + line.slice(0, 60).replace(/\n/g, ' '));
});
