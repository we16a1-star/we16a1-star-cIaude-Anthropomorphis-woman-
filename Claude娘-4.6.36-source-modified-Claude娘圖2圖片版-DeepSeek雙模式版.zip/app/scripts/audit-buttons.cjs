#!/usr/bin/env node
// 前端／後端「每個按鍵都要能用」稽核。
//   1. index.html 的每一顆靜態按鈕都要有直接或事件委派處理。
//   2. 每個 input／select／textarea 至少要有變更處理，或是所在表單的送出處理。
//   3. preload 暴露的 IPC 頻道與主程序 handler 必須一對一。
//   4. server.js 的 API 路由要能啟動並回應（--live 時實際打本機服務）。
// 這是靜態契約檢查，實際行為仍由 tests/**/*.test.js 與 packaged UI 冒煙測試覆蓋。
const fs = require('fs');
const path = require('path');

const appDir = path.resolve(__dirname, '..');
const read = rel => fs.readFileSync(path.join(appDir, rel), 'utf8');
const html = read('www/index.html');
const js = read('www/app.js');
const preload = read('electron-preload.cjs');
const main = read('electron-main.cjs');
const server = read('server/server.js');

const failures = [];
const notes = [];

// ── 1. 收集靜態按鈕 ───────────────────────────────────────────────
const buttons = [...html.matchAll(/<button\b([^>]*)>([\s\S]*?)<\/button>/g)].map((match, index) => {
  const attrs = match[1];
  const id = (attrs.match(/\bid="([^"]+)"/) || [])[1] || '';
  const classes = ((attrs.match(/\bclass="([^"]+)"/) || [])[1] || '').split(/\s+/).filter(Boolean);
  const type = (attrs.match(/\btype="([^"]+)"/) || [])[1] || '';
  const data = [...attrs.matchAll(/\b(data-[a-z0-9-]+)(?:="([^"]*)")?/g)].map(m => ({name: m[1], value: m[2] || ''}));
  const text = match[2].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
  return {index, id, classes, type, data, text};
});

const escapeRe = value => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const directIds = new Set();
for (const match of js.matchAll(/\$\('([^']+)'\)\s*(?:\?\.|\.)\s*(onclick|onchange|oninput|onkeydown|onkeyup|addEventListener)\s*[=(]/g)) {
  directIds.add(match[1]);
}
for (const match of js.matchAll(/getElementById\('([^']+)'\)\s*(?:\?\.|\.)\s*(onclick|onchange|oninput|onkeydown|onkeyup|addEventListener)\s*[=(]/g)) {
  directIds.add(match[1]);
}
// 別名指派：const btn = $('gameMenuBtn'); if (btn) btn.onclick = ...
for (const match of js.matchAll(/([A-Za-z_$][\w$]*)\s*=\s*\$\('([^']+)'\)/g)) {
  const variable = escapeRe(match[1]);
  if (new RegExp('\\b' + variable + '\\s*(?:\\?\\.|\\.)\\s*(?:onclick|onchange|oninput|onkeydown|onkeyup|addEventListener)\\s*[=(]').test(js)) {
    directIds.add(match[2]);
  }
}

// querySelectorAll / querySelector 的處理器（含 forEach 內指派）
const selectors = [];
for (const match of js.matchAll(/querySelector(?:All)?\('([^']+)'\)/g)) {
  const tail = js.slice(match.index, match.index + 700);
  if (/\.(?:onclick|onchange|oninput|onkeydown|onkeyup)\s*=|addEventListener\('(?:click|change|input|keydown|keyup)'/.test(tail)) {
    selectors.push(match[1]);
  }
}
const selectorMatchesButton = button => selectors.some(selector => {
  for (const cls of button.classes) {
    if (selector === '.' + cls || selector.includes('.' + cls)) return true;
  }
  if (button.id && (selector === '#' + button.id || selector.includes('#' + button.id))) return true;
  for (const data of button.data) {
    if (selector.includes('[' + data.name + ']') || selector.includes('[' + data.name + '=')) return true;
  }
  return false;
});

const nativeDialogButtons = button => {
  // <button formmethod="dialog"> 或關閉 <dialog> 的原生按鈕
  return button.type === 'submit' && false;
};

const unhandledButtons = [];
for (const button of buttons) {
  const handled = (button.id && directIds.has(button.id))
    || selectorMatchesButton(button)
    || nativeDialogButtons(button);
  if (!handled) unhandledButtons.push(button);
}
if (unhandledButtons.length) {
  failures.push(`有 ${unhandledButtons.length} 顆靜態按鈕沒有處理器`);
  for (const button of unhandledButtons) {
    failures.push(`  - #${button.index} id="${button.id}" class="${button.classes.join(' ')}" text="${button.text.slice(0, 30)}"`);
  }
}

// ── 2. 表單控制項 ─────────────────────────────────────────────────
const controls = [...html.matchAll(/<(input|select|textarea)\b([^>]*)>/g)].map(match => {
  const attrs = match[2];
  return {
    tag: match[1],
    id: (attrs.match(/\bid="([^"]+)"/) || [])[1] || '',
    type: (attrs.match(/\btype="([^"]+)"/) || [])[1] || '',
    name: (attrs.match(/\bname="([^"]+)"/) || [])[1] || ''
  };
});
const handledControlIds = new Set([...directIds]);
// 檔案選擇器由按鈕點擊，onchange 會用 id 指派，已包含在 directIds；
// 其他控制項可能由表單層級的 click/change 委派處理。
for (const match of js.matchAll(/querySelectorAll\('([^']+)'\)/g)) {
  const tail = js.slice(match.index, match.index + 700);
  if (/\.(?:onchange|oninput|onclick)\s*=|addEventListener\('(?:change|input|click)'/.test(tail)) {
    const selector = match[1];
    for (const control of controls) {
      if (control.id && selector.includes('#' + control.id)) handledControlIds.add(control.id);
    }
  }
}
const unhandledControls = controls.filter(control => {
  if (!control.id) return false; // 無 id 的控制項由表單／外層容器處理
  if (handledControlIds.has(control.id)) return false;
  if (control.type === 'hidden') return false;
  if (control.type === 'radio' || control.type === 'checkbox') return false; // 由表單或同 name 群組處理
  return true;
});
// 有 id 但只由 render/顯示邏輯使用、沒有變更事件的控制項，列為提示（仍需人工確認是否唯讀）
for (const control of unhandledControls) {
  notes.push(`控制項 #${control.id} (${control.tag}${control.type ? ' ' + control.type : ''}) 沒有直接變更處理器；請確認是否由外層表單處理`);
}

// ── 3. IPC 契約 ───────────────────────────────────────────────────
const uniq = list => [...new Set(list)];
const invoked = uniq([...preload.matchAll(/ipcRenderer\.invoke\('([^']+)'/g)].map(m => m[1]));
const sent = uniq([...preload.matchAll(/ipcRenderer\.send\('([^']+)'/g)].map(m => m[1]));
const listened = uniq([...preload.matchAll(/ipcRenderer\.on\('([^']+)'/g)].map(m => m[1]));
const handled = uniq([...main.matchAll(/ipcMain\.handle\('([^']+)'/g)].map(m => m[1]));
const mainOn = uniq([...main.matchAll(/ipcMain\.on\('([^']+)'/g)].map(m => m[1]));
const pushed = uniq([...main.matchAll(/webContents\.send\('([^']+)'/g)].map(m => m[1]));
for (const channel of invoked) if (!handled.includes(channel)) failures.push(`IPC invoke 沒有 handler：${channel}`);
for (const channel of handled) if (!invoked.includes(channel)) failures.push(`IPC handler 沒有 preload 入口：${channel}`);
for (const channel of sent) if (!mainOn.includes(channel)) failures.push(`IPC send 沒有主程序 listener：${channel}`);
for (const channel of pushed) if (!listened.includes(channel)) failures.push(`主程序推送沒有 preload listener：${channel}`);
for (const channel of listened) {
  if (!pushed.includes(channel) && channel !== 'ai-web:google-sign-in-handoff') {
    failures.push(`preload listener 沒有主程序推送：${channel}`);
  }
}

// ── 4. 後端路由 ───────────────────────────────────────────────────
const routes = uniq([...server.matchAll(/app\.(get|post|put|delete|patch)\('([^']+)'/g)].map(m => m[1].toUpperCase() + ' ' + m[2]));
if (!routes.length) failures.push('server.js 沒有找到任何 API 路由');
const frontendEndpoints = uniq([...js.matchAll(/['"`](\/api\/[a-z0-9-]+)['"`]/gi)].map(m => m[1]));
for (const endpoint of frontendEndpoints) {
  if (endpoint === '/api') continue;
  if (!routes.some(route => route.endsWith(' ' + endpoint))) failures.push(`前端呼叫了不存在的路由：${endpoint}`);
}

// ── 5. 產生報告 ───────────────────────────────────────────────────
const report = [];
report.push('Claude娘 前端／後端按鍵稽核');
report.push(`靜態按鈕：${buttons.length}（有 id ${buttons.filter(b => b.id).length}、無 id ${buttons.filter(b => !b.id).length}）`);
report.push(`表單控制項：${controls.length}`);
report.push(`直接事件處理：${directIds.size} 個 id；事件委派：${selectors.length} 個 selector`);
report.push(`IPC：invoke ${invoked.length}、handler ${handled.length}、推送 ${pushed.length}、preload listener ${listened.length}`);
report.push(`API 路由：${routes.join('、')}`);
report.push(`前端呼叫：${frontendEndpoints.join('、') || '（無）'}`);
if (notes.length) {
  report.push('');
  report.push('提示：');
  for (const note of notes) report.push('  - ' + note);
}
report.push('');
if (failures.length) {
  report.push('結果：FAIL');
  for (const failure of failures) report.push('  - ' + failure);
} else {
  report.push('結果：PASS（所有靜態按鍵與 IPC／路由契約都有對應處理）');
}
const output = report.join('\n');
fs.writeFileSync(path.join(appDir, '..', '按鍵稽核報告.txt'), output, 'utf8');
console.log(output);
process.exitCode = failures.length ? 1 : 0;
