#!/usr/bin/env node
// Windows installer size trimmer (electron-builder afterPack hook).
//
// The source tree and the source ZIP stay complete. This hook only removes
// files that the packaged Electron app can never load at runtime:
//   - @google/genai alternate builds: Electron main uses the Node ESM entry
//     (dist/node/index.mjs). The browser bundle, CJS duplicate, tokenizer and
//     Vertex-only subpath are not imported by server/server.js or the preload.
//   - web-streams-polyfill: only dist/ponyfill.es2018.js is referenced by
//     fetch-blob as a legacy fallback. Node 22 already provides ReadableStream,
//     but the fallback file is kept so the dependency stays functional.
//   - @capacitor/*: Android-only dependencies; the Electron bundle contains
//     its own copy of the web code and the server never imports them.
//   - legacy splash.html and its generated eye-frame scripts, which are not
//     referenced by any runtime file.
//
// The hook fails the build instead of silently shipping a broken package if a
// required runtime entry is missing after pruning.
'use strict';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const asar = require('@electron/asar');

const KEEP_REQUIRED = [
  'node_modules/@google/genai/dist/node/index.mjs',
  'node_modules/@google/genai/package.json',
  'node_modules/web-streams-polyfill/dist/ponyfill.es2018.js',
  'node_modules/web-streams-polyfill/package.json'
];

function remove(target, removed) {
  let stat;
  try { stat = fs.lstatSync(target); } catch { return; }
  if (stat.isDirectory()) {
    for (const entry of fs.readdirSync(target)) remove(path.join(target, entry), removed);
    try { fs.rmdirSync(target); } catch {}
    return;
  }
  const size = stat.size;
  fs.rmSync(target, {force: true});
  removed.push({path: target, size});
}

async function pruneAsar(asarPath) {
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'claude-asar-'));
  const backup = asarPath + '.original';
  const next = asarPath + '.pruned';
  try {
    asar.extractAll(asarPath, work);
    for (const rel of KEEP_REQUIRED) {
      if (!fs.existsSync(path.join(work, rel))) {
        throw new Error('runtime entry missing before prune: ' + rel);
      }
    }
    const removed = [];
    for (const rel of [
      'node_modules/@google/genai/dist/node/index.cjs',
      'node_modules/@google/genai/dist/index.cjs',
      'node_modules/@google/genai/dist/index.mjs',
      'node_modules/@google/genai/dist/web',
      'node_modules/@google/genai/dist/tokenizer',
      'node_modules/@google/genai/dist/vertex_internal',
      'node_modules/@capacitor',
      'www/splash.html',
      'www/assets/claude-splash'
    ]) {
      remove(path.join(work, rel), removed);
    }
    const jpgDir = path.join(work, 'www', 'assets', 'claude-splash-user');
    if (fs.existsSync(jpgDir)) {
      for (const name of fs.readdirSync(jpgDir)) {
        if (/\.jpe?g$/i.test(name)) remove(path.join(jpgDir, name), removed);
      }
    }
    const streams = path.join(work, 'node_modules', 'web-streams-polyfill', 'dist');
    if (fs.existsSync(streams)) {
      const keep = new Set(['ponyfill.js', 'ponyfill.es2018.js']);
      for (const name of fs.readdirSync(streams)) {
        if (!keep.has(name)) remove(path.join(streams, name), removed);
      }
    }
    for (const rel of KEEP_REQUIRED) {
      if (!fs.existsSync(path.join(work, rel))) {
        throw new Error('runtime entry missing after prune: ' + rel);
      }
    }
    fs.copyFileSync(asarPath, backup);
    await asar.createPackage(work, next);
    fs.rmSync(asarPath, {force: true});
    fs.renameSync(next, asarPath);
    fs.rmSync(backup, {force: true});
    const saved = removed.reduce((sum, item) => sum + item.size, 0);
    console.log('[prune-pack] removed ' + (saved / 1048576).toFixed(2) + ' MB from app.asar');
  } catch (error) {
    try { if (fs.existsSync(backup)) { fs.rmSync(asarPath, {force: true}); fs.renameSync(backup, asarPath); } } catch {}
    throw error;
  } finally {
    try { fs.rmSync(next, {force: true}); } catch {}
    try { fs.rmSync(work, {recursive: true, force: true}); } catch {}
  }
}

module.exports = async function afterPack(context) {
  const asarPath = path.join(context.appOutDir, 'resources', 'app.asar');
  if (!fs.existsSync(asarPath)) throw new Error('app.asar not found: ' + asarPath);
  await pruneAsar(asarPath);
};
