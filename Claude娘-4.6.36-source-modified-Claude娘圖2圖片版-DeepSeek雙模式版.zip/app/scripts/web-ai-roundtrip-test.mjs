import readline from 'node:readline';
import { spawn } from 'node:child_process';
import { existsSync, unlinkSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { prompt, parse, systemInstruction } from '../server/server.js';
import { CHOICE_PLAN, RESPONSE_COUNT, advanceRound } from './web-ai-roundtrip-core.mjs';

const webProviders = {
  openai: { name: 'ChatGPT', url: 'https://chatgpt.com/' },
  anthropic: { name: 'Claude', url: 'https://claude.ai/' },
  gemini: { name: 'Google Gemini', url: 'https://gemini.google.com/app' },
  deepseek: { name: 'DeepSeek', url: 'https://chat.deepseek.com/' },
  grok: { name: 'Grok', url: 'https://grok.com/' },
  qwen: { name: 'Qwen', url: 'https://chat.qwen.ai/' },
  mistral: { name: 'Mistral Le Chat', url: 'https://chat.mistral.ai/chat' },
  copilot: { name: 'Microsoft Copilot', url: 'https://copilot.microsoft.com/' },
  perplexity: { name: 'Perplexity', url: 'https://www.perplexity.ai/' },
  meta: { name: 'Meta AI', url: 'https://www.meta.ai/' },
  kimi: { name: 'Kimi', url: 'https://www.kimi.com/' },
  glm: { name: 'Z.ai / GLM', url: 'https://chat.z.ai/' }
};
const readlineInterface = readline.createInterface({ input: process.stdin, output: process.stdout });
const inputLines = readlineInterface[Symbol.asyncIterator]();
const promptFallbackFiles = new Set();
const requestedProviderId = String(process.argv.slice(2).find(arg => arg !== '--' && !arg.startsWith('--')) || '').toLowerCase();
const state = {
  language: 'zh',
  characterName: 'Claude娘',
  characterProfile: 'Claude娘是成年女性書庫守護者，優雅沉靜、觀察敏銳，對玩家逐漸建立信任並展現溫柔。中文一律用「她」，英文用 she/her。尊重玩家選擇，延續伏筆與因果。',
  responseMode: 'fast',
  affection: 50,
  storyTemplate: '這是三回合接續測試：序章和前兩個玩家行動回合都必須讓故事繼續，ending 必須是 false、endingText 必須是 null，並提供恰好 7 個不同的非結局選項。完成第 3 個玩家行動回合後才可自然結束或繼續故事。保留故事因果、角色反應和記憶，不要跳過任何玩家行動。',
  storyMemory: '',
  history: []
};

async function chooseProvider() {
  if (requestedProviderId) {
    if (webProviders[requestedProviderId]) return { id: requestedProviderId, ...webProviders[requestedProviderId] };
    throw new Error('不支援的網頁 AI：' + requestedProviderId + '。可用選項：' + Object.keys(webProviders).join(', '));
  }

  const providers = Object.entries(webProviders);
  console.log('請選擇要測試的 AI 網頁：');
  providers.forEach(([id, item], index) => console.log((index + 1) + '. ' + item.name + ' (' + id + ')'));
  console.log('輸入編號；直接按 Enter 預設 Google Gemini。');
  for (;;) {
    const item = await inputLines.next();
    if (item.done) throw new Error('輸入已結束，尚未選擇 AI 網站。');
    const answer = String(item.value).trim().toLowerCase();
    if (!answer) return { id: 'gemini', ...webProviders.gemini };
    if (webProviders[answer]) return { id: answer, ...webProviders[answer] };
    const index = Number(answer) - 1;
    if (Number.isInteger(index) && providers[index]) return { id: providers[index][0], ...providers[index][1] };
    console.log('請輸入 1 到 ' + providers.length + '，或服務代號；直接按 Enter 使用 Gemini。');
  }
}

function copyToClipboard(text) {
  const command = process.platform === 'win32' ? 'clip.exe' : process.platform === 'darwin' ? 'pbcopy' : 'xclip';
  const args = command === 'xclip' ? ['-selection', 'clipboard'] : [];
  return new Promise(resolve => {
    let settled = false;
    const finish = success => { if (!settled) { settled = true; resolve(success); } };
    let clipboard;
    try {
      clipboard = spawn(command, args, { stdio: ['pipe', 'ignore', 'ignore'], windowsHide: true });
    } catch {
      finish(false);
      return;
    }
    clipboard.once('error', () => finish(false));
    clipboard.once('close', code => finish(code === 0));
    clipboard.stdin.once('error', () => finish(false));
    clipboard.stdin.end(String(text), 'utf8');
  });
}

function readClipboardText() {
  if (process.platform !== 'win32') return Promise.resolve(null);
  return new Promise(resolve => {
    let output = '';
    let settled = false;
    const finish = value => { if (!settled) { settled = true; resolve(value); } };
    let reader;
    try {
      reader = spawn('powershell.exe', [
        '-NoProfile',
        '-NonInteractive',
        '-STA',
        '-Command',
        '[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; Get-Clipboard -Raw'
      ], { stdio: ['ignore', 'pipe', 'ignore'], windowsHide: true });
    } catch {
      finish(null);
      return;
    }
    reader.stdout.setEncoding('utf8');
    reader.stdout.on('data', chunk => { output += chunk; });
    reader.once('error', () => finish(null));
    reader.once('close', code => finish(code === 0 ? output.replace(/\r?\n$/, '').trim() : null));
  });
}

async function openPromptFallbackFile(text) {
  if (process.platform !== 'win32') return '';
  const filePath = join(tmpdir(), 'Claude娘-ai-prompt-' + process.pid + '-' + Date.now() + '.txt');
  try {
    writeFileSync(filePath, String(text), { encoding: 'utf8', flag: 'wx' });
    promptFallbackFiles.add(filePath);
  } catch {
    return '';
  }
  return new Promise(resolve => {
    let editor;
    try {
      editor = spawn('notepad.exe', [filePath], { detached: true, stdio: 'ignore', windowsHide: false });
    } catch {
      promptFallbackFiles.delete(filePath);
      try { unlinkSync(filePath); } catch {}
      resolve('');
      return;
    }
    editor.once('spawn', () => {
      editor.unref();
      resolve(filePath);
    });
    editor.once('error', () => {
      promptFallbackFiles.delete(filePath);
      try { unlinkSync(filePath); } catch {}
      resolve('');
    });
  });
}

function cleanupPromptFallbackFiles() {
  for (const filePath of promptFallbackFiles) {
    try { unlinkSync(filePath); } catch {}
  }
  promptFallbackFiles.clear();
}
process.once('exit', cleanupPromptFallbackFiles);

function findChromeExecutable() {
  if (process.platform !== 'win32') return '';
  const candidates = [
    process.env.CHROME_PATH,
    process.env.ProgramFiles && join(process.env.ProgramFiles, 'Google', 'Chrome', 'Application', 'chrome.exe'),
    process.env['ProgramFiles(x86)'] && join(process.env['ProgramFiles(x86)'], 'Google', 'Chrome', 'Application', 'chrome.exe'),
    process.env.LOCALAPPDATA && join(process.env.LOCALAPPDATA, 'Google', 'Chrome', 'Application', 'chrome.exe')
  ].filter(Boolean);
  return candidates.find(candidate => existsSync(candidate)) || '';
}

function openProviderPage(url) {
  const chromePath = findChromeExecutable();
  if (chromePath) {
    try {
      const browser = spawn(chromePath, ['--new-window', url], { detached: true, stdio: 'ignore', windowsHide: false });
      browser.once('error', () => {});
      browser.unref();
      return 'chrome';
    } catch {
      // Fall back to the operating system's configured browser.
    }
  }
  const command = process.platform === 'win32' ? 'rundll32.exe' : process.platform === 'darwin' ? 'open' : 'xdg-open';
  const args = process.platform === 'win32' ? ['url.dll,FileProtocolHandler', url] : [url];
  try {
    const browser = spawn(command, args, { detached: true, stdio: 'ignore', windowsHide: true });
    browser.once('error', () => {});
    browser.unref();
    return 'default';
  } catch {
    return '';
  }
}

async function writePrompt(text, provider) {
  console.log('\n' + '='.repeat(24) + ' 請貼到 ' + provider.name + ' ' + '='.repeat(24));
  console.log(text);
  console.log('='.repeat(68));
  if (await copyToClipboard(text)) {
    console.log('提示詞已複製到剪貼簿；切到官方 AI 網站後，在輸入框按 Ctrl+V。');
  } else {
    const fallbackFile = await openPromptFallbackFile(text);
    console.log(fallbackFile
      ? '系統剪貼簿不可用；已在記事本開啟提示詞。請在記事本按 Ctrl+A、Ctrl+C，再貼到官方 AI 網站。暫存檔會在測試結束時清除。'
      : '無法自動寫入剪貼簿；請只複製上方完整提示詞，再貼到官方 AI 網站。');
  }
}

async function readAIReply(label, provider, mustContinue, isOpening=false) {
  let repairReason = '';
  for (let attempt = 1; attempt <= 3; attempt++) {
    console.log('\n' + label);
    console.log('第 ' + attempt + ' 次檢查，最多可修復 2 次。');
    if (repairReason) {
      const repairPrompt = `請修復上一則回覆並保留故事、玩家行動、正文與記憶。${repairReason}\nnarration至少500字（含標點，不含JSON／選項／記憶），可以更長；choices恰好7個且彼此不同。只輸出有效JSON，不要Markdown。`;
      if (await copyToClipboard(repairPrompt)) {
        console.log('已將修復提示複製到剪貼簿。回到同一個 ' + provider.name + ' 對話按 Ctrl+V、Enter，等修復完成後再複製 JSON。');
      } else {
        const fallbackFile = await openPromptFallbackFile(repairPrompt);
        console.log(fallbackFile
          ? '系統剪貼簿不可用；修復提示已在記事本開啟，請複製後貼到同一個 ' + provider.name + ' 對話。'
          : '請在同一個 ' + provider.name + ' 對話貼上此修復要求：\n' + repairPrompt);
      }
    } else {
      console.log('請在 ' + provider.name + ' 使用回覆旁的「複製」，或只選取完整 JSON 回覆後複製。');
    }
    const useClipboardRead = process.platform === 'win32';
    let raw = '';
    if (useClipboardRead) {
      console.log('在官方網站按回覆旁的「複製」後回到終端按 Enter；也可輸入 P 並按 Enter，改為手動貼回 JSON。腳本只在 Enter 後讀取剪貼簿文字，不讀取網頁。');
      const item = await inputLines.next();
      if (item.done) throw new Error('輸入已結束，三回合測試中止。');
      if (String(item.value).trim().toLowerCase() !== 'p') {
        raw = await readClipboardText() || '';
        if (raw && !/^\s*(?:```(?:json)?\s*)?\{/.test(raw)) {
          console.log('剪貼簿內容未包含故事正文 JSON 欄位；請確認只複製了 AI 回覆，再試一次，或改用手動貼回。');
          raw = '';
        }
        if (!raw) console.log('剪貼簿沒有可用的故事回覆；改用手動貼回 JSON，貼完後另輸入一行 END。');
      }
    }
    if (!raw) {
      const lines = [];
      console.log('貼上完整 JSON 回覆；若貼上的內容無法解析，再輸入一行 END 結束本次貼上。');
      for (;;) {
        const item = await inputLines.next();
        if (item.done) throw new Error('輸入已結束，三回合測試中止。');
        if (String(item.value).trim().toUpperCase() === 'END') break;
        lines.push(String(item.value));
        const candidate = lines.join('\n').trim();
        try {
          parse(candidate);
          raw = candidate;
          break;
        } catch {
          // Keep collecting until the pasted JSON becomes complete or END is entered.
        }
      }
      if (!raw) raw = lines.join('\n').trim();
    }
    if (!raw) {
      repairReason = '上一則回覆沒有貼入內容，請依照目前回合提示完整回覆。';
      continue;
    }
    try {
      const reply = parse(raw);
      if (mustContinue && reply.ending) {
        repairReason = '現在還沒完成三個選項回合，ending 必須為 false、endingText 必須為 null，並提供可以繼續的 7 個不同選項。';
        continue;
      }
      return reply;
    } catch (error) {
      repairReason = '上一則回覆格式檢查失敗：' + (error?.message || String(error)) + '。請修正格式，不要重置故事或改寫已發生的情節。';
    }
  }
  throw new Error('回覆在 3 次檢查後仍未通過格式／續寫要求；故事尚未前進，請重試目前回合。');
}

function showChoices(choices, provider) {
  console.log('\n' + provider.name + ' 提供的 7 個選項：');
  choices.forEach((choice, index) => console.log((index + 1) + '. ' + choice));
}

try {
  const provider = await chooseProvider();
  console.log(provider.name + ' 網頁三回合接續測試');
  const browserMode = openProviderPage(provider.url);
  console.log((browserMode === 'chrome' ? '已用 Chrome 開啟 ' : browserMode === 'default' ? '已在預設瀏覽器開啟 ' : '請在瀏覽器手動開啟 ') + provider.url + '，登入後保持同一段對話。');
  console.log('本腳本不登入、不操作或讀取 AI 網頁；它會維持故事脈絡並依序選第 2、4、5 項。');
  console.log(process.platform === 'win32'
    ? '每一步在官方網站貼上並送出提示詞；生成完成後按網站「複製」，回到終端按 Enter 讀取純文字剪貼簿。也可輸入 P 並按 Enter，改為手動貼回 JSON。腳本不讀取或操作網頁。'
    : '每一步把提示詞貼到 ' + provider.name + ' 送出，再手動複製完整 JSON 回覆並貼回此處。');

  let nextAction = '__OPENING_STYLE__:rainy_first_meeting';
  const selectedActions = [];

  for (let responseIndex = 0; responseIndex < RESPONSE_COUNT; responseIndex++) {
    const isOpening = responseIndex === 0;
    const request = { ...state, action: nextAction };
    const currentPrompt = systemInstruction(request) + '\n\n' + prompt(request);
    const label = isOpening
      ? '序章：請在 ' + provider.name + ' 產生開場回覆。'
      : '第 ' + responseIndex + ' 輪：已在提示詞中帶入前一輪選項 ' + nextAction;
    await writePrompt(currentPrompt, provider);
    const reply = await readAIReply(label, provider, responseIndex < CHOICE_PLAN.length);
    showChoices(reply.choices, provider);
    const result = advanceRound(state, nextAction, reply, responseIndex);
    if (result.selectedAction) {
      nextAction = result.selectedAction.text;
      selectedActions.push(result.selectedAction);
      console.log('\n自動測試動作：第 ' + result.selectedAction.round + ' 輪選第 ' + result.selectedAction.number + ' 項。');
    }
  }

  console.log('\n測試通過：已完成 ' + provider.name + ' 序章及 3 個故事回合；選項順序為 2 → 4 → 5。');
  selectedActions.forEach((action) => console.log('第 ' + action.round + ' 輪選 ' + action.number + '：' + action.text));
} catch (error) {
  console.error('\n測試中止：' + (error?.message || String(error)));
  process.exitCode = 1;
} finally {
  readlineInterface.close();
  cleanupPromptFallbackFiles();
}
