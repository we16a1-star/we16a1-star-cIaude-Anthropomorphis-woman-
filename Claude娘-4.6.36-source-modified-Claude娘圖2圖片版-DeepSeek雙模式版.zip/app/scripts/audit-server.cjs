#!/usr/bin/env node
// 後端 API 冒煙測試：啟動真正的 server.js（隨機埠、桌面 token），逐一呼叫前端會用到的路由。
// 不需要任何 API Key；沒有金鑰時應回傳可讀的 JSON 錯誤，而不是崩潰或 404。
const path = require('path');
const {pathToFileURL} = require('url');

const token = 'audit-' + Date.now().toString(36);
const results = [];
const fail = message => { results.push('FAIL ' + message); process.exitCode = 1; };
const ok = message => results.push('OK   ' + message);

(async () => {
  const mod = await import(pathToFileURL(path.join(__dirname, '..', 'server', 'server.js')).href);
  const server = await mod.startApiServer({port: 0, host: '127.0.0.1', token});
  const base = 'http://127.0.0.1:' + server.address().port;
  const request = async (routePath, options = {}) => {
    const headers = {...(options.headers || {})};
    if (options.auth !== false) headers['X-Desktop-Token'] = token;
    const response = await fetch(base + routePath, {...options, headers});
    const text = await response.text();
    let body = null;
    try { body = JSON.parse(text); } catch {}
    return {status: response.status, body, text, headers: response.headers};
  };
  try {
    let response = await request('/api/health');
    if (response.status === 200 && response.body?.ok === true) ok('GET /api/health 回傳 ok');
    else fail(`GET /api/health 狀態 ${response.status}：${response.text.slice(0, 120)}`);

    response = await request('/api/health', {auth: false});
    if (response.status === 401) ok('GET /api/health 未帶 token 會被拒絕');
    else fail(`GET /api/health 未帶 token 應為 401，實際 ${response.status}`);

    response = await request('/api/health', {headers: {'X-Desktop-Token': 'wrong'}, auth: false});
    if (response.status === 401) ok('GET /api/health 錯誤 token 會被拒絕');
    else fail(`GET /api/health 錯誤 token 應為 401，實際 ${response.status}`);

    response = await request('/api/story', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({provider: 'openai', model: 'audit-no-key'})
    });
    if ([400, 401, 402, 403, 429, 500, 502, 503].includes(response.status) && response.body && typeof response.body.error === 'string') {
      ok(`POST /api/story 無金鑰時回傳 JSON 錯誤（${response.status}）`);
    } else {
      fail(`POST /api/story 無金鑰時回應異常（${response.status}）：${response.text.slice(0, 120)}`);
    }

    response = await request('/api/model-check', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({})
    });
    if (response.status === 400 && response.body && typeof response.body.error === 'string') {
      ok('POST /api/model-check 空參數回傳 400 JSON');
    } else if (response.status === 200 && response.body) {
      ok('POST /api/model-check 回傳檢測結果');
    } else {
      fail(`POST /api/model-check 回應異常（${response.status}）：${response.text.slice(0, 120)}`);
    }

    response = await request('/api/not-a-route');
    if (response.status === 404) ok('未知的 /api 路由回傳 404');
    else fail(`未知的 /api 路由應為 404，實際 ${response.status}`);

    response = await fetch(base + '/api/health', {headers: {'X-Desktop-Token': token, Origin: 'https://example.com'}});
    const allow = response.headers.get('access-control-allow-origin');
    if (!allow || allow !== 'https://example.com') ok('外部網站 Origin 不會取得 CORS 放行');
    else fail('外部網站 Origin 竟取得 CORS 放行');
  } finally {
    await new Promise(resolve => server.close(resolve));
  }
  console.log('Claude娘 後端 API 冒煙測試');
  for (const line of results) console.log(line);
  console.log(process.exitCode ? '結果：FAIL' : '結果：PASS');
})().catch(error => {
  console.error('FAIL 後端啟動或測試失敗：', error);
  process.exitCode = 1;
});
