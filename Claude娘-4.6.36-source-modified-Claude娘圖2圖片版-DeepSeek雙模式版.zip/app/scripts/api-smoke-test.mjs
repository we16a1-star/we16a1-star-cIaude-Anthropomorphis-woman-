// API 自動化驗證：免手動操作，一鍵檢測「金鑰存在 → 後端健康 → 自動生成」全鏈路。
// 用法：node scripts/api-smoke-test.mjs [provider] [profile] [--model <id>]
//   provider 預設 gemini；profile 預設 default（對應 <PREFIX>_API_KEY_<PROFILE>）。
// 沒有設定金鑰時印出設定指引並以 exit 2 離開（視為略過，不是失敗）。
// 有金鑰時會實際呼叫一次 fast 檔生成（會消耗供應商額度，請先確認）。
// 金鑰只從環境變數讀取，不寫入任何檔案、不印出金鑰本體。
import {startApiServer} from '../server/server.js';

const PREFIX = {anthropic: 'ANTHROPIC', openai: 'OPENAI', gemini: 'GEMINI', openrouter: 'OPENROUTER', deepseek: 'DEEPSEEK', qwen: 'QWEN', groq: 'GROQ', mistral: 'MISTRAL', xai: 'XAI'};

function usage() {
  console.log('用法：node scripts/api-smoke-test.mjs [provider] [profile] [--model <id>]');
  console.log('支援的 provider：' + Object.keys(PREFIX).join('、'));
}

async function main() {
  const args = process.argv.slice(2);
  if (args.includes('-h') || args.includes('--help')) { usage(); return 0; }
  const provider = (args[0] || 'gemini').toLowerCase();
  const profile = String(args[1] || 'default').toUpperCase();
  const modelIndex = args.indexOf('--model');
  const model = modelIndex >= 0 ? args[modelIndex + 1] : undefined;
  if (!PREFIX[provider]) { console.error('不支援的 provider：' + provider); usage(); return 1; }
  if (!/^[A-Z0-9_]{1,32}$/.test(profile)) { console.error('profile 需為 1–32 個英數字或底線'); return 1; }

  const keyName = `${PREFIX[provider]}_API_KEY${profile === 'DEFAULT' ? '' : '_' + profile}`;
  if (!process.env[keyName]) {
    console.log(`未偵測到 ${keyName}，略過實際生成。`);
    console.log(`設定方式：App「設定 → AI 帳號」新增 ${provider} 金鑰（Windows 加密本機保存），`);
    console.log(`或在 server .env 加入 ${keyName}=你的金鑰後重跑本腳本。注意：有金鑰時會實際生成一次 fast 回合併消耗額度。`);
    return 2;
  }

  const token = 'smoke-' + Math.random().toString(36).slice(2);
  const server = await startApiServer({host: '127.0.0.1', port: 0, token});
  const base = `http://127.0.0.1:${server.address().port}`;
  try {
    const health = await (await fetch(base + '/api/health', {headers: {'X-Desktop-Token': token}})).json();
    const profiles = health?.profiles?.[provider] || [];
    if (!profiles.map(x => String(x).toUpperCase()).includes(profile === 'DEFAULT' ? 'DEFAULT' : profile)) {
      console.error(`後端未見到 ${provider}/${profile} 的金鑰設定：` + JSON.stringify(profiles));
      return 1;
    }
    console.log(`健康檢查通過：${provider}/${profile} 金鑰存在，開始一次 fast 自動生成…`);
    const body = {provider, accountProfile: profile === 'DEFAULT' ? '' : profile, responseMode: 'fast', history: [], action: '__OPENING_STYLE__:rainy_first_meeting', affection: 50, ...(model ? {model} : {})};
    const res = await fetch(base + '/api/story', {method: 'POST', headers: {'Content-Type': 'application/json', 'X-Desktop-Token': token}, body: JSON.stringify(body)});
    const data = await res.json();
    if (!res.ok) { console.error('生成失敗：' + (data.error || res.status)); return 1; }
    const narrationLength = Array.from(String(data.narration || '')).length;
    const checks = [
      ['正文500字', narrationLength >= 500],
      ['恰好7選項', Array.isArray(data.choices) && data.choices.length === 7],
      ['好感數值', Number.isFinite(Number(data.affectionDelta))],
      ['記憶字串', typeof data.memory === 'string']
    ];
    for (const [name, ok] of checks) console.log(`${ok ? '通過' : '失敗'}：${name}`);
    console.log(`摘要：正文${narrationLength}字、選項${data.choices?.length}個、好感變化${data.affectionDelta}`);
    return checks.every(([, ok]) => ok) ? 0 : 1;
  } finally {
    await new Promise(resolve => server.close(resolve));
  }
}

process.exitCode = await main();
