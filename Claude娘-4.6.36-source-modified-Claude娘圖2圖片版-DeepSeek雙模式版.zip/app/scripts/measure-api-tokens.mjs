// 量測每回合的規模並檢查「輸出上限留不留得下最低需求」。
// 用法：npm run api:measure-tokens      改 www/token-budget.js 後重跑即可對照。
// 單位是字元數（中文約 1 字 ≈ 1.3～1.5 token）；token 欄位是估算值，實際依模型而異。
import {requestSystemInstruction, requestPrompt} from '../server/server.js';
import {TOKEN_BUDGET, OUTPUT_TARGET} from '../www/token-budget.js';

const CHARS_PER_TOKEN = 1.4;
const estimate = chars => Math.round(chars * CHARS_PER_TOKEN);

const filler = '她把書頁輕輕翻過，窗外的雨聲落在彩窗上，茶香在木書架之間緩緩散開；';
const narration = length => filler.repeat(Math.ceil(length / filler.length)).slice(0, length);
const history = Array.from({length: 12}, (_, i) => i % 2 === 0
  ? {role: 'user', text: '我想先問問她剛才提到的那本古籍，並請她說明它的來歷。'}
  : {role: 'ai', text: narration(800)});
const memory = '重要事件：雨夜相遇、修復古籍、發現禁書。關係：她逐漸信任玩家。承諾：明晚一起整理三樓書庫。伏筆：星形印記、鐘樓。'.repeat(8).slice(0, 800);

console.log('【輸入】每回合送給 API 的固定前綴與當回合提示（合成：旁白 800 字、記憶 800 字）');
console.log('模式      system   使用者提示   合計(字元)   合計(≈token)   輸入預算');
for (const mode of ['fast', 'quality']) {
  const body = {responseMode: mode, language: 'zh', affection: 62, characterName: 'Claude娘', storyMemory: memory, history, action: '我提議明晚一起去三樓書庫看看。'};
  const system = requestSystemInstruction(body).length;
  const user = requestPrompt(body).length;
  console.log(`${mode.padEnd(8)} ${String(system).padStart(6)} ${String(user).padStart(10)} ${String(system + user).padStart(11)} ${String(estimate(system + user)).padStart(14)}   ${JSON.stringify(TOKEN_BUDGET[mode])}`);
}
console.log('註：system 是固定前綴（Anthropic 會標記快取，命中時以低價計）；換算成 token 後只計實際送出的量。\n');

console.log('【輸出】每回合要模型寫多少（提示詞要求的區間）與 max_tokens 的關係');
const labels = [
  ['旁白 narration', OUTPUT_TARGET.narrationMin, OUTPUT_TARGET.narrationMax, '提示寫「最多不要超過 ' + OUTPUT_TARGET.narrationHard + ' 字」'],
  ['7 個選項', OUTPUT_TARGET.choiceMin * 7, OUTPUT_TARGET.choiceMax * 7, '每個 ' + OUTPUT_TARGET.choiceMin + '～' + OUTPUT_TARGET.choiceMax + ' 字，硬上限 ' + OUTPUT_TARGET.choiceHard + ' 字（超過只截短，不整回合重打）'],
  ['記憶 memory 改寫', 0, 0, '上限＝該模式的 memoryChars'],
  ['JSON 欄位與標記', 90, 130, '欄位名、引號、布林值等']
];
for (const mode of ['fast', 'quality']) {
  const memoryChars = TOKEN_BUDGET[mode].memoryChars;
  const low = OUTPUT_TARGET.narrationMin + OUTPUT_TARGET.choiceMin * 7 + 0 + 90;
  const high = OUTPUT_TARGET.narrationMax + OUTPUT_TARGET.choiceMax * 7 + memoryChars + 130;
  const cap = OUTPUT_TARGET.maxTokens[mode];
  console.log(`\n${mode}（記憶上限 ${memoryChars} 字）`);
  for (const [name, a, b, note] of labels) {
    const lo = name.startsWith('記憶') ? 0 : a;
    const hi = name.startsWith('記憶') ? memoryChars : b;
    console.log(`  ${name.padEnd(18)} ${String(lo).padStart(4)}～${String(hi).padEnd(5)} 字  ≈ ${String(estimate(lo)).padStart(4)}～${String(estimate(hi)).padEnd(5)} token   ${note}`);
  }
  const withMemory = low + memoryChars;
  console.log(`  ${'—'.repeat(18)} 最低需求 ≈ ${estimate(low)}（記憶 0）～ ${estimate(withMemory)}（記憶寫滿）token；典型上限 ≈ ${estimate(high)} token`);
  console.log(`  max_tokens = ${cap}  →  對「記憶寫滿的最低需求」餘裕 ${cap - estimate(withMemory)} token（${Math.round((cap / estimate(withMemory) - 1) * 100)}%）；對典型上限餘裕 ${cap - estimate(high)} token`);
  if (cap <= estimate(withMemory)) {
    console.log('  ⚠ 上限已經低於最低需求：模型只要多寫一點就會被截斷，JSON 不完整 → 整回合失敗 → 使用者手動重打 = 雙倍花費。請調高 maxTokens。');
  } else {
    console.log('  ✓ 上限高於最低需求，模型正常發揮不會被截斷（max_tokens 本身不計費，只計實際輸出）。');
  }
}
console.log('\n提示：真正花錢的是「輸出」，所以減少輸出的字數（旁白區間、選項長度、記憶精簡）比壓縮輸入有效得多。');
