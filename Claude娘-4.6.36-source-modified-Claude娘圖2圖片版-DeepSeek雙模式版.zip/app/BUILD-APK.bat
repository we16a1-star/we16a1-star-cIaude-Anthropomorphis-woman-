@echo off
call "%~dp0BUILD-APK-Windows.bat"
