// 創意工坊「套用到原始專案」核心邏輯（不依賴 Electron，可直接用 node --test 驗證）。
// 流程：路徑安全檢查 → 找到原始專案資料夾 → 語法檢查 → 備份舊檔 → 原子寫入（失敗自動還原）。
// 修改只會寫進原始專案資料夾，不會在已安裝的遊戲內即時執行；之後由一鍵建置腳本重新編譯與安裝。
//
// v4.4.0「整個專案都能開、都能改」：不再維護可編輯白名單。
// 專案資料夾內任何文字檔都能開啟與修改（含新增檔案、README、測試、建置腳本）。
// 仍然擋下的只有以下幾類（安全性與實用性，不是權限）：
//   1. 跳出專案資料夾的路徑（絕對路徑、. 或 ..）。
//   2. 相依與建置產物：node_modules、dist、release、_build-tools、android…（動了也不會生效，且體積巨大）。
//   3. 備份與快取：.workshop-backup、.cache、coverage…
//   4. 版本控制資料：.git
//   5. 秘密檔：.env？— 避免把 API Key 讀進畫面或寫進修改包。
'use strict';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const {spawnSync} = require('node:child_process');

const MAX_FILE_BYTES = 400000;     // 單一檔案上限（400 KB；www/app.js 已 227 KB）
const MAX_TOTAL_BYTES = 2000000;   // 一次套用的總量上限（2 MB）
const MAX_LISTED_FILES = 4000;     // 清單上限，避免相依目錄把介面拖垮
const PROJECT_NAME = 'claude-novel-windows11';
const SOURCE_ROOT_FILE = 'source-root.json';
const BACKUP_DIR_NAME = '.workshop-backup';

// 永遠不開放編輯的目錄名稱（路徑中任何一層出現就擋下）。
const BLOCKED_DIRS = new Set([
  'node_modules', '.git', 'dist', 'dist-app', 'release', '_build-tools', '.workshop-backup',
  '.cache', '.npm', '.yarn', '.pnpm-store', 'coverage', '.nyc_output', 'android', '.gradle', 'out'
]);
// 永遠不開放編輯的檔名（秘密檔、打包前才產生的標記檔）。
const BLOCKED_FILES = new Set([SOURCE_ROOT_FILE]);
const BLOCKED_FILE_PATTERNS = [/^\.env(?:\.|$)/i, /\.workshop-tmp$/i];

function isBlockedRelative(relativePath) {
  const segments = relativePath.split('/');
  if (segments.some(segment => BLOCKED_DIRS.has(segment.toLowerCase()) || segment.toLowerCase().startsWith('.workshop-'))) return true;
  const base = segments[segments.length - 1] || '';
  if (BLOCKED_FILES.has(base)) return true;
  return BLOCKED_FILE_PATTERNS.some(pattern => pattern.test(base));
}

// 把使用者輸入或修改包裡的路徑正規化：允許開頭的 ./ 與多餘的斜線，但一律擋掉絕對路徑與 ..（含 Windows 磁碟機代號）。
function normalizeRelativePath(value) {
  if (typeof value !== 'string' || !value.trim()) throw new Error('不支援的路徑（不得為空）。');
  const raw = value.trim().replace(/\\/g, '/');
  if (raw.startsWith('/') || /^[A-Za-z]:/.test(raw)) throw new Error('不支援的路徑（不可使用絕對路徑）：' + value);
  const segments = raw.split('/');
  if (segments.includes('..')) throw new Error('不支援的路徑（不可包含 ..）：' + value);
  const cleaned = segments.filter(segment => segment !== '' && segment !== '.');
  if (!cleaned.length) throw new Error('不支援的路徑（格式無效）：' + value);
  // Windows 專案：擋掉 Win32 會「重新解讀」而可能繞過封鎖清單的寫法——
  //   * 冒號＝NTFS 替代資料流：`.env:stream` 其實是 `.env` 的附掛資料流，可繞過 .env 封鎖
  //   * 結尾句點／空白：Windows 會自動去掉，`foo.` 與 `foo` 是同一個檔案
  //   * CON／NUL 等保留裝置名稱：寫入行為不是一般檔案
  for (const segment of cleaned) {
    if (segment.includes(':')) throw new Error('不支援的路徑（Windows 檔名不可包含冒號）：' + value);
    if (/[. ]$/.test(segment)) throw new Error('不支援的路徑（Windows 會忽略結尾的句點或空白，可能誤寫到別的檔案）：' + value);
    if (/^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(segment)) throw new Error('不支援的路徑（Windows 保留裝置名稱不可作為檔名）：' + value);
  }
  return cleaned.join('/');
}

// allowed 可以是：Set（舊介面，白名單）、函式（自訂規則）或 null／undefined（＝整個專案都開放）。
function assertEditablePath(relativePath, allowed) {
  const normalized = normalizeRelativePath(relativePath);
  if (isBlockedRelative(normalized)) throw new Error('不支援的路徑（相依、建置產物、備份或秘密檔不開放編輯）：' + normalized);
  if (allowed) {
    const permitted = typeof allowed === 'function' ? allowed(normalized) : allowed.has(normalized);
    if (!permitted) throw new Error('修改檔案包含不支援的路徑或內容格式。');
  }
  return normalized;
}

function validateFiles(requested, allowed) {
  if (!requested || typeof requested !== 'object' || Array.isArray(requested)) throw new Error('修改檔案格式無效。');
  const entries = [];
  let total = 0;
  for (const [relativePath, content] of Object.entries(requested)) {
    if (typeof content !== 'string') throw new Error('修改檔案包含不支援的路徑或內容格式。');
    const file = assertEditablePath(relativePath, allowed);
    const bytes = Buffer.byteLength(content, 'utf8');
    if (bytes > MAX_FILE_BYTES) throw new Error(`單一程式檔超過 ${Math.round(MAX_FILE_BYTES / 1000)} KB：${file}`);
    total += bytes;
    if (total > MAX_TOTAL_BYTES) throw new Error('修改程式碼總量過大，請分批套用。');
    entries.push({path: file, content});
  }
  if (!entries.length) throw new Error('沒有可套用的程式碼修改。');
  return entries;
}

// 防止路徑跳脫：結果必須落在 appDir 底下。
function safeTarget(appDir, relativePath) {
  const root = path.resolve(appDir);
  const target = path.resolve(root, relativePath);
  if (target !== root && !target.startsWith(root + path.sep)) throw new Error('拒絕寫入原始專案以外的路徑。');
  return target;
}

// 一鍵建置腳本會在打包前寫下 source-root.json：
//   appDir  ＝ 原始專案的 app 資料夾（自動重建要在這裡跑 BUILD-WINDOWS11-AUTO.bat）
//   rootDir ＝ 整個交付資料夾（v4.4.0 起記錄；工坊的可編輯範圍，含文件與建置腳本）
function readSourceMarker(appPath) {
  const markerPath = path.join(appPath, SOURCE_ROOT_FILE);
  let marker;
  try { marker = JSON.parse(fs.readFileSync(markerPath, 'utf8')); }
  catch { throw new Error('找不到原始專案位置。請用「一鍵安裝-Windows11.bat」建置安裝，或改用「匯出修改程式碼 ZIP」。'); }
  return marker && typeof marker === 'object' ? marker : {};
}

function isProjectAppDir(dir) {
  if (!dir || !fs.existsSync(dir)) return false;
  let pkg;
  try { pkg = JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8')); }
  catch { return false; }
  return pkg?.name === PROJECT_NAME && fs.existsSync(path.join(dir, 'electron-main.cjs'));
}

// 原始專案的 app 資料夾（自動重建時要跑這裡的 BUILD-WINDOWS11-AUTO.bat）。
function resolveSourceRoot(appPath) {
  const marker = readSourceMarker(appPath);
  const stated = [marker.appDir, marker.rootDir && path.join(String(marker.rootDir), 'app')].filter(Boolean).map(dir => path.resolve(String(dir)));
  for (const dir of stated) if (isProjectAppDir(dir)) return dir;
  if (!stated.length) throw new Error('找不到原始專案位置。請用「一鍵安裝-Windows11.bat」建置安裝，或改用「匯出修改程式碼 ZIP」。');
  if (!fs.existsSync(stated[0])) throw new Error('原始專案資料夾已移動或刪除；請改用「匯出修改程式碼 ZIP」。');
  let pkg;
  try { pkg = JSON.parse(fs.readFileSync(path.join(stated[0], 'package.json'), 'utf8')); } catch { throw new Error('原始專案資料夾內找不到有效的 package.json。'); }
  if (pkg?.name !== PROJECT_NAME || !fs.existsSync(path.join(stated[0], 'electron-main.cjs'))) throw new Error('該資料夾看起來不是本專案的原始碼，已停止套用。');
  return stated[0];
}

// 工坊的可編輯範圍（不是拋錯，而是回報「可以改到什麼程度」）：
//   project   ＝ 整個交付資料夾（推薦；含 app\ 以外的 README、優化紀錄、一鍵安裝腳本）
//   app       ＝ 只有 app 資料夾（舊版 source-root.json 沒記 rootDir 時）
//   installed ＝ 已安裝的 App 內容（找不到原始專案；仍可讀取與匯出修改包）
function resolveWorkshopRoot(appPath) {
  const installed = {dir: path.resolve(appPath), original: false, scope: 'installed'};
  let marker;
  try { marker = readSourceMarker(appPath); } catch (error) { return {...installed, reason: error.message}; }
  const rootDir = marker.rootDir ? path.resolve(String(marker.rootDir)) : '';
  if (rootDir && isProjectAppDir(path.join(rootDir, 'app'))) return {dir: rootDir, original: true, scope: 'project'};
  try { return {dir: resolveSourceRoot(appPath), original: true, scope: 'app'}; }
  catch (error) { return {...installed, reason: error.message}; }
}

// 遞迴列出可編輯的檔案（相依、建置產物、備份與秘密檔會自動略過）。
// 只回傳一般檔案；符號連結等一律不跟隨，避免透過連結讀到專案外的內容。
function listEditableFiles(rootDir, {limit = MAX_LISTED_FILES} = {}) {
  const root = path.resolve(rootDir);
  const files = [];
  const walk = dir => {
    if (files.length >= limit) return;
    let entries;
    try { entries = fs.readdirSync(dir, {withFileTypes: true}); } catch { return; }
    entries.sort((a, b) => a.name.localeCompare(b.name, 'en'));
    for (const entry of entries) {
      if (files.length >= limit) return;
      const full = path.join(dir, entry.name);
      const relative = path.relative(root, full).split(path.sep).join('/');
      if (isBlockedRelative(relative)) continue;
      if (entry.isDirectory()) { walk(full); continue; }
      if (!entry.isFile()) continue;
      let bytes = 0;
      try { bytes = fs.statSync(full).size; } catch { continue; }
      files.push({path: relative, bytes});
    }
  };
  walk(root);
  return files;
}

// 讀取可編輯的檔案（utf8）。會再次確認實際路徑仍在專案內（防止連結跳脫），並套用大小上限。
function readEditableFile(rootDir, relativePath, allowed) {
  const root = path.resolve(rootDir);
  const file = assertEditablePath(relativePath, allowed);
  const target = safeTarget(root, file);
  let realRoot;
  try { realRoot = fs.realpathSync(root); } catch { throw new Error('找不到原始專案資料夾。'); }
  let realTarget;
  try { realTarget = fs.realpathSync(target); }
  catch { throw new Error('找不到這個程式檔（可能是新檔案，儲存後即可建立）：' + file); }
  if (realTarget !== realRoot && !realTarget.startsWith(realRoot + path.sep)) throw new Error('拒絕讀取原始專案以外的路徑。');
  let stat;
  try { stat = fs.statSync(realTarget); } catch { throw new Error('無法讀取這個程式檔：' + file); }
  if (!stat.isFile()) throw new Error('這不是一個檔案：' + file);
  if (stat.size > MAX_FILE_BYTES) throw new Error(`檔案超過 ${Math.round(MAX_FILE_BYTES / 1000)} KB，工坊不開放編輯：${file}`);
  return fs.readFileSync(realTarget, 'utf8');
}

// 以 node --check 檢查語法（Electron 內用 ELECTRON_RUN_AS_NODE=1）。.js 在本專案是 ESM，需以 .mjs 暫存檢查。
// 只有真正的 SyntaxError 會擋下套用；若檢查器本身無法使用，該檔記入 unchecked，由介面明確告知「未檢查」。
function checkSyntax(entries, {nodePath = process.execPath, spawn = spawnSync} = {}) {
  const problems = [];
  const unchecked = [];
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'workshop-check-'));
  try {
    entries.forEach((entry, index) => {
      const file = entry.path;
      if (/\.json$/i.test(file)) {
        try {
          const data = JSON.parse(entry.content);
          if (file === 'package.json' && (data.name !== PROJECT_NAME || data.main !== 'electron-main.cjs' || !data.scripts?.dist || !data.build)) {
            problems.push({file, message: 'package.json 的 name、main、scripts.dist 或 build 設定被改動，會讓建置失敗。'});
          }
        } catch (error) { problems.push({file, message: 'JSON 格式錯誤：' + error.message}); }
        return;
      }
      if (!/\.(?:js|cjs|mjs)$/.test(file)) return;
      const ext = file.endsWith('.cjs') ? '.cjs' : '.mjs';
      const probe = path.join(tmp, `${index}${ext}`);
      fs.writeFileSync(probe, entry.content, 'utf8');
      const result = spawn(nodePath, ['--check', probe], {encoding: 'utf8', env: {...process.env, ELECTRON_RUN_AS_NODE: '1'}, timeout: 20000});
      const stderr = String(result.stderr || '');
      if (result.error || (result.status !== 0 && !/SyntaxError/.test(stderr))) { unchecked.push(file); return; }
      if (result.status !== 0) {
        const text = stderr.split(/\r?\n/).filter(line => line && !line.startsWith('Node.js v')).slice(0, 6).join('\n').split(probe).join(file);
        problems.push({file, message: text || '語法錯誤'});
      }
    });
  } finally { fs.rmSync(tmp, {recursive: true, force: true}); }
  return {problems, unchecked};
}

function stamp(date = new Date()) {
  const pad = n => String(n).padStart(2, '0');
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}-${pad(date.getHours())}${pad(date.getMinutes())}${pad(date.getSeconds())}`;
}

// 備份舊檔到 appDir/.workshop-backup/<時間>/，再逐檔以「暫存檔＋改名」寫入；任一檔失敗就還原已寫入的檔案。
function applyFiles(appDir, entries, {now = new Date()} = {}) {
  const backupDir = path.join(appDir, BACKUP_DIR_NAME, stamp(now));
  const written = [];
  const originals = new Map();
  try {
    for (const entry of entries) {
      const target = safeTarget(appDir, entry.path);
      const existed = fs.existsSync(target);
      if (existed) {
        const backupTarget = safeTarget(backupDir, entry.path);
        fs.mkdirSync(path.dirname(backupTarget), {recursive: true});
        fs.copyFileSync(target, backupTarget);
      }
      originals.set(target, existed ? backupDir : null);
      fs.mkdirSync(path.dirname(target), {recursive: true});
      const temp = target + '.workshop-tmp';
      fs.writeFileSync(temp, entry.content, 'utf8');
      fs.renameSync(temp, target);
      written.push(entry.path);
    }
  } catch (error) {
    for (const entry of entries) {
      const target = safeTarget(appDir, entry.path);
      try {
        if (!originals.has(target)) continue;
        const backupRoot = originals.get(target);
        if (backupRoot) fs.copyFileSync(safeTarget(backupRoot, entry.path), target);
        else fs.rmSync(target, {force: true});
      } catch { /* 盡力還原 */ }
      try { fs.rmSync(target + '.workshop-tmp', {force: true}); } catch { /* ignore */ }
    }
    throw new Error('寫入原始專案失敗，已還原：' + error.message);
  }
  return {written, backupDir};
}

module.exports = {
  MAX_FILE_BYTES, MAX_TOTAL_BYTES, MAX_LISTED_FILES, PROJECT_NAME, SOURCE_ROOT_FILE, BACKUP_DIR_NAME,
  isBlockedRelative, normalizeRelativePath, assertEditablePath, validateFiles, safeTarget,
  readSourceMarker, isProjectAppDir, resolveSourceRoot, resolveWorkshopRoot,
  listEditableFiles, readEditableFile, checkSyntax, applyFiles, stamp
};
