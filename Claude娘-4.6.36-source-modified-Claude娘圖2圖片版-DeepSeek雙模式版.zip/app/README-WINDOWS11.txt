【Windows 11 電腦版｜一鍵安裝】

安裝完成後，App 會自動啟動本機 AI 後端；不需要另外安裝 Node.js，也不用手動啟動 server。

首次建置需要網路。解壓 ZIP 後雙擊套件根目錄的「一鍵安裝-Windows11.bat」，即可下載建置工具、建置安裝程式並自動安裝到目前 Windows 帳戶。配套的自解壓安裝 EXE 會在自動解壓後直接執行安裝流程。

App 安裝後，前往「設定 → AI 帳號與 API 連線」，在官方 API 主控台建立 API Key，再新增並切換帳號。金鑰使用 Windows 使用者加密保存；一般 Claude.ai / ChatGPT 網站免費帳號不能直接供 App 呼叫；Gemini 可用一般 Google 帳號至 AI Studio 建立 API Key，部分模型有受限制的免費 API 層。API 額度不足時故事會停在原處，可切換至符合供應商條款且你有權使用的連線後重試。切換 AI 帳號或模型會沿用目前故事存檔及未完成回合；只有切換存檔才會改變故事。

若要使用網頁版而非 API Key，進入設定選擇「網頁版輔助模式」。程式會將遊戲縮至左側並保持最前方，右側顯示系統瀏覽器的官方網站。每回合程式會複製角色人格、故事記憶摘要和最近 8 則對話的純文字提示詞；請在網站貼上並送出，完成後選取／複製回覆，再到遊戲回覆框按 Ctrl+V。有效 JSON 貼入後會自動延續原存檔。支援 ChatGPT、Claude、Gemini、DeepSeek、Grok、Qwen、Mistral、Copilot、Perplexity、Meta AI、Kimi、Z.ai。登入與網站操作由使用者完成；App 不讀取網站密碼、Cookie、Token、截圖或網頁輸出。若需全自動並留在遊戲裡，請設定官方 API Key。
