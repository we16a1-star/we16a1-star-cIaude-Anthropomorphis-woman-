@echo off
setlocal EnableExtensions
set "AUTO_INSTALL_SFX=1"
set "PAYLOAD=%~dp0payload.zip"
set "EXTRACT_ROOT=%TEMP%\ClaudeNovelInstall_%RANDOM%_%RANDOM%_%RANDOM%"
if not exist "%PAYLOAD%" goto fail_payload
mkdir "%EXTRACT_ROOT%" 2>nul
if errorlevel 1 goto fail_folder
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Expand-Archive -LiteralPath $env:PAYLOAD -DestinationPath $env:EXTRACT_ROOT -Force"
if errorlevel 1 goto fail_extract
set "BUILD_SCRIPT=%EXTRACT_ROOT%\app\BUILD-WINDOWS11-AUTO.bat"
if not exist "%BUILD_SCRIPT%" goto fail_launcher
call "%BUILD_SCRIPT%"
set "INSTALL_RC=%ERRORLEVEL%"
if not "%INSTALL_RC%"=="0" goto fail_install
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Remove-Item -LiteralPath $env:EXTRACT_ROOT -Recurse -Force"
echo.
echo cIoudo娘 Windows 11 電腦版已安裝。
echo 可從桌面或開始功能表開啟。
exit /b 0

:fail_payload
echo [錯誤] 自解壓套件中找不到 payload.zip.
goto fail
:fail_folder
echo [錯誤] 無法建立臨時解壓資料夾.
goto fail
:fail_extract
echo [錯誤] 自動解壓失敗.
goto fail
:fail_launcher
echo [錯誤] 解壓內容中找不到一鍵安裝啟動檔.
goto fail
:fail_install
echo [錯誤] 安裝流程失敗；解壓內容保留在：
echo %EXTRACT_ROOT%
goto fail
:fail
echo.
if /I not "%AUTO_INSTALL_SFX%"=="1" pause
exit /b 1
