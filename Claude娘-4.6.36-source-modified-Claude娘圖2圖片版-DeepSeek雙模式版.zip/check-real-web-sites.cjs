// r10（2026-10-19）：品牌字串統一「Claude娘」；同 12娘 同步版。
// 真實官網相容性檢查（web automation real-site check）——全部 12 家 AI 官網掃描版
// 目的：驗證 App 的自動化腳本（ai-web-flow.cjs）在「真實官網」上也能正常運作——
//       假頁面測試（verify-web-auto.cjs）驗證流程；本檢查驗證真實版面，並涵蓋 App 支援的
//       全部 12 個 AI 官網（主流模型都要能用）。
//
// 流程：
//   1. 用隔離的 user-data-dir 啟動「已安裝版」App（完全不碰真實存檔與真實自動化瀏覽器設定檔）。
//   2. 設定：網頁模式＋外部瀏覽器＋ChatGPT，開始故事 → App 自己啟動「自動化專用」瀏覽器。
//   3. 共用同一個分頁，依序導覽到 12 個官網，對每一家：
//      - 記錄現況：輸入框（面積最大優先）、送出鈕、複製鈕、停止鈕、登入牆、常見類名樣本。
//      - 執行探測腳本、複製鈕腳本；有輸入框就再執行填入腳本並看填入後的變化。
//      - 「找得到送出鈕嗎」用乾跑（只找不點）模擬送出腳本的邏輯，避免在真站真的送出。
//   4. 收尾：關閉 App 與自動化瀏覽器（只關測試用的行程）。
//
// 用法：node check-real-web-sites.cjs ["已安裝 exe 路徑"] ["app 資料夾路徑"]
//   （需要網路；登出狀態下不會真的發出訊息。預設找已安裝版 %LOCALAPPDATA%\Programs\claude-novel-windows11；
//     app 資料夾預設為本檔旁邊的 app\。）
const { spawn, spawnSync } = require('node:child_process');
const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');

const arg = index => String(process.argv[index] || '').trim();
const appExe = arg(2) || path.join(process.env.LOCALAPPDATA || '', 'Programs', 'claude-novel-windows11', 'Claude娘 - Windows 11 電腦版.exe');
const appDir = arg(3) || path.join(__dirname, 'app');
const flow = require(path.join(appDir, 'ai-web-flow.cjs'));
const userDataDir = path.join(os.tmpdir(), 'opencode', 'cioudo-webauto-real', 'userdata');
const port = 9459;
const automationPort = 4462;
const endpoint = `http://127.0.0.1:${port}`;
const automationEndpoint = `http://127.0.0.1:${automationPort}`;
const testPrompt = '（相容性檢查，請忽略）如果你看到這行文字，回覆「OK」兩個字就好。';

// 與 app\electron-main.cjs 的 AI_WEBSITE_URLS 相同（改版時兩邊一起更新）。
const PROVIDERS = [
  ['openai', 'ChatGPT', 'https://chatgpt.com/auth/login'],
  ['anthropic', 'Claude', 'https://claude.ai/login'],
  ['gemini', 'Gemini', 'https://gemini.google.com/app'],
  ['deepseek', 'DeepSeek', 'https://chat.deepseek.com/'],
  ['grok', 'Grok', 'https://grok.com/'],
  ['qwen', 'Qwen', 'https://chat.qwen.ai/'],
  ['mistral', 'Mistral', 'https://chat.mistral.ai/chat'],
  ['copilot', 'Copilot', 'https://copilot.microsoft.com/'],
  ['perplexity', 'Perplexity', 'https://www.perplexity.ai/'],
  ['meta', 'Meta AI', 'https://www.meta.ai/'],
  ['kimi', 'Kimi', 'https://www.kimi.com/'],
  ['glm', 'Z.ai (GLM)', 'https://chat.z.ai/']
];

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const get = url => new Promise((resolve, reject) => {
  http.get(url, res => { let data = ''; res.on('data', c => data += c); res.on('end', () => { try { resolve(JSON.parse(data)); } catch (e) { reject(e); } }); }).on('error', reject);
});
async function findTargets(base) { try { return await get(base + '/json/list'); } catch { return []; } }
async function waitForTarget(base, predicate, label, attempts = 120) {
  for (let i = 0; i < attempts; i += 1) {
    const list = await findTargets(base);
    const hit = list.find(predicate);
    if (hit && hit.webSocketDebuggerUrl) return hit;
    await sleep(1000);
  }
  throw new Error('等不到目標：' + label);
}
function connect(target, timeoutMs = 15000) {
  return new Promise((resolve, reject) => {
    const socket = new WebSocket(target.webSocketDebuggerUrl);
    let nextId = 1;
    const waiting = new Map();
    const openTimer = setTimeout(() => reject(new Error('連線目標逾時：' + String(target.url).slice(0, 60))), timeoutMs);
    socket.onmessage = event => {
      const message = JSON.parse(typeof event.data === 'string' ? event.data : String(event.data));
      if (message.method === 'Page.javascriptDialogOpening') {
        socket.send(JSON.stringify({ id: nextId++, method: 'Page.handleJavaScriptDialog', params: { accept: true } }));
        return;
      }
      const pending = waiting.get(message.id);
      if (!pending) return;
      waiting.delete(message.id);
      pending(message);
    };
    socket.onerror = error => { clearTimeout(openTimer); reject(new Error('WebSocket 錯誤：' + error.message)); };
    socket.onopen = () => {
      clearTimeout(openTimer);
      resolve({
        send(method, params = {}) {
          const id = nextId++;
          socket.send(JSON.stringify({ id, method, params }));
          return new Promise((resolveCall, rejectCall) => {
            waiting.set(id, message => message.error ? rejectCall(new Error(method + '：' + JSON.stringify(message.error))) : resolveCall(message.result));
            setTimeout(() => { waiting.delete(id); rejectCall(new Error(method + ' 逾時')); }, 30000);
          });
        },
        close() { socket.close(); }
      });
    };
  });
}
async function evaluate(client, expression, awaitPromise = false) {
  const result = await client.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise });
  if (result.exceptionDetails) throw new Error('頁面例外：' + JSON.stringify(result.exceptionDetails.exception?.description || result.exceptionDetails.text).slice(0, 300));
  return result.result.value;
}
const info = (label, detail) => console.log('[資訊] ' + label + (detail === undefined ? '' : ' → ' + JSON.stringify(detail).slice(0, 400)));
const line = (ok, label, detail) => console.log((ok ? '[OK]   ' : '[注意] ') + label + (detail === undefined ? '' : ' → ' + JSON.stringify(detail).slice(0, 400)));

// 一次抓齊「這家官網現在有什麼」：輸入框、送出鈕、複製鈕、停止鈕、登入牆、常見類名樣本。
const sweepSnapshot = `(() => {
  const vis = e => !!(e && e.getClientRects().length && getComputedStyle(e).display !== 'none' && getComputedStyle(e).visibility !== 'hidden');
  const label = e => String(e.getAttribute('aria-label') || e.getAttribute('title') || e.getAttribute('data-testid') || (e.innerText || '').trim()).replace(/\\s+/g, ' ').slice(0, 40);
  const editors = [...document.querySelectorAll('textarea,[contenteditable="true"],[role="textbox"]')].filter(vis);
  editors.sort((a, b) => { const ar = a.getBoundingClientRect(), br = b.getBoundingClientRect(); return br.width * br.height - ar.width * ar.height; });
  const top = editors[0] || null;
  const buttons = [...document.querySelectorAll('button,[role="button"],input[type="submit"]')].filter(vis);
  const send = buttons.find(e => { const l = label(e); return /(send|submit|送出|傳送|发送|送信)/i.test(l) && !/(stop|停止|中止|voice|mic|語音|attach|附件|upload|上傳|file|image|圖片|model|模型|new chat|新對話)/i.test(l); });
  const copies = buttons.filter(e => /^(copy|複製|コピー|拷贝|复制)/i.test(label(e))).map(label).slice(0, 4);
  const stops = buttons.filter(e => /(^|[^a-z])(stop|stop generating|stop streaming|停止|停止生成|中止)([^a-z]|$)/i.test(label(e))).map(label).slice(0, 4);
  const iframes = [...document.querySelectorAll('iframe')].slice(0, 4).map(f => String(f.src || '').slice(0, 60));
  let shadowEditors = 0;
  for (const host of document.querySelectorAll('*')) { if (host.shadowRoot) shadowEditors += host.shadowRoot.querySelectorAll('textarea,[contenteditable="true"],[role="textbox"]').length; if (shadowEditors > 6) break; }
  const classes = {};
  for (const key of ['markdown', 'message', 'response', 'assistant', 'answer', 'prose', 'bubble']) {
    const hits = [...document.querySelectorAll('[class]')].filter(e => String(e.className || '').toLowerCase().includes(key));
    classes[key] = { n: hits.length, samples: hits.slice(-2).map(e => (e.tagName.toLowerCase() + '.' + String(e.className).replace(/\\s+/g, '.').slice(0, 70))) };
  }
  return {
    url: location.href,
    title: document.title.slice(0, 50),
    loginWall: /(\\/login|\\/auth|sign[-_]?in)/i.test(location.href),
    editors: editors.length,
    editorInfo: top ? { tag: top.tagName.toLowerCase(), cls: String(top.className).slice(0, 40), preview: String(('value' in top) ? top.value : (top.innerText || top.textContent) || '').replace(/\\s+/g, ' ').slice(0, 60) } : null,
    send: send ? { label: label(send), disabled: !!(send.disabled || send.getAttribute('aria-disabled') === 'true') } : null,
    copies, stops, iframes, shadowEditors, classes
  };
})()`;

// 乾跑「送出腳本怎麼找送出鈕」：只找不點，避免在真站真的送出。
const drySendFinder = `(() => {
  const visible = e => !!(e && e.getClientRects().length && getComputedStyle(e).visibility !== 'hidden' && getComputedStyle(e).display !== 'none');
  const label = e => String(e?.getAttribute?.('aria-label') || e?.getAttribute?.('title') || e?.getAttribute?.('data-testid') || e?.innerText || e?.textContent || '').replace(/\\s+/g, ' ').trim();
  const unavailable = e => !!(e.disabled || e.getAttribute('aria-disabled') === 'true');
  const sendWords = /${flow.SITE_HINTS.sendWords}/i;
  const blockWords = /${flow.SITE_HINTS.sendBlockWords}/i;
  const editors = [...document.querySelectorAll(${JSON.stringify(flow.SITE_HINTS.editorSelectors)})].filter(e => visible(e) && !e.disabled && !e.readOnly && e.tagName.toLowerCase() !== 'input');
  editors.sort((a, b) => { const ar = a.getBoundingClientRect(), br = b.getBoundingClientRect(); return br.width * br.height - ar.width * ar.height; });
  const editor = editors[0];
  if (!editor) return { found: false, reason: 'no-editor' };
  const pick = scope => [...scope.querySelectorAll(${JSON.stringify(flow.SITE_HINTS.buttonSelectors)})]
    .filter(e => visible(e) && !unavailable(e))
    .filter(e => { const l = label(e); return l.length > 0 && l.length < 60 && sendWords.test(l) && !blockWords.test(l); });
  let target = null, via = '';
  let scope = editor;
  for (let depth = 0; depth < 8 && scope && !target; depth += 1, scope = scope.parentElement) {
    const found = pick(scope);
    if (found.length) { target = found[found.length - 1]; via = 'editor+ancestor'; break; }
  }
  if (!target) {
    const strict = [...document.querySelectorAll(${JSON.stringify(flow.SITE_HINTS.strictSendSelectors)})].filter(e => visible(e) && !unavailable(e));
    if (strict.length) { target = strict[strict.length - 1]; via = 'strict'; }
  }
  return target ? { found: true, via, label: label(target), disabled: unavailable(target) } : { found: false, reason: 'no-send-button' };
})()`;

let appProcess = null;
const clients = [];
async function shutdown() {
  for (const client of clients.splice(0)) { try { client.close(); } catch {} }
  if (!appProcess) return;
  const pid = appProcess.pid;
  appProcess = null;
  try { spawnSync('taskkill', ['/F', '/T', '/PID', String(pid)], { stdio: 'ignore' }); } catch {}
  spawnSync('powershell', ['-NoProfile', '-Command',
    "Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('chrome.exe','msedge.exe') -and $_.CommandLine -and ($_.CommandLine -like '*web-automation-browser*' -or $_.CommandLine -like '*cioudo-webauto-real*') } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"
  ], { stdio: 'ignore' });
  await sleep(800);
}

async function sweepProvider(extClient, key, name, url) {
  console.log('');
  console.log('──────── ' + name + '（' + url + '）────────');
  try {
    await extClient.send('Page.navigate', { url });
  } catch (error) {
    console.log('[注意] 導覽失敗：' + error.message);
    return { key, name, error: 'navigate: ' + error.message };
  }
  await sleep(2500);
  for (let i = 0; i < 10; i += 1) {
    try {
      const state = await evaluate(extClient, '(()=>({ready:document.readyState,url:location.href}))()');
      if (/interactive|complete/.test(String(state.ready))) break;
    } catch {}
    await sleep(1500);
  }
  await sleep(2500);
  // SPA 官網（Grok／Perplexity）的輸入框比頁面載入晚一步：等它出現再快照（最多約 9 秒）。
  for (let i = 0; i < 6; i += 1) {
    const ready = await evaluate(extClient, `document.querySelectorAll('textarea,[contenteditable="true"],[role="textbox"]').length`);
    if (ready > 0) break;
    await sleep(1500);
  }
  const snap = await evaluate(extClient, sweepSnapshot);
  info(name + ' 現況', { url: snap.url, title: snap.title, loginWall: snap.loginWall, editors: snap.editors, editor: snap.editorInfo, send: snap.send, copies: snap.copies, stops: snap.stops });
  info(name + ' 類名樣本', snap.classes);
  let probe = null, copy = null, fill = null, after = null, dry = null;
  try { probe = await evaluate(extClient, flow.buildReplyProbeScript()); info(name + ' 探測腳本', probe); } catch (e) { console.log('[注意] 探測腳本例外：' + e.message); }
  try { copy = await evaluate(extClient, flow.buildCopyClickScript()); info(name + ' 複製鈕腳本', copy); } catch (e) { console.log('[注意] 複製鈕腳本例外：' + e.message); }
  if (snap.editors > 0) {
    try {
      fill = await evaluate(extClient, flow.buildFillScript(testPrompt), true);
      info(name + ' 填入腳本', fill);
      after = await evaluate(extClient, sweepSnapshot);
      info(name + ' 填入後', { editor: after.editorInfo, send: after.send });
      line(Boolean(fill && fill.ok), name + '：填入腳本回報成功', fill && { verified: fill.verified });
      line(Boolean(after.editorInfo && String(after.editorInfo.preview).includes('相容性檢查')), name + '：文字真的進到輸入框', after.editorInfo);
    } catch (e) { console.log('[注意] 填入腳本例外：' + e.message); }
    try { dry = await evaluate(extClient, drySendFinder); info(name + ' 送出鈕乾跑（只找不點）', dry); } catch (e) { console.log('[注意] 乾跑例外：' + e.message); }
  } else {
    line(snap.loginWall, name + '：沒有輸入框（' + (snap.loginWall ? '登入牆，屬預期' : '請人工確認版面') + '）', snap.url);
  }
  return { key, name, url: snap.url, loginWall: snap.loginWall, editors: snap.editors, sendFound: Boolean(dry && dry.found) || Boolean(snap.send), fillOk: Boolean(fill && fill.ok), fillVerified: Boolean(fill && fill.verified), probe: probe ? { generating: probe.generating, count: probe.count, textLen: String(probe.text || '').length } : null, copyFound: Boolean(copy && copy.clicked) };
}

async function main() {
  console.log('== 真實官網相容性檢查：全部 12 家（登出狀態、隔離設定檔） ==');
  fs.rmSync(userDataDir, { recursive: true, force: true });
  appProcess = spawn(appExe, [`--user-data-dir=${userDataDir}`, `--remote-debugging-port=${port}`], { stdio: 'ignore', detached: false });
  const appTarget = await waitForTarget(endpoint, t => t.type === 'page' && String(t.url).startsWith('file:'), 'App 主視窗');
  const appClient = await connect(appTarget);
  clients.push(appClient);
  await appClient.send('Page.enable');
  await appClient.send('Runtime.enable');

  await evaluate(appClient, `document.getElementById('enableWebAiBtn').click()`);
  await sleep(800);
  await evaluate(appClient, `(() => { const s = document.getElementById('webAiProvider'); s.value = 'openai'; s.dispatchEvent(new Event('change')); })()`);
  await evaluate(appClient, `(() => { const s = document.getElementById('webBrowserModeSelect'); s.value = 'external'; s.dispatchEvent(new Event('change')); })()`);
  await sleep(500);
  info('已設定：網頁模式／外部瀏覽器／ChatGPT；自動化預設開啟', { auto: await evaluate(appClient, `localStorage.getItem('claude_novel_web_auto_flow_v1')`) });

  await evaluate(appClient, `document.getElementById('startStoryBtn').click()`);
  const extTab = await waitForTarget(automationEndpoint, t => t.type === 'page' && String(t.url).includes('chatgpt.com'), '自動化瀏覽器的官網分頁', 150);
  info('自動化瀏覽器已開啟官網分頁', String(extTab.url).slice(0, 80));
  const extClient = await connect(await waitForTarget(automationEndpoint, t => t.type === 'page' && String(t.url).includes('chatgpt.com'), '分頁（第二次）', 5));
  clients.push(extClient);
  await extClient.send('Page.enable');
  await extClient.send('Runtime.enable');

  const rows = [];
  for (const [key, name, url] of PROVIDERS) {
    try { rows.push(await sweepProvider(extClient, key, name, url)); }
    catch (error) { console.log('[注意] ' + name + ' 檢查中止：' + error.message); rows.push({ key, name, error: error.message }); }
  }

  console.log('');
  console.log('======== 總結（登出狀態）========');
  for (const row of rows) {
    if (row.error) { console.log('[注意] ' + row.name + '：' + row.error); continue; }
    console.log(`${row.editors > 0 ? '[有輸入框]' : '[無輸入框]'} ${row.name.padEnd(9, ' ')} 送出鈕=${row.sendFound ? '有' : '無'}  填入=${row.fillOk ? (row.fillVerified ? '成功(已驗證)' : '成功(未驗證)') : '未測/失敗'}  探測count=${row.probe ? row.probe.count : '-'}（文字${row.probe ? row.probe.textLen : '-'}字）  複製鈕=${row.copyFound ? '有' : '無'}  ${row.loginWall ? '（登入牆）' : ''}`);
  }
  console.log('');
  console.log('（收尾：關閉 App 與自動化瀏覽器）');
  await shutdown();
  console.log('檢查完成');
}

main().catch(async error => {
  console.error('[中止] ' + (error && error.message));
  process.exitCode = 1;
  await shutdown();
});
