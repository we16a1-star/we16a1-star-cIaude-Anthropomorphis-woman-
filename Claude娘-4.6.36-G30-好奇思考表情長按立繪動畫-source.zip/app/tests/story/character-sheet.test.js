// 追加六：角色頁人設欄與角色卡編輯（標語／名言／外觀欄位／介紹段落）的閘門。
// 這裡釘住三件事：預設資料與預設人設同步（不再出現舊版文字）、存檔正規化、UI 與管線接線。
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { DEFAULT_CHARACTER_PROFILE, DEFAULT_CHARACTER_SHEET, normalizeCharacterSheet } from '../../www/character-profile.js';

const source = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');
const html = readFileSync(new URL('../../www/index.html', import.meta.url), 'utf8');
const css = readFileSync(new URL('../../www/style.css', import.meta.url), 'utf8');

const profileBody = title => {
  const match = DEFAULT_CHARACTER_PROFILE.match(new RegExp(`【${title}】\\n([^\\n]*)`));
  return match ? match[1] : '';
};

test('character sheet defaults mirror the current default persona (no stale text)', () => {
  assert.equal(DEFAULT_CHARACTER_SHEET.stats.length, 6, 'six appearance fields');
  assert.deepEqual(DEFAULT_CHARACTER_SHEET.stats.map(item => item.label), ['髮色', '瞳色', '服裝', '髮飾', '鞋子', '隨身物']);
  assert.deepEqual(DEFAULT_CHARACTER_SHEET.sections.map(item => item.title),
    ['個性', '信念', '喜歡', '不喜歡', '小習慣', '戀愛觀', '會讓她心動的瞬間', '給在乎之人的信物']);
  for (const section of DEFAULT_CHARACTER_SHEET.sections) {
    assert.equal(section.body, profileBody(section.title).trim(), `${section.title} 的預設段落＝預設人設的同一段（單一來源）`);
    assert.ok(section.body.length > 0, `${section.title} has content`);
  }
  assert.ok(DEFAULT_CHARACTER_SHEET.sections[0].body.includes('表面冷靜、少話；內在害羞、溫柔、認真'), '個性段落是現行版本，不是舊版文字');
  assert.ok(DEFAULT_CHARACTER_PROFILE.includes('高冷'), '預設人設維持高冷第一印象');
  assert.ok(DEFAULT_CHARACTER_SHEET.sections[0].body.includes('冷靜的外表下'), '角色卡個性段落跟隨預設人設的反差');
  assert.match(DEFAULT_CHARACTER_SHEET.quote, /把書架重新排了三遍/);
  assert.ok(DEFAULT_CHARACTER_SHEET.tagline.length > 0 && DEFAULT_CHARACTER_SHEET.quote.length > 0);
});

test('normalizeCharacterSheet rejects non-objects, trims, caps and drops empty entries', () => {
  for (const bad of [null, undefined, '', '文字', [], 12, true]) {
    assert.equal(normalizeCharacterSheet(bad), null, `non-object ${JSON.stringify(bad)} falls back to the default card`);
  }
  const sheet = normalizeCharacterSheet({
    tagline: '  新標語  ' + 'x'.repeat(200),
    quote: ' 名言 ',
    stats: [
      { label: ' 瞳色 ', value: ' 紅 ' },
      { label: '', value: '' },
      { label: null, value: '只有值' },
      ...Array.from({ length: 10 }, (_, index) => ({ label: 'L' + index, value: 'V' + index }))
    ],
    sections: [
      { title: ' 段一 ', body: ' 內文 ' },
      { title: '', body: '' },
      ...Array.from({ length: 15 }, (_, index) => ({ title: 'T' + index, body: 'B' + index }))
    ]
  });
  assert.equal(sheet.tagline.length, 120, 'tagline capped at 120');
  assert.ok(sheet.tagline.startsWith('新標語'), 'tagline trimmed and kept');
  assert.equal(sheet.quote, '名言', 'quote trimmed');
  assert.equal(sheet.stats.length, 8, 'appearance fields capped at 8');
  assert.deepEqual(sheet.stats[0], { label: '瞳色', value: '紅' }, 'label and value trimmed');
  assert.ok(sheet.stats.some(item => item.value === '只有值'), 'value-only fields are kept');
  assert.ok(!sheet.stats.some(item => !item.label && !item.value), 'fully empty fields are dropped');
  assert.equal(sheet.sections.length, 12, 'sections capped at 12');
  assert.deepEqual(sheet.sections[0], { title: '段一', body: '內文' }, 'title and body trimmed');
  assert.ok(!sheet.sections.some(item => !item.title && !item.body), 'fully empty sections are dropped');
  const truncated = normalizeCharacterSheet({
    stats: [{ label: 'A'.repeat(50), value: 'B'.repeat(500) }],
    sections: [{ title: 'T'.repeat(60), body: 'S'.repeat(5000) }]
  });
  assert.equal(truncated.stats[0].label.length, 30);
  assert.equal(truncated.stats[0].value.length, 200);
  assert.equal(truncated.sections[0].title.length, 40);
  assert.equal(truncated.sections[0].body.length, 4000);
  assert.deepEqual(normalizeCharacterSheet({}), { tagline: '', quote: '', stats: [], sections: [] });
});

test('persona field and character card editor markup is in place', () => {
  for (const id of ['profileCharacterProfile', 'saveProfileProfileBtn', 'resetProfileProfileBtn',
    'characterSheet', 'sheetEditBtn', 'sheetEditDialog', 'sheetEditTagline', 'sheetEditQuote',
    'sheetEditStats', 'sheetAddStatBtn', 'sheetEditSections', 'sheetAddSectionBtn', 'sheetEditStatus',
    'sheetEditSaveBtn', 'sheetEditCancelBtn', 'sheetEditResetBtn']) {
    assert.ok(html.includes(`id="${id}"`), `index.html has #${id}`);
    assert.ok(source.includes(`$('${id}')`), `app.js uses #${id}`);
  }
  assert.ok(html.includes('aria-labelledby="sheetEditTitle"'), 'editor is a labelled dialog');
  assert.ok(!html.includes('圖書館「知識之塔」的管理者'), '角色卡預設文字改由 character-profile.js 提供（不再是寫死的 HTML）');
  assert.ok(!html.includes('class="stat-grid"'), '外觀欄位改由 renderCharacterSheet() 動態繪製');
  assert.match(source, /'<p class="sheet-credit">'\+esc\(uiText\('預設角色形象：此形象來自 B站ZipZipPipe；此形象使用 CC BY-NC-SA 4\.0 協議。'\)\)\+'<\/p>'/,
    '角色卡固定顯示形象來源與授權');
  assert.match(html, /<aside class="workshop-notice" role="note" aria-label="免責宣告">/, '創意工坊頁首顯示免責宣告');
  assert.ok(html.includes('代碼許可不自動涵蓋圖片、視頻、角色形象及商標'), '創意工坊說明程式碼許可不包含媒體與商標權利');
  assert.ok(!html.includes('本程式是免費開源，禁止商業使用'), '不顯示與專案 MIT 授權不一致的商業使用限制');
  assert.ok(!html.includes('製作人員名單'), '創意工坊不顯示製作人員名單');
  assert.match(css, /\.sheet-credit\{[^}]*border-top:1px solid var\(--line\)/, '形象授權樣式');
  assert.match(css, /\.workshop-notice\{[^}]*border-radius:12px/, '授權公告樣式');
});

test('character card and persona are persisted, synced and rendered through the save pipeline', () => {
  assert.match(source, /characterSheet: null,/, 'each new save starts with its own default card');
  assert.match(source, /characterSheet: normalizeCharacterSheet\(rawState\.characterSheet\)/, 'loading a slot normalizes the card');
  assert.match(source, /characterSheet: normalizeCharacterSheet\(source\.characterSheet\)/, 'serializing a save normalizes the card');
  assert.match(source, /storyTemplate:state\.storyTemplate,characterSheet:state\.characterSheet,/, 'restarting keeps a customized card');
  assert.match(source, /characterSheet:state\.characterSheet,difficulty:state\.difficulty,temperature:state\.temperature,/,
    'restarting keeps the chosen difficulty (same slot, new story)');
  assert.match(source, /function render\(\) \{\s*renderCharacterName\(\);\s*renderWorldSetting\(\);\s*renderProfileProfile\(\);\s*renderCharacterPortrait\(\);\s*renderCharacterSheet\(\);/,
    'render() repaints the persona field and the card');
  assert.match(source, /if\(b\.dataset\.tab==='profile'\)\{renderCharacterName\(\);renderWorldSetting\(\);renderProfileProfile\(\);renderCharacterSheet\(\);applyUiLanguage\(\);\}/,
    'opening the profile tab repaints everything editable (incl. language walk for the EN card)');
  assert.match(source, /const previous=state\.characterSheet,previousCards=state\.characterCards;[\s\S]*?if\(!save\(\)\)\{state\.characterSheet=previous;state\.characterCards=previousCards;render\(\);return;\}/,
    'a failed save rolls the in-memory card back');
  assert.match(source, /function renderProfileProfile\(\)\{[\s\S]*?profileCharacterProfile[\s\S]*?workshopCharacterProfile[\s\S]*?\}/,
    'the persona field syncs the profile page and the workshop');
  assert.match(source, /\$\('saveProfileProfileBtn'\)\.onclick=\(\)=>\{if\(!busy\)saveProfileProfile\(\);\};/);
  assert.match(source, /\$\('resetProfileProfileBtn'\)\.onclick=\(\)=>\{if\(!busy\)resetProfileProfile\(\);\};/);
  assert.match(source, /function resetProfileProfile\(\)\{\s*state\.characterProfile=DEFAULT_CHARACTER_PROFILE;/);
});

test('character card editor: row builders, add caps and delete delegation are wired', () => {
  for (const fn of ['renderCharacterSheet', 'sheetStatRows', 'sheetSectionRows', 'makeSheetStatRow', 'makeSheetSectionRow',
    'fillSheetEditDialog', 'openSheetEditDialog', 'closeSheetEditDialog', 'saveSheetEditDialog', 'resetSheetEditDialog',
    'addSheetStatRow', 'addSheetSectionRow', 'removeSheetRowFromEvent']) {
    assert.ok(source.includes(`function ${fn}(`), `app.js defines ${fn}`);
  }
  assert.match(source, /if\(sheetStatRows\(\)\.length>=8\)\{/, 'appearance fields stop at 8');
  assert.match(source, /if\(sheetSectionRows\(\)\.length>=12\)\{/, 'about sections stop at 12');
  assert.match(source, /\$\('sheetEditStats'\)\.addEventListener\('click',removeSheetRowFromEvent\);/, 'stat rows delete via delegation');
  assert.match(source, /\$\('sheetEditSections'\)\.addEventListener\('click',removeSheetRowFromEvent\);/, 'section rows delete via delegation');
  assert.match(source, /\$\('sheetEditResetBtn'\)\.onclick=resetSheetEditDialog;/, 'reset button is bound');
});

test('copy integration: cold-outside librarian persona is the single source for the card', () => {
  for (const marker of ['【說話方式】', '【信念】', '「人家」', '才、才不是', '這一頁我還沒讀過', '不隱瞞自己是 AI 扮演的角色', '恰好 7 個']) {
    assert.ok(DEFAULT_CHARACTER_PROFILE.includes(marker), `DEFAULT_CHARACTER_PROFILE 含 ${marker}`);
  }
  assert.ok(DEFAULT_CHARACTER_PROFILE.includes('表面冷靜、少話；內在害羞、溫柔、認真'), '新版反差人設入稿');
  assert.ok(DEFAULT_CHARACTER_SHEET.sections[0].body.includes('表面冷靜、少話'), '角色卡個性段自動跟隨新文案');
  assert.ok(!DEFAULT_CHARACTER_SHEET.sections[0].body.includes('四分傲、六分嬌'), '角色卡不再是舊版傲嬌文案');
  assert.ok(!DEFAULT_CHARACTER_SHEET.sections[0].body.includes('嘴上逞強、偶爾否認在意'), '角色卡不再是舊版文字');
  assert.doesNotMatch(DEFAULT_CHARACTER_PROFILE, /顏文字|▽/, '批5 Ａ4：預設人設顏文字去除');
});
