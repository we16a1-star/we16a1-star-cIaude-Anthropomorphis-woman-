// 追加八：故事時間（第 N 天・早上/中午/晚上）與好感度階段（疏離/熟悉/在意/親密）的閘門。
// 批4（E10）：故事時間新增「綁定現實時間」第三態——mode 遷移、real 映射邊界、real 不推進、
// 新故事三選一與 API 契約（timeAdvance 句只在 story 模式出現）。
// 釘住四件事：純模組邊界、存檔欄位與舊存檔遷移、app.js 接線（提示詞只在啟用時加時間）、
// server.js 的 API 契約（欄位列表句永不改，timeAdvance 只在 story 模式以額外句子出現）。
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import {
  STORY_SLOTS, AFFECTION_STAGES, normalizeStoryClock, advanceStoryClock,
  realSlotIndexAt, realDayNumberAt, realStoryClock,
  stageIndexOfAffection, affectionStageKeyOf, stageByKey, stageIndexByKey,
  normalizeMilestoneKey, storySlotName, storyClockLabel
} from '../../www/story-clock.js';

const source = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');
const html = readFileSync(new URL('../../www/index.html', import.meta.url), 'utf8');
const serverSource = readFileSync(new URL('../../server/server.js', import.meta.url), 'utf8');

test('storyClock 正規化：舊存檔遷移（enabled→mode）與壞資料一律安全', () => {
  assert.deepEqual(normalizeStoryClock(undefined), { mode: 'off', enabled: false, day: 1, slot: 0, anchor: 0 });
  assert.deepEqual(normalizeStoryClock(null), { mode: 'off', enabled: false, day: 1, slot: 0, anchor: 0 });
  assert.deepEqual(normalizeStoryClock({}), { mode: 'off', enabled: false, day: 1, slot: 0, anchor: 0 });
  assert.deepEqual(normalizeStoryClock({ enabled: 'yes', day: '3' }), { mode: 'off', enabled: false, day: 3, slot: 0, anchor: 0 });
  assert.deepEqual(normalizeStoryClock({ enabled: true, day: -5, slot: 9 }), { mode: 'story', enabled: true, day: 1, slot: 2, anchor: 0 }, '舊存檔 enabled:true→story');
  assert.deepEqual(normalizeStoryClock({ enabled: true, day: 12.6, slot: 1.4 }), { mode: 'story', enabled: true, day: 13, slot: 1, anchor: 0 });
  assert.deepEqual(normalizeStoryClock({ mode: 'real', day: 2, slot: 1, anchor: 123.6 }), { mode: 'real', enabled: true, day: 2, slot: 1, anchor: 124 }, 'real＝mode 制霸、anchor 正規化');
  assert.deepEqual(normalizeStoryClock({ mode: 'bogus', enabled: true }), { mode: 'story', enabled: true, day: 1, slot: 0, anchor: 0 }, '壞 mode 回退至 enabled');
  assert.deepEqual(normalizeStoryClock({ mode: 'bogus', enabled: false }), { mode: 'off', enabled: false, day: 1, slot: 0, anchor: 0 });
  assert.equal(normalizeStoryClock({ mode: 'real', anchor: -9 }).anchor, 0, '負 anchor 視為未設');
});

test('advanceStoryClock：story 推進（晚上→隔天早上、限 0～6、缺省 1）；real／off 一律不推進', () => {
  assert.deepEqual(advanceStoryClock({ enabled: true, day: 3, slot: 2 }), { mode: 'story', enabled: true, day: 4, slot: 0, anchor: 0 });
  assert.deepEqual(advanceStoryClock({ enabled: true, day: 1, slot: 0 }, 0), { mode: 'story', enabled: true, day: 1, slot: 0, anchor: 0 });
  assert.deepEqual(advanceStoryClock({ enabled: true, day: 1, slot: 0 }, 7), { mode: 'story', enabled: true, day: 3, slot: 0, anchor: 0 });
  assert.deepEqual(advanceStoryClock({ enabled: true, day: 1, slot: 1 }, 'x'), { mode: 'story', enabled: true, day: 1, slot: 2, anchor: 0 });
  assert.deepEqual(advanceStoryClock({ enabled: true, day: 1, slot: 0 }, '2.4'), { mode: 'story', enabled: true, day: 1, slot: 2, anchor: 0 });
  assert.deepEqual(advanceStoryClock({ mode: 'real', day: 2, slot: 1, anchor: 999 }, 6), { mode: 'real', enabled: true, day: 2, slot: 1, anchor: 999 }, 'real：timeAdvance 一律忽略');
  assert.deepEqual(advanceStoryClock({ mode: 'off', day: 5, slot: 2 }, 3), { mode: 'off', enabled: false, day: 5, slot: 2, anchor: 0 }, 'off：不推進');
});

test('real 模式映射：時段邊界（05／12／18）與換日 +1（跨現實日界線）', () => {
  const at = (day, hour, minute = 0) => new Date(2026, 9, day, hour, minute, 0); // 2026-10（月＝9）
  assert.equal(realSlotIndexAt(at(18, 4, 59)), 2, '04:59＝晚上');
  assert.equal(realSlotIndexAt(at(18, 5, 0)), 0, '05:00＝早上');
  assert.equal(realSlotIndexAt(at(18, 11, 59)), 0, '11:59＝早上');
  assert.equal(realSlotIndexAt(at(18, 12, 0)), 1, '12:00＝中午');
  assert.equal(realSlotIndexAt(at(18, 17, 59)), 1, '17:59＝中午');
  assert.equal(realSlotIndexAt(at(18, 18, 0)), 2, '18:00＝晚上');
  assert.equal(realSlotIndexAt(at(19, 0, 0)), 2, '00:00＝晚上');
  const anchor = at(18, 23, 30).getTime();
  assert.equal(realDayNumberAt(anchor, at(18, 23, 59)), 1, '同日＝第 1 天');
  assert.equal(realDayNumberAt(anchor, at(19, 0, 1)), 2, '跨午夜＝第 2 天');
  assert.equal(realDayNumberAt(anchor, at(21, 10, 0)), 4, '之後每跨一個現實日界線 +1');
  assert.equal(realDayNumberAt(anchor, at(17, 10, 0)), 1, '時鐘回退不低於第 1 天');
  const live = realStoryClock({ mode: 'real', day: 1, slot: 0, anchor }, at(19, 6, 0));
  assert.deepEqual(live, { mode: 'real', enabled: true, day: 2, slot: 0, anchor }, 'realStoryClock＝現實日數＋現時段');
  assert.deepEqual(realStoryClock({ mode: 'story', day: 5, slot: 1 }, at(19, 6, 0)), { mode: 'story', enabled: true, day: 5, slot: 1, anchor: 0 }, '非 real 原樣回傳');
});

test('好感度階段邊界：0–30 疏離、31–60 熟悉、61–85 在意、86–100 親密', () => {
  assert.equal(affectionStageKeyOf(0), 'distant');
  assert.equal(affectionStageKeyOf(30), 'distant');
  assert.equal(affectionStageKeyOf(31), 'familiar');
  assert.equal(affectionStageKeyOf(60), 'familiar');
  assert.equal(affectionStageKeyOf(61), 'caring');
  assert.equal(affectionStageKeyOf(85), 'caring');
  assert.equal(affectionStageKeyOf(86), 'intimate');
  assert.equal(affectionStageKeyOf(100), 'intimate');
  assert.equal(affectionStageKeyOf(NaN), 'familiar', '非數字視為預設 50');
  assert.equal(affectionStageKeyOf(999), 'intimate', '超過 100 收斂到親密');
  assert.equal(stageIndexOfAffection(86), 3);
  assert.equal(stageByKey('caring').zh, '在意');
  assert.equal(stageByKey('bogus'), null);
  assert.equal(stageIndexByKey('intimate'), 3);
  assert.equal(stageIndexByKey('bogus'), -1);
  assert.equal(AFFECTION_STAGES.length, 4);
});

test('時間與階段的顯示字串（中英；舊形狀 enabled 仍可讀）與里程碑鍵正規化', () => {
  assert.equal(storyClockLabel({ enabled: true, day: 3, slot: 2 }, 'zh'), '第 3 天・晚上');
  assert.equal(storyClockLabel({ enabled: true, day: 3, slot: 2 }, 'en'), 'Day 3 · Evening');
  assert.equal(storyClockLabel({ mode: 'real', day: 3, slot: 2, anchor: 1 }, 'zh'), '第 3 天・晚上');
  assert.equal(storySlotName(0, 'zh'), '早上');
  assert.equal(storySlotName(1, 'en'), 'Noon');
  assert.equal(storySlotName(2, 'zh'), '晚上');
  assert.equal(STORY_SLOTS.length, 3);
  assert.equal(normalizeMilestoneKey('caring'), 'caring');
  assert.equal(normalizeMilestoneKey(''), '');
  assert.equal(normalizeMilestoneKey('bogus'), '');
});

test('app.js 網頁提示詞：時間未啟用不加時段行；啟用才加（real＝現實同步句、story＝timeAdvance 規則）', () => {
  assert.match(source, /import \{ advanceStoryClock, affectionStageKeyOf, affectionStageOf, normalizeMilestoneKey, normalizeStoryClock, realSlotIndexAt, realStoryClock, stageByKey, stageIndexByKey, storyClockLabel \} from '\.\/story-clock\.js';/);
  assert.match(source, /const storyClock=realStoryClock\(state\.storyClock\);/, '批4：提示詞前重算（real 適用，非 real 等同 normalize）');
  assert.match(source, /const clockLines=storyClock\.enabled\?\[/, '時段行只在啟用時加入');
  assert.match(source, /storyClock\.mode==='real'/, 'real 走現實同步句');
  assert.ok(source.includes('與現實時間同步'), 'real 句＝與現實時間同步');
  assert.ok(source.includes('不需回報 "timeAdvance"'), 'real 句＝不需 timeAdvance');
  assert.match(source, /const milestoneLines=milestone\?specialEventPromptLines\('milestone',uiLanguage\):/, '里程碑行只在有待處理里程碑時加入');
  assert.match(source, /'好感：'\+state\.affection\+'\/100（關係階段：'\+stageNow\.zh\+'）'/);
  assert.match(source, /\.\.\.clockLines,/, '提示詞陣列帶入時段行');
  assert.match(source, /\.\.\.milestoneLines,/, '提示詞陣列帶入里程碑行');
  assert.ok(source.includes('只輸出JSON：narration、affectionDelta、choices、ending、endingText、memory、emotion'),
    '欄位列表句維持逐字不變（工具相容不變量）');
  assert.match(source, /const storyClockMode=normalizeStoryClock\(state\.storyClock\)\.mode;/, '修復提示以 mode 判定');
  assert.match(source, /結局狀態與記憶\$\{storyClockMode==='story'\?'、時間推進':''\}，不要重開故事/, '修復提示只在 story 保留時間推進');
});

test('app.js 回合套用：七選項檢查通過後才判定階段與時間（story 推進／real 依現實重算）', () => {
  assert.match(source, /const stageBefore=affectionStageKeyOf\(state\.affection\);\s*storyNoticeText='';\s*state\.pendingMilestone='';/);
  assert.match(source, /function handleAffectionStageChange\(beforeKey\)\{[\s\S]*?storyNoticeText=uiText\('關係升溫：好感度進入「'\+after\.zh\+'」階段。'\);[\s\S]*?state\.pendingMilestone=after\.key;/);
  assert.match(source, /storyNoticeText=uiText\('關係轉冷：好感度退回「'\+after\.zh\+'」階段。'\);/);
  assert.match(source, /handleAffectionStageChange\(stageBefore\);[\s\S]*?if \(clock\.mode==='story'\) state\.storyClock=advanceStoryClock\(clock,r\.timeAdvance\);\s*else if \(clock\.mode==='real'\) state\.storyClock=realStoryClock\(clock\);/);
  const throwIndex = source.indexOf("if(state.choices.length<7) throw new Error('AI 回傳的選項不足 7 個');");
  const noticeIndex = source.indexOf('handleAffectionStageChange(stageBefore);');
  const advanceIndex = source.indexOf("if (clock.mode==='story') state.storyClock=advanceStoryClock(clock,r.timeAdvance);");
  const realIndex = source.indexOf("else if (clock.mode==='real') state.storyClock=realStoryClock(clock);");
  assert.ok(throwIndex > 0 && noticeIndex > throwIndex && advanceIndex > noticeIndex && realIndex > advanceIndex,
    '時間推進／現實重算都在「選項不足即 throw」之後，失敗回合不會改動時間');
  assert.match(source, /const stageBeforeGift=affectionStageKeyOf\(state\.affection\);[\s\S]*?handleAffectionStageChange\(stageBeforeGift\);/, '送禮也判定階段（但不推進時間）');
});

test('儲存與解析：timeAdvance 清化、API 請求帶入 storyClock（real 依當下）與 pendingMilestone', () => {
  assert.match(source, /if\(Number\.isFinite\(advance\)\) result\.timeAdvance=Math\.max\(0,Math\.min\(6,Math\.round\(advance\)\)\); else delete result\.timeAdvance;/, '網頁回覆清化 timeAdvance');
  assert.match(source, /storyClock:realStoryClock\(state\.storyClock\),pendingMilestone:state\.pendingMilestone\|\|'',/, 'API 請求帶時間與里程碑');
  assert.match(serverSource, /const advance=Number\(j\.timeAdvance\); if\(Number\.isFinite\(advance\)\)j\.timeAdvance=Math\.max\(0,Math\.min\(6,Math\.round\(advance\)\)\); else delete j\.timeAdvance;/, 'API 回覆清化 timeAdvance');
});

test('存檔欄位：fresh／normalizeSlot／serializeState 都有 storyClock 與 pendingMilestone（舊存檔＝off）', () => {
  assert.match(source, /storyMemory: '',\s*storyEmotion: 'neutral',\s*storyClock: \{ mode: 'off', enabled: false, day: 1, slot: 0, anchor: 0 \},\s*pendingMilestone: ''/);
  assert.match(source, /storyClock: normalizeStoryClock\(rawState\.storyClock\),\s*pendingMilestone: normalizeMilestoneKey\(rawState\.pendingMilestone\),/);
  assert.match(source, /storyClock: normalizeStoryClock\(source\.storyClock\),\s*pendingMilestone: normalizeMilestoneKey\(source\.pendingMilestone\),/);
});

test('畫面接線：階段標籤、時間晶片、關係通知與新故事三選一（預設隨劇情推進）', () => {
  for (const id of ['affLabel', 'storyClockChip', 'storyNotice']) {
    assert.ok(html.includes(`id="${id}"`), `index.html has #${id}`);
    assert.ok(source.includes(`$('${id}')`), `app.js uses #${id}`);
  }
  assert.match(source, /\$\('affLabel'\)\.textContent = uiText\('好感度'\) \+ '・' \+ uiText\(affectionStageOf\(state\.affection\)\.zh\);/);
  assert.match(source, /const storyClockNow = realStoryClock\(state\.storyClock\);/, '晶片顯示前重算（real 適用）');
  assert.match(source, /\$\('storyClockChip'\)\.hidden = !storyClockNow\.enabled;/);
  assert.match(source, /\$\('storyNotice'\)\.hidden = !storyNoticeText;/);
  assert.match(source, /name="openingClockMode" id="openingClockOff" value="off"/, '三選一：不啟用');
  assert.match(source, /name="openingClockMode" id="openingClockStory" value="story" checked/, '三選一：隨劇情推進（預設）');
  assert.match(source, /name="openingClockMode" id="openingClockReal" value="real"/, '三選一：綁定現實時間');
  assert.match(source, /state\.storyClock=\{mode:openingClockMode,enabled:openingClockMode!=='off',day:1,slot:openingClockMode==='real'\?realSlotIndexAt\(new Date\(\)\):0,anchor:openingClockMode==='real'\?Date\.now\(\):0\};/, '開始故事時寫入模式與錨點');
  assert.match(source, /clockLabel: clock\.enabled \? storyClockLabel\(clock, uiLanguage\) : ''/, '存檔卡顯示天數與時段');
});

test('中英字典：階段、通知句與三選一字串都有英譯', () => {
  for (const key of [
    '疏離', '熟悉', '在意', '親密', '故事時間', '不啟用', '隨劇情推進', '綁定現實時間',
    '關係升溫：好感度進入「熟悉」階段。', '關係升溫：好感度進入「在意」階段。', '關係升溫：好感度進入「親密」階段。',
    '關係轉冷：好感度退回「疏離」階段。', '關係轉冷：好感度退回「熟悉」階段。', '關係轉冷：好感度退回「在意」階段。'
  ]) {
    assert.ok(source.includes(`'${key}':`), `UI_EN 缺少「${key}」`);
  }
  assert.match(source, /'「隨劇情推進」＝[^']*現實時刻[^']*': '[^']+'/, '三選一說明句有英譯');
});

test('server.js API 契約：off 不加時間句；story 加 timeAdvance 說明；real 加現實同步句（欄位列表句不變）', async () => {
  const { requestPrompt, requestSystemInstruction, parse } = await import('../../server/server.js');
  const base = { language: 'zh', affection: 62 };
  const off = requestPrompt({ ...base, storyClock: { enabled: false, day: 1, slot: 0 } });
  assert.ok(!off.includes('故事時間'), '未啟用時不加時間行');
  assert.ok(!off.includes('timeAdvance'), '未啟用時不提 timeAdvance');
  assert.ok(off.includes('關係階段：在意'), '關係階段永遠帶入提示詞');
  const on = requestPrompt({ ...base, storyClock: { enabled: true, day: 2, slot: 2 }, pendingMilestone: 'caring' });
  assert.ok(on.includes('故事時間：現在是 第 2 天・晚上'), 'story：帶入目前時間（舊存檔 enabled:true 遷移）');
  assert.ok(on.includes('關係里程碑'), '有待處理里程碑時帶入彈性提示');
  const real = requestPrompt({ ...base, storyClock: { mode: 'real', day: 1, slot: 0, anchor: Date.now() } });
  assert.ok(real.includes('故事時間：現在是'), 'real：帶入時間行（依現實重算）');
  assert.ok(real.includes('與現實時間同步'), 'real：語意＝與現實時間同步');
  assert.ok(!real.includes('可在 JSON 最外層加上 "timeAdvance"'), 'real：不教 timeAdvance');
  const sysOn = requestSystemInstruction({ language: 'zh', storyClock: { enabled: true } });
  assert.ok(sysOn.includes('timeAdvance'), 'story：輸出契約附帶 timeAdvance 說明');
  const sysReal = requestSystemInstruction({ language: 'zh', storyClock: { mode: 'real', anchor: Date.now() } });
  assert.ok(sysReal.includes('與現實時間同步'), 'real：輸出契約＝現實同步句');
  assert.ok(!sysReal.includes('可在 JSON 最外層加上 "timeAdvance"'), 'real：輸出契約不教 timeAdvance');
  const sysOff = requestSystemInstruction({ language: 'zh' });
  assert.ok(!sysOff.includes('timeAdvance'), '未啟用時輸出契約與現行相同');
  const reply = { narration: '故'.repeat(520), affectionDelta: 1, choices: ['一', '二', '三', '四', '五', '六', '七'], ending: false, endingText: null, memory: '記憶' };
  assert.ok(!('timeAdvance' in parse(JSON.stringify(reply))), '未回報時移除 timeAdvance');
  assert.equal(parse(JSON.stringify({ ...reply, timeAdvance: 3.6 })).timeAdvance, 4);
  assert.equal(parse(JSON.stringify({ ...reply, timeAdvance: 99 })).timeAdvance, 6);
  assert.equal(parse(JSON.stringify({ ...reply, timeAdvance: -2 })).timeAdvance, 0);
});
