import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFileSync } from 'node:fs';
import { OUTPUT_TARGET, outputTargetLines, webPromptBudget } from '../../www/token-budget.js';
import { normalizeStoryClock, realStoryClock, affectionStageOf, stageByKey, storyClockLabel } from '../../www/story-clock.js';
import { specialEventPromptLines } from '../../www/special-events.js';

const source = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');
const html = readFileSync(new URL('../../www/index.html', import.meta.url), 'utf8');
const rulesSource = readFileSync(new URL('../../www/prompt-rules.js', import.meta.url), 'utf8').replace(/^export /gm, '');
const worldBookSource = readFileSync(new URL('../../www/world-book.js', import.meta.url), 'utf8').replace(/^export /gm, '');

function slice(from, to) {
  const start = source.indexOf(from);
  assert.ok(start >= 0, `missing ${from}`);
  return source.slice(start, source.indexOf(to, start));
}
function constant(name) {
  const match = new RegExp(`const ${name}='([^\\n]*)';`).exec(source);
  assert.ok(match, `missing constant ${name}`);
  return match[1];
}

function buildPrompt({ mode = 'fast', provider = 'openai', language = 'zh', worldBook = undefined, authorNote = undefined, promptTweaks = undefined, action = '我走向她。' } = {}) {
  const code = [
    rulesSource,
    worldBookSource,
    slice('function compactWebPromptText(value, limit,', '\nfunction makeWebPrompt(action){'),
    slice('const WEB_AI_PROVIDERS=[', '\nconst WEB_AI_URL='),
    slice('function normalizeWebAIProvider(id){', '\nfunction webAIProviderName'),
    slice('function makeWebPrompt(action){', '\nfunction makeWebRepairPrompt'),
    `this.PROMPT = makeWebPrompt(${JSON.stringify(action)});`,
  ].join('\n');
  const sandbox = {
    Number, Math, JSON, String, Array, uiLanguage: language,
    DEFAULT_CHARACTER_NAME: 'Claude娘',
    DEFAULT_CHARACTER_PROFILE: '__R__', COMPACT_DEFAULT_CHARACTER_PROMPT: constant('COMPACT_DEFAULT_CHARACTER_PROMPT'),
    DEFAULT_WORLD_SETTING: '__R__', COMPACT_DEFAULT_WORLD_PROMPT: constant('COMPACT_DEFAULT_WORLD_PROMPT'),
    DEFAULT_STORY_TEMPLATE: '__R__', COMPACT_DEFAULT_RULES_PROMPT: constant('COMPACT_DEFAULT_RULES_PROMPT'),
    CUSTOM_OPENING_STYLE: '__custom__', openingStylePrompt: () => '', outputTargetLines, webPromptBudget,
    normalizeStoryClock, realStoryClock, affectionStageOf, stageByKey, storyClockLabel,
    specialEventPromptLines,
    state: {
      characterName: 'Claude娘', characterProfile: '__R__', worldSetting: '__R__', storyTemplate: '__R__',
      affection: 62, storyMemory: 'M'.repeat(2000),
      history: Array.from({ length: 10 }, (_, i) => ({ role: i % 2 ? 'ai' : 'user', text: `T${i}` + 'x'.repeat(700) })),
      responseMode: mode, webProvider: provider, openingStyle: 'x', openingCustomPrompt: '',
      worldBook, authorNote, promptTweaks,
    },
  };
  vm.createContext(sandbox);
  vm.runInContext(code, sandbox);
  return sandbox.PROMPT;
}

test('trimmed web prompt keeps the narration band, seven choices, persona and player action', () => {
  for (const [mode, provider] of [['fast', 'openai'], ['quality', 'openai'], ['fast', 'gemini']]) {
    const prompt = buildPrompt({ mode, provider });
    assert.ok(prompt.includes(`narration 每回合 ${OUTPUT_TARGET.narrationMin}～${OUTPUT_TARGET.narrationMax} 字`), `${mode}/${provider} keeps the narration band`);
    assert.ok(prompt.includes(`最多不要超過 ${OUTPUT_TARGET.narrationHard} 字`), `${mode}/${provider} caps the tail`);
    assert.ok(prompt.includes('恰好7個'), `${mode}/${provider} keeps seven choices`);
    assert.ok(prompt.includes(constant('COMPACT_DEFAULT_CHARACTER_PROMPT')), `${mode}/${provider} keeps persona text`);
    assert.ok(prompt.includes('不替玩家決定行動或想法'), `${mode}/${provider} keeps the global autonomy rule`);
    assert.ok(prompt.includes('玩家行動：我走向她。'), `${mode}/${provider} carries the player action`);
    assert.ok(prompt.includes('成年'), `${mode}/${provider} still states adulthood`);
    assert.ok(!prompt.includes('顏文字'), `${mode}/${provider} 已去除顏文字字樣`);
  }
});

test('trimmed web prompt: fast stays lighter than detailed and within a size guard', () => {
  const fast = buildPrompt({ mode: 'fast' }).length;
  const detailed = buildPrompt({ mode: 'quality' }).length;
  assert.ok(fast < detailed, 'fast prompt is shorter');
  // 護欄在 v4.4.0 各放寬約 100 字：新增的是「旁白字數區間＋選項長度上限＋記憶精簡成條列」，
  // 這幾行讓模型每回合少寫 100～500 字（輸出單價比輸入高好幾倍），是划算的交換。
  // 2026-10-18 E8b＋E12：COMPACT 依裁定同步口徑（「一點傲嬌」＋語氣輕柔簡短／少量顏文字／
  // 撒嬌語氣詞；護欄與立繪段不動），兩條護欄再各放寬 25 字並保留約 9 字餘裕，
  // 繼續攔住「非本次裁定以外」的意外膨脹。
  // 2026-10-19 批5 Ａ4：COMPACT 去除「少量顏文字」字樣（-6 字）；兩護欄同步下修 6 字、維持原餘裕。
  // v4.6.32 傲嬌強化：tone 規則與 COMPACT 合計增加約 46 字（更常嘴硬、端架子、否認在意），
  // 這是刻意的角色語氣調整；兩條護欄同步上調 50 字，其餘膨脹仍會被攔下。
  // v4.6.34 高冷追加：COMPACT 增加「氣質高冷」與「高冷是慢熟的保護色」，兩條護欄同步上調 20 字。
  // v4.6.34 人設改版：改為「表面冷靜、內在害羞」的新圖書館員，COMPACT 增加信念、誠實與 AI 提問說明，
  // 這是使用者指定的角色設定；兩條護欄同步上調 110 字，其餘膨脹仍會被攔下。
  // v4.6.34 高冷／傲嬌追加：COMPACT 補「帶傲嬌式嘴硬（越在意越否認、被看穿時先轉移話題）」（+25 字），
  // tone 規則補「傲嬌嘴硬」（+5 字），合計 +30 字；兩條護欄同步上調 30 字並保留 9 字餘裕。
  // G25：AI 情緒欄位需在 JSON 契約中註明五個允許值，提示詞護欄各增加 80 字。
  assert.ok(fast <= 2858, `fast prompt guard (got ${fast})`);
  assert.ok(detailed <= 3658, `detailed prompt guard (got ${detailed})`);
});

test('non-Gemini web prompt does not repeat memory guidance but Gemini keeps it', () => {
  assert.ok(!buildPrompt({ provider: 'openai' }).includes('留事件關係承諾伏筆'));
  assert.ok(buildPrompt({ provider: 'gemini' }).includes('留事件關係承諾伏筆'));
});

test('story quick controls: every id used by the new code exists in index.html', () => {
  const ids = ['responseModeBtn', 'storyEditBtn', 'storyEditDialog', 'storyEditName', 'storyEditProfile', 'storyEditWorld',
    'storyEditRules', 'storyEditStatus', 'storyEditSaveBtn', 'storyEditCancelBtn', 'storyEditResetBtn', 'storyEditAdvancedBtn',
    'sceneImageBtn', 'importSceneImageBtn', 'sceneImageFile', 'responseMode', 'promptMode', 'promptModeBtn'];
  for (const id of ids) {
    assert.ok(html.includes(`id="${id}"`), `index.html has #${id}`);
    assert.ok(source.includes(`$('${id}')`), `app.js uses #${id}`);
  }
});

test('story quick controls: toggle reuses the settings handler and render refreshes the label', () => {
  assert.match(source, /\$\('responseMode'\)\.value=next;\s*\$\('responseMode'\)\.onchange\(\);/);
  assert.match(source, /renderStoryQuickControls\(\);\s*\[\s*'restartBtn'/, 'label refresh runs before the busy early return');
  assert.match(source, /'responseModeBtn','promptModeBtn'\]\.forEach/, 'both quick toggles are disabled while a turn is in flight');
  assert.match(source, /fillWorkshopSettings\(\);\s*render\(\);\s*closeStoryEditDialog\(\)/, 'dialog save keeps the workshop form in sync');
});

test('prompt mode toggle is wired in the toolbar, the settings page and the pending web panel', () => {
  // 工具列按鈕 → 共用同一個 setPromptMode：存檔、同步選單、回報字元數。
  assert.match(source, /\$\('promptModeBtn'\)\.onclick=togglePromptMode;/);
  assert.match(source, /\$\('promptMode'\)\.onchange=\(\)=>setPromptMode\(\$\('promptMode'\)\.value\);/);
  assert.match(source, /function setPromptMode\(next\) \{[\s\S]*?if\(!save\(\)\) return;/);
  assert.match(source, /function togglePromptMode\(\) \{\s*if\(busy\) return;/);
  assert.match(source, /const promptModeSelect=\$\('promptMode'\); if\(promptModeSelect\) promptModeSelect\.value = state\.promptMode === 'saving' \? 'saving' : 'standard';/);
  assert.match(source, /pendingPromptMode\.onchange=\(\)=>setPromptMode\(pendingPromptMode\.value\);/);
  assert.match(source, /function renderStoryQuickControls\(\)[\s\S]*?promptButton\.setAttribute\('aria-pressed',String\(saving\)\);/);
  // 狀態列訊息必須在 render() 之後寫，不然會立刻被 render() 重設成預設文字（同 toggleResponseMode 的做法）。
  assert.match(source, /function setPromptMode\(next\) \{[\s\S]*?render\(\);\s*\/\/ 狀態列訊息[\s\S]*?\$\('sceneImageStatus'\)\.textContent=/, 'the size report is written after render so the user can see it');
});

test('story quick controls: every new UI string has an English entry and no duplicate keys', () => {
  const keys = [...source.matchAll(/^  '([^'\n]+)': /gm)].map(m => m[1]);
  const seen = new Set(), dup = [];
  for (const k of keys) { if (seen.has(k)) dup.push(k); seen.add(k); }
  assert.deepEqual(dup, [], 'UI_EN has no duplicate keys');
  for (const k of ['⚡ 快速回覆', '✦ 詳細回覆', '✎ 人設／世界觀', '編輯人設與世界觀', '儲存並套用', '恢復預設', '進階設定（創意工坊）',
    '設定已保存到目前存檔，下一回合起套用。', '✧ 插圖提示詞', '🖼 匯入插圖', '拖入的檔案不是圖片。', '已切換為「文字＋插圖」顯示，圖片已加入目前場景。',
    '提示詞模式', '選擇提示詞精簡程度', '標準（完整規則，回覆最穩）', '⚡ 節省模式（輸入約少一半，輸出格式不變）',
    '標準（完整規則）', '⚡ 節省模式（輸入約少一半）', '✂ 提示詞：標準', '✂ 提示詞：節省',
    '點一下切換：標準／節省模式（網頁提示詞較短、省輸入額度；正文長度與七個選項不變）']) {
    assert.ok(seen.has(k), `English entry for ${k}`);
  }
});

test('story toolbar is grouped by purpose and keeps every control id', () => {
  for (const group of ['tool-group-story', 'tool-group-slot', 'tool-group-scene', 'tool-group-tune']) {
    assert.ok(html.includes(`tool-group ${group}`), `toolbar group ${group}`);
  }
  for (const id of ['storyLogBtn', 'promptHistoryBtn', 'saveStoryBtn', 'storySlotPicker', 'deleteStorySlotBtn', 'storyTextShrinkBtn', 'storyTextGrowBtn']) {
    assert.ok(html.includes(`id="${id}"`), `toolbar keeps #${id}`);
  }
  assert.ok(!source.includes('匯入已生成插圖」。網站額度'), 'status message no longer points at the old button label');
});

test('世界書／作者註記／提示詞管理器：對實際組裝出的網頁提示詞生效；未使用＝零追加行', () => {
  const base = buildPrompt();
  const off = buildPrompt({ worldBook: { enabled: false, entries: [{ keywords: ['她'], text: '設定', enabled: true }] },
    authorNote: { enabled: false, text: '多寫雨聲' }, promptTweaks: { rulesOff: [], extra: '' } });
  assert.equal(off, base, '關閉／空設定＝提示詞逐字元相同');

  const hit = buildPrompt({ worldBook: { enabled: true, entries: [{ keywords: ['她'], text: '她是圖書館守護者。', enabled: true }] } });
  assert.ok(hit.includes('世界書（命中關鍵詞，僅供參考）：'), '命中＝注入標頭');
  assert.ok(hit.includes('她是圖書館守護者。'), '命中＝注入文字');
  assert.ok(hit.indexOf('世界書（命中關鍵詞') > hit.indexOf('近期對話：'), '世界書在近期對話之後');
  const miss = buildPrompt({ worldBook: { enabled: true, entries: [{ keywords: ['不存在'], text: '不該出現', enabled: true }] } });
  assert.ok(!miss.includes('世界書'), '未命中＝零追加行');

  const tweaks = buildPrompt({ promptTweaks: { rulesOff: ['tone', 'choices'], extra: '少用成語' }, authorNote: { enabled: true, text: '多描寫雨聲' } });
  assert.ok(!tweaks.includes('語氣隨好感漸變'), '關掉的規則不出現在實際提示詞');
  assert.ok(tweaks.includes('補充指示：少用成語'));
  assert.ok(tweaks.indexOf('作者註記（') > tweaks.indexOf('玩家行動：'), '作者註記在玩家行動之後');
});
