import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { parse, requestSystemInstruction } from '../../server/server.js';
import { evaluateModelCheck } from '../../www/model-check.js';

const choices = ['陪她喝茶', '問起窗外的雨', '一起整理書架', '看她手上的書', '點亮桌燈', '談談今晚的音樂', '安靜坐在一旁'];
const base = { narration: '她接過熱茶，露出笑容。', affectionDelta: 1, choices, ending: false, endingText: null, memory: '雨夜喝茶。' };
const app = readFileSync(new URL('../../www/app.js', import.meta.url), 'utf8');
const anim = readFileSync(new URL('../../www/portrait-anim.js', import.meta.url), 'utf8');
const css = readFileSync(new URL('../../www/style.css', import.meta.url), 'utf8');

test('故事回覆情緒契約：提示詞列出情緒值，API parser 保留有效值並相容舊回覆', () => {
  const prompt = requestSystemInstruction({ language: 'zh' });
  assert.match(prompt, /欄位：narration、affectionDelta、choices、ending、endingText、memory、emotion/);
  assert.match(prompt, /neutral、happy、shy、surprised、dizzy、curious/);
  assert.match(prompt, /不能只按 affectionDelta 推測/);
  assert.equal(parse(JSON.stringify({ ...base, emotion: 'shy' })).emotion, 'shy');
  assert.equal(parse(JSON.stringify({ ...base, emotion: 'curious' })).emotion, 'curious');
  assert.equal(parse(JSON.stringify(base)).emotion, 'neutral', '舊版 API 回覆缺欄位時預設 neutral');
  assert.equal(parse(JSON.stringify({ ...base, emotion: 'angry' })).emotion, 'neutral', '未知情緒值安全回退 neutral');
});

test('模型相容性檢查：emotion 是必備的新 JSON 欄位', () => {
  const reply = { ...base, emotion: 'happy' };
  assert.equal(evaluateModelCheck(reply).ok, true);
  const missing = evaluateModelCheck(base);
  assert.equal(missing.ok, false);
  assert.equal(missing.checks.find(item => item.key === 'emotion').ok, false);
});

test('故事情緒存入存檔並驅動立繪表情窗；舊存檔仍回退 neutral', () => {
  assert.match(app, /function normalizeStoryEmotion\(value\)/);
  assert.match(app, /storyEmotion: normalizeStoryEmotion\(rawState\.storyEmotion\)/);
  assert.match(app, /state\.storyEmotion=\['neutral','happy','shy','surprised','dizzy','curious'\]\.includes/);
  assert.match(app, /window\.__portraitAnim\?\.setStoryEmotion\?\.\(window\.__storyEmotion\)/);
  assert.match(anim, /function setStoryEmotion\(value\)/);
  assert.match(anim, /emotion === 'shy' \? 'pat' : emotion === 'curious' \? 'curious' : emotion/);
  assert.match(anim, /emotion === 'curious' \? 'curious'/);
  assert.match(css, /\.pa-face\.pa-curious::after/);
  assert.match(anim, /classList\.add\('pa-story-emotion'\)/);
  assert.match(css, /\.pa-face\.pa-story-emotion\{opacity:1;scale:1;animation:none\}/);
});
