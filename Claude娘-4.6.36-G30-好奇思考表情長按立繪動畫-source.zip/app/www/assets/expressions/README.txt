表情窗素材（assets/expressions）
================================
用途：點擊立繪時，在角色頭旁邊彈出的圓形「表情窗」（portrait-anim.js 的 G21.4）。
  pat.webp       摸頭   → 害羞（閉眼、臉紅）
  happy.webp     碰髮絲 → 開心
  surprised.webp 戳身體／碰裙擺 → 驚訝
  dizzy.webp     短時間連點 → 暈頭轉向

來源：claude-xiaoke（https://github.com/blackshoretuner/claude-xiaoke）的 art/ 資料夾，原檔未修改（520×488 WebP）。
角色形象原作者：ZipZipPipe（依該專案 ART-NOTICE.md 的說明；表情差分是該專案作者以 AI 編輯產生）。

授權狀態（請務必讀）：
  · 該專案的 LICENSE（MIT）只涵蓋程式碼，並明寫這些圖片「不在範圍內」；ART-NOTICE.md 要求轉用於其他作品前先取得原作者授權。
  · 使用者（本專案作者）表示：原作立繪為 CC 授權，且已在本專案標註。
  · 我（產生這個版本的 AI）無法驗證該 CC 授權的實際條款。請確認它涵蓋「使用／散布修改過的版本」
    （例如是否為 BY-NC、ND 之類的限制），以及隨安裝包散布是否允許。

要移除這個功能：直接刪掉整個 assets/expressions 資料夾即可。程式偵測到圖片載入失敗時會自動停用表情窗，
其餘觸碰動畫（反應、壓扁、愛心、漣漪）不受影響。
